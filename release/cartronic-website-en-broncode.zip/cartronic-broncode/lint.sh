#!/bin/sh
# Lints the application script exactly as build.mjs concatenates it.
cd "$(dirname "$0")"
node -e "
const fs=require('fs');const order=fs.readFileSync('build.mjs','utf8').match(/const js = \[([^\]]+)\]/)[1].match(/'([^']+)'/g).map(s=>s.slice(1,-1));
fs.writeFileSync('app.js','(function () {\n\'use strict\';\n'+order.map(f=>fs.readFileSync('src/'+f,'utf8')).join('\n')+'\n})();\n');"
NODE_PATH=/opt/node22/lib/node_modules node /opt/node22/lib/node_modules/eslint/bin/eslint.js -c eslint.config.mjs app.js
