/* =====================================================================
   MOTION — GSAP + ScrollTrigger
   Restrained, transform/opacity only. Disabled for prefers-reduced-motion and
   whenever the library cannot be loaded; content is always visible without it.
   ===================================================================== */
const Motion = {
  g: null,
  ctx: null,
  bootAt: (typeof performance !== 'undefined' ? performance.now() : 0),
  async init() {
    if (reducedMotion()) { document.documentElement.classList.add('no-motion'); return; }
    try { await window.__ctMotionReady; } catch (e) { document.documentElement.classList.add('no-motion'); return; }
    if (!window.gsap || !window.ScrollTrigger) { document.documentElement.classList.add('no-motion'); return; }
    window.gsap.registerPlugin(window.ScrollTrigger);
    window.gsap.defaults({ ease: 'power3.out', duration: 0.8 });
    this.g = window.gsap;
    // If the library arrives after the first paint, never hide content that is already visible.
    const late = performance.now() - this.bootAt > 700;
    this.page($('#app'), { late });
  },
  get on() { return !!this.g && !reducedMotion(); },
  cleanup() { if (this.ctx) { this.ctx.revert(); this.ctx = null; } },
  inView(el) { const r = el.getBoundingClientRect(); return r.top < window.innerHeight && r.bottom > 0; },
  page(root, { late = false } = {}) {
    if (!this.on || !root) return;
    this.cleanup();
    const g = this.g; const ST = window.ScrollTrigger;
    const skip = (el) => late && this.inView(el);
    this.ctx = g.context(() => {
      const hero = root.querySelector('[data-hero]');
      if (hero) {
        const img = hero.querySelector('.hero-media img');
        if (!late) {
          const tl = g.timeline();
          if (img) tl.from(img, { scale: 1.06, opacity: 0, duration: 1.6, ease: 'power2.out' }, 0);
          tl.from(hero.querySelectorAll('[data-hero-line]'), { yPercent: 35, opacity: 0, duration: 1, stagger: 0.12 }, 0.12)
            .from(hero.querySelectorAll('[data-hero-item]'), { y: 14, opacity: 0, duration: 0.8, stagger: 0.07 }, 0.32);
        }
        if (img) g.to(img, { yPercent: 5, ease: 'none', scrollTrigger: { trigger: hero, start: 'top top', end: 'bottom top', scrub: true } });
      }
      root.querySelectorAll('.page-header h1').forEach((h) => { if (!skip(h)) g.from(h, { y: 16, opacity: 0, duration: 0.8, delay: 0.05 }); });
      root.querySelectorAll('[data-split], [data-reveal]').forEach((el) => {
        if (skip(el) || el.closest('.page-header')) return;
        g.from(el, { y: el.hasAttribute('data-split') ? 26 : 18, opacity: 0, duration: 0.85, scrollTrigger: { trigger: el, start: 'top 90%', once: true } });
      });
      root.querySelectorAll('[data-stagger]').forEach((grp) => {
        const kids = Array.from(grp.children).filter((k) => !k.hidden);
        if (!kids.length || skip(grp)) return;
        g.from(kids, { y: 24, opacity: 0, duration: 0.7, stagger: 0.07, scrollTrigger: { trigger: grp, start: 'top 90%', once: true } });
      });
      root.querySelectorAll('[data-mask]').forEach((el) => {
        if (skip(el)) return;
        g.from(el, { clipPath: 'inset(0% 0% 100% 0%)', duration: 1.1, ease: 'power3.inOut', scrollTrigger: { trigger: el, start: 'top 88%', once: true } });
        const img = el.querySelector('img');
        if (img) g.from(img, { scale: 1.1, duration: 1.5, ease: 'power2.out', scrollTrigger: { trigger: el, start: 'top 88%', once: true } });
      });
      root.querySelectorAll('.eyebrow--line').forEach((el) => { if (!skip(el) && !el.closest('[data-hero]')) g.from(el, { opacity: 0, x: -10, duration: 0.6, scrollTrigger: { trigger: el, start: 'top 92%', once: true } }); });
      const seq = root.querySelector('[data-sequence]');
      if (seq) {
        const bar = seq.querySelector('.steps-progress');
        if (bar) g.fromTo(bar, { scaleY: 0 }, { scaleY: 1, ease: 'none', scrollTrigger: { trigger: seq, start: 'top 72%', end: 'bottom 62%', scrub: 0.4 } });
        seq.querySelectorAll('.step').forEach((step) => {
          ST.create({ trigger: step, start: 'top 74%', onEnter: () => step.classList.add('is-active'), onLeaveBack: () => step.classList.remove('is-active') });
          if (!skip(step)) g.from(step.querySelectorAll('h3, p, .step-tag'), { y: 14, opacity: 0, duration: 0.7, stagger: 0.06, scrollTrigger: { trigger: step, start: 'top 86%', once: true } });
        });
      }
    }, root);
    // ScrollTrigger.refresh can move the window to a position it remembered from the previous page: keep ours.
    requestAnimationFrame(() => { const y = window.scrollY; ST.refresh(); if (Math.abs(window.scrollY - y) > 1) window.scrollTo(0, y); });
  },
  /** Short entrance for re-rendered lists (filters). */
  swap(container, selector) {
    if (!container) return;
    this.enter(Array.from(selector ? container.querySelectorAll(selector) : container.children));
  },
  enter(els) {
    if (!this.on || !els || !els.length) return;
    this.g.fromTo(els, { opacity: 0, y: 10 }, { opacity: 1, y: 0, duration: 0.38, stagger: 0.035, ease: 'power2.out', overwrite: true, clearProps: 'transform,opacity' });
    const y = window.scrollY; window.ScrollTrigger.refresh(); if (Math.abs(window.scrollY - y) > 1) window.scrollTo(0, y);
  },
  vehicleFound(el) {
    if (!el || !this.on) return;
    this.g.fromTo(el, { opacity: 0, y: 10, scale: 0.985 }, { opacity: 1, y: 0, scale: 1, duration: 0.5, ease: 'power3.out', clearProps: 'transform,opacity' });
  },
};
