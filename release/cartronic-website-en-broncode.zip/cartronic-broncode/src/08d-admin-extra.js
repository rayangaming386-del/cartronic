/* =====================================================================
   ADMIN — Meer van ons werk, Storingen, Beveiliging, Video's, Merken & modellen, Account
   Everything is saved in the website draft (Content.update) and published with the website.
   ===================================================================== */

/* ---------- Photos: upload (compressed in the browser), replace, remove, order, alt text ---------- */
const PHOTO_MAX_SIDE = 1600;
const PHOTO_MAX_BYTES = 900 * 1024; // per photo after compression; keeps the browser storage usable
/** A photo file → a WebP (or JPEG where WebP is not supported) data URL of at most 1600 px. */
async function compressPhoto(file) {
  const ALLOWED = ['image/png', 'image/jpeg', 'image/webp'];
  if (!file || !ALLOWED.includes(file.type)) throw new Error('Kies een JPG-, PNG- of WebP-foto.');
  if (file.size > 25 * 1024 * 1024) throw new Error('Deze foto is groter dan 25 MB. Kies een kleinere foto.');
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('Deze foto kon niet worden gelezen.')); i.src = url; });
    let side = PHOTO_MAX_SIDE; let out = '';
    for (const q of [0.82, 0.72, 0.62]) {
      const scale = Math.min(1, side / Math.max(img.naturalWidth, img.naturalHeight));
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(img.naturalWidth * scale)); c.height = Math.max(1, Math.round(img.naturalHeight * scale));
      const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
      out = c.toDataURL('image/webp', q);
      if (!out.startsWith('data:image/webp')) out = c.toDataURL('image/jpeg', q + 0.04);
      if (out.length * 0.75 <= PHOTO_MAX_BYTES) return out;
      side = Math.round(side * 0.8);
    }
    return out;
  } finally { URL.revokeObjectURL(url); }
}
const photoItem = (ph) => `<div class="photo-item">
    <div class="photo-thumb">${Media.html(ph.src, '', { kind: 'camera' })}</div>
    <input type="hidden" data-ph-src value="${attr(ph.src)}">
    <div class="photo-fields">
      <label class="field"><span class="label">Beschrijving (alt-tekst)</span><input class="input input--sm" data-ph-alt value="${attr(ph.alt || '')}" maxlength="${Content.LIMITS.alt}"></label>
      <div class="photo-actions">
        <label class="btn btn--light btn--xs photo-replace">${icon('refresh')} Vervangen<input type="file" accept="image/png,image/jpeg,image/webp" data-ph-replace class="sr-only"></label>
        <button class="icon-btn icon-btn--sm" type="button" data-ph-up aria-label="Foto naar voren">${icon('left')}</button>
        <button class="icon-btn icon-btn--sm" type="button" data-ph-down aria-label="Foto naar achteren">${icon('right')}</button>
        <button class="icon-btn icon-btn--sm" type="button" data-ph-del aria-label="Foto verwijderen">${icon('trash')}</button>
      </div>
    </div>
  </div>`;
/** A list of photos. name: form key; max: number of photos; alt: default description for new photos. */
function photoField(name, photos, { label = 'Foto’s', max = 8, alt = '', hint = '' } = {}) {
  return `<div class="field span-2 photo-field" data-photos="${attr(name)}" data-max="${max}" data-alt="${attr(alt)}">
    <span class="label">${esc(label)}</span>
    <div class="photo-items" data-ph-items>${(photos || []).map(photoItem).join('')}</div>
    <div class="photo-add"${(photos || []).length >= max ? ' hidden' : ''} data-ph-addwrap>
      <label class="btn btn--light btn--sm">${icon('upload')} ${max === 1 ? 'Foto uploaden' : 'Foto’s uploaden'}<input type="file" accept="image/png,image/jpeg,image/webp"${max > 1 ? ' multiple' : ''} data-ph-add class="sr-only"></label>
      <span class="hint">JPG, PNG of WebP. Wordt verkleind tot ${PHOTO_MAX_SIDE} px${max > 1 ? `; maximaal ${max} foto’s` : ''}.</span>
    </div>
    ${hint ? `<span class="hint">${hint}</span>` : ''}
    <span class="field-error" data-err="${attr(name)}"></span>
  </div>`;
}
function mountPhotoFields(root, onChange) {
  $$('[data-photos]', root).forEach((box) => {
    const items = $('[data-ph-items]', box); const max = Number(box.dataset.max) || 1;
    const sync = () => { $('[data-ph-addwrap]', box).hidden = items.children.length >= max; onChange(); };
    const add = async (files) => {
      let added = 0;
      for (const file of files) {
        if (items.children.length >= max) { Toast.show(`Maximaal ${max} ${max === 1 ? 'foto' : 'foto’s'}.`, { error: true }); break; }
        try {
          const src = await compressPhoto(file);
          items.insertAdjacentHTML('beforeend', photoItem({ src, alt: box.dataset.alt || '' }));
          added += 1;
        } catch (er) { Toast.show(er.message, { error: true }); }
      }
      if (!added) return; // nothing changed
      sync();
      Toast.show(added === 1 ? 'Foto toegevoegd. Controleer de beschrijving en klik op opslaan.' : `${added} foto’s toegevoegd. Controleer de beschrijvingen en klik op opslaan.`);
      const last = $$('[data-ph-alt]', items).pop(); if (last) last.focus();
    };
    box.addEventListener('change', async (e) => {
      if (e.target.matches('[data-ph-add]')) { const files = [...e.target.files]; e.target.value = ''; if (files.length) await add(files); return; }
      if (e.target.matches('[data-ph-replace]')) {
        const file = e.target.files[0]; const item = e.target.closest('.photo-item'); e.target.value = '';
        if (!file) return;
        try {
          const src = await compressPhoto(file);
          $('[data-ph-src]', item).value = src;
          $('.photo-thumb', item).innerHTML = Media.html(src, '', { kind: 'camera' });
          onChange(); Toast.show('Foto vervangen. Klik op opslaan.');
        } catch (er) { Toast.show(er.message, { error: true }); }
      }
    });
    box.addEventListener('click', (e) => {
      const item = e.target.closest('.photo-item'); if (!item) return;
      if (e.target.closest('[data-ph-del]')) { item.remove(); sync(); const b = $('[data-ph-add]', box); if (b) b.closest('label').focus(); return; }
      if (e.target.closest('[data-ph-up]') && item.previousElementSibling) { items.insertBefore(item, item.previousElementSibling); onChange(); return; }
      if (e.target.closest('[data-ph-down]') && item.nextElementSibling) { items.insertBefore(item.nextElementSibling, item); onChange(); }
    });
  });
}
/** The photos of a photo field: [{ src, alt }]. */
const photosOf = (box) => (box ? $$('.photo-item', box).map((it) => ({ src: $('[data-ph-src]', it).value, alt: $('[data-ph-alt]', it).value.trim() })) : []);
const photoError = (photos) => (photos.some((p) => !p.alt) ? 'Geef elke foto een korte beschrijving (alt-tekst), bijvoorbeeld wat er op de foto te zien is.' : '');

/* ---------- Headings and introduction of a public page (editable texts) ---------- */
function textsPanel(keys, { title = 'Koppen en introductie', page = '' } = {}) {
  const texts = Content.texts();
  return `<form data-texts-panel novalidate><section class="panel"><div class="panel-head"><div><h2>${esc(title)}</h2><p>Leeg = standaardtekst</p></div>${page ? `<a class="btn btn--light btn--sm" href="#${attr(page)}" target="_blank" rel="noopener">${icon('external')} Bekijk pagina</a>` : ''}</div>
    <div class="panel-body"><div class="form-grid">${keys.map((k) => {
      const d = TEXT[k]; const v = typeof texts[k] === 'string' ? texts[k] : d.def;
      return saField({ name: `t:${k}`, label: d.label, value: v, multi: !!(d.multi || v.includes('\n') || v.length > 90), rows: 2, max: 2000, opt: !!d.optional });
    }).join('')}</div></div>${saveBar('Teksten opslaan', '', { inline: true })}</section></form>`;
}
/** Writes the text fields of a form (t:<key>) into a draft, as Beheer → Teksten does. */
function putTexts(d, form, keys) {
  const texts = { ...(isObj(d.texts) ? d.texts : {}) };
  keys.forEach((k) => {
    const el = form.elements[`t:${k}`]; if (!el) return;
    const val = el.value.replace(/\r\n/g, '\n').trim(); const def = TEXT[k];
    delete texts[k];
    if (!val) { if (def.optional) texts[k] = ''; return; }
    if (val !== def.def.trim()) texts[k] = val;
  });
  d.texts = texts;
}
function mountTextsPanel(root, keys) {
  const f = $('[data-texts-panel]', root); if (!f) return null;
  const st = trackDirty(f);
  const shown = () => keys.map((k) => f.elements[`t:${k}`].value);
  let before = shown();
  f.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!showErrors(f, {})) return;
    const now = shown(); const changed = keys.filter((k, i) => now[i] !== before[i]);
    if (saveContent((d) => putTexts(d, f, changed), 'Teksten opgeslagen.')) { st.set(false); before = now; }
  });
  return () => Router.setGuard(null);
}

/* ---------- Meer van ons werk (Portfolio page) ---------- */
const WORK_TEXTS = ['projects.more.eyebrow', 'projects.more.title', 'projects.more.intro'];
const workRow = (m = {}) => `<div class="row-edit row-edit--card">
  <div class="form-grid">
    <label class="field span-2"><span class="label">Titel</span><input class="input input--sm" data-w="title" value="${attr(m.title || '')}" maxlength="${Content.LIMITS.workTitle}"></label>
    <label class="field span-2"><span class="label">Tekst <span class="opt">(optioneel)</span></span><textarea class="textarea textarea--sm" data-w="text" rows="2">${esc(m.text || '')}</textarea></label>
    <label class="field span-2"><span class="label">Links <span class="opt">(optioneel)</span></span><textarea class="textarea textarea--sm" data-w="links" rows="2">${esc(linksText((m.links || []).map(([l, h]) => [l, h.replace(/^#/, '')])))}</textarea><span class="hint">Eén per regel (maximaal 4): <code class="code">Linktekst | https://…</code> of <code class="code">Linktekst | /portfolio</code></span></label>
    ${photoField('photo', m.photo ? [m.photo] : [], { label: 'Foto', max: 1, alt: m.title || '' })}
  </div>
  <div class="row-edit-actions"><button class="icon-btn icon-btn--sm" type="button" data-row-up aria-label="Kaart omhoog">${icon('left').replace('<svg', '<svg style="transform:rotate(90deg)"')}</button><button class="icon-btn icon-btn--sm" type="button" data-row-down aria-label="Kaart omlaag">${icon('right').replace('<svg', '<svg style="transform:rotate(90deg)"')}</button><button class="icon-btn icon-btn--sm" type="button" data-row-del aria-label="Kaart verwijderen">${icon('trash')}</button></div>
</div>`;
Pages.adminMoreWork = adminPage({
  key: 'meer-werk', title: 'Meer van ons werk',
  render() {
    const texts = Content.texts();
    return `<form data-work novalidate>
      ${UI.notice('Dit blok staat op de pagina Portfolio onder de projecten. Kaarten kunnen een foto, tekst en links hebben (bijvoorbeeld naar foto’s of video’s op Facebook). Zonder kaarten verdwijnt het blok.', { ic: 'info' })}
      <section class="panel"><div class="panel-head"><div><h2>Kop en introductie</h2><p>Leeg = standaardtekst</p></div><a class="btn btn--light btn--sm" href="#/portfolio" target="_blank" rel="noopener">${icon('external')} Bekijk pagina</a></div>
        <div class="panel-body"><div class="form-grid">${WORK_TEXTS.map((k) => saField({ name: `t:${k}`, label: TEXT[k].label, value: typeof texts[k] === 'string' ? texts[k] : TEXT[k].def, multi: k.endsWith('intro'), rows: 2, max: 600, opt: !!TEXT[k].optional })).join('')}</div></div></section>
      <section class="panel"><div class="panel-head"><div><h2>Kaarten</h2><p>Volgorde = volgorde op de website</p></div><button class="btn btn--light btn--sm" type="button" data-w-add>${icon('plus')} Kaart toevoegen</button></div>
        <div class="panel-body"><div class="rows-editor" data-w-rows>${MORE_WORK.map(workRow).join('')}</div>
        <p class="hint mt-16" data-w-empty${MORE_WORK.length ? ' hidden' : ''}>Nog geen kaarten. Het blok staat nu niet op de website.</p></div></section>
      ${saveBar()}
    </form>`;
  },
  mount(root) {
    const f = $('[data-work]', root);
    const st = trackDirty(f);
    const rows = $('[data-w-rows]', f);
    const changed = () => { st.set(true); $('[data-w-empty]', f).hidden = !!rows.children.length; };
    bindRowEditor(rows, workRow, changed);
    mountPhotoFields(rows, changed);
    $('[data-w-add]', f).addEventListener('click', () => {
      rows.insertAdjacentHTML('beforeend', workRow());
      mountPhotoFields(rows.lastElementChild, changed); changed();
      $$('.row-edit', rows).pop().querySelector('input').focus();
    });
    const raw = () => ({ texts: WORK_TEXTS.map((k) => f.elements[`t:${k}`].value), rows: $$('.row-edit', rows).map((row) => [...['title', 'text', 'links'].map((k) => $(`[data-w="${k}"]`, row).value.trim()), photosOf($('[data-photos]', row))]) });
    let shown = raw();
    const listNow = () => stableStringify(MORE_WORK); // kept up to date when another tab saves
    let base = listNow();
    f.addEventListener('submit', (e) => {
      e.preventDefault();
      let bad = '';
      const L = Content.LIMITS;
      const items = $$('.row-edit', rows).map((row) => {
        const g = (k) => $(`[data-w="${k}"]`, row).value.trim();
        const links = parseLinks(g('links'));
        const photo = photosOf($('[data-photos]', row))[0];
        if (!g('title')) bad = 'Elke kaart heeft een titel nodig.';
        else if (g('title').length > L.workTitle) bad = `Een titel mag maximaal ${L.workTitle} tekens hebben.`;
        if (g('text').length > L.workText) bad = `De tekst van een kaart mag maximaal ${L.workText} tekens hebben.`;
        if (!links) bad = 'Schrijf elke link als “Linktekst | https://…” of “Linktekst | /pagina”.';
        else if (links.length > 4) bad = 'Gebruik maximaal 4 links per kaart.';
        else if (linkLabelError(links)) bad = linkLabelError(links);
        if (photo && !photo.alt) bad = 'Geef elke foto een korte beschrijving (alt-tekst).';
        const out = { title: g('title'), text: g('text'), links: links || [] };
        if (photo) out.photo = photo;
        return out;
      });
      if (items.length > L.workItems) bad = `Gebruik maximaal ${L.workItems} kaarten.`;
      if (bad) { Toast.show(bad, { error: true }); return; }
      if (!showErrors(f, {})) return;
      const next = raw();
      const listChanged = stableStringify(next.rows) !== stableStringify(shown.rows);
      // The cards are one list: if another tab saved it meanwhile, saving here would undo that.
      if (listChanged && listNow() !== base) { Toast.show('Deze kaarten zijn intussen in een ander tabblad gewijzigd. Laad de pagina opnieuw en voer uw wijziging opnieuw in.', { error: true }); return; }
      const textChanged = WORK_TEXTS.filter((k, i) => next.texts[i] !== shown.texts[i]);
      if (saveContent((d) => { if (listChanged) d.moreWork = items; putTexts(d, f, textChanged); }, 'Opgeslagen.')) { st.set(false); shown = next; base = listNow(); }
    });
    return () => Router.setGuard(null);
  },
});

/* ---------- Storingen ---------- */
const STOR_TEXTS = ['stor.eyebrow', 'stor.title', 'stor.lead', 'stor.note', 'stor.symptoms', 'stor.cause', 'stor.solution', 'stor.cta.title', 'stor.cta.text'];
const storeStoringen = (list, msg) => saveContent((d) => { d.storingen = list; }, msg);
Pages.adminStoringen = orderedListPage({
  key: 'storingen', title: 'Storingen', newLabel: 'Nieuwe storing', base: 'storingen',
  note: 'Storingen staan op de pagina Storingen & oplossingen, elk met een eigen pagina. Verborgen storingen staan niet op de website en niet in de sitemap.',
  items: () => STORINGEN, store: storeStoringen,
  rowHtml: (x) => `<div class="prod"><div class="thumb">${x.photos.length ? Media.html(x.photos[0].src, '', { kind: x.art }) : Art.html(x.art, 0, '')}</div><div><a class="p-name text-link" href="#/admin/storingen/${attr(x.slug)}">${esc(x.title)}</a><div class="p-sub">${esc(x.brand ? BRAND[x.brand].name : 'Alle merken')} · /storingen/${esc(x.slug)} · ${plural(x.photos.length, 'foto', 'foto’s')}${x.visible ? '' : ' · <span class="pill">Verborgen</span>'}</div></div></div>`,
  top: () => textsPanel(STOR_TEXTS, { page: '/storingen' }),
  mountTop: (root) => mountTextsPanel(root, STOR_TEXTS),
});
Pages.adminStoringForm = adminPage({
  key: 'storingen', title: 'Storing',
  heading: (ctx) => (ctx.params.slug ? 'Storing bewerken' : 'Nieuwe storing'),
  render(ctx) {
    const isNew = !ctx.params.slug;
    const x = isNew ? { slug: '', title: '', brand: '', models: [], symptoms: [], cause: '', solution: '', art: 'module', photos: [], service: '', retrofit: '', visible: true } : STORINGEN.find((y) => y.slug === ctx.params.slug);
    if (!x) return UI.empty({ icon: 'activity', title: 'Storing niet gevonden', actions: '<a class="btn btn--dark btn--sm" href="#/admin/storingen">Alle storingen</a>' });
    const path = isNew ? '' : `/storingen/${x.slug}`;
    const ART_LABELS = { module: 'Module', assist: 'Rijhulpsysteem', camera: 'Camera', sensor: 'Sensor', connect: 'Multimedia', cockpit: 'Cockpit', gauge: 'Instrumenten', mirror: 'Spiegel', light: 'Verlichting', alarm: 'Alarm', key: 'Sleutel', nav: 'Navigatie', wheel: 'Stuur', box: 'Onderdeel' };
    return `<p><a class="link link--ink" href="#/admin/storingen">${icon('arrowLeft')} Alle storingen</a></p>
      <form data-stor-form novalidate data-new="${isNew}" data-slug="${attr(x.slug)}"><div class="form-layout">
        <div class="form-col">
          <section class="panel"><div class="panel-head"><div><h2>Storing</h2></div>${isNew ? '' : `<a class="btn btn--light btn--sm" href="#${attr(path)}" target="_blank" rel="noopener">${icon('external')} Bekijk</a>`}</div><div class="panel-body"><div class="form-grid">
            ${saField({ name: 'title', label: 'Titel', value: x.title, max: Content.LIMITS.storingTitle, placeholder: 'Bijv. Parkeersensoren piepen continu' })}
            ${isNew ? saField({ name: 'slug', label: 'Webadres (slug)', value: '', max: 120, placeholder: 'wordt gemaakt van de titel', hint: '/storingen/<strong>…</strong> — kan later niet worden gewijzigd.' }) : ''}
            ${saField({ name: 'symptoms', label: 'Symptomen', value: x.symptoms.join('\n'), multi: true, rows: 4, hint: `Eén symptoom per regel, maximaal ${Content.LIMITS.storingSymptoms}.` })}
            ${saField({ name: 'cause', label: 'Mogelijke oorzaak', value: x.cause, multi: true, rows: 4, max: Content.LIMITS.storingText })}
            ${saField({ name: 'solution', label: 'Oplossing', value: x.solution, multi: true, rows: 4, max: Content.LIMITS.storingText })}
          </div></div></section>
          <section class="panel"><div class="panel-head"><div><h2>Foto’s</h2><p>Zonder foto toont de website een illustratie</p></div></div><div class="panel-body"><div class="form-grid">
            ${photoField('photos', x.photos, { max: Content.LIMITS.storingPhotos, alt: x.title || 'Storing' })}
            <div class="field span-2"><label for="sf-art">Illustratie (als er geen foto is)</label><select class="select" id="sf-art" name="art">${Content.STORING_ART.map((a) => `<option value="${a}"${x.art === a ? ' selected' : ''}>${ART_LABELS[a] || a}</option>`).join('')}</select></div>
          </div></div></section>
        </div>
        <div class="form-col">
          <section class="panel"><div class="panel-head"><div><h2>Zichtbaarheid</h2></div></div><div class="panel-body"><div class="form-grid">${saSwitch('visible', 'Tonen op de website', x.visible)}</div></div></section>
          <section class="panel"><div class="panel-head"><div><h2>Merk en modellen</h2></div></div><div class="panel-body" style="display:grid;gap:16px">
            <div class="field"><label for="sf-brand">Merk</label><select class="select" id="sf-brand" name="brand"><option value="">Alle vier de merken</option>${BRANDS.map((b) => `<option value="${b.id}"${x.brand === b.id ? ' selected' : ''}>${esc(b.name)}</option>`).join('')}</select></div>
            <div class="field"><span class="label">Modellen <span class="opt">(optioneel)</span></span><div class="model-checks" data-stor-models>${BRANDS.map((b) => `<div class="mc-brand" data-mb="${b.id}">${esc(b.name)}</div>${MODELS.filter((m) => m.brand === b.id).map((m) => `<label class="check" data-mb="${b.id}"><input type="checkbox" name="models" value="${m.id}"${x.models.includes(m.id) ? ' checked' : ''}><span class="box">${icon('check')}</span>${esc(m.name)}</label>`).join('')}`).join('')}</div></div>
          </div></section>
          <section class="panel"><div class="panel-head"><div><h2>Gerelateerd</h2></div></div><div class="panel-body" style="display:grid;gap:16px">
            <div class="field"><label for="sf-svc">Dienst</label><select class="select" id="sf-svc" name="service"><option value="">Geen</option>${SERVICES.map((s) => `<option value="${s.slug}"${x.service === s.slug ? ' selected' : ''}>${esc(s.title)}</option>`).join('')}</select></div>
            <div class="field"><label for="sf-prod">Product (catalogus)</label><select class="select" id="sf-prod" name="retrofit"><option value="">Geen</option>${RETROFITS.slice().sort((a, b) => a.title.localeCompare(b.title, 'nl')).map((r) => `<option value="${r.slug}"${x.retrofit === r.slug ? ' selected' : ''}>${esc(r.title)}</option>`).join('')}</select></div>
          </div></section>
          <section class="panel"><div class="panel-head"><div><h2>Google</h2><p>Leeg = automatisch (titel en eerste symptoom)</p></div></div><div class="panel-body"><div class="form-grid">${seoFields(path)}</div></div></section>
        </div>
      </div>${saveBar(isNew ? 'Storing toevoegen' : 'Opslaan')}</form>`;
  },
  mount(root) {
    const f = $('[data-stor-form]', root); if (!f) return null;
    const isNew = f.dataset.new === 'true';
    const st = trackDirty(f);
    mountPhotoFields(f, () => st.set(true));
    const showModels = () => { const b = f.elements.brand.value; $$('[data-stor-models] [data-mb]', f).forEach((el) => { el.hidden = !!b && el.dataset.mb !== b; if (el.hidden) { const c = $('input', el); if (c) c.checked = false; } }); };
    f.elements.brand.addEventListener('change', showModels); showModels();
    if (isNew) {
      f.elements.title.addEventListener('input', () => { if (!f.elements.slug.dataset.touched) f.elements.slug.value = slugify(f.elements.title.value); });
      f.elements.slug.addEventListener('input', () => { f.elements.slug.dataset.touched = '1'; });
    }
    f.addEventListener('submit', (e) => {
      e.preventDefault();
      const v = (k) => f.elements[k].value.trim();
      const L = Content.LIMITS;
      const slug = isNew ? (v('slug') || slugify(v('title'))) : f.dataset.slug;
      const errs = {};
      if (!v('title')) errs.title = 'Vul een titel in.';
      if (isNew && !Content.isSlug(slug)) errs.slug = 'Gebruik kleine letters, cijfers en koppeltekens.';
      else if (isNew && slug === 'nieuw') errs.slug = RESERVED_SLUG;
      else if (isNew && STORINGEN.some((y) => y.slug === slug)) errs.slug = 'Dit webadres bestaat al. Kies een ander.';
      const symptoms = lines(f.elements.symptoms.value);
      const sl = listLimit(symptoms, L.storingSymptoms, L.storingSymptom, 'symptomen'); if (sl) errs.symptoms = sl;
      if (!symptoms.length && !v('cause') && !v('solution')) errs.symptoms = 'Vul ten minste de symptomen, de oorzaak of de oplossing in.';
      const photos = photosOf($('[data-photos="photos"]', f));
      const pe = photoError(photos); if (pe) errs.photos = pe;
      if (!showErrors(f, errs)) return;
      const next = { slug, title: v('title'), brand: f.elements.brand.value, models: $$('input[name="models"]:checked', f).map((c) => c.value), symptoms, cause: v('cause'), solution: v('solution'),
        art: f.elements.art.value, photos, service: f.elements.service.value, retrofit: f.elements.retrofit.value, visible: f.elements.visible.checked };
      const list = deepClone(STORINGEN);
      const i = list.findIndex((y) => y.slug === slug);
      if (i > -1) list[i] = next; else list.push(next);
      if (list.length > L.storingen) { Toast.show(`Gebruik maximaal ${L.storingen} storingen.`, { error: true }); return; }
      if (!saveContent((d) => { d.storingen = list; putSeo(d, `/storingen/${slug}`, f); }, isNew ? 'Storing toegevoegd.' : 'Storing opgeslagen.')) return;
      st.set(false);
      Router.go('/admin/storingen');
    });
    return () => Router.setGuard(null);
  },
});

/* ---------- Beveiliging ---------- */
const SEC_TEXTS = ['sec.eyebrow', 'sec.title', 'sec.lead', 'sec.oem.title', 'sec.oem.text', 'sec.oem.btn', 'sec.classes.title', 'sec.why.title', 'sec.marks.title', 'sec.cta.title', 'sec.cta.text', 'sec.btn', 'sec.note', 'home.sec.eyebrow', 'home.sec.title', 'home.sec.text', 'home.sec.link'];
const classRow = (c = {}) => `<div class="row-edit row-edit--card">
  <div class="form-grid">
    <label class="field"><span class="label">Klasse</span><input class="input input--sm" data-c="title" value="${attr(c.title || '')}" maxlength="40" placeholder="Klasse 1"></label>
    <label class="field"><span class="label">Naam</span><input class="input input--sm" data-c="name" value="${attr(c.name || '')}" maxlength="80" placeholder="Startonderbreker"></label>
    <label class="field span-2"><span class="label">Uitleg</span><textarea class="textarea textarea--sm" data-c="text" rows="3">${esc(c.text || '')}</textarea></label>
    <input type="hidden" data-c="id" value="${attr(c.id || '')}">
    <label class="switch span-2"><input type="checkbox" data-c="visible"${c.visible !== false ? ' checked' : ''}><span class="track"></span>Tonen op de website</label>
  </div>
  <div class="row-edit-actions"><button class="icon-btn icon-btn--sm" type="button" data-row-up aria-label="Omhoog">${icon('left').replace('<svg', '<svg style="transform:rotate(90deg)"')}</button><button class="icon-btn icon-btn--sm" type="button" data-row-down aria-label="Omlaag">${icon('right').replace('<svg', '<svg style="transform:rotate(90deg)"')}</button><button class="icon-btn icon-btn--sm" type="button" data-row-del aria-label="Klasse verwijderen">${icon('trash')}</button></div>
</div>`;
const markRow = (m = {}) => `<div class="row-edit row-edit--card">
  <div class="form-grid">
    <label class="field span-2"><span class="label">Keurmerk</span><input class="input input--sm" data-m="name" value="${attr(m.name || '')}" maxlength="40"></label>
    <label class="field span-2"><span class="label">Uitleg</span><textarea class="textarea textarea--sm" data-m="text" rows="2">${esc(m.text || '')}</textarea></label>
  </div>
  <div class="row-edit-actions"><button class="icon-btn icon-btn--sm" type="button" data-row-up aria-label="Omhoog">${icon('left').replace('<svg', '<svg style="transform:rotate(90deg)"')}</button><button class="icon-btn icon-btn--sm" type="button" data-row-down aria-label="Omlaag">${icon('right').replace('<svg', '<svg style="transform:rotate(90deg)"')}</button><button class="icon-btn icon-btn--sm" type="button" data-row-del aria-label="Keurmerk verwijderen">${icon('trash')}</button></div>
</div>`;
Pages.adminSecurity = adminPage({
  key: 'beveiliging', title: 'Beveiliging',
  render() {
    const S = SECURITY; const texts = Content.texts();
    const tf = (k, o = {}) => saField({ name: `t:${k}`, label: TEXT[k].label, value: typeof texts[k] === 'string' ? texts[k] : TEXT[k].def, multi: !!TEXT[k].multi, rows: 3, max: 2000, ...o });
    return `<form data-sec novalidate>
      ${UI.notice('Alles op de pagina Beveiliging en het blok op de homepage. Noem alleen systemen, merken en certificaten die CarTronic echt levert. Het blok op de homepage zet u aan of uit bij Beheer → Weergave.', { ic: 'info' })}
      <section class="panel"><div class="panel-head"><div><h2>Pagina</h2></div><a class="btn btn--light btn--sm" href="#/beveiliging" target="_blank" rel="noopener">${icon('external')} Bekijk</a></div><div class="panel-body"><div class="form-grid">
        ${['sec.eyebrow', 'sec.title', 'sec.lead', 'sec.oem.title', 'sec.oem.text', 'sec.oem.btn'].map((k) => tf(k)).join('')}
        <p class="hint span-2">In teksten: <code class="code">**tekst**</code> = vet, <code class="code">[linktekst](/kennis/…)</code> = link.</p>
      </div></div></section>
      <section class="panel"><div class="panel-head"><div><h2>Beveiligingsklassen</h2><p>Volgorde = volgorde op de website</p></div><button class="btn btn--light btn--sm" type="button" data-c-add>${icon('plus')} Klasse toevoegen</button></div>
        <div class="panel-body"><div class="form-grid" style="margin-bottom:16px">${tf('sec.classes.title')}</div><div class="rows-editor" data-c-rows>${S.classes.map(classRow).join('')}</div></div></section>
      <section class="panel"><div class="panel-head"><div><h2>Peilsystemen en verzekeraar</h2></div></div><div class="panel-body"><div class="form-grid">
        ${saSwitch('peilVisible', 'Blok “Peilsystemen” tonen', S.peil.visible)}
        ${saField({ name: 'peilTitle', label: 'Titel', value: S.peil.title, max: 80 })}
        ${saField({ name: 'peilText', label: 'Tekst', value: S.peil.text, multi: true, rows: 4, max: Content.LIMITS.secText })}
        ${tf('sec.why.title')}
        ${saField({ name: 'why', label: 'Waarom eist een verzekeraar een klasse? — tekst', value: S.why, multi: true, rows: 4, max: Content.LIMITS.secText, opt: true, hint: 'Leeg = blok verbergen.' })}
      </div></div></section>
      <section class="panel"><div class="panel-head"><div><h2>Keurmerken</h2></div><button class="btn btn--light btn--sm" type="button" data-m-add>${icon('plus')} Keurmerk toevoegen</button></div>
        <div class="panel-body"><div class="form-grid" style="margin-bottom:16px">${tf('sec.marks.title')}${tf('sec.note')}</div><div class="rows-editor" data-m-rows>${S.marks.map(markRow).join('')}</div></div></section>
      <section class="panel"><div class="panel-head"><div><h2>Foto’s</h2><p>Bijvoorbeeld een inbouw in de werkplaats; zonder foto toont de pagina een illustratie</p></div></div><div class="panel-body"><div class="form-grid">
        ${photoField('photos', S.photos, { max: Content.LIMITS.secPhotos, alt: 'Beveiliging ingebouwd door CarTronic' })}
      </div></div></section>
      <section class="panel"><div class="panel-head"><div><h2>Knoppen en afsluiting</h2></div></div><div class="panel-body"><div class="form-grid">
        ${['sec.cta.title', 'sec.cta.text', 'sec.btn'].map((k) => tf(k)).join('')}
      </div></div></section>
      <section class="panel"><div class="panel-head"><div><h2>Blok op de homepage</h2><p>Staat boven “Uit de werkplaats”</p></div></div><div class="panel-body"><div class="form-grid">
        ${['home.sec.eyebrow', 'home.sec.title', 'home.sec.text', 'home.sec.link'].map((k) => tf(k)).join('')}
      </div></div></section>
      ${saveBar()}
    </form>`;
  },
  mount(root) {
    const f = $('[data-sec]', root);
    const st = trackDirty(f);
    const cRows = $('[data-c-rows]', f); const mRows = $('[data-m-rows]', f);
    bindRowEditor(cRows, classRow, () => st.set(true));
    bindRowEditor(mRows, markRow, () => st.set(true));
    mountPhotoFields(f, () => st.set(true));
    $('[data-c-add]', f).addEventListener('click', () => { cRows.insertAdjacentHTML('beforeend', classRow()); st.set(true); $$('.row-edit', cRows).pop().querySelector('input').focus(); });
    $('[data-m-add]', f).addEventListener('click', () => { mRows.insertAdjacentHTML('beforeend', markRow()); st.set(true); $$('.row-edit', mRows).pop().querySelector('input').focus(); });
    const textVals = () => SEC_TEXTS.map((k) => (f.elements[`t:${k}`] ? f.elements[`t:${k}`].value : null));
    const read = () => {
      const used = new Set();
      const classes = $$('.row-edit', cRows).map((r) => {
        const g = (k) => $(`[data-c="${k}"]`, r);
        const base = (g('id').value || slugify(g('title').value) || 'klasse').slice(0, 34).replace(/-+$/, '') || 'klasse';
        let id = base; let n = 2;
        while (used.has(id)) { id = `${base}-${n}`; n += 1; }
        used.add(id);
        return { id, title: g('title').value.trim(), name: g('name').value.trim(), text: g('text').value.trim(), visible: g('visible').checked };
      });
      const marks = $$('.row-edit', mRows).map((r) => ({ name: $('[data-m="name"]', r).value.trim(), text: $('[data-m="text"]', r).value.trim() }));
      return { classes, peil: { visible: f.elements.peilVisible.checked, title: f.elements.peilTitle.value.trim(), text: f.elements.peilText.value.trim() }, why: f.elements.why.value.trim(), marks, photos: photosOf($('[data-photos="photos"]', f)) };
    };
    let shownTexts = textVals(); let shownData = stableStringify(read());
    f.addEventListener('submit', (e) => {
      e.preventDefault();
      const data = read(); const L = Content.LIMITS;
      const errs = {};
      let bad = '';
      if (data.classes.some((c) => !c.title)) bad = 'Elke klasse heeft een naam als “Klasse 1” nodig.';
      else if (data.classes.length > L.secClasses) bad = `Gebruik maximaal ${L.secClasses} klassen.`;
      else if (data.classes.some((c) => c.text.length > L.secText)) bad = `De uitleg van een klasse mag maximaal ${L.secText} tekens hebben.`;
      else if (data.marks.some((m) => !m.name)) bad = 'Elk keurmerk heeft een naam nodig.';
      else if (new Set(data.marks.map((m) => m.name.toLowerCase())).size < data.marks.length) bad = 'Twee keurmerken hebben dezelfde naam. Geef elk keurmerk een eigen naam.';
      else if (data.marks.length > L.secMarks) bad = `Gebruik maximaal ${L.secMarks} keurmerken.`;
      else if (data.marks.some((m) => m.text.length > 600)) bad = 'De uitleg van een keurmerk mag maximaal 600 tekens hebben.';
      if (!data.peil.title) errs.peilTitle = 'Vul een titel in.';
      const pe = photoError(data.photos); if (pe) errs.photos = pe;
      if (bad) { Toast.show(bad, { error: true }); return; }
      if (!showErrors(f, errs)) return;
      const tv = textVals(); const changedTexts = SEC_TEXTS.filter((k, i) => tv[i] !== shownTexts[i]);
      const dataChanged = stableStringify(data) !== shownData;
      if (saveContent((d) => { if (dataChanged) d.security = data; putTexts(d, f, changedTexts); }, 'Beveiliging opgeslagen.')) { st.set(false); shownTexts = tv; shownData = stableStringify(data); }
    });
    return () => Router.setGuard(null);
  },
});

/* ---------- Video's ---------- */
const VID_TEXTS = ['vid.eyebrow', 'vid.title', 'vid.lead', 'vid.privacy', 'vid.follow'];
const storeVideos = (list, msg) => saveContent((d) => { d.videos = list; }, msg);
Pages.adminVideos = orderedListPage({
  key: 'videos', title: 'Video’s', newLabel: 'Nieuwe video', base: 'videos', id: 'id',
  note: 'Plak een link van YouTube (ook Shorts), TikTok, Instagram of Facebook; het platform wordt herkend. Video’s laden pas als een bezoeker op afspelen klikt. Uitgelichte video’s staan bovenaan.',
  items: () => VIDEOS, store: storeVideos,
  rowHtml: (v) => { const info = parseVideoUrl(v.url); return `<div class="prod"><div class="thumb">${v.thumb ? Media.html(v.thumb, '', { kind: 'camera' }) : `<span class="icon-circle icon-circle--sm">${icon('video')}</span>`}</div><div><a class="p-name text-link" href="#/admin/videos/${attr(v.id)}">${esc(v.title)}</a><div class="p-sub">${info ? VIDEO_PLATFORMS[info.platform] : 'Ongeldige link'}${v.featured ? ' · Uitgelicht' : ''}${v.visible ? '' : ' · <span class="pill">Verborgen</span>'}</div></div></div>`; },
  top: () => `${textsPanel(VID_TEXTS, { page: '/videos' })}
    <section class="panel"><div class="panel-head"><div><h2>Volg ons</h2><p>Een rij met links naar uw Facebook-pagina en andere profielen (Beheer → Bedrijfsgegevens)</p></div></div><div class="panel-body"><label class="switch"><input type="checkbox" data-follow${Content.videoSettings().follow ? ' checked' : ''}><span class="track"></span>“Volg ons” tonen op de pagina Video’s</label></div></section>`,
  mountTop: (root) => {
    const cb = $('[data-follow]', root);
    if (cb) cb.addEventListener('change', () => { if (!saveContent((d) => { d.videoSettings = { follow: cb.checked }; }, cb.checked ? '“Volg ons” staat aan.' : '“Volg ons” staat uit.')) cb.checked = !cb.checked; });
    return mountTextsPanel(root, VID_TEXTS);
  },
});
Pages.adminVideoForm = adminPage({
  key: 'videos', title: 'Video',
  heading: (ctx) => (ctx.params.id ? 'Video bewerken' : 'Nieuwe video'),
  render(ctx) {
    const isNew = !ctx.params.id;
    const v = isNew ? { id: '', title: '', description: '', url: '', thumb: '', featured: false, visible: true } : VIDEOS.find((x) => x.id === ctx.params.id);
    if (!v) return UI.empty({ icon: 'video', title: 'Video niet gevonden', actions: '<a class="btn btn--dark btn--sm" href="#/admin/videos">Alle video’s</a>' });
    return `<p><a class="link link--ink" href="#/admin/videos">${icon('arrowLeft')} Alle video’s</a></p>
      <form data-vid-form novalidate data-id="${attr(v.id)}"><div class="form-layout">
        <div class="form-col"><section class="panel"><div class="panel-head"><div><h2>Video</h2></div></div><div class="panel-body"><div class="form-grid">
          ${saField({ name: 'url', label: 'Link naar de video', value: v.url, type: 'url', max: 600, placeholder: 'https://www.youtube.com/watch?v=…', hint: 'YouTube (ook Shorts), TikTok, Instagram (post of reel) of Facebook. Kopieer de link uit de adresbalk of via “Delen”.' })}
          <p class="span-2" data-vid-platform aria-live="polite"></p>
          ${saField({ name: 'title', label: 'Titel', value: v.title, max: Content.LIMITS.videoTitle })}
          ${saField({ name: 'description', label: 'Beschrijving', value: v.description, multi: true, rows: 3, max: Content.LIMITS.videoText, opt: true })}
        </div></div></section></div>
        <div class="form-col">
          <section class="panel"><div class="panel-head"><div><h2>Weergave</h2></div></div><div class="panel-body"><div class="form-grid">
            ${saSwitch('visible', 'Tonen op de website', v.visible)}
            ${saSwitch('featured', 'Uitgelicht (bovenaan, groter)', v.featured)}
          </div></div></section>
          <section class="panel"><div class="panel-head"><div><h2>Voorbeeldafbeelding</h2></div></div><div class="panel-body"><div class="form-grid">
            ${photoField('thumb', v.thumb ? [{ src: v.thumb, alt: v.title || 'Video' }] : [], { label: 'Afbeelding', max: 1, alt: v.title || 'Video', hint: 'Zonder eigen afbeelding: bij YouTube de afbeelding van YouTube, bij andere platforms een neutrale afbeelding. De beschrijving wordt niet getoond; de knop draagt de titel.' })}
          </div></div></section>
        </div>
      </div>${saveBar(isNew ? 'Video toevoegen' : 'Opslaan')}</form>`;
  },
  mount(root) {
    const f = $('[data-vid-form]', root); if (!f) return null;
    const st = trackDirty(f);
    mountPhotoFields(f, () => st.set(true));
    const out = $('[data-vid-platform]', f);
    const detect = () => {
      const u = f.elements.url.value.trim();
      const info = u ? parseVideoUrl(u) : null;
      out.innerHTML = !u ? '' : (info ? `<span class="pill pill--ok">${icon('check')} ${VIDEO_PLATFORMS[info.platform]}${info.short ? ' · staand formaat' : ''}</span>` : '<span class="pill pill--warn">Geen geldige videolink herkend</span>');
    };
    f.elements.url.addEventListener('input', detect); detect();
    f.addEventListener('submit', (e) => {
      e.preventDefault();
      const v = (k) => f.elements[k].value.trim();
      const errs = {};
      const u = v('url');
      if (!u) errs.url = 'Plak de link naar de video.';
      else if (!/^https:\/\//i.test(u)) errs.url = 'Een videolink begint met https://.';
      else if (!parseVideoUrl(u)) errs.url = /fb\.watch|vm\.tiktok|youtube\.com\/(playlist|channel|@)/i.test(u)
        ? 'Dit is een verkorte link of geen link naar één video. Open de video en kopieer de volledige link uit de adresbalk.'
        : 'Deze link wordt niet herkend. Gebruik een link naar één video op YouTube, TikTok, Instagram of Facebook.';
      if (!v('title')) errs.title = 'Vul een titel in.';
      if (!showErrors(f, errs)) return;
      const thumb = photosOf($('[data-photos="thumb"]', f))[0];
      const id = f.dataset.id || `vid_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
      const next = { id, title: v('title'), description: v('description'), url: u, thumb: thumb ? thumb.src : '', featured: f.elements.featured.checked, visible: f.elements.visible.checked };
      const list = deepClone(VIDEOS);
      const i = list.findIndex((x) => x.id === id);
      if (i > -1) list[i] = next; else list.push(next);
      if (list.length > Content.LIMITS.videos) { Toast.show(`Gebruik maximaal ${Content.LIMITS.videos} video’s.`, { error: true }); return; }
      if (!saveContent((d) => { d.videos = list; }, f.dataset.id ? 'Video opgeslagen.' : 'Video toegevoegd.')) return;
      st.set(false);
      Router.go('/admin/videos');
    });
    return () => Router.setGuard(null);
  },
});

/* ---------- Merken & modellen ---------- */
/** Where a model is used: catalog products, webshop products, portfolio and storingen. */
function modelUse(id) {
  return {
    retrofits: RETROFITS.filter((r) => r.models.includes(id)),
    only: RETROFITS.filter((r) => r.scope !== 'brand' && r.models.length === 1 && r.models[0] === id),
    products: Repo.products().filter((p) => (p.compatibility.models || []).includes(id) || p.model === id),
    projects: Repo.projects().filter((p) => (p.models || []).includes(id)),
    storingen: STORINGEN.filter((x) => x.models.includes(id)),
  };
}
const storeModels = (list, msg) => saveContent((d) => { d.models = list; }, msg);
Pages.adminModels = adminPage({
  key: 'modellen', title: 'Merken & modellen',
  actions: () => `<a class="btn btn--primary btn--sm" href="#/admin/modellen/nieuw">${icon('plus')}<span class="hide-sm">Nieuw model</span></a>`,
  render() {
    return `${UI.notice('Modellen verschijnen in de voertuigzoeker, op de merkpagina’s, in de filters van Producten, in het zoeken en in de sitemap. Verbergen haalt een model overal weg zonder iets te verwijderen. De merkteksten past u aan bij Categorieën &amp; merken.', { ic: 'info' })}
      ${BRANDS.map((b) => {
        const list = MODELS.filter((m) => m.brand === b.id);
        return `<section class="panel"><div class="panel-head"><div><h2>${esc(b.name)}</h2><p>${plural(list.filter((m) => !m.hidden).length, 'zichtbaar model', 'zichtbare modellen')}</p></div><a class="btn btn--light btn--sm" href="#/merken/${b.id}" target="_blank" rel="noopener">${icon('external')} Bekijk</a></div>
          <div class="panel-body panel-body--flush"><div class="table-wrap rtable"><table class="table admin-table"><tbody>${list.map((m, i) => `<tr${m.hidden ? ' class="is-muted"' : ''}>
            <td class="cell-main" data-label="Model"><a class="p-name text-link" href="#/admin/modellen/${attr(m.id)}">${esc(m.name)}</a><div class="p-sub">${modelYears(m)} · ${plural(modelUse(m.id).retrofits.length, 'product', 'producten')}${m.hidden ? ' · <span class="pill">Verborgen</span>' : ''}</div></td>
            <td class="num cell-actions"><div class="row-actions">
              <button class="icon-btn icon-btn--sm" type="button" data-mmove="${attr(m.id)}" data-dir="-1"${i ? '' : ' disabled'} aria-label="${attr(m.name)} omhoog">${icon('left').replace('<svg', '<svg style="transform:rotate(90deg)"')}</button>
              <button class="icon-btn icon-btn--sm" type="button" data-mmove="${attr(m.id)}" data-dir="1"${i < list.length - 1 ? '' : ' disabled'} aria-label="${attr(m.name)} omlaag">${icon('right').replace('<svg', '<svg style="transform:rotate(90deg)"')}</button>
              <button class="icon-btn icon-btn--sm" type="button" data-mhide="${attr(m.id)}" aria-label="${m.hidden ? 'Tonen' : 'Verbergen'}: ${attr(m.name)}" title="${m.hidden ? 'Tonen' : 'Verbergen'}">${icon(m.hidden ? 'eye' : 'eyeOff')}</button>
              <a class="icon-btn icon-btn--sm" href="#/admin/modellen/${attr(m.id)}" aria-label="Bewerken: ${attr(m.name)}" title="Bewerken">${icon('pencil')}</a>
              <button class="icon-btn icon-btn--sm" type="button" data-mdel="${attr(m.id)}" aria-label="Verwijderen: ${attr(m.name)}" title="Verwijderen">${icon('trash')}</button>
            </div></td></tr>`).join('')}</tbody></table></div></div></section>`;
      }).join('')}`;
  },
  mount(root) {
    root.addEventListener('click', async (e) => {
      const mv = e.target.closest('[data-mmove]');
      if (mv) {
        const list = deepClone(MODELS); const i = list.findIndex((m) => m.id === mv.dataset.mmove); if (i < 0) return;
        const dir = Number(mv.dataset.dir); let j = i + dir;
        while (j >= 0 && j < list.length && list[j].brand !== list[i].brand) j += dir; // the next model of the same brand
        if (j < 0 || j >= list.length) return;
        [list[i], list[j]] = [list[j], list[i]];
        if (storeModels(list, 'Volgorde opgeslagen.')) Router.render();
        return;
      }
      const hd = e.target.closest('[data-mhide]');
      if (hd) {
        const list = deepClone(MODELS); const m = list.find((x) => x.id === hd.dataset.mhide); if (!m) return;
        if (m.hidden) delete m.hidden; else m.hidden = true;
        if (storeModels(list, m.hidden ? `${m.name} is verborgen.` : `${m.name} staat weer op de website.`)) Router.render();
        return;
      }
      const del = e.target.closest('[data-mdel]');
      if (del) {
        const m = MODEL[del.dataset.mdel]; if (!m) return;
        if (MODELS.filter((x) => x.brand === m.brand).length <= 1) { Toast.show('Een merk heeft ten minste één model nodig. Verberg het model in plaats daarvan.', { error: true }); return; }
        const use = modelUse(m.id);
        const linked = use.retrofits.length + use.products.length + use.projects.length + use.storingen.length;
        const choice = linked ? await askModelDelete(m, use) : ((await Overlay.confirm({ title: 'Model verwijderen?', message: `“${esc(modelLabel(m.id))}” wordt verwijderd. Dit model is nergens aan gekoppeld.`, confirmLabel: 'Verwijderen', danger: true })) ? 'delete' : '');
        if (choice === 'hide') { const list = deepClone(MODELS); list.find((x) => x.id === m.id).hidden = true; if (storeModels(list, `${m.name} is verborgen.`)) Router.render(); }
        if (choice === 'delete' && storeModels(deepClone(MODELS).filter((x) => x.id !== m.id), `${m.name} is verwijderd.`)) {
          // Webshop products and portfolio items no longer refer to it (they stay valid and can be saved).
          use.products.forEach((p) => Repo.saveProduct({ ...p, model: p.model === m.id ? '' : p.model, compatibility: { ...p.compatibility, models: (p.compatibility.models || []).filter((x) => x !== m.id) } }));
          if (use.projects.length) Repo.saveProjects(Repo.projects().map((p) => ({ ...p, models: (p.models || []).filter((x) => x !== m.id) })));
          Router.render();
        }
      }
    });
  },
});
/** Deleting a model that is in use: explain what happens and offer hiding instead. Resolves 'hide', 'delete' or ''. */
function askModelDelete(m, use) {
  return new Promise((resolve) => {
    let answer = '';
    const li = [
      use.retrofits.length ? `${plural(use.retrofits.length, 'product', 'producten')} in de catalogus${use.only.length ? ` (waarvan ${use.only.length} alleen voor dit model: die verdwijnen dan van de website)` : ''}` : '',
      use.products.length ? plural(use.products.length, 'webshopproduct', 'webshopproducten') : '',
      use.projects.length ? `${plural(use.projects.length, 'portfolio-item', 'portfolio-items')}` : '',
      use.storingen.length ? plural(use.storingen.length, 'storing', 'storingen') : '',
    ].filter(Boolean);
    Overlay.open({
      title: 'Dit model is in gebruik', size: 'sm',
      body: `<p class="text-muted" style="font-size:14.5px;line-height:1.65">“${esc(modelLabel(m.id))}” is gekoppeld aan:</p><ul class="mt-8" style="padding-left:18px;font-size:14.5px">${li.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>
        <p class="text-muted mt-16" style="font-size:14.5px;line-height:1.65"><strong>Advies: verberg het model.</strong> Het verdwijnt dan uit de zoeker, filters, merkpagina en sitemap, maar alle koppelingen en pagina’s blijven werken.</p>`,
      foot: '<button class="btn btn--light btn--sm" type="button" data-close>Annuleren</button><button class="btn btn--ghost btn--sm" type="button" data-md="delete" style="color:var(--red)">Toch verwijderen</button><button class="btn btn--dark btn--sm" type="button" data-md="hide">Verbergen</button>',
      initialFocus: '[data-md="hide"]',
      onMount(panel, close) { panel.addEventListener('click', (e) => { const b = e.target.closest('[data-md]'); if (b) { answer = b.dataset.md; close(); } }); },
      onClose() { resolve(answer); },
    });
  });
}
const tokensText = (list) => (list || []).join(', ');
const tokensOf = (s) => uniq(String(s || '').split(/[,\s]+/).map((t) => t.toUpperCase().replace(/[^A-Z0-9]/g, '')).filter(Boolean));
Pages.adminModelForm = adminPage({
  key: 'modellen', title: 'Model',
  heading: (ctx) => (ctx.params.id ? 'Model bewerken' : 'Nieuw model'),
  render(ctx) {
    const isNew = !ctx.params.id;
    const m = isNew ? { id: '', brand: ctx.query.merk && BRAND[ctx.query.merk] ? ctx.query.merk : 'volkswagen', name: '', base: '', from: new Date().getFullYear(), to: null, match: [], types: [], exclude: [] } : MODEL[ctx.params.id];
    if (!m) return UI.empty({ icon: 'car', title: 'Model niet gevonden', actions: '<a class="btn btn--dark btn--sm" href="#/admin/modellen">Alle modellen</a>' });
    return `<p><a class="link link--ink" href="#/admin/modellen">${icon('arrowLeft')} Alle modellen</a></p>
      <form data-model-form novalidate data-new="${isNew}" data-id="${attr(m.id)}"><div class="form-layout">
        <div class="form-col"><section class="panel"><div class="panel-head"><div><h2>Model</h2></div></div><div class="panel-body"><div class="form-grid">
          <div class="field"><label for="mf-brand">Merk</label><select class="select" id="mf-brand" name="brand"${isNew ? '' : ' disabled'}>${BRANDS.map((b) => `<option value="${b.id}"${m.brand === b.id ? ' selected' : ''}>${esc(b.name)}</option>`).join('')}</select>${isNew ? '' : '<span class="hint">Het merk ligt vast: producten en pagina’s zijn eraan gekoppeld.</span>'}</div>
          ${saField({ name: 'name', label: 'Naam (zoals getoond)', value: m.name, max: Content.LIMITS.modelName, half: true, placeholder: 'Golf 8' })}
          ${isNew ? saField({ name: 'id', label: 'Webadres (slug)', value: '', max: 40, placeholder: 'wordt gemaakt van merk en naam', hint: 'Gebruikt in links zoals /producten?model=<strong>…</strong>. Kan later niet worden gewijzigd.' }) : `<div class="field"><span class="label">Webadres (slug)</span><p class="code" style="padding-top:8px">${esc(m.id)}</p></div>`}
          ${saField({ name: 'base', label: 'Modelnaam zonder generatie', value: m.base, max: Content.LIMITS.modelName, half: true, placeholder: 'Golf', hint: 'Voor het zoeken (“golf camera”).' })}
          ${saField({ name: 'from', label: 'Bouwjaar vanaf', value: m.from, type: 'number', half: true, attrs: ' min="1950" max="2100"' })}
          ${saField({ name: 'to', label: 'Bouwjaar tot en met', value: m.to == null ? '' : m.to, type: 'number', half: true, opt: true, attrs: ' min="1950" max="2100"', hint: 'Leeg = nog in productie (“heden”).' })}
          ${saSwitch('hidden', 'Verbergen op de website', !!m.hidden, 'Verborgen modellen staan niet in de zoeker, filters, merkpagina, het zoeken en de sitemap. Koppelingen blijven bestaan.')}
        </div></div></section></div>
        <div class="form-col"><section class="panel"><div class="panel-head"><div><h2>Herkenning via kenteken (RDW)</h2></div></div><div class="panel-body"><div class="form-grid">
          ${UI.notice('Bij een kenteken leest de website de handelsbenaming en het type bij de RDW. <strong>Zoekwoorden</strong> worden vergeleken met het begin van de handelsbenaming, zonder merknaam, spaties en tekens (“GOLF VARIANT” wordt “GOLFVARIANT”). <strong>Typecodes</strong> (bijvoorbeeld CD voor de Golf 8) helpen als twee generaties in hetzelfde bouwjaar vallen. Twijfelt u, laat ze dan zoals ze zijn.', { ic: 'info' })}
          ${saField({ name: 'match', label: 'Zoekwoorden (handelsbenaming)', value: tokensText(m.match), placeholder: 'GOLF', hint: 'Gescheiden door komma’s, bijvoorbeeld “A3, S3, RS3”. Standaard: de modelnaam zonder generatie.' })}
          ${saField({ name: 'types', label: 'Typecodes', value: tokensText(m.types), opt: true, placeholder: 'CD', hint: 'Gescheiden door komma’s, maximaal 4 tekens per code.' })}
          ${saField({ name: 'exclude', label: 'Uitzonderingen', value: tokensText(m.exclude), opt: true, placeholder: 'GOLFSPORTSVAN', hint: 'Handelsbenamingen die met een zoekwoord beginnen maar een ander model zijn.' })}
        </div></div></section></div>
      </div>${saveBar(isNew ? 'Model toevoegen' : 'Opslaan')}</form>`;
  },
  mount(root) {
    const f = $('[data-model-form]', root); if (!f) return null;
    const isNew = f.dataset.new === 'true';
    const st = trackDirty(f);
    if (isNew) {
      const auto = () => { if (!f.elements.id.dataset.touched) f.elements.id.value = slugify(f.elements.name.value); };
      f.elements.name.addEventListener('input', auto);
      f.elements.id.addEventListener('input', () => { f.elements.id.dataset.touched = '1'; });
    }
    f.addEventListener('submit', (e) => {
      e.preventDefault();
      const v = (k) => f.elements[k].value.trim();
      const errs = {};
      const id = isNew ? (v('id') || slugify(v('name'))) : f.dataset.id;
      const brand = isNew ? f.elements.brand.value : MODEL[id].brand;
      if (!v('name')) errs.name = 'Vul de naam van het model in.';
      if (isNew && (!Content.isSlug(id) || id.length > 40)) errs.id = 'Gebruik kleine letters, cijfers en koppeltekens (maximaal 40 tekens).';
      else if (isNew && (MODEL[id] || id === 'nieuw')) errs.id = 'Dit webadres bestaat al. Kies een ander, bijvoorbeeld met de generatie erbij.';
      const from = Number(v('from')); const to = v('to') ? Number(v('to')) : null;
      if (!Number.isInteger(from) || from < 1950 || from > 2100) errs.from = 'Vul een bouwjaar in tussen 1950 en 2100.';
      if (to !== null && (!Number.isInteger(to) || to < 1950 || to > 2100)) errs.to = 'Vul een bouwjaar in tussen 1950 en 2100, of laat leeg.';
      else if (to !== null && !errs.from && to < from) errs.to = 'Het laatste bouwjaar ligt vóór het eerste.';
      const base = v('base') || v('name');
      const match = tokensOf(v('match')).length ? tokensOf(v('match')) : tokensOf(base.replace(/\s+/g, ''));
      if (match.length > 20) errs.match = 'Gebruik maximaal 20 zoekwoorden.';
      else if (match.some((t) => t.length > 24)) errs.match = 'Een zoekwoord mag maximaal 24 tekens hebben.';
      const types = tokensOf(v('types'));
      if (types.some((t) => t.length > 4)) errs.types = 'Een typecode heeft maximaal 4 tekens, bijvoorbeeld CD of 8V.';
      else if (types.length > 20) errs.types = 'Gebruik maximaal 20 typecodes.';
      const exclude = tokensOf(v('exclude'));
      if (exclude.length > 30 || exclude.some((t) => t.length > 24)) errs.exclude = 'Maximaal 30 uitzonderingen van elk 24 tekens.';
      if (!showErrors(f, errs)) return;
      const old = isNew ? {} : deepClone(MODEL[id]);
      const next = { ...old, id, brand, name: v('name'), base, from, to, match, types };
      if (exclude.length) next.exclude = exclude; else delete next.exclude;
      if (next.matchTo) { Object.keys(next.matchTo).forEach((k) => { if (!match.includes(k)) delete next.matchTo[k]; }); if (!Object.keys(next.matchTo).length) delete next.matchTo; }
      if (f.elements.hidden.checked) next.hidden = true; else delete next.hidden;
      const list = deepClone(MODELS);
      const i = list.findIndex((x) => x.id === id);
      if (i > -1) list[i] = next;
      else { const last = list.map((x) => x.brand).lastIndexOf(brand); list.splice(last + 1, 0, next); } // after the other models of this brand
      if (list.length > Content.LIMITS.models) { Toast.show(`Gebruik maximaal ${Content.LIMITS.models} modellen.`, { error: true }); return; }
      if (!storeModels(list, isNew ? 'Model toegevoegd. U kunt het nu bij producten kiezen.' : 'Model opgeslagen.')) return;
      st.set(false);
      Router.go('/admin/modellen');
    });
    return () => Router.setGuard(null);
  },
});

/* ---------- Account: user name and password ---------- */
Pages.adminAccount = adminPage({
  key: 'account', title: 'Account & wachtwoord',
  render() {
    const c = Auth.creds();
    return `${UI.notice('Het nieuwe wachtwoord geldt in deze browser direct; op andere apparaten pas nadat u de website opnieuw hebt gepubliceerd en geüpload.', { ic: 'info' })}
      <form data-account novalidate autocomplete="on"><section class="panel"><div class="panel-head"><div><h2>Inloggegevens</h2><p>Huidige gebruikersnaam: <strong>${esc(c.user)}</strong></p></div></div><div class="panel-body"><div class="form-grid">
        <input type="text" name="username" autocomplete="username" value="${attr(c.user)}" hidden>
        ${saField({ name: 'current', label: 'Huidig wachtwoord', type: 'password', attrs: ' autocomplete="current-password"' })}
        ${saField({ name: 'next', label: 'Nieuw wachtwoord', type: 'password', half: true, attrs: ' autocomplete="new-password"', hint: 'Minimaal 10 tekens. Gebruik bij voorkeur een zin of een wachtwoordmanager.' })}
        ${saField({ name: 'again', label: 'Nieuw wachtwoord (nogmaals)', type: 'password', half: true, attrs: ' autocomplete="new-password"' })}
        ${saField({ name: 'user', label: 'Nieuwe gebruikersnaam', value: '', max: 60, opt: true, placeholder: c.user, hint: 'Leeg = gebruikersnaam blijft hetzelfde. Geen spaties.' })}
      </div></div>${saveBar('Wachtwoord wijzigen', '', { inline: true })}</section></form>
      <section class="panel"><div class="panel-head"><div><h2>Zo werkt de beveiliging</h2></div></div><div class="panel-body prose" style="font-size:14.5px">
        <p>Het wachtwoord wordt nergens opgeslagen; de website bewaart alleen een gezouten hash (PBKDF2-SHA-256). Na ${Auth.FREE_TRIES} mislukte pogingen moet u steeds langer wachten, en na 30 minuten zonder activiteit wordt u automatisch uitgelogd.</p>
        <p>Dit is een controle in de browser, geen serverbeveiliging. Wat bezoekers zien, verandert alleen als u de website publiceert en uploadt.</p>
      </div></section>`;
  },
  mount(root) {
    const f = $('[data-account]', root);
    const st = trackDirty(f);
    const btn = f.querySelector('[type="submit"]');
    f.addEventListener('submit', async (e) => {
      e.preventDefault();
      const cur = f.elements.current.value; const next = f.elements.next.value; const again = f.elements.again.value;
      const user = f.elements.user.value.trim();
      const errs = {};
      if (!cur) errs.current = 'Vul uw huidige wachtwoord in.';
      if (next.length < 10) errs.next = 'Het nieuwe wachtwoord moet minimaal 10 tekens hebben.';
      else if (next === cur) errs.next = 'Het nieuwe wachtwoord moet anders zijn dan het huidige.';
      if (!errs.next && again !== next) errs.again = 'De twee nieuwe wachtwoorden zijn niet gelijk.';
      if (user && (/\s/.test(user) || user.length > 60)) errs.user = 'Gebruik een gebruikersnaam zonder spaties (maximaal 60 tekens).';
      if (!showErrors(f, errs)) return;
      if (!Auth.available()) { Toast.show('Wachtwoord wijzigen werkt alleen via een beveiligde verbinding (https).', { error: true }); return; }
      btn.disabled = true; btn.setAttribute('aria-busy', 'true');
      try {
        if (!(await Auth.check(cur))) { showErrors(f, { current: 'Het huidige wachtwoord klopt niet.' }); f.elements.current.value = ''; return; }
        const creds = await Auth.make(user || Auth.creds().user, next);
        if (!saveContent((d) => { d.auth = creds; }, null)) return;
        Auth.renew();
        st.set(false);
        f.reset();
        Toast.show('Wachtwoord gewijzigd. Het nieuwe wachtwoord geldt in deze browser direct; op andere apparaten pas nadat u de website opnieuw hebt gepubliceerd en geüpload.');
        Router.render();
      } catch (er) { console.error(er); Toast.show('Het wachtwoord kon niet worden gewijzigd. Probeer het opnieuw.', { error: true }); } finally { btn.disabled = false; btn.removeAttribute('aria-busy'); }
    });
    return () => Router.setGuard(null);
  },
});
