/* =====================================================================
   SHARED UI — layout, components, vehicle finder, search, cart UI
   ===================================================================== */
const titleCase = (s) => String(s || '').toLowerCase().replace(/(^|[\s-])([a-zà-ž])/g, (m, a, b) => a + b.toUpperCase());
const EU_STARS = '<svg viewBox="0 0 24 24" aria-hidden="true"><g fill="#FFD94A">' + Array.from({ length: 12 }, (_, i) => {
  const a = (i / 12) * Math.PI * 2; const x = 12 + Math.cos(a) * 8; const y = 12 + Math.sin(a) * 8;
  return `<circle cx="${x.toFixed(2)}" cy="${y.toFixed(2)}" r="1.25"/>`;
}).join('') + '</g></svg>';
/** A link to a page of this site (#/… in hash mode, /… in path mode). */
const isAppLink = (a) => { const h = a.getAttribute('href') || ''; return h.startsWith('#/') || (h.startsWith('/') && !h.startsWith('//')); };
/** A plain left click (no new tab or window): only then does the current page navigate. */
const plainClick = (e) => !(e.button || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey);
const plateChip = (plate) => `<span class="plate plate--sm" aria-label="Kenteken ${attr(plate)}"><span class="plate-eu" aria-hidden="true">${EU_STARS}NL</span><span class="val">${esc(plate)}</span></span>`;

/* ---------- WhatsApp ---------- */
const WhatsApp = {
  url(text) { return `https://wa.me/${COMPANY.whatsapp}?text=${encodeURIComponent(text)}`; },
  /** The WhatsApp number as shown on the site (the phone number unless a separate one is set). */
  display() { return COMPANY.whatsappDisplay || COMPANY.phoneDisplay; },
  generic() {
    const v = VehicleStore.get();
    let t = 'Hallo CarTronic,\n\n';
    if (v) t += `Voertuig: ${VehicleStore.name(v)}${v.year ? ` (${v.year})` : ''}\n\n`;
    t += Content.rawText('wa.generic');
    return this.url(t);
  },
  /** Structured enquiry. Never contains internal ids. */
  enquiry({ name, topic, vehicle, plate, vin, year, options = [], products = [], question }) {
    const lines = ['Hallo CarTronic,', ''];
    if (topic) lines.push(`Onderwerp: ${topic}`);
    if (name) lines.push(`Naam: ${name}`);
    lines.push(`Voertuig: ${vehicle || 'nog niet gekozen'}`);
    if (plate) lines.push(`Kenteken: ${plate}`);
    if (vin) lines.push(`Chassisnummer (VIN): ${vin}`);
    if (year) lines.push(`Bouwjaar: ${year}`);
    if (options.length) { lines.push('', 'Geselecteerde optie(s):'); options.forEach((o) => lines.push(`- ${o}`)); }
    if (products.length) { lines.push('', 'Producten:'); products.forEach((p) => lines.push(`- ${p}`)); }
    lines.push('', 'Vraag:', question || '-');
    return lines.join('\n');
  },
};

/* ---------- Layout: header, mobile nav, footer, mobile bar ---------- */
const NAV_ALL = [
  ['mogelijkheden', 'Mogelijkheden', '#/mogelijkheden'],
  ['merken', 'Merken', '#/merken'],
  ['expertise', 'Expertise', '#/expertise'],
  ['projecten', 'Projecten', '#/projecten'],
  ['webshop', 'Webshop', '#/webshop'],
  ['over', 'Over CarTronic', '#/over'],
  ['contact', 'Contact', '#/contact'],
];
/* Mobile menu (as in the approved mobile design): the main pages, then the call button. */
const MOBILE_NAV_ALL = [
  ['mogelijkheden', 'Mogelijkheden', '#/mogelijkheden'],
  ['expertise', 'Expertise', '#/expertise'],
  ['projecten', 'Projecten', '#/projecten'],
  ['webshop', 'Webshop', '#/webshop'],
  ['over', 'Over CarTronic', '#/over'],
  ['contact', 'Contact', '#/contact'],
  ['beoordelingen', 'Beoordelingen', '#/beoordelingen'],
];
/* The webshop can be switched off in Beheer → Weergave; its menu items disappear with it. */
const navItems = (list) => list.filter(([k]) => k !== 'webshop' || Content.shopOn());
const Layout = {
  renderHeader() {
    const shop = Content.shopOn();
    const old = $('#mobileNav');
    if (old && old.parentNode !== $('#siteHeader')) old.remove();
    $('#siteHeader').innerHTML = `
      <div class="container header-inner">
        <a class="brand-logo" href="#/" aria-label="CarTronic — naar de homepage">${logoSvg()}</a>
        <nav class="main-nav" aria-label="Hoofdnavigatie"><ul>
          ${navItems(NAV_ALL).map(([k, l, h]) => `<li><a href="${h}" data-nav="${k}">${l}</a></li>`).join('')}
        </ul></nav>
        <div class="header-tools">
          <button class="icon-btn tool-search" type="button" data-action="open-search" aria-label="Zoeken" title="Zoeken (Ctrl K)">${icon('search')}</button>
          <button class="vehicle-chip" type="button" data-action="open-vehicle" id="vehicleChip"></button>
          ${shop ? `<a class="icon-btn tool-cart" href="#/winkelmand" data-action="open-cart" id="cartBtn" aria-label="Winkelmand">${icon('cart')}<span class="count" hidden>0</span></a>` : ''}
          <a class="header-phone" href="${attr(COMPANY.phoneHref)}" aria-label="Bel ${attr(COMPANY.name)}: ${attr(COMPANY.phoneDisplay)}">${icon('phone')}<span class="num">${esc(COMPANY.phoneDisplay)}</span></a>
          <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="mobileNav" data-action="toggle-menu" aria-label="Menu">
            <span class="bars" aria-hidden="true"><span></span><span></span><span></span></span>
          </button>
        </div>
      </div>
      <div class="mobile-nav" id="mobileNav">
        <div class="mn-backdrop" data-action="toggle-menu" aria-hidden="true"></div>
        <div class="mn-panel" role="dialog" aria-modal="true" aria-labelledby="mnTitle">
          <div class="mn-head">
            <p class="mn-title" id="mnTitle">CarTronic</p>
            <button class="mn-close" type="button" data-action="toggle-menu" aria-label="Menu sluiten">${icon('x')}</button>
          </div>
          <p class="mn-sub">${tx('mn.sub')}</p>
          <nav aria-label="Mobiele navigatie"><ul class="m-links">
            ${navItems(MOBILE_NAV_ALL).map(([k, l, h]) => `<li><a href="${h}" data-nav="${k}">${l}</a></li>`).join('')}
          </ul></nav>
          <a class="btn btn--primary btn--block mn-call" href="${attr(COMPANY.phoneHref)}">${icon('phone')} ${esc(COMPANY.phoneDisplay)}</a>
          <button class="mn-search" type="button" data-action="open-search">${icon('search')}<span>Zoek een optie, model of dienst</span></button>
          <div class="mn-vehicle" id="mobileVehicle"></div>
          <ul class="mn-more">
            <li><a href="#/merken" data-nav="merken">Merken &amp; modellen</a></li>
            <li><a href="#/mijn-auto" data-nav="mijn-auto">Mijn auto &amp; bewaard</a></li>
            ${shop ? '<li><a href="#/winkelmand" data-nav="cart" id="mobileCartLink">Winkelmand</a></li>' : ''}
            <li><a href="${attr(WhatsApp.generic())}" target="_blank" rel="noopener" data-action="whatsapp" data-wa-generic>WhatsApp</a></li>
          </ul>
        </div>
      </div>`;
    // The header uses backdrop-filter, which would make it the containing block of the fixed
    // mobile menu; keep the menu panel outside the header so it can cover the viewport.
    const mnav = $('#mobileNav');
    if (mnav) document.body.insertBefore(mnav, $('#main'));
    this.renderAnnouncement();
    if (this.scrollBound) return;
    this.scrollBound = true;
    let ticking = false;
    const onScroll = () => {
      if (ticking) return; ticking = true;
      requestAnimationFrame(() => { $('#siteHeader').classList.toggle('is-scrolled', window.scrollY > 8); ticking = false; });
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  },
  /** Optional announcement strip above the header (Beheer → Weergave). */
  renderAnnouncement() {
    const a = Content.display().announcement;
    let bar = $('#announceBar');
    if (!a.on || !a.text) { if (bar) bar.remove(); return; }
    if (!bar) {
      bar = document.createElement('div');
      bar.id = 'announceBar';
      document.body.insertBefore(bar, $('#siteHeader'));
    }
    const ext = /^https?:/i.test(a.link);
    bar.className = `announce announce--${a.tone}`;
    bar.setAttribute('role', 'region');
    bar.setAttribute('aria-label', 'Mededeling');
    bar.innerHTML = `<div class="container announce-inner"><p>${fmtText(a.text)}${a.link && a.linkLabel ? ` <a href="${attr(a.link)}"${ext ? ' target="_blank" rel="noopener"' : ''}>${esc(a.linkLabel)}</a>` : ''}</p></div>`;
  },
  renderFooter() {
    const year = new Date().getFullYear();
    const legal = [COMPANY.kvk ? `KvK ${esc(COMPANY.kvk)}` : '', COMPANY.vat ? `btw ${esc(COMPANY.vat)}` : ''].filter(Boolean).map((x) => `<span class="sep">·</span>${x}`).join('');
    $('#siteFooter').innerHTML = `
      <div class="container">
        <div class="footer-grid">
          <div class="footer-brand">
            <a class="footer-logo" href="#/" aria-label="CarTronic — naar de homepage">${logoSvg()}</a>
            <p class="footer-tagline">${tx('footer.tagline')}</p>
          </div>
          <div class="footer-col"><h2>Ontdek de mogelijkheden</h2><ul>
            <li><button type="button" data-action="open-vehicle">Selecteer uw auto</button></li>
            <li><a href="#/expertise">Expertise &amp; diensten</a></li>
            <li><a href="#/projecten">Projecten</a></li>
            <li><a href="#/mogelijkheden">Alle mogelijkheden</a></li>
            <li><a href="#/merken">Merken &amp; modellen</a></li>
            ${Content.shopOn() ? '<li><a href="#/webshop">Webshop</a></li>' : ''}
          </ul></div>
          <div class="footer-col"><h2>CarTronic</h2><ul>
            <li><a href="#/over">Over CarTronic</a></li>
            <li><a href="#/kennis">Berichten &amp; kennis</a></li>
            <li><a href="#/productinformatie">Productinformatie</a></li>
            <li><a href="#/beoordelingen">Beoordelingen</a></li>
            <li><a href="#/contact">Contact</a></li>
            <li><a href="#/mijn-auto">Mijn auto &amp; bewaard</a></li>
          </ul></div>
          <div class="footer-col footer-contact"><h2>Contact</h2><ul>
            <li>${esc(COMPANY.street)}<br>${esc(COMPANY.postal)} ${esc(COMPANY.city)}</li>
            <li><a href="${attr(COMPANY.phoneHref)}">${esc(COMPANY.phoneDisplay)}</a></li>
            <li><a href="${attr(WhatsApp.generic())}" target="_blank" rel="noopener" data-action="whatsapp" data-wa-generic>WhatsApp: ${esc(WhatsApp.display())}</a></li>
            <li><a href="mailto:${attr(COMPANY.email)}">${esc(COMPANY.email)}</a></li>
          </ul>
          <dl class="footer-hours">${COMPANY.hours.map(([d, t]) => `<dt>${esc(d)}</dt><dd>${esc(t)}</dd>`).join('')}</dl>
          </div>
        </div>
        <div class="footer-bottom">
          <div>© ${year} ${esc(COMPANY.name)} · ${esc(COMPANY.city)}${legal}<span class="sep">·</span>${tx('footer.legal')}</div>
          <div><a href="#/privacy">Privacy</a>${Content.display().footerAdmin ? '<span class="sep">·</span><a href="#/admin">Beheer (demo)</a>' : ''}${tx('footer.proto') ? `<span class="sep">·</span><span>${tx('footer.proto')}</span>` : ''}</div>
        </div>
      </div>`;
  },
  refreshDynamic() {
    const v = VehicleStore.get();
    const chip = $('#vehicleChip');
    if (chip) {
      chip.classList.toggle('is-empty', !v);
      chip.innerHTML = v
        ? `${icon('car')}<span class="vc-text"><span class="lbl">Uw auto</span><span class="val">${esc(VehicleStore.short(v))}</span></span>`
        : `${icon('car')}<span class="vc-text"><span class="val">Kies uw auto</span></span>`;
      chip.setAttribute('aria-label', v ? `Uw auto: ${VehicleStore.name(v)}. Wijzig auto` : 'Kies uw auto');
    }
    const mv = $('#mobileVehicle');
    if (mv) {
      mv.innerHTML = v
        ? `<span class="mnv-icon">${icon('car')}</span><span class="mnv-text"><span class="mnv-lbl">Uw auto</span><span class="mnv-val">${esc(VehicleStore.name(v))}</span></span><button class="mnv-btn" type="button" data-action="open-vehicle">Wijzig</button>`
        : `<span class="mnv-icon">${icon('car')}</span><span class="mnv-text"><span class="mnv-lbl">Uw auto</span><span class="mnv-val">Nog niet gekozen</span></span><button class="mnv-btn" type="button" data-action="open-vehicle">Kies uw auto</button>`;
    }
    const count = Content.shopOn() ? Cart.count() : 0;
    const btn = $('#cartBtn');
    if (btn) {
      const c = btn.querySelector('.count');
      const prev = parseInt(c.textContent, 10) || 0;
      c.textContent = count;
      c.hidden = count === 0;
      btn.classList.toggle('has-items', count > 0);
      if (count > prev) { c.classList.remove('bump'); void c.offsetWidth; c.classList.add('bump'); }
      btn.setAttribute('aria-label', `Winkelmand, ${plural(count, 'artikel', 'artikelen')}`);
    }
    const mc = $('#mobileCartLink');
    if (mc) mc.textContent = count ? `Winkelmand (${count})` : 'Winkelmand';
    $$('[data-wa-generic]').forEach((a) => { a.href = WhatsApp.generic(); });
  },
  update(ctx, page) {
    this.navKey = page.nav || '';
    this.markNav();
    this.closeMenu();
    this.refreshDynamic();
  },
  markNav() {
    const key = this.navKey || '';
    $$('[data-nav]').forEach((a) => { if (a.dataset.nav === key) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
  },
  toggleMenu(force) {
    const nav = $('#mobileNav'); const btn = $('#siteHeader .nav-toggle');
    if (!nav || !btn) return;
    const open = typeof force === 'boolean' ? force : !nav.classList.contains('is-open');
    nav.classList.toggle('is-open', open);
    btn.setAttribute('aria-expanded', String(open));
    btn.setAttribute('aria-label', open ? 'Menu sluiten' : 'Menu');
    document.body.classList.toggle('is-locked', open);
    // The menu is a modal panel: keep keyboard and screen-reader focus inside it while it is open.
    [...document.body.children].forEach((el) => { if (el !== nav && el.tagName !== 'SCRIPT') el.inert = open; });
    if (open) { const c = $('.mn-close', nav); if (c) c.focus({ preventScroll: true }); } else if (nav.contains(document.activeElement)) btn.focus({ preventScroll: true });
  },
  closeMenu() { if ($('#mobileNav')?.classList.contains('is-open')) this.toggleMenu(false); },
};

/* ---------- Generic components ---------- */
const UI = {
  crumbs(items, { light = false } = {}) {
    return `<nav aria-label="Kruimelpad"><ol class="crumbs${light ? ' crumbs--light' : ''}">
      ${items.map((it, i) => (i === items.length - 1
        ? `<li><span aria-current="page">${esc(it[0])}</span></li>`
        : `<li><a href="${attr(it[1])}">${esc(it[0])}</a></li>`)).join('')}
    </ol></nav>`;
  },
  pageHeader({ crumbs = [], eyebrow = '', title = '', lead = '', compact = false, extra = '' }) {
    return `<header class="page-header${compact ? ' page-header--compact' : ''} on-dark">
      <div class="container">
        ${crumbs.length ? `<div class="crumbs-wrap">${this.crumbs([['Home', '#/'], ...crumbs])}</div>` : ''}
        ${eyebrow ? `<p class="eyebrow" data-reveal>${esc(eyebrow)}</p>` : ''}
        <h1 class="h1" data-split>${title}</h1>
        ${lead ? `<p class="lead" data-reveal>${lead}</p>` : ''}
        ${extra}
      </div>
    </header>`;
  },
  saveBtn(type, id, label) {
    const on = Saved.has(type, id);
    return `<button class="save-btn" type="button" data-action="toggle-save" data-type="${type}" data-id="${attr(id)}" aria-pressed="${on}" aria-label="${on ? 'Verwijder uit bewaard' : 'Bewaar'}: ${attr(label)}" title="${on ? 'Bewaard' : 'Bewaar'}">${icon('bookmark')}</button>`;
  },
  retrofitCard(r, { vehicle = VehicleStore.get(), status = true } = {}) {
    const st = status && vehicle ? Compat.status(r, vehicle) : null;
    const brandName = r.scope === 'brand' && !r.brand ? 'Alle merken' : BRAND[r.brand].name;
    return `<article class="card retrofit-card">
      <div class="card-media">${Media.html(retrofitImage(r), r.title, { kind: r.art })}${this.saveBtn('retrofits', r.slug, r.title)}</div>
      <div class="card-body">
        <p class="card-eyebrow">${esc(brandName)}</p>
        <h3 class="card-title"><a href="#/mogelijkheden/${r.slug}">${esc(r.title)}</a></h3>
        ${st ? `<div class="card-meta">${Compat.badge(st)}</div>` : ''}
        <div class="card-foot"><span class="link">Bekijk deze optie</span></div>
      </div>
    </article>`;
  },
  productFit(p, v = VehicleStore.get()) {
    if (!v) return null;
    const c = p.compatibility || {};
    if (v.modelId && (c.models || []).includes(v.modelId)) return 'model';
    if (!(c.models || []).length && (!(c.brands || []).length || c.brands.includes(v.brandId))) return 'brand';
    if ((c.models || []).length && (c.brands || []).includes(v.brandId)) return null;
    return null;
  },
  productCard(p, { vehicle = VehicleStore.get() } = {}) {
    const pr = Pricing.calc(p);
    const st = Stock.status(p);
    const fit = this.productFit(p, vehicle);
    const cat = Repo.shopCategory(p.category);
    return `<article class="card product-card">
      <div class="card-media">${Media.html(p.images[0], p.name, { kind: productArtKind(p) })}
        <div class="badges">
          ${pr.onSale ? `<span class="badge badge--sale">−${pr.pct}%</span>` : ''}
          ${p.featured ? '<span class="badge badge--featured">Uitgelicht</span>' : ''}
          ${st.key === 'out' ? '<span class="badge badge--soldout">Uitverkocht</span>' : ''}
          ${fit === 'model' ? `<span class="badge badge--fit">Voor uw ${esc(VehicleStore.short(vehicle))}</span>` : ''}
        </div>
        ${this.saveBtn('products', p.id, p.name)}
      </div>
      <div class="card-body">
        <p class="card-eyebrow card-eyebrow--muted">${esc(cat ? cat.name : 'Webshop')}</p>
        <h3 class="card-title"><a href="#/webshop/${p.slug}">${esc(p.name)}</a></h3>
        <p class="card-text">${esc(p.shortDescription)}</p>
        <div class="mt-8">${Pricing.html(p)}</div>
        ${Stock.html(p)}
        <div class="pc-actions">
          <a class="btn btn--light btn--sm" href="#/webshop/${p.slug}">Bekijk</a>
          <button class="btn btn--dark btn--sm" type="button" data-action="add-to-cart" data-id="${p.id}"${st.key === 'out' ? ' disabled' : ''}>${icon('cart')} ${st.key === 'out' ? 'Uitverkocht' : 'In winkelmand'}</button>
        </div>
      </div>
    </article>`;
  },
  projectCard(p) {
    return `<article class="card project-card" data-type="${attr(p.type)}" data-brands="${attr((p.brands || []).join(' '))}">
      <div class="card-media">${Media.html(p.image, `${p.title} — ${p.vehicle}`, { kind: 'camera' })}<span class="media-tag">${esc(p.tag)}</span></div>
      <div class="card-body">
        <p class="card-eyebrow">${esc(p.vehicle)}</p>
        <h3 class="card-title"><a href="#/projecten/${p.slug}">${esc(p.title)}</a></h3>
        <p class="card-text">${esc(p.short)}</p>
        <div class="card-foot"><span class="link">Bekijk het project</span></div>
      </div>
    </article>`;
  },
  empty({ icon: ic = 'search', title, text = '', actions = '' }) {
    return `<div class="empty"><div class="e-icon">${icon(ic)}</div><p class="e-title">${esc(title)}</p>${text ? `<p>${text}</p>` : ''}${actions ? `<div class="e-actions">${actions}</div>` : ''}</div>`;
  },
  notice(html, { type = '', ic = 'info', actions = '' } = {}) {
    return `<div class="notice${type ? ` notice--${type}` : ''}">${icon(ic)}<div class="n-body">${html}${actions ? `<div class="n-actions">${actions}</div>` : ''}</div></div>`;
  },
  accordion(items) {
    return `<div class="accordion" data-accordion>${items.map((it, i) => {
      const id = uid('acc');
      return `<div class="acc-item${it.open ? ' is-open' : ''}">
        <h3><button class="acc-trigger" type="button" aria-expanded="${!!it.open}" aria-controls="${id}" id="${id}_t">${esc(it.title)}<span class="acc-icon" aria-hidden="true"></span></button></h3>
        <div class="acc-panel" id="${id}" role="region" aria-labelledby="${id}_t"><div><div class="acc-content">${it.html}</div></div></div>
      </div>`;
    }).join('')}</div>`;
  },
  miniItem(entry) {
    const isR = entry.type === 'retrofit';
    const it = entry.item;
    const href = isR ? `#/mogelijkheden/${it.slug}` : `#/webshop/${it.slug}`;
    const media = isR ? Media.html(retrofitImage(it), it.title, { kind: it.art }) : Media.html(it.images[0], it.name, { kind: productArtKind(it) });
    return `<div class="mini-item">
      <div class="mi-media">${media}</div>
      <div><div class="mi-type">${isR ? 'Retrofit' : 'Product'}</div><a class="mi-title stretch" href="${href}">${esc(isR ? it.title : it.name)}</a></div>
      <div class="mi-aside">${isR ? '' : `<span class="text-small tabular" style="font-weight:600">${Money.fmt(Pricing.calc(it).price)}</span>`}</div>
    </div>`;
  },
  qty({ id, value, max, size = '', label = 'Aantal' }) {
    return `<div class="qty${size ? ` qty--${size}` : ''}" data-qty="${attr(id)}">
      <button type="button" data-step="-1" aria-label="Minder"${value <= 1 ? ' disabled' : ''}>${icon('minus')}</button>
      <input type="number" inputmode="numeric" min="1" max="${max}" value="${value}" aria-label="${attr(label)}">
      <button type="button" data-step="1" aria-label="Meer"${value >= max ? ' disabled' : ''}>${icon('plus')}</button>
    </div>`;
  },
  beforeAfter(before, after, alt) {
    return `<div class="ba" data-ba style="--pos:50%">
      <img src="${attr(Media.src(before))}" alt="Voor: ${attr(alt)}" loading="lazy">
      <img class="ba-after" src="${attr(Media.src(after))}" alt="Na: ${attr(alt)}" loading="lazy">
      <span class="ba-label l">Voor</span><span class="ba-label r">Na</span>
      <input type="range" min="0" max="100" value="50" step="1" aria-label="Vergelijk voor en na">
      <span class="ba-handle" aria-hidden="true"></span>
    </div>`;
  },
  gallery(images, alt, kind) {
    const imgs = images.length ? images : [`art:${kind}:0`];
    return `<div class="gallery" data-gallery>
      <div class="gallery-main" aria-roledescription="carrousel" aria-label="Afbeeldingen van ${attr(alt)}">
        ${imgs.map((src, i) => `<div class="g-slide${i === 0 ? ' is-active' : ''}" role="group" aria-roledescription="dia" aria-label="${i + 1} van ${imgs.length}"${i ? ' aria-hidden="true"' : ''}>${Media.html(src, `${alt} (${i + 1})`, { kind, eager: i === 0 })}</div>`).join('')}
        ${imgs.length > 1 ? `<button class="gallery-nav prev" type="button" data-g="-1" aria-label="Vorige afbeelding">${icon('left')}</button>
        <button class="gallery-nav next" type="button" data-g="1" aria-label="Volgende afbeelding">${icon('right')}</button>
        <span class="gallery-count" aria-hidden="true"><span data-g-index>1</span> / ${imgs.length}</span>` : ''}
      </div>
      ${imgs.length > 1 ? `<div class="gallery-thumbs" role="group" aria-label="Kies een afbeelding">${imgs.map((src, i) => `<button type="button" data-g-to="${i}" aria-label="Afbeelding ${i + 1}" aria-current="${i === 0}">${Media.html(src, '', { kind })}</button>`).join('')}</div>` : ''}
    </div>`;
  },
};

/* Behaviour for components rendered as HTML strings */
const Behaviours = {
  mount(root) {
    // Accordions
    $$('[data-accordion] .acc-trigger', root).forEach((btn) => {
      btn.addEventListener('click', () => {
        const item = btn.closest('.acc-item');
        const open = !item.classList.contains('is-open');
        item.classList.toggle('is-open', open);
        btn.setAttribute('aria-expanded', String(open));
      });
    });
    // Galleries
    $$('[data-gallery]', root).forEach((g) => {
      const slides = $$('.g-slide', g); const thumbs = $$('[data-g-to]', g);
      if (slides.length < 2) return;
      let i = 0;
      const show = (n) => {
        i = (n + slides.length) % slides.length;
        slides.forEach((s, k) => { s.classList.toggle('is-active', k === i); s.setAttribute('aria-hidden', String(k !== i)); });
        thumbs.forEach((t, k) => t.setAttribute('aria-current', String(k === i)));
        const idx = $('[data-g-index]', g); if (idx) idx.textContent = String(i + 1);
      };
      g.addEventListener('click', (e) => {
        const nav = e.target.closest('[data-g]'); if (nav) show(i + Number(nav.dataset.g));
        const to = e.target.closest('[data-g-to]'); if (to) show(Number(to.dataset.gTo));
      });
      const main = $('.gallery-main', g);
      main.tabIndex = 0;
      main.addEventListener('keydown', (e) => { if (e.key === 'ArrowRight') show(i + 1); if (e.key === 'ArrowLeft') show(i - 1); });
      let sx = null; let sy = null;
      main.addEventListener('touchstart', (e) => { sx = e.touches[0].clientX; sy = e.touches[0].clientY; }, { passive: true });
      main.addEventListener('touchend', (e) => {
        if (sx == null) return;
        const dx = e.changedTouches[0].clientX - sx; const dy = e.changedTouches[0].clientY - sy;
        if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy)) show(i + (dx < 0 ? 1 : -1));
        sx = null;
      });
    });
    // Before / after sliders (mouse, touch and keyboard via the native range input)
    $$('[data-ba]', root).forEach((ba) => {
      const input = $('input[type="range"]', ba);
      const set = (v) => ba.style.setProperty('--pos', `${clamp(Number(v), 0, 100)}%`);
      input.addEventListener('input', () => set(input.value));
    });
    // Quantity steppers (generic: dispatch a change event on the input)
    $$('[data-qty]', root).forEach((q) => {
      const input = $('input', q);
      q.addEventListener('click', (e) => {
        const b = e.target.closest('[data-step]'); if (!b) return;
        const max = Number(input.max) || 99;
        input.value = clamp((parseInt(input.value, 10) || 1) + Number(b.dataset.step), 1, max);
        input.dispatchEvent(new Event('change', { bubbles: true }));
      });
      input.addEventListener('change', () => {
        const max = Number(input.max) || 99;
        input.value = clamp(parseInt(input.value, 10) || 1, 1, max);
        $('[data-step="-1"]', q).disabled = Number(input.value) <= 1;
        $('[data-step="1"]', q).disabled = Number(input.value) >= max;
      });
    });
  },
};

/* ---------- Vehicle finder (kenteken + manual) ---------- */
let finderSeq = 0;
const VehicleFinder = {
  html({ tab = 'plate', context = 'home', tabs = true } = {}) {
    const id = `fx${++finderSeq}`;
    const brandOpts = BRANDS.map((b) => `<option value="${b.id}">${esc(b.name)}</option>`).join('');
    const panelAttrs = (name) => (tabs ? `role="tabpanel" id="${id}-p-${name}" aria-labelledby="${id}-t-${name}"` : `id="${id}-p-${name}"`);
    return `<div class="finder${tabs ? '' : ' finder--simple'}" data-finder data-context="${context}" data-id="${id}">
      ${tabs ? `<div class="segmented finder-tabs" role="tablist" aria-label="Zoek uw auto">
        <button type="button" role="tab" id="${id}-t-plate" aria-controls="${id}-p-plate" aria-selected="${tab === 'plate'}" tabindex="${tab === 'plate' ? 0 : -1}" data-tab="plate">${icon('search')} Kenteken<span class="hide-xs">&nbsp;invullen</span></button>
        <button type="button" role="tab" id="${id}-t-manual" aria-controls="${id}-p-manual" aria-selected="${tab === 'manual'}" tabindex="${tab === 'manual' ? 0 : -1}" data-tab="manual">${icon('car')} Handmatig<span class="hide-xs">&nbsp;selecteren</span></button>
      </div>` : ''}
      <div ${panelAttrs('plate')} data-panel="plate"${tab === 'plate' ? '' : ' hidden'}>
        <form class="finder-form finder-form--plate" data-plate-form novalidate>
          <div class="field">
            <label for="${id}-plate">Kenteken</label>
            <div class="plate" data-plate-box><span class="plate-eu" aria-hidden="true">${EU_STARS}NL</span>
              <input id="${id}-plate" name="plate" type="text" inputmode="text" autocomplete="off" autocapitalize="characters" spellcheck="false" maxlength="12" placeholder="AB-123-C" aria-describedby="${id}-plate-hint ${id}-plate-err">
            </div>
            <span class="field-error" id="${id}-plate-err" data-plate-err></span>
          </div>
          <button class="btn btn--primary" type="submit" data-plate-submit>${icon('search')} Zoek voertuig</button>
        </form>
        <div class="finder-foot">
          <span id="${id}-plate-hint">Uw auto wordt opgezocht via RDW Open Data. Het kenteken bewaren we alleen tijdelijk in deze browser.</span>
          <button type="button" data-demo-toggle aria-expanded="false">Demo-kentekens</button>
          ${tabs ? '' : '<button type="button" data-tab="manual">Liever merk en model kiezen</button>'}
        </div>
        <div class="demo-plates" data-demo-list hidden>
          <span class="lbl">Testkentekens (demo-gegevens, geen RDW):</span>
          ${DEMO_PLATE_LIST.map(([k, lbl]) => `<button type="button" data-demo-plate="${k}">${Plate.format(k)}<span>${esc(lbl || DEMO_VEHICLES[k]._hint)}</span></button>`).join('')}
        </div>
      </div>
      <div ${panelAttrs('manual')} data-panel="manual"${tab === 'manual' ? '' : ' hidden'}>
        <form class="finder-form finder-form--manual" data-manual-form novalidate>
          <div class="field"><label for="${id}-brand">1. Merk</label>
            <select class="select" id="${id}-brand" name="brand" aria-describedby="${id}-model-err"><option value="">Kies uw merk</option>${brandOpts}</select></div>
          <div class="field"><label for="${id}-model">2. Model / generatie</label>
            <select class="select" id="${id}-model" name="model" disabled aria-describedby="${id}-model-err"><option value="">Kies uw model</option></select>
            <span class="field-error" id="${id}-model-err" data-model-err></span></div>
          <div class="field finder-year"${tabs ? '' : ' hidden'}><label for="${id}-year">3. Bouwjaar <span class="opt">(optioneel)</span></label>
            <select class="select" id="${id}-year" name="year" disabled><option value="">Onbekend</option></select></div>
          <button class="btn btn--primary" type="submit">${icon('search')} Bekijk mogelijkheden</button>
        </form>
        <div class="finder-foot"><span>Uw model staat er niet bij? <a href="#/contact">Vraag naar de mogelijkheden.</a></span>
          ${tabs ? '' : '<span>Liever zoeken op kenteken? <button type="button" data-tab="plate">Zoek op kenteken</button></span>'}</div>
      </div>
      <div class="finder-result" data-result aria-live="polite"></div>
    </div>`;
  },

  mount(root, { onDone } = {}) {
    const finder = root.matches && root.matches('[data-finder]') ? root : $('[data-finder]', root);
    if (!finder) return;
    const tabs = $$('[data-tab]', finder);
    const result = $('[data-result]', finder);
    const plateInput = $('input[name="plate"]', finder);
    const plateBox = $('[data-plate-box]', finder);
    const plateErr = $('[data-plate-err]', finder);
    const brandSel = $('select[name="brand"]', finder);
    const modelSel = $('select[name="model"]', finder);
    const yearSel = $('select[name="year"]', finder);
    const modelErr = $('[data-model-err]', finder);
    let busy = false;

    const roleTabs = tabs.filter((t) => t.getAttribute('role') === 'tab');
    const selectTab = (name, focus = false) => {
      $$('[data-panel]', finder).forEach((p) => { p.hidden = p.dataset.panel !== name; });
      roleTabs.forEach((t) => {
        const on = t.dataset.tab === name;
        t.setAttribute('aria-selected', String(on)); t.tabIndex = on ? 0 : -1;
        if (on && focus) t.focus();
      });
      // Without tabs (home), move focus into the newly shown panel.
      if (focus && !roleTabs.length) { const f = $(`[data-panel="${name}"] input, [data-panel="${name}"] select`, finder); if (f) f.focus(); }
    };
    tabs.forEach((t) => t.addEventListener('click', () => { selectTab(t.dataset.tab, !roleTabs.length); result.innerHTML = ''; }));
    const tablist = $('[role="tablist"]', finder);
    if (tablist) tablist.addEventListener('keydown', (e) => {
      if (!['ArrowLeft', 'ArrowRight'].includes(e.key)) return;
      const cur = roleTabs.findIndex((t) => t.getAttribute('aria-selected') === 'true');
      selectTab(roleTabs[(cur + (e.key === 'ArrowRight' ? 1 : -1) + roleTabs.length) % roleTabs.length].dataset.tab, true);
    });

    // Prefill manual selects with the current vehicle
    const fillModels = () => {
      const b = brandSel.value;
      modelSel.innerHTML = `<option value="">Kies uw model</option>${MODELS.filter((m) => m.brand === b).map((m) => `<option value="${m.id}">${esc(m.name)} (${modelYears(m)})</option>`).join('')}`;
      modelSel.disabled = !b;
      fillYears();
    };
    const fillYears = () => {
      const m = MODEL[modelSel.value];
      const nowY = new Date().getFullYear();
      yearSel.innerHTML = '<option value="">Onbekend</option>' + (m ? Array.from({ length: Math.min(m.to || nowY, nowY) - m.from + 1 }, (_, i) => (m.to ? Math.min(m.to, nowY) : nowY) - i).map((y) => `<option value="${y}">${y}</option>`).join('') : '');
      yearSel.disabled = !m;
      const yf = yearSel.closest('.finder-year');
      if (yf && finder.classList.contains('finder--simple')) yf.hidden = !m;
    };
    brandSel.addEventListener('change', () => { fillModels(); modelErr.textContent = ''; modelSel.removeAttribute('aria-invalid'); brandSel.removeAttribute('aria-invalid'); });
    modelSel.addEventListener('change', () => { fillYears(); modelErr.textContent = ''; modelSel.removeAttribute('aria-invalid'); });
    // Prefill the manual selects with the chosen car (at mount and when "Wijzig" opens them after a plate match).
    const prefill = () => {
      const cur = VehicleStore.get();
      if (!cur) return;
      brandSel.value = cur.brandId; fillModels();
      if (cur.modelId) { modelSel.value = cur.modelId; fillYears(); }
      if (cur.year) yearSel.value = String(cur.year);
    };
    prefill();

    $('[data-manual-form]', finder).addEventListener('submit', (e) => {
      e.preventDefault();
      if (!brandSel.value) { brandSel.focus(); brandSel.setAttribute('aria-invalid', 'true'); modelErr.textContent = 'Kies eerst uw merk.'; return; }
      brandSel.removeAttribute('aria-invalid');
      if (!modelSel.value) { modelSel.setAttribute('aria-invalid', 'true'); modelErr.textContent = 'Kies uw model of generatie.'; modelSel.focus(); return; }
      const v = VehicleStore.set({ brandId: brandSel.value, modelId: modelSel.value, year: yearSel.value ? Number(yearSel.value) : null, source: 'manual', confidence: 'manual' });
      if (onDone) onDone(v, { via: 'manual' });
    });

    // Plate input: normalise as the user types
    plateInput.addEventListener('input', () => {
      const raw = plateInput.value;
      const formatted = Plate.format(raw);
      const compact = Plate.compact(raw);
      plateInput.value = formatted || compact.slice(0, 8);
      plateBox.classList.remove('is-invalid'); plateErr.textContent = '';
      plateInput.removeAttribute('aria-invalid');
    });
    const curPlate = VehicleStore.plate();
    if (curPlate) plateInput.value = curPlate;

    const demoToggle = $('[data-demo-toggle]', finder);
    const demoList = $('[data-demo-list]', finder);
    const showDemo = (on) => { demoList.hidden = !on; demoToggle.setAttribute('aria-expanded', String(on)); };
    demoToggle.addEventListener('click', () => showDemo(demoList.hidden));
    demoList.addEventListener('click', (e) => {
      const b = e.target.closest('[data-demo-plate]'); if (!b) return;
      plateInput.value = Plate.format(b.dataset.demoPlate);
      $('[data-plate-form]', finder).requestSubmit ? $('[data-plate-form]', finder).requestSubmit() : $('[data-plate-submit]', finder).click();
    });

    const runLookup = async () => {
      if (busy) return;
      const value = plateInput.value;
      if (!Plate.isValid(value)) {
        plateBox.classList.add('is-invalid'); plateInput.setAttribute('aria-invalid', 'true');
        plateErr.textContent = value.trim() ? 'Dit is geen geldig Nederlands kenteken. Bijvoorbeeld: AB-123-C of 12-AB-34.' : 'Vul uw kenteken in.';
        plateInput.focus();
        return;
      }
      busy = true;
      const submit = $('[data-plate-submit]', finder);
      submit.classList.add('is-loading'); submit.setAttribute('aria-busy', 'true');
      result.innerHTML = `<div class="state-card"><div class="loading-dot" aria-hidden="true"></div>
        <div><div class="sc-kicker" style="color:var(--muted)">Voertuig zoeken</div><div class="sc-title" style="font-size:16px">${plateChip(Plate.format(value))}</div>
        <div class="mt-8" style="display:grid;gap:8px;max-width:320px"><div class="skeleton-line" style="width:80%"></div><div class="skeleton-line" style="width:55%"></div></div></div></div>`;
      const res = await VehicleLookup.lookup(value);
      busy = false;
      submit.classList.remove('is-loading'); submit.removeAttribute('aria-busy');
      if (res.status === 'invalid') { result.innerHTML = ''; plateBox.classList.add('is-invalid'); plateErr.textContent = 'Dit is geen geldig Nederlands kenteken.'; return; }
      this.renderResult(finder, res, { onDone, selectTab, showDemo, retry: runLookup, prefill });
    };
    $('[data-plate-form]', finder).addEventListener('submit', (e) => { e.preventDefault(); runLookup(); });
  },

  renderResult(finder, res, { onDone, selectTab, showDemo, retry, prefill = () => {} }) {
    const result = $('[data-result]', finder);
    const srcTag = res.source === 'demo'
      ? `<span class="demo-flag">${icon('info')} Demo-gegevens</span>`
      : `<span class="source-tag">${icon('check')} Bron: RDW Open Data</span>`;
    const rdwTitle = `${titleCase(res.rdwBrand)} ${titleCase(res.rdwName)}`.trim();
    const contactBtns = `<a class="btn btn--dark btn--sm" href="#/contact">Contact opnemen</a>
      <a class="btn btn--whatsapp btn--sm" href="${WhatsApp.url(WhatsApp.enquiry({ vehicle: rdwTitle || 'onbekend', plate: res.plate, year: res.year, question: 'Welke mogelijkheden zijn er voor mijn auto?' }))}" target="_blank" rel="noopener" data-action="whatsapp">${icon('whatsapp')} WhatsApp</a>`;
    const manualBtn = '<button class="btn btn--light btn--sm" type="button" data-r="manual">Kies een andere auto</button>';
    let html = '';
    const card = (variant, ic, kicker, title, body, actions, extra = '') => `<div class="state-card state-card--${variant}" data-state>
      <div class="sc-icon">${icon(ic)}</div>
      <div><div class="sc-kicker">${kicker}</div><div class="sc-title">${title}</div>${body}</div>
      <div class="sc-actions">${actions}</div>${extra}</div>`;

    const matched = (modelId, confidence) => {
      const v = VehicleStore.set({ brandId: res.brandId, modelId, year: res.year, body: res.body, source: res.source, confidence, rdwName: res.rdwName }, { plate: res.plate });
      const n = Compat.forVehicle(v).length;
      const m = MODEL[modelId];
      const note = { year: `Generatie (${m.name}) bepaald op basis van het bouwjaar.`, user: 'Generatie door u gekozen.', unverified: `Let op: de generatie (${m.name}) kon niet met zekerheid worden bepaald. Klopt dit niet? Kies uw auto handmatig.` }[confidence] || '';
      result.innerHTML = card('ok', 'check', 'Voertuig gevonden', esc(VehicleStore.name(v)),
        `<div class="sc-meta">${plateChip(res.plate)}<span>${esc(VehicleStore.meta(v))}</span>${srcTag}</div>`,
        `<a class="btn btn--primary btn--sm" href="#/mogelijkheden" data-r="done">Bekijk mogelijkheden${n ? ` (${n})` : ''}</a>${manualBtn.replace('Kies een andere auto', 'Wijzig')}`,
        `<p class="sc-note">${note ? `${esc(note)} ` : ''}${esc(Compat.disclaimer)}</p>`);
      Motion.vehicleFound($('[data-state]', result));
      announce(`Voertuig gevonden: ${VehicleStore.name(v)}`);
      $('[data-r="done"]', result).addEventListener('click', (e) => { if (onDone) { e.preventDefault(); onDone(v, { via: 'plate' }); } });
    };

    switch (res.status) {
      case 'matched': matched(res.modelId, res.confidence); break;
      case 'ambiguous':
        html = card('warn', 'info', 'Generatie kiezen', `${esc(BRAND[res.brandId].name)} ${esc(MODEL[res.options[0]].base)} · ${res.year}`,
          `<p class="sc-text">Het bouwjaar valt in de overgang tussen twee generaties. Kies de juiste generatie:</p>`,
          '', `<div class="sc-options">${res.options.map((id) => `<button class="chip" type="button" data-gen="${id}">${esc(MODEL[id].name)} <span class="n">${modelYears(MODEL[id])}</span></button>`).join('')}</div>
          <p class="sc-note">${plateChip(res.plate)} ${srcTag}</p>`);
        break;
      case 'generation_unknown':
        html = card('warn', 'info', 'Generatie niet in online catalogus', `${esc(BRAND[res.brandId].name)} ${esc(res.baseName)}${res.year ? ` · ${res.year}` : ''}`,
          `<p class="sc-text">Voor deze generatie hebben we momenteel geen online mogelijkheden. Neem contact op — CarTronic bekijkt graag wat er mogelijk is.</p><div class="sc-meta">${plateChip(res.plate)}${srcTag}</div>`,
          contactBtns + manualBtn);
        break;
      case 'unknown_model':
        html = card('warn', 'info', 'Model niet in online catalogus', esc(rdwTitle || BRAND[res.brandId].name) + (res.year ? ` · ${res.year}` : ''),
          `<p class="sc-text">Voor dit voertuig hebben we momenteel geen online mogelijkheden beschikbaar.</p><div class="sc-meta">${plateChip(res.plate)}${srcTag}</div>`,
          contactBtns + manualBtn);
        break;
      case 'unsupported_brand':
        html = card('warn', 'info', 'Merk niet ondersteund', esc(rdwTitle) + (res.year ? ` · ${res.year}` : ''),
          `<p class="sc-text">CarTronic is gespecialiseerd in Volkswagen, Audi, SEAT en Škoda. Voor dit voertuig hebben we momenteel geen online mogelijkheden beschikbaar.</p><div class="sc-meta">${plateChip(res.plate)}${srcTag}</div>`,
          '<a class="btn btn--dark btn--sm" href="#/contact">Contact opnemen</a>' + manualBtn);
        break;
      case 'unsupported_kind':
        html = card('warn', 'info', 'Voertuigsoort niet ondersteund', esc(rdwTitle || res.plate),
          `<p class="sc-text">Dit kenteken hoort bij een ${esc(String(res.kind || '').toLowerCase())}. Onze online catalogus richt zich op personen- en bedrijfsauto’s.</p>`,
          '<a class="btn btn--dark btn--sm" href="#/contact">Contact opnemen</a>' + manualBtn);
        break;
      case 'not_found':
        html = card('error', 'alertCircle', 'Kenteken niet gevonden', plateChip(res.plate),
          `<p class="sc-text">Bij dit kenteken vonden we geen voertuig${res.source === 'demo' ? ' (demo)' : ' in de RDW-gegevens'}. Controleer het kenteken of kies uw auto handmatig.</p>`,
          '<button class="btn btn--dark btn--sm" type="button" data-r="edit">Kenteken aanpassen</button><button class="btn btn--light btn--sm" type="button" data-r="manual">Handmatig selecteren</button>');
        break;
      default: // unavailable
        html = card('warn', 'alert', 'RDW tijdelijk niet bereikbaar', 'Voertuiggegevens konden niet worden opgehaald',
          '<p class="sc-text">De RDW-gegevens zijn op dit moment niet bereikbaar. Probeer het opnieuw, kies uw auto handmatig of gebruik een demo-kenteken om de werking te bekijken.</p>',
          '<button class="btn btn--dark btn--sm" type="button" data-r="retry">Opnieuw proberen</button><button class="btn btn--light btn--sm" type="button" data-r="manual">Handmatig selecteren</button><button class="btn btn--ghost btn--sm" type="button" data-r="demo">Demo-kentekens</button>');
    }
    if (html) { result.innerHTML = html; Motion.vehicleFound($('[data-state]', result)); }
    result.onclick = (e) => {
      const g = e.target.closest('[data-gen]');
      if (g) { matched(g.dataset.gen, 'user'); return; }
      const r = e.target.closest('[data-r]'); if (!r) return;
      const act = r.dataset.r;
      if (act === 'manual') { e.preventDefault(); result.innerHTML = ''; prefill(); selectTab('manual', true); }
      if (act === 'edit') { result.innerHTML = ''; const inp = $('input[name="plate"]', finder); inp.focus(); inp.select(); }
      if (act === 'retry') retry();
      if (act === 'demo') showDemo(true);
    };
  },
};

/* ---------- Vehicle modal ("Uw auto") ---------- */
const VehicleModal = {
  open() {
    const v = VehicleStore.get();
    const plate = VehicleStore.plate();
    const current = v ? `<div class="vehicle-hero" style="padding:20px 22px;margin-bottom:24px">
        <div><div class="vh-kicker">Huidige auto</div><h2 style="font-size:22px">${esc(VehicleStore.name(v))}</h2>
          <div class="vh-meta">${plate ? plateChip(plate) : ''}<span>${esc(VehicleStore.meta(v))}</span><span>${esc(VehicleStore.sourceLabel(v))}</span></div></div>
        <div class="vh-actions"><a class="btn btn--dark btn--sm" href="#/mogelijkheden">Mogelijkheden</a><button class="btn btn--light btn--sm" type="button" data-clear-vehicle>Verwijderen</button></div>
      </div><p class="label" style="margin-bottom:12px">Andere auto kiezen</p>` : '';
    Overlay.open({
      title: v ? 'Uw auto' : 'Kies uw auto', size: 'wide',
      body: `${current}${VehicleFinder.html({ tab: 'plate', context: 'modal' })}
        <p class="hint mt-16">${esc(Compat.disclaimer)}</p>`,
      onMount(panel, close) {
        VehicleFinder.mount(panel, {
          onDone(veh, { via }) {
            close();
            Toast.show(`Uw auto is ingesteld: ${VehicleStore.name(veh)}`, { action: { label: 'Mogelijkheden', href: '#/mogelijkheden' } });
            const path = Router.current && Router.current.path;
            // Catalog, home and garage jump to the options for this car; detail pages re-render in place.
            if (path !== '/contact' && (via === 'plate' || ['/', '/mijn-auto', '/mogelijkheden'].includes(path))) Router.go('/mogelijkheden'); else Router.render();
          },
        });
        const clr = $('[data-clear-vehicle]', panel);
        if (clr) clr.addEventListener('click', () => { VehicleStore.clear(); close(); Toast.show('Uw auto is verwijderd.'); Router.render(); });
        // Links inside the dialog lead to another page: close it first.
        panel.addEventListener('click', (e) => { const a = e.target.closest('a[href]'); if (a && isAppLink(a) && plainClick(e)) close(); });
      },
    });
  },
};

/* ---------- Search overlay with autocomplete ---------- */
const SearchOverlay = {
  open(initial = '') {
    const id = uid('sr');
    const v = VehicleStore.get();
    const suggestions = ['Achteruitrijcamera', 'CarPlay', 'ACC kalibratie', 'Virtual Cockpit', 'Trekhaak', 'Inklapbare spiegels', 'Parkeersensoren'];
    Overlay.open({
      kind: 'raw', className: 'search-panel', labelledBy: `${id}_label`,
      body: `<h2 class="sr-only" id="${id}_label">Zoeken</h2>
        <div class="search-field">${icon('search')}
          <input type="text" role="combobox" aria-expanded="false" aria-controls="${id}_list" aria-autocomplete="list" aria-label="Zoek opties, diensten, producten of projecten" placeholder="Zoek op optie, model, dienst of product…" autocomplete="off" spellcheck="false" value="${attr(initial)}">
          <span class="kbd-hint"><button class="kbd" type="button" data-close aria-label="Sluiten">Esc</button></span>
        </div>
        <div class="search-results" id="${id}_list" role="listbox" aria-label="Zoekresultaten"></div>
        <div class="search-foot"><span class="keys"><span><span class="kbd">↑</span> <span class="kbd">↓</span> navigeren</span><span><span class="kbd">Enter</span> openen</span></span><a href="#/zoeken" data-all class="text-link">Alle resultaten</a></div>`,
      initialFocus: 'input',
      onMount(panel, close) {
        const input = $('input', panel); const list = $(`#${id}_list`, panel); const all = $('[data-all]', panel);
        let active = -1; let results = [];
        const setActive = (i) => {
          const opts = $$('[role="option"]', list);
          active = opts.length ? (i + opts.length) % opts.length : -1;
          opts.forEach((o, k) => o.setAttribute('aria-selected', String(k === active)));
          if (active > -1) { input.setAttribute('aria-activedescendant', opts[active].id); opts[active].scrollIntoView({ block: 'nearest' }); } else input.removeAttribute('aria-activedescendant');
        };
        const renderEmpty = () => {
          list.innerHTML = `<div class="search-suggest"><div class="search-group-label" style="padding:0 0 4px">Veelgezocht</div>
            <div class="chips">${suggestions.map((s) => `<button class="chip" type="button" data-suggest="${attr(s)}">${esc(s)}</button>`).join('')}
            ${v ? `<a class="chip" href="#/mogelijkheden">${icon('car')} Opties voor uw ${esc(VehicleStore.short(v))}</a>` : ''}</div></div>`;
          input.setAttribute('aria-expanded', 'false');
          all.href = '#/zoeken';
        };
        const run = () => {
          const q = input.value.trim();
          all.href = `#/zoeken?q=${encodeURIComponent(q)}`;
          if (q.length < 2) { results = []; renderEmpty(); return; }
          results = Search.query(q, { limit: 9, perType: 3 });
          input.setAttribute('aria-expanded', String(results.length > 0));
          if (!results.length) {
            list.innerHTML = `<div class="search-empty">Geen resultaten voor “${esc(q)}”.<br><span class="text-small">Probeer een andere term, of <a class="text-link" href="#/contact">vraag het ons</a>.</span></div>`;
            active = -1; return;
          }
          const groups = Search.TYPE_ORDER.map((t) => [t, results.filter((r) => r.type === t)]).filter(([, r]) => r.length);
          let n = 0;
          list.innerHTML = groups.map(([t, rs]) => `<div class="search-group" role="group" aria-label="${Search.TYPE_LABEL[t]}">
            ${rs.map((r) => `<a class="search-option" role="option" id="${id}_o${n++}" href="${attr(r.href)}" aria-selected="false">
              <span class="so-type" data-type="${r.type}">${Search.TYPE_LABEL[r.type]}</span>
              <span><span class="so-title">${Search.highlight(r.title, q)}</span><span class="so-sub" style="display:block">${esc(r.sub || '')}</span></span>
              ${icon('arrow', 'so-go')}</a>`).join('')}</div>`).join('');
          setActive(0);
        };
        const debounced = debounce(run, 90);
        input.addEventListener('input', debounced);
        input.addEventListener('keydown', (e) => {
          if (e.key === 'ArrowDown') { e.preventDefault(); setActive(active + 1); }
          else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(active - 1); }
          else if (e.key === 'Enter') {
            e.preventDefault();
            const opts = $$('[role="option"]', list);
            if (active > -1 && opts[active]) { close(); Router.go(opts[active].getAttribute('href')); }
            else if (input.value.trim().length >= 2) { close(); Router.go('/zoeken', { q: input.value.trim() }); }
          }
        });
        list.addEventListener('click', (e) => {
          const s = e.target.closest('[data-suggest]');
          if (s) { input.value = s.dataset.suggest; run(); input.focus(); return; }
          if (e.target.closest('a') && plainClick(e)) close();
        });
        list.addEventListener('mousemove', (e) => {
          const o = e.target.closest('[role="option"]'); if (!o) return;
          const idx = $$('[role="option"]', list).indexOf(o); if (idx !== active) setActive(idx);
        });
        all.addEventListener('click', (e) => { if (plainClick(e)) close(); }); // a new-tab click keeps the search open
        run();
      },
    });
  },
};

/* ---------- Cart UI: drawer + mini cart ---------- */
const CartUI = {
  linesHtml(lines) {
    if (!lines.length) return UI.empty({ icon: 'cart', title: 'Uw winkelmand is leeg', text: 'Bekijk de webshop of bewaar eerst de opties die u interesseren.', actions: '<a class="btn btn--dark btn--sm" href="#/webshop">Naar de webshop</a>' });
    return `<div class="cart-lines">${lines.map((l) => `<div class="cart-line" data-line="${l.product.id}">
      <div class="cl-media">${Media.html(l.product.images[0], l.product.name, { kind: productArtKind(l.product) })}</div>
      <div>
        <div class="cl-title"><a href="#/webshop/${l.product.slug}">${esc(l.product.name)}</a></div>
        <div class="cl-meta">${Money.fmt(l.unitPrice)} per stuk${l.pricing.onSale ? ` · <span style="color:var(--red)">−${l.pricing.pct}%</span>` : ''}</div>
        <div class="cl-row">
          ${UI.qty({ id: l.product.id, value: l.qty, max: Stock.max(l.product), size: 'sm', label: `Aantal ${l.product.name}` })}
          <div class="cl-total">${l.pricing.onSale ? `<small>${Money.fmt(l.lineRegular)}</small>` : ''}${Money.fmt(l.lineTotal)}</div>
        </div>
        <button class="cl-remove mt-8" type="button" data-remove="${l.product.id}">Verwijderen</button>
      </div></div>`).join('')}</div>`;
  },
  totalsHtml(t, { shippingLabel = 'Verzending', shippingKnown = false } = {}) {
    return `<div class="totals">
      ${t.discountTotal ? `<div class="t-row"><span>Subtotaal (normale prijs)</span><span>${Money.fmt(t.subtotalRegular)}</span></div>
      <div class="t-row is-discount"><span>Korting</span><span>−${Money.fmt(t.discountTotal)}</span></div>` : ''}
      <div class="t-row"><span>Subtotaal</span><span>${Money.fmt(t.subtotal)}</span></div>
      <div class="t-row"><span>${esc(shippingLabel)}</span><span>${shippingKnown ? (t.shipping ? Money.fmt(t.shipping) : Money.fmt(0)) : 'Bij afrekenen'}</span></div>
      <div class="t-row is-total"><span>Totaal</span><span>${Money.fmt(t.total)}</span></div>
      ${t.vat.included && Repo.settings().vat.showBreakdown ? `<div class="t-row is-sub"><span>Waarvan btw (${t.vat.rate}%)</span><span>${Money.fmt(t.vat.amount)}</span></div>` : ''}
    </div>`;
  },
  openDrawer({ added = null } = {}) {
    const { notices } = Cart.validate();
    const render = (panel) => {
      const lines = Cart.lines();
      const t = computeTotals(lines, 0);
      $('.drawer-body', panel).innerHTML = `${notices.length ? `<div class="notice-stack mb-16" style="margin-bottom:16px">${notices.map((n) => UI.notice(esc(n), { type: 'warn', ic: 'alert' })).join('')}</div>` : ''}${this.linesHtml(lines)}`;
      const foot = $('.drawer-foot', panel);
      foot.hidden = !lines.length;
      foot.innerHTML = lines.length ? `${this.totalsHtml(t)}<div class="grid mt-16" style="gap:10px">
        <a class="btn btn--primary btn--block" href="#/afrekenen">Afrekenen</a>
        <a class="btn btn--light btn--block" href="#/winkelmand">Bekijk winkelmand</a></div>` : '';
      Behaviours.mount(panel);
    };
    Overlay.open({
      kind: 'drawer', title: `${icon('cart')} Winkelmand`,
      body: '', foot: ' ',
      onMount: (panel, close) => {
        if (added) $('.drawer-head', panel).insertAdjacentHTML('afterend', `<div class="added-banner">${icon('check')} Toegevoegd aan winkelmand</div>`);
        render(panel);
        panel.addEventListener('change', (e) => {
          const q = e.target.closest('[data-qty]'); if (!q) return;
          const r = Cart.setQty(q.dataset.qty, e.target.value);
          if (r.limited) Toast.show('Maximaal beschikbare aantal bereikt.');
          render(panel);
        });
        panel.addEventListener('click', (e) => {
          const rm = e.target.closest('[data-remove]');
          if (rm) { Cart.remove(rm.dataset.remove); render(panel); announce('Product verwijderd uit winkelmand'); return; }
          const a = e.target.closest('a[href]'); if (a && isAppLink(a) && plainClick(e)) close();
        });
      },
    });
  },
  miniTimer: null,
  showAdded(product, res) {
    if (window.matchMedia('(max-width: 760px)').matches) {
      Toast.show(`${product.name} is toegevoegd aan uw winkelmand.`, { action: { label: 'Bekijk', href: '#/winkelmand' } });
      return;
    }
    let el = $('#miniCart');
    if (!el) {
      el = document.createElement('div');
      el.id = 'miniCart'; el.className = 'mini-cart'; el.setAttribute('role', 'status');
      document.body.appendChild(el);
    }
    const pr = Pricing.calc(product);
    el.innerHTML = `<div class="mc-head">${icon('check')} Toegevoegd aan winkelmand<button class="icon-btn icon-btn--sm" type="button" aria-label="Sluiten" data-mc-close>${icon('x')}</button></div>
      <div class="mc-body"><div class="cart-line" style="padding:0;border:0">
        <div class="cl-media">${Media.html(product.images[0], product.name, { kind: productArtKind(product) })}</div>
        <div><div class="cl-title">${esc(product.name)}</div><div class="cl-meta">${res.qty} × ${Money.fmt(pr.price)}${res.limited ? ' · maximaal beschikbaar' : ''}</div></div></div></div>
      <div class="mc-actions"><a class="btn btn--light btn--sm" href="#/winkelmand">Bekijk winkelmand</a><a class="btn btn--primary btn--sm" href="#/afrekenen">Afrekenen</a></div>`;
    requestAnimationFrame(() => el.classList.add('is-open'));
    const hide = () => el.classList.remove('is-open');
    $('[data-mc-close]', el).onclick = hide;
    $$('a', el).forEach((a) => { a.onclick = (e) => { if (plainClick(e)) hide(); }; });
    clearTimeout(this.miniTimer);
    this.miniTimer = setTimeout(hide, 5000);
    el.onmouseenter = () => clearTimeout(this.miniTimer);
    el.onmouseleave = () => { this.miniTimer = setTimeout(hide, 2500); };
  },
};
