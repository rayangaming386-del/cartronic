/* =====================================================================
   PUBLIC PAGES
   ===================================================================== */
const Pages = {};
/* How CarTronic works (expertise page, technique card). */
const STEP_ICONS = ['cpu', 'wrench', 'settings2', 'target', 'check'];
const steps = () => STEP_ICONS.map((ic, i) => [ic, tx(`tech.step${i + 1}.title`), tx(`tech.step${i + 1}.text`)]);
const techCard = ({ headingTag = 'h2', id = 'tech-title', link = true } = {}) => `
  <div class="tech-card" data-reveal>
    <div class="tech-media">${Media.html('img:about', 'Volkswagen Golf Sportsvan op de uitlijnbrug in de CarTronic-werkplaats', { kind: 'assist' })}<span class="tech-caption">${tx('tech.caption')}</span></div>
    <div class="tech-panel on-dark">
      <p class="eyebrow">${tx('tech.eyebrow')}</p>
      <${headingTag} id="${id}">${tx('tech.title')}</${headingTag}>
      <p>${tx('tech.text')}</p>
      <ul class="tech-list">${steps().map(([ic, t, p]) => `<li>${icon(ic)}<div><strong>${t}</strong><span>${p}</span></div></li>`).join('')}</ul>
      ${link ? `<p class="tech-more"><a class="ink-link" href="#/expertise">${tx('tech.link')}</a></p>` : ''}
    </div>
  </div>`;
const svcCard = (s) => `<article class="svc-card">
    <span class="svc-icon">${icon(s.icon)}</span>
    <h3>${esc(s.card)}</h3>
    <p>${esc(s.cardText)}</p>
    <ul>${s.points.map((p) => `<li>${esc(p)}</li>`).join('')}</ul>
    <a class="ink-link" href="${s.cta[1]}">${esc(s.cta[0])}</a>
  </article>`;
/* Star rating; the fill shows the real score (9,4 / 10 → 94 %). */
const starRow = (score, scale = 10, cls = 'stars') => {
  const pct = Math.max(0, Math.min(100, (parseFloat(String(score).replace(',', '.')) / scale) * 100));
  const five = icon('star').repeat(5);
  return `<span class="${cls}" aria-hidden="true"><span class="st-base">${five}</span><span class="st-fill" style="width:${pct.toFixed(1)}%">${five}</span></span>`;
};
const reviewCard = (r) => `<article class="review-card">
    ${starRow(r.score, 10, 'rc-stars')}<span class="sr-only">Score: ${esc(String(r.score))} van 10.</span>
    <h3>${esc(r.title)}</h3>
    <blockquote>“${esc(r.text)}”</blockquote>
    <p class="rc-who">${esc(r.name)}, ${esc(r.place)} · ${esc(fmtDate(r.date))}</p>
  </article>`;
const reviewsBlock = ({ id = 'reviews-title', headingTag = 'h2', limit = REVIEWS.items.length, eyebrow = true, more = 'external' } = {}) => `
  <div class="reviews-head">
    <div class="reviews-score">
      ${eyebrow ? `<p class="eyebrow">${tx('rev.eyebrow')}</p>` : ''}
      <${headingTag} class="h2" id="${id}" data-split>${tx('rev.title')}</${headingTag}>
      <p class="score"><span class="score-num">${REVIEWS.score}</span><span class="score-of">/ ${REVIEWS.scale}</span><span class="sr-only"> gemiddeld, op basis van ${REVIEWS.count} beoordelingen</span></p>
      ${starRow(REVIEWS.score, REVIEWS.scale)}
      <p class="score-meta">Gemiddelde van ${REVIEWS.count} beoordelingen op ${esc(REVIEWS.source)}.</p>
      <p class="reviews-links">${more === 'page'
        ? `<a class="ink-link" href="#/beoordelingen">${tx('rev.more')}</a>`
        : `<a class="ink-link" href="${attr(REVIEWS.url)}" target="_blank" rel="noopener">Bekijk alle beoordelingen op ${esc(REVIEWS.source)}<span class="sr-only"> (opent in een nieuw venster)</span></a>`}</p>
    </div>
    <div class="review-grid">${REVIEWS.items.slice(0, limit).map(reviewCard).join('')}</div>
  </div>`;
/* Closing call-to-action band (can be switched off in Beheer → Weergave). */
const ctaBand = ({ title = tx('cta.title'), text = tx('cta.text') } = {}) => (!Content.section('cta') ? '' : `
  <section class="cta-band on-dark" aria-labelledby="cta-title">
    <div class="container cta-band-inner">
      <div data-reveal><h2 id="cta-title">${title}</h2><p>${text}</p></div>
      <div class="cta-actions" data-reveal>
        <a class="btn btn--white" href="#/contact">${tx('cta.btn1')}</a>
        <a class="btn btn--outline-light" href="${attr(COMPANY.phoneHref)}" aria-label="${attr(tt('cta.btn2'))}: ${attr(COMPANY.phoneDisplay)}">${icon('phone')} ${tx('cta.btn2')}</a>
      </div>
    </div>
  </section>`);
const aboutProse = () => ['about.p1', 'about.p2', 'about.p3'].map((k) => tx(k)).filter(Boolean).map((p) => `
  <p>${p}</p>`).join('');
const recentSection = (list, { title = 'Recent bekeken' } = {}) => `
  <section class="section section--sm" aria-labelledby="recent-title">
    <div class="container">
      <div class="section-head" style="margin-bottom:24px"><div><p class="eyebrow">${icon('history').replace('<svg', '<svg style="width:14px;height:14px"')} Uw geschiedenis</p><h2 class="h3 mt-8" id="recent-title">${title}</h2></div>
      <button class="btn btn--ghost btn--sm" type="button" data-action="clear-recent">Wis geschiedenis</button></div>
      <div class="mini-list">${list.slice(0, 6).map((e) => UI.miniItem(e)).join('')}</div>
    </div>
  </section>`;

/* ---------- Home ---------- */
Pages.home = {
  id: 'home', nav: '',
  meta: () => ({ title: null, description: Content.seo().description }),
  render() {
    const v = VehicleStore.get();
    const recent = Recent.list();
    const featured = Content.shopOn() && Content.section('home.shop') ? Repo.products().filter((p) => isPublicProduct(p) && p.featured).slice(0, 3) : [];
    const projects = Repo.projects().filter((p) => p.active).slice(0, 3);
    const on = (k) => Content.section(k);
    const own = v ? Compat.forVehicle(v) : [];
    return `
    <section class="hero on-dark" data-hero aria-labelledby="hero-title">
      <div class="hero-media" aria-hidden="true">${Media.html('img:hero', '', { kind: 'cockpit', eager: true })}</div>
      <div class="container"><div class="hero-content">
        <p class="eyebrow eyebrow--line" data-hero-item>${tx('home.hero.eyebrow')}</p>
        <h1 class="display" id="hero-title"><span class="l1" data-hero-line>${tx('home.hero.line1')}</span><span class="l2" data-hero-line>${tx('home.hero.line2')}</span></h1>
        <p class="lead" data-hero-item>${tx('home.hero.lead')}</p>
        <div class="hero-cta" data-hero-item>
          <a class="btn btn--primary" href="#/mogelijkheden"${on('home.finder') ? ' data-action="scroll-to" data-target="vind-uw-auto"' : ''}>${tx('home.hero.cta1')}</a>
          <a class="btn btn--outline-light" href="#/projecten">${tx('home.hero.cta2')}</a>
        </div>
        <ul class="hero-checks" data-hero-item>
          <li>${icon('check')}${tx('home.hero.check1')}</li>
          <li>${icon('check')}${tx('home.hero.check2')}</li>
        </ul>
      </div></div>
      <p class="hero-caption" data-hero-item aria-hidden="true">${tx('home.hero.caption')}</p>
    </section>

    ${on('home.brands') ? `<section class="brand-band" aria-label="Merken">
      <div class="container brand-band-inner">
        <p class="tagline">${tx('home.brands.tagline')}</p>
        ${BRANDS.map((b) => `<a href="#/merken/${b.id}" aria-label="${b.name}: modellen en mogelijkheden"><span class="wordmark ${b.wordmark}">${b.name}</span></a>`).join('')}
      </div>
    </section>` : ''}

    ${on('home.finder') ? `<section class="finder-band" id="vind-uw-auto" aria-labelledby="finder-title">
      <div class="container finder-grid">
        <div class="finder-intro">
          <p class="eyebrow">${tx('home.finder.eyebrow')}</p>
          <h2 id="finder-title">${tx('home.finder.title')}</h2>
        </div>
        <div>${VehicleFinder.html({ tab: 'manual', context: 'home', tabs: false })}</div>
      </div>
    </section>` : ''}

    ${v ? `<section class="section section--sm" aria-labelledby="own-title">
      <div class="container">
        <div class="section-head">
          <div><p class="eyebrow">Voor uw auto</p><h2 class="h2 mt-16" id="own-title">Mogelijkheden voor uw ${esc(VehicleStore.short(v))}.</h2></div>
          ${own.length ? `<a class="link" href="#/mogelijkheden">Alle ${plural(own.length, 'mogelijkheid', 'mogelijkheden')} ${icon('arrow')}</a>` : ''}
        </div>
        ${own.length ? `<div class="results-grid" data-stagger>${own.slice(0, 3).map(({ item }) => UI.retrofitCard(item, { vehicle: v })).join('')}</div>`
          : UI.empty({ icon: 'car', title: 'Voor dit voertuig hebben we momenteel geen online mogelijkheden beschikbaar.', text: 'Neem contact op: CarTronic bekijkt graag wat er voor uw auto mogelijk is.', actions: '<a class="btn btn--dark btn--sm" href="#/contact">Contact opnemen</a><button class="btn btn--light btn--sm" type="button" data-action="open-vehicle">Kies een andere auto</button>' })}
      </div>
    </section>` : ''}

    ${recent.length && Content.section('recent') ? recentSection(recent) : ''}

    ${on('home.categories') ? `<section class="section" aria-labelledby="cats-title">
      <div class="container">
        <div class="section-intro">
          <p class="eyebrow">${tx('home.cats.eyebrow')}</p>
          <h2 class="h2" id="cats-title" data-split>${tx('home.cats.title')}</h2>
          <p class="lead" data-reveal>${tx('home.cats.lead')}</p>
        </div>
        <div class="cat-grid" data-stagger>
          ${CATEGORIES.map((c, i) => `<article class="cat-card">
            <div class="cc-top"><span class="cc-icon">${icon(c.icon)}</span><span class="cc-num" aria-hidden="true">${String(i + 1).padStart(2, '0')}</span></div>
            <h3>${esc(c.name)}</h3>
            <p>${esc(c.tagline)}</p>
            <a class="cc-link stretch" href="#/mogelijkheden?cat=${c.id}" aria-label="${attr(tt('home.cats.link'))}: ${attr(c.name)}">${tx('home.cats.link')}</a>
          </article>`).join('')}
        </div>
      </div>
    </section>` : ''}

    ${on('home.services') ? `<section class="section section--tight-top" aria-labelledby="svc-title">
      <div class="container">
        <div class="section-intro">
          <p class="eyebrow">${tx('home.svc.eyebrow')}</p>
          <h2 class="h2" id="svc-title" data-split>${tx('home.svc.title')}</h2>
          <p class="lead" data-reveal>${tx('home.svc.lead')}</p>
        </div>
        <div class="svc-grid" data-stagger>${SERVICES.slice(0, 3).map(svcCard).join('')}</div>
        <p class="center-link"><a class="ink-link" href="#/expertise">${tx('home.svc.link')}</a></p>
      </div>
    </section>` : ''}

    ${on('home.tech') ? `<section class="section section--tight-top" aria-label="${attr(tt('tech.eyebrow'))}">
      <div class="container">${techCard()}</div>
    </section>` : ''}

    ${on('home.projects') && projects.length ? `<section class="section section--soft" aria-labelledby="projects-title">
      <div class="container">
        <div class="section-intro">
          <p class="eyebrow">${tx('home.proj.eyebrow')}</p>
          <h2 class="h2" id="projects-title" data-split>${tx('home.proj.title')}</h2>
          <p class="intro-link" data-reveal><a class="ink-link" href="#/projecten">${tx('home.proj.link')}</a></p>
        </div>
        <div class="proj-grid" data-stagger>${projects.map((p) => UI.projectCard(p)).join('')}</div>
      </div>
    </section>` : ''}

    ${on('home.reviews') ? `<section class="section" aria-labelledby="reviews-title">
      <div class="container">${reviewsBlock({ limit: 2, more: 'page' })}</div>
    </section>` : ''}

    ${featured.length ? `<section class="section section--soft" aria-labelledby="featured-title">
      <div class="container">
        <div class="section-intro section-intro--row">
          <div><p class="eyebrow">${tx('home.shop.eyebrow')}</p><h2 class="h2" id="featured-title" data-split>${tx('home.shop.title')}</h2></div>
          <p class="intro-link"><a class="ink-link" href="#/webshop">${tx('home.shop.link')}</a></p>
        </div>
        <div class="featured-strip" data-stagger>${featured.map((p) => UI.productCard(p)).join('')}</div>
        ${tx('home.shop.hint') ? `<p class="hint mt-16">${tx('home.shop.hint')}</p>` : ''}
      </div>
    </section>` : ''}

    ${ctaBand()}`;
  },
  mount(root) {
    const finder = $('[data-finder]', root);
    if (finder) VehicleFinder.mount(finder, { onDone: () => Router.go('/mogelijkheden') });
    Behaviours.mount(root);
  },
};

/* ---------- Catalog (Mogelijkheden) ---------- */
function catalogState(query) {
  const v = VehicleStore.get();
  const explicit = !!(query.merk || query.model);
  const useVehicle = !explicit && !query.alle && !!v;
  let merk = query.merk || ''; let model = query.model || '';
  if (model && MODEL[model]) merk = MODEL[model].brand;
  if (merk && !BRAND[merk]) merk = '';
  if (model && !MODEL[model]) model = '';
  if (useVehicle) { merk = v.brandId; model = v.modelId || ''; }
  return { v, useVehicle, merk, model, cat: CATEGORY[query.cat] ? query.cat : '', groep: GROUP[query.groep] ? query.groep : '', q: query.q || '' };
}
function catalogResults(s) {
  let textSet = null;
  if (s.q.trim().length >= 2) textSet = new Set(Search.query(s.q, { limit: 999, perType: 0, types: ['RETROFIT'] }).map((r) => r.id));
  let items = RETROFITS.filter((r) => {
    if (s.merk && !Compat.brandsOf(r).includes(s.merk)) return false;
    if (s.model && !(r.models.includes(s.model) || r.scope === 'brand')) return false;
    if (s.cat && r.cat !== s.cat) return false;
    if (s.groep && CATEGORY[r.cat].group !== s.groep) return false;
    if (textSet && !textSet.has(r.slug)) return false;
    return true;
  });
  const catIdx = (r) => CATEGORIES.findIndex((c) => c.id === r.cat);
  if (s.v) {
    const rank = (r) => { const st = Compat.status(r, s.v); return st ? Compat.STATUS[st.key].rank : 9; };
    items = items.slice().sort((a, b) => rank(a) - rank(b) || (s.model ? catIdx(a) - catIdx(b) : 0));
  } else if (s.model) {
    // One model: group its options by category (camera & parkeren first, as in the filters).
    items = items.slice().sort((a, b) => catIdx(a) - catIdx(b));
  }
  return items;
}
Pages.catalog = {
  id: 'catalog', nav: 'mogelijkheden',
  meta(ctx) {
    const s = catalogState(ctx.query);
    const what = s.model ? modelLabel(s.model) : (s.merk ? BRAND[s.merk].name : 'Volkswagen, Audi, SEAT en Škoda');
    return { title: s.model || s.merk ? `Mogelijkheden voor ${what}` : 'Mogelijkheden — wat past bij uw auto?', description: `Originele fabrieksopties voor ${what}: camera, parkeerhulp, App Connect, Virtual Cockpit, trekhaken en meer. Bekijk de mogelijkheden en vraag ze aan bij CarTronic.` };
  },
  render(ctx) {
    const s = catalogState(ctx.query);
    const v = s.v;
    const shared = !!(ctx.query.merk || ctx.query.model) && (!v || (s.model && s.model !== v.modelId) || (!s.model && s.merk && s.merk !== v.brandId));
    const vehicleBar = v ? `<div class="vehicle-bar"><div class="container vehicle-bar-inner">
        ${icon('car', 'car')}
        <div><div class="vb-label">Uw auto</div><div class="vb-name">${esc(VehicleStore.name(v))} <span class="vb-meta">· ${esc(VehicleStore.meta(v))}</span></div></div>
        <div class="vb-actions">
          ${s.useVehicle ? '<a class="btn btn--light btn--sm" href="#/mogelijkheden?alle=1">Toon alle mogelijkheden</a>' : `<a class="btn btn--dark btn--sm" href="#/mogelijkheden">Toon opties voor uw ${esc(VehicleStore.short(v))}</a>`}
          <button class="btn btn--light btn--sm" type="button" data-action="open-vehicle">Wijzig auto</button>
        </div></div></div>` : '';
    const sharedBar = shared && s.model ? `<div class="container" style="padding-top:24px">${UI.notice(`<strong>Gedeelde selectie:</strong> ${esc(modelLabel(s.model))}.`, { ic: 'link', actions: `<button class="btn btn--dark btn--xs" type="button" data-action="adopt-vehicle" data-brand="${s.merk}" data-model="${s.model}">Instellen als mijn auto</button>` })}</div>` : '';
    return `
      ${UI.pageHeader({ crumbs: [[tt('catalog.title')]], eyebrow: tt('catalog.eyebrow'), title: tx('catalog.title'), lead: tx('catalog.lead') })}
      ${vehicleBar}${sharedBar}
      <section class="section section--sm" style="padding-top:56px">
        <div class="container catalog">
          <div data-filters-home><aside class="filters" aria-label="Filters" data-filters>${this.filtersHtml(s)}</aside></div>
          <div>
            <div class="results-head">
              <p class="results-count" data-count aria-live="polite"></p>
              <div class="results-tools">
                <button class="btn btn--light btn--sm filters-toggle" type="button" data-action="open-filters">${icon('sliders')} Filters</button>
                <button class="btn btn--ghost btn--sm" type="button" data-action="share-selection">${icon('link')} Deel selectie</button>
                <span class="hide-sm">Originele fabrieksopties</span>
              </div>
            </div>
            <div class="active-filters" data-active></div>
            <h2 class="sr-only">Resultaten</h2>
            <div class="results-grid" data-results></div>
            <div class="load-more" data-more></div>
            <div class="mt-48">${UI.notice(`<strong>Over de statussen.</strong> ${esc(Compat.disclaimer)}<div class="chips mt-16">${Object.values(Compat.STATUS).map((x) => `<span class="status status--${x.cls}">${x.label}</span>`).join('')}</div>`, { ic: 'info' })}</div>
          </div>
        </div>
      </section>
      ${ctaBand()}`;
  },
  filtersHtml(s) {
    const modelOpts = (brand) => (brand ? MODELS.filter((m) => m.brand === brand).map((m) => `<option value="${m.id}"${m.id === s.model ? ' selected' : ''}>${esc(m.name)}</option>`).join('')
      : BRANDS.map((b) => `<optgroup label="${attr(b.name)}">${MODELS.filter((m) => m.brand === b.id).map((m) => `<option value="${m.id}"${m.id === s.model ? ' selected' : ''}>${esc(m.name)}</option>`).join('')}</optgroup>`).join(''));
    return `<div class="filters-head">${icon('sliders')} Verfijn uw selectie</div>
      <div class="field"><label for="f-merk">Merk</label><select class="select" id="f-merk" data-f="merk"><option value="">Alle merken</option>${BRANDS.map((b) => `<option value="${b.id}"${b.id === s.merk ? ' selected' : ''}>${esc(b.name)}</option>`).join('')}</select></div>
      <div class="field"><label for="f-model">Model / generatie</label><select class="select" id="f-model" data-f="model"><option value="">Alle modellen</option>${modelOpts(s.merk)}</select></div>
      <div class="field"><label for="f-cat">Upgrade</label><select class="select" id="f-cat" data-f="cat"><option value="">Alle upgrades</option>${CATEGORIES.map((c) => `<option value="${c.id}"${c.id === s.cat ? ' selected' : ''}>${esc(c.name)}</option>`).join('')}</select></div>
      <div class="field"><label for="f-q">Zoek een optie</label><div class="input-icon">${icon('search')}<input class="input" id="f-q" type="search" data-f="q" placeholder="Bijv. camera of CarPlay" value="${attr(s.q)}" autocomplete="off"></div></div>
      <button class="filter-reset" type="button" data-action="reset-filters">Filters wissen</button>
      <p class="filter-note">${tx('catalog.filterNote')}</p>`;
  },
  mount(root, ctx) {
    let s = catalogState(ctx.query);
    const filtersEl = $('[data-filters]', root);
    const grid = $('[data-results]', root);
    const countEl = $('[data-count]', root);
    const activeEl = $('[data-active]', root);
    let limit = 18;
    const update = ({ animate = true, keepLimit = false } = {}) => {
      if (!keepLimit) limit = 18;
      const items = catalogResults(s);
      countEl.innerHTML = `<strong>${items.length}</strong> ${items.length === 1 ? 'mogelijkheid' : 'mogelijkheden'} gevonden`;
      const chips = [];
      if (s.useVehicle) chips.push(`<span class="chip chip--removable is-active">${icon('car')} ${esc(VehicleStore.name(s.v))}<button type="button" data-clear="vehicle" aria-label="Toon alle merken">${icon('x')}</button></span>`);
      else {
        if (s.merk && !s.model) chips.push(`<span class="chip chip--removable">${esc(BRAND[s.merk].name)}<button type="button" data-clear="merk" aria-label="Verwijder filter merk">${icon('x')}</button></span>`);
        if (s.model) chips.push(`<span class="chip chip--removable">${esc(modelLabel(s.model))}<button type="button" data-clear="model" aria-label="Verwijder filter model">${icon('x')}</button></span>`);
      }
      if (s.groep) chips.push(`<span class="chip chip--removable">Groep: ${esc(GROUP[s.groep].name)}<button type="button" data-clear="groep" aria-label="Verwijder filter groep">${icon('x')}</button></span>`);
      if (s.cat) chips.push(`<span class="chip chip--removable">${esc(CATEGORY[s.cat].name)}<button type="button" data-clear="cat" aria-label="Verwijder filter upgrade">${icon('x')}</button></span>`);
      if (s.q) chips.push(`<span class="chip chip--removable">“${esc(s.q)}”<button type="button" data-clear="q" aria-label="Verwijder zoekterm">${icon('x')}</button></span>`);
      activeEl.innerHTML = chips.join('');
      grid.innerHTML = items.length ? items.slice(0, limit).map((r) => UI.retrofitCard(r, { vehicle: s.v })).join('')
        : UI.empty({ icon: 'search', title: 'Geen mogelijkheden gevonden', text: s.useVehicle ? 'Voor dit voertuig en deze selectie staan momenteel geen online mogelijkheden. Neem contact op of bekijk alle mogelijkheden.' : 'Voor deze combinatie staan geen opties in de online catalogus. Pas uw selectie aan of vraag het ons.', actions: '<button class="btn btn--dark btn--sm" type="button" data-action="reset-filters">Filters wissen</button><a class="btn btn--light btn--sm" href="#/contact">Contact opnemen</a>' });
      const more = $('[data-more]', root);
      more.innerHTML = items.length > limit ? `<button class="btn btn--light" type="button" data-action="load-more">Toon meer mogelijkheden</button><span class="hint">${Math.min(limit, items.length)} van ${items.length} getoond</span>` : '';
      if (animate) Motion.swap(grid);
      const toggle = $('.filters-toggle', root);
      const n = [s.merk && !s.useVehicle, s.model && !s.useVehicle, s.cat, s.groep, s.q].filter(Boolean).length;
      if (toggle) toggle.innerHTML = `${icon('sliders')} Filters${n ? ` (${n})` : ''}`;
    };
    const syncUrl = () => {
      const q = {};
      if (!s.useVehicle) { if (s.merk) q.merk = s.merk; if (s.model) q.model = s.model; if (s.v && !s.merk && !s.model) q.alle = '1'; }
      if (s.cat) q.cat = s.cat; if (s.groep) q.groep = s.groep; if (s.q) q.q = s.q;
      Router.setQuery(q);
    };
    const refreshModelSelect = () => {
      const sel = $('[data-f="model"]', filtersEl);
      if (!sel) return;
      const tmp = document.createElement('div');
      tmp.innerHTML = this.filtersHtml(s);
      sel.innerHTML = $('[data-f="model"]', tmp).innerHTML;
      sel.value = s.model || '';
      $('[data-f="merk"]', filtersEl).value = s.merk || '';
    };
    const onFilter = (key, value) => {
      if (key === 'merk' || key === 'model') {
        if (s.useVehicle) s.useVehicle = false;
        if (key === 'merk') { s.merk = value; if (s.model && MODEL[s.model].brand !== value) s.model = ''; }
        if (key === 'model') { s.model = value; if (value) s.merk = MODEL[value].brand; }
        refreshModelSelect();
      } else s[key] = value;
      if (key === 'cat') s.groep = '';
      syncUrl(); update();
    };
    filtersEl.addEventListener('change', (e) => { const f = e.target.dataset.f; if (f && f !== 'q') onFilter(f, e.target.value); });
    const qInput = $('[data-f="q"]', filtersEl);
    qInput.addEventListener('input', debounce(() => onFilter('q', qInput.value.trim()), 220));
    const reset = () => {
      s = { ...s, useVehicle: false, merk: '', model: '', cat: '', groep: '', q: '' };
      filtersEl.innerHTML = this.filtersHtml(s);
      $('[data-f="q"]', filtersEl).addEventListener('input', debounce((ev) => onFilter('q', ev.target.value.trim()), 220));
      syncUrl(); update();
    };
    root.addEventListener('click', (e) => {
      if (e.target.closest('[data-action="reset-filters"]')) { e.preventDefault(); reset(); return; }
      const c = e.target.closest('[data-clear]');
      if (c) {
        const k = c.dataset.clear;
        if (k === 'vehicle') { s.useVehicle = false; s.merk = ''; s.model = ''; refreshModelSelect(); }
        else if (k === 'merk') { s.merk = ''; s.model = ''; refreshModelSelect(); }
        else if (k === 'model') { s.model = ''; refreshModelSelect(); }
        else { s[k] = ''; const el = $(`[data-f="${k}"]`, filtersEl); if (el) el.value = ''; }
        syncUrl(); update();
        return;
      }
      if (e.target.closest('[data-action="share-selection"]')) { shareSelection(s); return; }
      if (e.target.closest('[data-action="load-more"]')) {
        const from = limit; limit += 18; update({ animate: false, keepLimit: true });
        const cards = $$('.retrofit-card', grid).slice(from);
        Motion.enter(cards);
        const first = cards[0] && cards[0].querySelector('a'); if (first) first.focus({ preventScroll: true });
        return;
      }
      if (e.target.closest('[data-action="open-filters"]')) openFiltersDrawer(filtersEl, $('[data-filters-home]', root), () => update());
    });
    update({ animate: false });
  },
};
function shareSelection(s) {
  const q = {};
  if (s.merk) q.merk = s.merk; if (s.model) q.model = s.model; if (s.cat) q.cat = s.cat; if (s.groep) q.groep = s.groep;
  const url = Router.absUrl('/mogelijkheden', q);
  const label = s.model ? modelLabel(s.model) : (s.merk ? BRAND[s.merk].name : 'CarTronic-mogelijkheden');
  if (navigator.share && window.matchMedia('(max-width: 760px)').matches) {
    navigator.share({ title: `CarTronic — ${label}`, url }).catch(() => {});
    return;
  }
  const done = () => Toast.show('Link naar deze selectie gekopieerd. Uw kenteken wordt niet gedeeld.');
  if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(url).then(done, () => showCopyModal(url));
  else showCopyModal(url);
}
function showCopyModal(url) {
  Overlay.open({
    title: 'Deel deze selectie', size: 'sm',
    body: `<p class="text-muted text-small" style="margin-bottom:12px">Kopieer de link. Uw kenteken wordt niet gedeeld.</p><input class="input" type="text" readonly value="${attr(url)}" data-copy>`,
    foot: '<button class="btn btn--dark btn--sm" type="button" data-close>Klaar</button>',
    onMount(panel) { const i = $('[data-copy]', panel); setTimeout(() => { i.focus(); i.select(); }, 80); },
  });
}
function openFiltersDrawer(filtersEl, home, onClose) {
  Overlay.open({
    kind: 'drawer', side: 'left', title: `${icon('sliders')} Filters`, body: '',
    foot: '<button class="btn btn--primary btn--block" type="button" data-close>Toon resultaten</button>',
    onMount(panel) { $('.drawer-body', panel).appendChild(filtersEl); },
    onClose() { home.appendChild(filtersEl); if (onClose) onClose(); },
  });
}

/* ---------- Retrofit detail ---------- */
/* Spec rows: standard rows (model, category, warranty, price) merged with the option's own specs. */
function retrofitSpecs(r) {
  const own = new Map(r.specs || []);
  const rows = [];
  const add = (k, val) => { const x = own.has(k) ? own.get(k) : val; own.delete(k); if (x) rows.push([k, x]); };
  add('Model', r.scope === 'brand' ? `Meerdere modellen (${Compat.brandsOf(r).map((b) => BRAND[b].name).join(', ')})`
    : r.models.map((m) => `${modelLabel(m)} (${modelYearsFor(r, m)})`).join(', '));
  add('Geschikt voor', '');
  add('Categorie', CATEGORY[r.cat].name);
  [...own.keys()].filter((k) => !['Garantie', 'Prijs'].includes(k)).forEach((k) => add(k, ''));
  add('Garantie', r.warranty);
  add('Prijs', r.price || 'Op aanvraag');
  add('Aanbieding', r.offer);
  return rows;
}
/* Breadcrumb trail of an option; used for the visible crumbs and the BreadcrumbList. */
function retrofitCrumbs(r) {
  const single = r.models.length === 1 ? r.models[0] : null;
  const crumbs = [['Home', '#/'], ['Mogelijkheden', '#/mogelijkheden']];
  if (r.brand) crumbs.push([BRAND[r.brand].name, `#/mogelijkheden?merk=${r.brand}`]);
  if (single) crumbs.push([MODEL[single].name, `#/mogelijkheden?merk=${r.brand}&model=${single}`]);
  crumbs.push([CATEGORY[r.cat].name, `#/mogelijkheden?${r.brand ? `merk=${r.brand}&` : ''}${single ? `model=${single}&` : ''}cat=${r.cat}`]);
  crumbs.push([r.name]);
  return crumbs;
}
const modelYearsFor = (r, m) => { const y = (r.yearsByModel && r.yearsByModel[m]) || null; return y ? `${y[0]}–${y[1]}` : modelYears(MODEL[m]); };
/* Up to n items, one per category first, so a related row shows different kinds of upgrades. */
function diverseRetrofits(list, n = 3, skipCat = null) {
  const out = []; const seen = new Set(skipCat ? [skipCat] : []);
  list.forEach((x) => { if (out.length < n && !seen.has(x.cat)) { out.push(x); seen.add(x.cat); } });
  list.forEach((x) => { if (out.length < n && !out.includes(x)) out.push(x); });
  return out;
}
const relatedSection = ({ id, eyebrow = 'Gerelateerd', title, link = '', items, v, follows = false }) => `
  <section class="section section--soft section--sm" aria-labelledby="${id}"${follows ? ' style="padding-top:0"' : ''}><div class="container">
    <div class="section-head" style="margin-bottom:28px"><div><p class="eyebrow">${esc(eyebrow)}</p><h2 class="h3 mt-8" id="${id}">${esc(title)}</h2></div>${link}</div>
    <div class="results-grid" data-stagger>${items.map((x) => UI.retrofitCard(x, { vehicle: v })).join('')}</div>
  </div></section>`;
Pages.retrofit = {
  id: 'retrofit', nav: 'mogelijkheden',
  meta(ctx) {
    const r = RETROFIT[ctx.params.slug];
    if (!r) return { title: 'Optie niet gevonden', noindex: true };
    const crumbs = retrofitCrumbs(r).map(([name, href]) => [name, href || `#/mogelijkheden/${r.slug}`]);
    return {
      title: r.title,
      description: retrofitDescription(r),
      jsonLd: [
        { '@context': 'https://schema.org', '@type': 'Service', name: r.title, description: r.short, serviceType: CATEGORY[r.cat].name, provider: providerLd() },
        breadcrumbLd(crumbs),
      ].filter(Boolean),
    };
  },
  render(ctx) {
    const r = RETROFIT[ctx.params.slug];
    if (!r) return Pages.notFound.render(ctx, { title: 'Deze optie bestaat niet (meer).', text: 'Mogelijk is de optie verplaatst. Bekijk de catalogus of zoek opnieuw.' });
    Recent.add('retrofit', r.slug);
    Analytics.track('retrofit_viewed', { slug: r.slug });
    const v = VehicleStore.get();
    const st = Compat.status(r, v);
    const copy = CATEGORY_COPY[r.cat] || {};
    const brandId = r.brand || (v ? v.brandId : null);
    const single = r.models.length === 1 ? r.models[0] : null;
    const crumbs = retrofitCrumbs(r);

    let compat;
    if (v && st) {
      compat = `<div class="compat-panel"><div class="cp-head"><div class="who">Uw auto: ${esc(VehicleStore.name(v))}<small>${esc(VehicleStore.meta(v))}</small></div>${Compat.badge(st)}</div>
        <div class="cp-body">${esc(st.reason)}<br><span class="text-muted">${esc(Compat.disclaimer)}</span></div></div>`;
    } else if (v && !st) {
      compat = `<div class="compat-panel"><div class="cp-head"><div class="who">Uw auto: ${esc(VehicleStore.name(v))}<small>${esc(VehicleStore.meta(v))}</small></div><span class="status status--neutral">Niet vermeld voor uw model</span></div>
        <div class="cp-body">Deze optie staat in de catalogus voor: ${esc(retrofitModelsText(r))}.
        <div class="cp-models"><a class="btn btn--dark btn--xs" href="#/mogelijkheden">Bekijk opties voor uw ${esc(VehicleStore.short(v))}</a><a class="btn btn--light btn--xs" href="#/contact?optie=${r.slug}">Toch vragen</a></div></div></div>`;
    } else {
      compat = `<div class="compat-panel"><div class="cp-head"><div class="who">${r.scope === 'brand' ? 'Merken' : 'Vermeld voor'}<small>${r.years ? `Bouwjaar ${r.years[0]}–${r.years[1]}` : 'Volgens de CarTronic-catalogus'}</small></div><button class="btn btn--dark btn--xs" type="button" data-action="open-vehicle">${icon('car')} Controleer voor uw auto</button></div>
        <div class="cp-body"><div class="cp-models" style="margin-top:0">${r.scope === 'brand'
          ? Compat.brandsOf(r).map((b) => `<span class="pill">${BRAND[b].name}</span>`).join('')
          : r.models.map((m) => `<span class="pill">${esc(modelLabel(m))} · ${modelYearsFor(r, m)}</span>`).join('')}</div>
        <p class="mt-16 text-muted">${esc(Compat.disclaimer)}</p></div></div>`;
    }
    const panels = [
      { title: 'Wat wordt ingebouwd?', html: `<p>${esc(copy.install || '')}</p>`, open: true },
      { title: 'Wat wordt geprogrammeerd?', html: `<p>${copy.program ? esc(copy.program) : tx('retro.program')}</p>` },
    ];
    if (copy.calibrate) panels.push({ title: 'Kalibratie nodig?', html: `<p>${esc(copy.calibrate)}</p><p class="mt-8"><a class="text-link" href="#/diensten/kalibratie-rijhulpsystemen">Meer over kalibratie</a></p>` });
    panels.push({ title: 'Afhankelijk van uitvoering?', html: `<p>${r.variantNote ? esc(r.variantNote) : tx('retro.variantDefault')}</p>${r.years ? `<p class="mt-8">Online vermeld voor bouwjaar ${r.years[0]}–${r.years[1]}.</p>` : ''}` });
    panels.push({ title: 'Wat heeft CarTronic nodig om te controleren?', html: `<ul><li>Uw kenteken of chassisnummer (VIN)</li><li>Bouwjaar en uitvoering van de auto</li><li>Welke systemen al aanwezig zijn, bijvoorbeeld het multimediasysteem</li></ul><p class="mt-8">Stuur dit mee via <a class="text-link" href="#/contact?optie=${r.slug}">het contactformulier</a> of WhatsApp.</p>` });

    // Related: (1) for the visitor's car, (2) other upgrades for this model, else (3) similar options.
    const sections = [];
    const forCar = v ? Compat.forVehicle(v).map((x) => x.item).filter((x) => x.slug !== r.slug) : [];
    if (forCar.length) sections.push({ id: 'rel-car', title: `Ook interessant voor uw ${VehicleStore.short(v)}`, items: diverseRetrofits(forCar), link: `<a class="link" href="#/mogelijkheden">Alle opties voor uw auto ${icon('arrow')}</a>` });
    const forModel = single && !(v && v.modelId === single) ? RETROFITS.filter((x) => x.slug !== r.slug && x.models.includes(single)) : [];
    if (forModel.length) sections.push({ id: 'rel-model', title: `Andere upgrades voor de ${modelLabel(single)}`, items: diverseRetrofits(forModel, 3, r.cat), link: `<a class="link" href="#/mogelijkheden?merk=${r.brand}&model=${single}">Alle ${catalogResults({ merk: r.brand, model: single, cat: '', groep: '', q: '', v: null }).length} opties ${icon('arrow')}</a>` });
    if (!sections.length) {
      const similar = RETROFITS.filter((x) => x.slug !== r.slug && x.cat === r.cat && (!brandId || Compat.brandsOf(x).includes(brandId)));
      if (similar.length) sections.push({ id: 'rel-similar', title: 'Vergelijkbare opties', items: diverseRetrofits(similar) });
    }
    const sameFeature = r.feature && r.brand && r.scope !== 'brand'
      ? RETROFITS.filter((x) => x.slug !== r.slug && x.feature === r.feature && x.brand === r.brand && x.scope !== 'brand' && !x.models.every((m) => r.models.includes(m))).slice(0, 12) : [];
    const project = r.project ? Repo.project(r.project) : null;
    const saved = Saved.has('retrofits', r.slug);
    const waText = WhatsApp.enquiry({ vehicle: v ? VehicleStore.name(v) : (single ? modelLabel(single) : ''), plate: VehicleStore.plate(), year: v ? v.year : null, options: [r.title], question: 'Is deze optie mogelijk voor mijn auto?' });
    const recent = Recent.list({ type: 'retrofit', id: r.slug });
    return `
      <div class="detail-top"><div class="container">${UI.crumbs(crumbs.slice(0), { light: true })}</div></div>
      <div class="container detail-grid">
        <div class="detail-media" data-mask>${Media.html(retrofitImage(r), r.title, { kind: r.art, eager: true })}${r.imageNote ? `<span class="media-note">${esc(r.imageNote)}</span>` : ''}</div>
        <div class="detail-info">
          <p class="eyebrow">${esc(r.brand ? BRAND[r.brand].name : 'Alle merken')} · ${esc(CATEGORY[r.cat].name)}</p>
          <h1>${esc(r.title)}</h1>
          <p class="lead">${esc(r.short)}</p>
          <div class="detail-actions">
            <a class="btn btn--primary" href="#/contact?optie=${r.slug}">Vraag deze optie aan</a>
            <a class="btn btn--whatsapp" href="${WhatsApp.url(waText)}" target="_blank" rel="noopener" data-action="whatsapp">${icon('whatsapp')} WhatsApp</a>
            <button class="btn btn--light" type="button" data-action="toggle-save" data-type="retrofits" data-id="${r.slug}" aria-pressed="${saved}">${icon('bookmark')} <span data-save-label>${saved ? 'Bewaard' : 'Bewaar optie'}</span></button>
          </div>
          <div class="detail-block"><h2>Compatibiliteit</h2>${compat}</div>
          <div class="detail-block"><h2>Voordelen</h2><ul class="benefits">${(copy.benefits || []).map((b) => `<li>${icon('check')}${esc(b)}</li>`).join('')}</ul></div>
          <div class="detail-block"><h2>Specificaties</h2><dl class="spec-list">${retrofitSpecs(r).map(([k, val]) => `<dt>${esc(k)}</dt><dd>${esc(val)}</dd>`).join('')}</dl>
            ${r.price || r.offer ? `<p class="hint mt-16">${tx('retro.priceNote')}</p>` : ''}</div>
          ${sameFeature.length ? `<div class="detail-block"><h2>${esc(r.name)} voor andere ${esc(BRAND[r.brand].name)}-modellen</h2><div class="cp-models">${sameFeature.map((x) => `<a class="pill pill--outline" href="#/mogelijkheden/${x.slug}">${esc(x.models.map((m) => MODEL[m].name).join(', '))}${x.variant && VARIANTS[x.variant].label ? ` ${esc(VARIANTS[x.variant].label)}` : ''}</a>`).join('')}</div></div>` : ''}
          <div class="detail-block"><h2>Technische informatie</h2>${UI.accordion(panels)}</div>
          ${project ? `<div class="detail-block">${UI.notice(`<strong>Uit de werkplaats:</strong> ${esc(project.title)} — ${esc(project.vehicle)}.`, { ic: 'camera', actions: `<a class="btn btn--dark btn--xs" href="#/projecten/${project.slug}">Bekijk het project</a>` })}</div>` : ''}
        </div>
      </div>
      ${sections.map((x, i) => relatedSection({ ...x, v, follows: i > 0 })).join('')}
      ${recent.length && Content.section('recent') ? recentSection(recent) : ''}
      ${ctaBand()}`;
  },
  mount(root) { Behaviours.mount(root); },
};

/* Search description of an option: its own text, plus the CarTronic line when that still fits. */
function retrofitDescription(r) {
  const tail = ` Originele fabrieksoptie, ingebouwd en geprogrammeerd door ${COMPANY.name} in ${COMPANY.city}.`;
  return (r.short + tail).length <= 160 ? r.short + tail : Seo.clamp(r.short);
}
/* Structured data shared by the detail pages. */
const providerLd = () => ({ '@type': 'AutoRepair', name: COMPANY.name, telephone: COMPANY.phoneHref.replace('tel:', ''), address: { '@type': 'PostalAddress', streetAddress: COMPANY.street, postalCode: COMPANY.postal, addressLocality: COMPANY.city, addressCountry: 'NL' } });
function breadcrumbLd(crumbs) {
  if (!Seo.url('/')) return null;
  return { '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: crumbs.map(([name, href], i) => ({ '@type': 'ListItem', position: i + 1, name, item: Seo.url(href) })) };
}

/* ---------- Brands ---------- */
Pages.brands = {
  id: 'brands', nav: 'merken',
  meta: { title: 'Merken en modellen', description: 'CarTronic is gespecialiseerd in Volkswagen, Audi, SEAT en Škoda. Bekijk per model welke originele fabrieksopties in de catalogus staan.' },
  render() {
    return `${UI.pageHeader({ crumbs: [['Merken']], eyebrow: tt('brands.eyebrow'), title: tx('brands.title'), lead: tx('brands.lead') })}
      <section class="section"><div class="container">
        <div class="grid grid-2" data-stagger>
          ${BRANDS.map((b) => {
            const models = MODELS.filter((m) => m.brand === b.id);
            const n = RETROFITS.filter((r) => Compat.brandsOf(r).includes(b.id)).length;
            return `<article class="brand-card on-dark">
              <span class="wordmark ${b.wordmark}">${b.name}</span>
              <p>${esc(b.intro)}</p>
              <div class="bc-models">${models.map((m) => `<span>${esc(m.name)}</span>`).join('')}</div>
              <div class="bc-foot"><span>${plural(models.length, 'model', 'modellen')} · ${plural(n, 'mogelijkheid', 'mogelijkheden')}</span><a class="link stretch" href="#/merken/${b.id}" aria-label="Bekijk ${b.name}">Bekijk ${icon('arrow')}</a></div>
            </article>`;
          }).join('')}
        </div>
        <div class="mt-48">${UI.notice(tx('brands.notice'), { ic: 'info' })}</div>
      </div></section>
      ${ctaBand()}`;
  },
};
Pages.brand = {
  id: 'brand', nav: 'merken',
  meta(ctx) { const b = BRAND[ctx.params.brand]; return b ? { title: `${b.name} — modellen en mogelijkheden`, description: `Originele fabrieksopties voor ${b.name}. ${b.intro}` } : { title: 'Merk niet gevonden', noindex: true }; },
  render(ctx) {
    const b = BRAND[ctx.params.brand];
    if (!b) return Pages.notFound.render(ctx);
    const v = VehicleStore.get();
    const models = MODELS.filter((m) => m.brand === b.id);
    const brandWide = RETROFITS.filter((r) => r.scope === 'brand' && Compat.brandsOf(r).includes(b.id));
    return `${UI.pageHeader({ crumbs: [['Merken', '#/merken'], [b.name]], eyebrow: 'Merk', title: esc(b.name), lead: esc(b.intro), compact: true })}
      <section class="section section--sm"><div class="container">
        <div class="section-head" style="margin-bottom:28px"><div><h2 class="h3">${tx('brand.models.title')}</h2><p class="text-muted mt-8" style="font-size:14.5px">${tx('brand.models.text')}</p></div></div>
        <div class="grid grid-3" data-stagger>
          ${models.map((m) => {
            const items = RETROFITS.filter((r) => r.models.includes(m.id));
            const cats = uniq(items.map((r) => r.cat));
            return `<article class="model-card${v && v.modelId === m.id ? ' is-current' : ''}">
              <h3>${esc(m.name)}</h3><span class="mc-years">${modelYears(m)}</span>
              <div class="mc-cats">${cats.map((c) => `<span class="pill">${esc(CATEGORY[c].name)}</span>`).join('')}</div>
              <div class="mc-foot"><span>${plural(items.length, 'mogelijkheid', 'mogelijkheden')}${v && v.modelId === m.id ? ' · <strong>uw auto</strong>' : ''}</span><a class="link stretch" href="#/mogelijkheden?merk=${b.id}&model=${m.id}" aria-label="Mogelijkheden voor ${esc(modelLabel(m.id))}">${icon('arrow')}</a></div>
            </article>`;
          }).join('')}
        </div>
        ${brandWide.length ? `<div class="mt-48"><h2 class="h3" style="margin-bottom:24px">Voor meerdere ${esc(b.name)}-modellen</h2><div class="results-grid" data-stagger>${brandWide.map((r) => UI.retrofitCard(r)).join('')}</div></div>` : ''}
      </div></section>
      ${ctaBand({ title: tx('brand.cta.title', { merk: b.name }), text: tx('brand.cta.text') })}`;
  },
};

/* ---------- Projects ---------- */
Pages.projects = {
  id: 'projects', nav: 'projecten',
  meta: { title: 'Projecten — uit de werkplaats', description: 'Originele upgrades en specialistische werkzaamheden, gefotografeerd in de CarTronic-werkplaats in Rijswijk.' },
  render(ctx) {
    const list = Repo.projects().filter((p) => p.active);
    const brands = BRANDS.filter((b) => list.some((p) => (p.brands || []).includes(b.id)));
    const types = PROJECT_TYPES.filter((t) => list.some((p) => p.type === t.id));
    const fb = ctx.query.merk || ''; const ft = ctx.query.type || '';
    const showFilters = list.length > 3 || !!(fb || ft);
    return `${UI.pageHeader({ crumbs: [[tt('projects.title')]], eyebrow: tt('projects.eyebrow'), title: tx('projects.title'), lead: tx('projects.lead') })}
      <section class="section section--first"><div class="container">
        ${showFilters ? `<div class="project-filters" role="group" aria-label="Filter projecten">
          <div class="chips" data-pf="merk"><button class="chip" type="button" data-v="" aria-pressed="${!fb}">Alle merken</button>${brands.map((b) => `<button class="chip" type="button" data-v="${b.id}" aria-pressed="${fb === b.id}">${b.name}</button>`).join('')}</div>
          <div class="chips" data-pf="type"><button class="chip" type="button" data-v="" aria-pressed="${!ft}">Alle types</button>${types.map((t) => `<button class="chip" type="button" data-v="${t.id}" aria-pressed="${ft === t.id}">${esc(t.name)}</button>`).join('')}</div>
        </div>` : ''}
        <h2 class="sr-only">Projecten</h2>
        <div class="proj-grid" data-project-grid>${list.map((p) => UI.projectCard(p)).join('')}</div>
        <div data-project-empty hidden>${UI.empty({ icon: 'camera', title: 'Geen projecten voor deze selectie', text: 'Kies een ander merk of type.', actions: '<button class="btn btn--dark btn--sm" type="button" data-pf-reset>Toon alle projecten</button>' })}</div>
      </div></section>
      ${MORE_WORK.length ? `<section class="section section--tight-top" aria-labelledby="more-title"><div class="container">
        <div class="section-intro">
          <p class="eyebrow">${tx('projects.more.eyebrow')}</p>
          <h2 class="h2" id="more-title" data-split>${tx('projects.more.title')}</h2>
        </div>
        <div class="more-grid" data-stagger>${MORE_WORK.map((m) => `<article class="more-card">
          <h3>${esc(m.title)}</h3><p>${esc(m.text)}</p>
          <div class="more-links">${m.links.map(([l, u]) => `<a class="ink-link" href="${attr(u)}" target="_blank" rel="noopener">${esc(l)}<span class="sr-only"> (opent in een nieuw venster)</span></a>`).join('')}</div>
        </article>`).join('')}</div>
        <div class="note-rule mt-48" data-reveal>${tx('projects.note')}</div>
      </div></section>` : `<section class="section section--tight-top" aria-label="Opmerking"><div class="container"><div class="note-rule" data-reveal>${tx('projects.note')}</div></div></section>`}
      ${ctaBand()}`;
  },
  mount(root, ctx) {
    const state = { merk: ctx.query.merk || '', type: ctx.query.type || '' };
    const grid = $('[data-project-grid]', root); const empty = $('[data-project-empty]', root);
    const apply = (animate = true) => {
      let shown = 0;
      $$('.project-card', grid).forEach((c) => {
        const ok = (!state.merk || c.dataset.brands.split(' ').includes(state.merk)) && (!state.type || c.dataset.type === state.type);
        c.hidden = !ok; if (ok) shown++;
      });
      empty.hidden = shown > 0;
      $$('[data-pf]', root).forEach((g) => $$('.chip', g).forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.v === state[g.dataset.pf]))));
      Router.setQuery(Object.fromEntries(Object.entries(state).filter(([, x]) => x)));
      if (animate) Motion.swap(grid, '.project-card:not([hidden])');
      announce(`${shown} ${shown === 1 ? 'project' : 'projecten'}`);
    };
    root.addEventListener('click', (e) => {
      const b = e.target.closest('[data-pf] .chip');
      if (b) { state[b.closest('[data-pf]').dataset.pf] = b.dataset.v; apply(); }
      if (e.target.closest('[data-pf-reset]')) { state.merk = ''; state.type = ''; apply(); }
    });
    apply(false);
  },
};
Pages.project = {
  id: 'project', nav: 'projecten',
  meta(ctx) { const p = Repo.project(ctx.params.slug); return p && p.active ? { title: `${p.title} — ${p.vehicle}`, description: p.short } : { title: 'Project niet gevonden', noindex: true }; },
  render(ctx) {
    const p = Repo.project(ctx.params.slug);
    if (!p || !p.active) return Pages.notFound.render(ctx, { title: 'Dit project bestaat niet (meer).' });
    const related = (p.related || []).map((s) => RETROFIT[s]).filter(Boolean);
    const services = (p.services || []).map((s) => SERVICE[s]).filter(Boolean);
    const type = PROJECT_TYPES.find((t) => t.id === p.type);
    const imgs = [p.image, ...(p.gallery || [])].filter(Boolean);
    const hasBA = Media.src(p.before) && Media.src(p.after);
    const others = Repo.projects().filter((x) => x.active && x.slug !== p.slug).slice(0, 3);
    return `${UI.pageHeader({ crumbs: [['Projecten', '#/projecten'], [p.title]], eyebrow: p.vehicle, title: esc(p.title), lead: esc(p.short), compact: true })}
      <section class="section section--sm"><div class="container">
        <div class="pdp" style="padding:0">
          <div class="pdp-gallery">${UI.gallery(imgs, p.title, 'camera')}</div>
          <div class="pdp-info">
            <p class="eyebrow">${esc(p.tag)}</p>
            <h2 class="h3 mt-16">Over dit project</h2>
            <div class="prose mt-16"><p>${esc(p.body || p.short)}</p></div>
            <dl class="spec-list mt-32"><dt>Voertuig</dt><dd>${esc(p.vehicle)}</dd><dt>Type werk</dt><dd>${esc(type ? type.name : p.tag)}</dd><dt>Locatie</dt><dd>CarTronic-werkplaats, Rijswijk</dd></dl>
            <div class="detail-actions">
              <a class="btn btn--primary" href="#/contact">Vraag dit aan voor uw auto</a>
              ${related.length ? `<a class="btn btn--light" href="#/mogelijkheden/${related[0].slug}">Bekijk de optie</a>` : ''}
            </div>
            ${services.length ? `<div class="detail-block"><h2>Gerelateerde dienst</h2><div class="grid">${services.map((s) => `<a class="mini-item" href="#/diensten/${s.slug}" style="grid-template-columns:40px minmax(0,1fr) auto"><span class="icon-circle icon-circle--sm">${icon(s.icon)}</span><span><span class="mi-type">Dienst</span><span class="mi-title" style="display:block">${esc(s.title)}</span></span>${icon('arrow').replace('<svg', '<svg style="width:16px;height:16px;color:var(--muted)"')}</a>`).join('')}</div></div>` : ''}
          </div>
        </div>
        ${hasBA ? `<div class="mt-48"><h2 class="h3" style="margin-bottom:20px">Voor en na</h2>${UI.beforeAfter(p.before, p.after, p.title)}<p class="hint mt-8">Sleep de schuifregelaar of gebruik de pijltjestoetsen.</p></div>` : ''}
        ${related.length ? `<div class="mt-48"><h2 class="h3" style="margin-bottom:24px">Deze optie in de catalogus</h2><div class="results-grid" data-stagger>${related.map((r) => UI.retrofitCard(r)).join('')}</div></div>` : ''}
      </div></section>
      ${others.length ? `<section class="section section--soft section--sm"><div class="container"><div class="section-head" style="margin-bottom:28px"><h2 class="h3">Meer uit de werkplaats</h2><a class="link" href="#/projecten">Alle projecten ${icon('arrow')}</a></div><div class="grid grid-3" data-stagger>${others.map((x) => UI.projectCard(x)).join('')}</div></div></section>` : ''}
      ${ctaBand()}`;
  },
  mount(root) { Behaviours.mount(root); },
};

/* ---------- Expertise & services ---------- */
Pages.expertise = {
  id: 'expertise', nav: 'expertise',
  meta: { title: 'Expertise — inbouwen, programmeren en kalibreren', description: 'Originele fabrieksopties inbouwen, online programmeren via de fabriek, kalibratie van ACC, Lane Assist en Night Vision, diagnose en reparatie voor Volkswagen, Audi, SEAT en Škoda.' },
  render() {
    return `${UI.pageHeader({ crumbs: [['Expertise']], eyebrow: tt('exp.eyebrow'), title: tx('exp.title'), lead: tx('exp.lead') })}
      <section class="section section--first" id="diensten" aria-labelledby="svc-title"><div class="container">
        <h2 class="sr-only" id="svc-title">Diensten</h2>
        <div class="svc-grid" data-stagger>${SERVICES.map(svcCard).join('')}</div>
      </div></section>
      <section class="section section--tight-top" aria-labelledby="tech-title"><div class="container">${techCard({ link: false })}</div></section>
      <section class="section section--soft" aria-labelledby="tools-title"><div class="container">
        <div class="section-intro">
          <p class="eyebrow">${tx('exp.tools.eyebrow')}</p>
          <h2 class="h2" id="tools-title" data-split>${tx('exp.tools.title')}</h2>
        </div>
        <div class="plain-features plain-features--4" data-stagger>
          ${[1, 2, 3, 4].map((n) => `<div><h3>${tx(`exp.t${n}.title`)}</h3><p>${tx(`exp.t${n}.text`)}</p></div>`).join(`
          `)}
        </div>
      </div></section>
      <section class="section" aria-labelledby="dealer-title"><div class="container container--narrow text-center">
        <p class="eyebrow">${tx('exp.dealer.eyebrow')}</p>
        <h2 class="h2 mt-16" id="dealer-title" data-split>${tx('exp.dealer.title')}</h2>
        <p class="lead mt-24" data-reveal>${tx('exp.dealer.text')}</p>
        <p class="mt-32" data-reveal><a class="btn btn--outline" href="#/contact">${tx('exp.dealer.btn')}</a></p>
      </div></section>
      ${ctaBand()}`;
  },
};
Pages.service = {
  id: 'service', nav: 'expertise',
  meta(ctx) {
    const s = SERVICE[ctx.params.slug];
    if (!s) return { title: 'Dienst niet gevonden', noindex: true };
    return { title: s.title, description: s.short, jsonLd: [
      { '@context': 'https://schema.org', '@type': 'Service', name: s.title, description: s.short, provider: providerLd() },
      breadcrumbLd([['Home', '#/'], ['Expertise', '#/expertise'], [s.title, `#/diensten/${s.slug}`]]),
    ].filter(Boolean) };
  },
  render(ctx) {
    const s = SERVICE[ctx.params.slug];
    if (!s) return Pages.notFound.render(ctx);
    const cats = (s.cats || []).map((c) => CATEGORY[c]).filter(Boolean);
    const others = SERVICES.filter((x) => x.slug !== s.slug).slice(0, 3);
    const projects = Repo.projects().filter((p) => p.active && (p.services || []).includes(s.slug));
    const wa = WhatsApp.enquiry({ vehicle: VehicleStore.get() ? VehicleStore.name() : '', plate: VehicleStore.plate(), options: [s.title], question: '' });
    return `${UI.pageHeader({ crumbs: [['Expertise', '#/expertise'], [s.title]], eyebrow: 'Dienst', title: esc(s.title), lead: esc(s.short), compact: true })}
      <section class="section section--sm"><div class="container split">
        <div>
          <div class="prose">${s.body.map((p) => `<p>${esc(p)}</p>`).join('')}</div>
          <div class="detail-actions">
            <a class="btn btn--primary" href="#/contact${SERVICE_TOPIC[s.slug] ? `?onderwerp=${SERVICE_TOPIC[s.slug]}` : ''}">Afspraak of vraag</a>
            <a class="btn btn--whatsapp" href="${WhatsApp.url(wa)}" target="_blank" rel="noopener" data-action="whatsapp">${icon('whatsapp')} WhatsApp</a>
            <a class="btn btn--light" href="${attr(COMPANY.phoneHref)}">${icon('phone')} Bel ons</a>
          </div>
          ${cats.length ? `<div class="detail-block"><h2>Gerelateerde mogelijkheden</h2><div class="chips">${cats.map((c) => `<a class="chip" href="#/mogelijkheden?cat=${c.id}">${icon(c.icon)} ${esc(c.name)}</a>`).join('')}</div></div>` : ''}
          ${projects.length ? `<div class="detail-block"><h2>Uit de werkplaats</h2><div class="grid">${projects.map((p) => `<div class="mini-item"><div class="mi-media">${Media.html(p.image, p.title, { kind: 'camera' })}</div><div><div class="mi-type">Project</div><a class="mi-title stretch" href="#/projecten/${p.slug}">${esc(p.title)}</a></div><div class="mi-aside"></div></div>`).join('')}</div></div>` : ''}
        </div>
        <div>${s.image ? `<div class="split-media" data-mask>${Media.html(imgRef(s.image), s.title, { kind: 'assist' })}</div>` : `<div class="split-media" style="aspect-ratio:4/3">${Art.html(s.icon === 'radar' || s.icon === 'target' ? 'assist' : (s.icon === 'cpu' || s.icon === 'settings2' ? 'module' : (s.icon === 'refresh' ? 'cockpit' : (s.icon === 'activity' ? 'module' : 'camera'))), 1, s.title)}</div>`}</div>
      </div></section>
      <section class="section section--soft section--sm"><div class="container">
        <h2 class="h3" style="margin-bottom:24px">Andere diensten</h2>
        <div class="grid grid-3" data-stagger>${others.map((x) => `<article class="service-card"><span class="sv-icon">${icon(x.icon)}</span><h3>${esc(x.title)}</h3><p>${esc(x.short)}</p><a class="link stretch" href="#/diensten/${x.slug}">Meer informatie ${icon('arrow')}</a></article>`).join('')}</div>
      </div></section>
      ${ctaBand()}`;
  },
};

/* ---------- About ---------- */
Pages.about = {
  id: 'about', nav: 'over',
  meta: { title: 'Over CarTronic — vier merken, één specialisme', description: 'CarTronic in Rijswijk richt zich op Volkswagen, Audi, SEAT en Škoda: originele fabrieksopties achteraf inbouwen, met diagnoseapparatuur op dealerniveau.' },
  render() {
    return `${UI.pageHeader({ crumbs: [[tt('about.title')]], eyebrow: tt('about.eyebrow'), title: tx('about.title'), lead: tx('about.lead') })}
      <section class="section section--first"><div class="container">
        <div class="split split--wide-media">
          <div>
            <p class="eyebrow">${tx('about.intro.eyebrow')}</p>
            <h2 class="h2" data-split>${tx('about.intro.title')}</h2>
            <div class="prose" data-reveal>${aboutProse()}</div>
            <p class="mt-32" data-reveal><a class="btn btn--primary" href="#/expertise">${tx('about.btn')}</a></p>
          </div>
          <div class="split-media" data-mask>${Media.html('img:about', 'Volkswagen Golf Sportsvan op de uitlijnbrug in de CarTronic-werkplaats', { kind: 'assist', eager: true })}</div>
        </div>
        <hr class="rule">
        <div class="plain-features" data-stagger>
          ${[1, 2, 3].map((n) => `<div><h3>${tx(`about.f${n}.title`)}</h3><p>${tx(`about.f${n}.text`)}</p></div>`).join(`
          `)}
        </div>
        <div class="note-rule mt-48" data-reveal>${tx('about.note')}</div>
      </div></section>
      ${ctaBand()}`;
  },
};

/* ---------- Contact (smart enquiry) ---------- */
Pages.contact = {
  id: 'contact', nav: 'contact',
  meta: { title: 'Contact — vraag naar de mogelijkheden', description: 'Neem contact op met CarTronic in Rijswijk: Patrijsweg 22, 070 383 9836, info@cartronic.nl. Stuur uw kenteken en gewenste optie via WhatsApp of e-mail.' },
  render() {
    return `${UI.pageHeader({ crumbs: [[tt('contact.title')]], eyebrow: tt('contact.eyebrow'), title: tx('contact.title'), lead: tx('contact.lead') })}
      <section class="section section--first"><div class="container contact-layout">
        <div class="contact-info">
          <p class="eyebrow">${tx('contact.info.eyebrow')}</p>
          <h2 class="h2" data-split>${tx('contact.info.title')}</h2>
          <p class="lead" data-reveal>${tx('contact.info.lead')}</p>
          <ul class="contact-rows">
            <li>${icon('phone')}<div><span class="cr-label">Bellen</span><a class="cr-value" href="${attr(COMPANY.phoneHref)}">${esc(COMPANY.phoneDisplay)}</a></div></li>
            <li>${icon('chat')}<div><span class="cr-label">${tx('contact.waLabel')}</span><a class="cr-value" href="${attr(WhatsApp.generic())}" target="_blank" rel="noopener" data-action="whatsapp" data-wa-generic><span class="sr-only">WhatsApp: </span>${esc(WhatsApp.display())}<span class="sr-only"> (opent in een nieuw venster)</span></a></div></li>
            <li>${icon('mail')}<div><span class="cr-label">E-mail</span><a class="cr-value" href="mailto:${attr(COMPANY.email)}">${esc(COMPANY.email)}</a></div></li>
            <li>${icon('pin')}<div><span class="cr-label">Adres</span><span class="cr-value">${esc(COMPANY.street)}<br>${esc(COMPANY.postal)} ${esc(COMPANY.city)}</span><a class="cr-more" href="${attr(COMPANY.mapsUrl)}" target="_blank" rel="noopener">Route plannen</a></div></li>
            <li>${icon('clock')}<div><span class="cr-label">Openingstijden</span><dl class="footer-hours footer-hours--light">${COMPANY.hours.map(([d, t]) => `<dt>${esc(d)}</dt><dd>${esc(t)}</dd>`).join('')}</dl></div></li>
          </ul>
        </div>
        <div class="contact-form-wrap">
          <h2 class="h3 contact-form-title" id="contact-form-title">${tx('contact.form.title')}</h2>
          <p class="contact-form-sub">${tx('contact.form.sub')}</p>
          <form class="contact-form" data-contact novalidate aria-labelledby="contact-form-title">
            <div data-contact-body></div>
          </form>
        </div>
      </div></section>`;
  },
  mount(root, ctx) {
    const v = VehicleStore.get();
    const draft = Storage.get('contactDraft', {}, 'session');
    const optionSlugs = uniq([ctx.query.optie, ...(draft.options || []), ...Saved.all().retrofits].filter((s) => s && RETROFIT[s]));
    const productIds = Content.shopOn() ? uniq([...(draft.products || []), ...Cart.get().items.map((i) => i.productId), ...Saved.all().products].filter((id) => isPublicProduct(Repo.product(id)))) : [];
    const state = {
      name: draft.name || '', email: draft.email || '', phone: draft.phone || '',
      vehicle: draft.vehicle || (v ? VehicleStore.name(v) : ''), plate: draft.plate || VehicleStore.plate() || '', year: draft.year || (v && v.year ? String(v.year) : ''),
      options: optionSlugs, products: productIds, question: draft.question || '', vin: draft.vin || '',
      topic: (ctx.query.onderwerp && ENQUIRY_TOPIC[ctx.query.onderwerp] ? ctx.query.onderwerp : '')
        || (ctx.query.optie && RETROFIT[ctx.query.optie] ? 'inbouw' : '')
        || (draft.topic && ENQUIRY_TOPIC[draft.topic] ? draft.topic : '') || (optionSlugs.length ? 'inbouw' : ''),
    };
    const VIN_RE = /^[A-HJ-NPR-Z0-9]{17}$/;
    const body = $('[data-contact-body]', root);
    const err = {};
    const summary = () => WhatsApp.enquiry({
      name: state.name, topic: state.topic ? ENQUIRY_TOPIC[state.topic].label : '', vin: state.vin,
      vehicle: state.vehicle, plate: Plate.format(state.plate) || state.plate, year: state.year,
      options: state.options.map((s) => RETROFIT[s].title), products: state.products.map((id) => Repo.product(id)).filter(Boolean).map((p) => `${p.name} (${p.sku})`), question: state.question,
    });
    const save = () => Storage.set('contactDraft', { ...state }, 'session');
    const render = () => {
      body.innerHTML = `
        <fieldset class="form-section topic-field"><legend class="topic-legend">Waar gaat uw vraag over?</legend>
          <div class="chips topic-chips">${ENQUIRY_TOPICS.filter((t) => t.id !== 'webshop' || Content.shopOn() || state.topic === t.id).map((t) => `<label class="chip chip-radio${state.topic === t.id ? ' is-checked' : ''}"><input type="radio" name="topic" value="${t.id}"${state.topic === t.id ? ' checked' : ''}><span>${esc(t.label)}</span></label>`).join('')}</div>
          ${state.topic === 'optielijst' ? '<p class="hint mt-8">De optielijst maakt CarTronic op basis van het chassisnummer (VIN). Dat staat op uw kentekenbewijs. U kunt het hieronder invullen of later sturen.</p>' : ''}
        </fieldset>
        <div class="form-section"><h3>Uw auto</h3>
          <div class="form-grid">
            <div class="field span-2"><label for="c-vehicle">Merk en model</label><input class="input" id="c-vehicle" data-k="vehicle" value="${attr(state.vehicle)}" placeholder="Bijv. Volkswagen Golf 8"></div>
            <div class="field"><label for="c-plate">Kenteken <span class="opt">(optioneel)</span></label><input class="input" id="c-plate" data-k="plate" value="${attr(state.plate)}" placeholder="AB-123-C" autocapitalize="characters" aria-describedby="c-plate-e"><span class="field-error" id="c-plate-e">${err.plate || ''}</span></div>
            <div class="field"><label for="c-year">Bouwjaar <span class="opt">(optioneel)</span></label><input class="input" id="c-year" data-k="year" inputmode="numeric" maxlength="4" value="${attr(state.year)}" placeholder="2019"></div>
            <div class="field span-2"><label for="c-vin">Chassisnummer (VIN) <span class="opt">(optioneel)</span></label><input class="input" id="c-vin" data-k="vin" maxlength="30" autocapitalize="characters" spellcheck="false" value="${attr(state.vin)}" placeholder="17 tekens, staat op uw kentekenbewijs" aria-describedby="c-vin-e"${err.vin ? ' aria-invalid="true"' : ''}><span class="field-error" id="c-vin-e">${err.vin || ''}</span></div>
          </div>
          ${v ? '' : `<p class="hint mt-8">Tip: <button type="button" class="text-link" data-action="open-vehicle">zoek uw auto op kenteken</button> om dit automatisch in te vullen.</p>`}
        </div>
        <div class="form-section"><h3>Geselecteerde opties</h3>
          <div class="chips" data-opt-list>${state.options.length ? state.options.map((s) => `<span class="chip chip--removable">${esc(RETROFIT[s].title)}<button type="button" data-rm-opt="${s}" aria-label="Verwijder ${attr(RETROFIT[s].title)}">${icon('x')}</button></span>`).join('') : '<span class="hint">Nog geen opties geselecteerd. Bewaar opties in de catalogus of voeg er hieronder een toe.</span>'}</div>
          <div class="field mt-16"><label for="c-addopt">Optie toevoegen</label><select class="select" id="c-addopt" data-add-opt><option value="">Kies een optie…</option>${(v ? Compat.forVehicle(v).map((x) => x.item) : RETROFITS).filter((r) => !state.options.includes(r.slug)).map((r) => `<option value="${r.slug}">${esc(r.title)}</option>`).join('')}</select></div>
          ${state.products.length ? `<div class="mt-16"><p class="label" style="margin-bottom:8px">Producten uit de webshop</p><div class="chips">${state.products.map((id) => { const p = Repo.product(id); return `<span class="chip chip--removable">${esc(p.name)}<button type="button" data-rm-prod="${id}" aria-label="Verwijder ${attr(p.name)}">${icon('x')}</button></span>`; }).join('')}</div></div>` : ''}
        </div>
        <div class="form-section"><h3>Uw vraag</h3>
          <div class="field"><label for="c-q">Vraag of opmerking</label><textarea class="textarea" id="c-q" data-k="question" placeholder="Bijv. welke uitvoering heb ik nodig, of wanneer kan ik langskomen?" aria-describedby="c-q-e">${esc(state.question)}</textarea><span class="field-error" id="c-q-e">${err.question || ''}</span></div>
        </div>
        <div class="form-section"><h3>Uw gegevens</h3>
          <div class="form-grid">
            <div class="field span-2"><label for="c-name">Naam</label><input class="input" id="c-name" data-k="name" autocomplete="name" value="${attr(state.name)}" aria-describedby="c-name-e"${err.name ? ' aria-invalid="true"' : ''}><span class="field-error" id="c-name-e">${err.name || ''}</span></div>
            <div class="field"><label for="c-email">E-mail <span class="opt">(optioneel)</span></label><input class="input" id="c-email" type="email" data-k="email" autocomplete="email" value="${attr(state.email)}" aria-describedby="c-email-e"${err.email ? ' aria-invalid="true"' : ''}><span class="field-error" id="c-email-e">${err.email || ''}</span></div>
            <div class="field"><label for="c-phone">Telefoon <span class="opt">(optioneel)</span></label><input class="input" id="c-phone" type="tel" data-k="phone" autocomplete="tel" value="${attr(state.phone)}" aria-describedby="c-phone-e"${err.phone ? ' aria-invalid="true"' : ''}><span class="field-error" id="c-phone-e">${err.phone || ''}</span></div>
          </div>
        </div>
        <div class="form-section"><h3>Samenvatting van uw aanvraag</h3>
          <div class="enquiry-summary"><pre data-summary>${esc(summary())}</pre></div>
          <div class="detail-actions">
            <button class="btn btn--whatsapp" type="button" data-send="whatsapp">${icon('whatsapp')} Verstuur via WhatsApp</button>
            <button class="btn btn--dark" type="button" data-send="email">${icon('mail')} Verstuur per e-mail</button>
          </div>
          <p class="hint mt-16">${tx('contact.form.hint')}</p>
        </div>`;
    };
    const validate = () => {
      Object.keys(err).forEach((k) => delete err[k]);
      if (!state.name.trim()) err.name = 'Vul uw naam in.';
      if (state.email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(state.email)) err.email = 'Vul een geldig e-mailadres in.';
      if (state.phone && !/^(\+|0)[0-9\s-]{8,15}$/.test(state.phone.trim())) err.phone = 'Vul een geldig telefoonnummer in.';
      if (state.plate && !Plate.isValid(state.plate)) err.plate = 'Dit is geen geldig Nederlands kenteken.';
      if (state.vin && !VIN_RE.test(state.vin)) err.vin = 'Een chassisnummer heeft 17 tekens (letters en cijfers, zonder I, O en Q).';
      const topicSays = state.topic && state.topic !== 'anders';
      if (!state.question.trim() && !state.options.length && !state.products.length && !topicSays) err.question = 'Kies een onderwerp, stel uw vraag of selecteer ten minste één optie.';
      return !Object.keys(err).length;
    };
    render();
    body.addEventListener('input', (e) => {
      const k = e.target.dataset.k; if (!k) return;
      if (k === 'vin') {
        const pos = e.target.selectionStart || 0;
        const before = e.target.value.slice(0, pos).replace(/\s+/g, '').length;
        state.vin = e.target.value.toUpperCase().replace(/\s+/g, '');
        if (e.target.value !== state.vin) { e.target.value = state.vin; try { e.target.setSelectionRange(before, before); } catch (er) { /* type without selection */ } }
      } else state[k] = e.target.value;
      if (err[k]) { delete err[k]; e.target.removeAttribute('aria-invalid'); const fe = document.getElementById(`${e.target.id}-e`); if (fe) fe.textContent = ''; }
      if (k === 'question' && err.question) delete err.question;
      if (k === 'plate') { const f = Plate.format(e.target.value); if (f) { state.plate = f; } }
      $('[data-summary]', body).textContent = summary();
      save();
    });
    body.addEventListener('change', (e) => {
      if (e.target.name === 'topic') { state.topic = e.target.value; delete err.question; save(); render(); const r = $(`input[name="topic"][value="${state.topic}"]`, body); if (r) r.focus(); return; }
      if (e.target.matches('[data-add-opt]') && e.target.value) { state.options.push(e.target.value); delete err.question; save(); render(); $('[data-add-opt]', body).focus(); }
      if (e.target.dataset.k === 'plate') { const f = Plate.format(state.plate); if (f) e.target.value = f; }
    });
    body.addEventListener('click', (e) => {
      const ro = e.target.closest('[data-rm-opt]'); if (ro) { state.options = state.options.filter((s) => s !== ro.dataset.rmOpt); save(); render(); return; }
      const rp = e.target.closest('[data-rm-prod]'); if (rp) { state.products = state.products.filter((s) => s !== rp.dataset.rmProd); save(); render(); return; }
      const send = e.target.closest('[data-send]'); if (!send) return;
      if (!validate()) {
        render();
        const first = $('[aria-invalid="true"], .field-error:not(:empty)', body);
        const target = first && first.classList.contains('field-error') ? first.previousElementSibling : first;
        if (target) target.focus();
        Toast.show('Controleer de gemarkeerde velden.', { error: true });
        return;
      }
      const text = summary();
      if (send.dataset.send === 'whatsapp') {
        Analytics.track('whatsapp_clicked', { context: 'contact' });
        window.open(WhatsApp.url(text), '_blank', 'noopener');
      } else {
        Analytics.track('enquiry_email_opened', {});
        const subject = `Aanvraag via website${state.vehicle ? ` — ${state.vehicle}` : ''}`;
        location.href = `mailto:${COMPANY.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(text)}`;
      }
      Toast.show('Uw aanvraag is klaargezet. Controleer en verstuur het bericht.');
    });
  },
};

/* ---------- Beoordelingen ---------- */
Pages.reviews = {
  id: 'reviews', nav: 'beoordelingen',
  meta: () => ({ title: 'Beoordelingen — ervaringen van klanten', description: `CarTronic scoort gemiddeld ${REVIEWS.score} uit ${REVIEWS.scale} op ${REVIEWS.source}, op basis van ${REVIEWS.count} beoordelingen.` }),
  render() {
    return `${UI.pageHeader({ crumbs: [[tt('reviews.eyebrow')]], eyebrow: tt('reviews.eyebrow'), title: tx('reviews.title'), lead: tx('reviews.lead', { bron: REVIEWS.source }) })}
      <section class="section section--first"><div class="container">${reviewsBlock({ eyebrow: false })}</div></section>
      <section class="section section--soft section--sm" aria-labelledby="write-title"><div class="container">
        <div class="review-cta">
          <div><h2 class="h3" id="write-title">${tx('reviews.write.title')}</h2><p>${tx('reviews.write.text', { bron: REVIEWS.source })}</p></div>
          <a class="btn btn--dark" href="${attr(REVIEWS.writeUrl)}" target="_blank" rel="noopener">${tx('reviews.write.btn')}</a>
        </div>
        <p class="hint mt-24">${tx('reviews.note', { bron: REVIEWS.source })}</p>
      </div></section>
      ${ctaBand()}`;
  },
};

/* ---------- Berichten & kennis ---------- */
const kbCard = (a, h = 'h2') => `<article class="kb-card">
    <p class="kb-tag">${esc(a.tag)}</p>
    <${h} class="kb-title">${esc(a.title)}</${h}>
    <p>${esc(a.short)}</p>
    <a class="red-link stretch" href="#/kennis/${a.slug}" aria-label="Lees verder: ${attr(a.title)}">Lees verder</a>
  </article>`;
Pages.knowledge = {
  id: 'knowledge', nav: 'kennis',
  meta: { title: 'Berichten & kennis', description: 'Uitleg van CarTronic over originele opties, programmeren via de fabriek, kalibratie van rijhulpsystemen, origineel alarm, CarPlay en de optielijst van uw auto.' },
  render() {
    return `${UI.pageHeader({ crumbs: [[tt('kb.eyebrow')]], eyebrow: tt('kb.eyebrow'), title: tx('kb.title'), lead: tx('kb.lead') })}
      <section class="section section--first"><div class="container">
        <div class="kb-grid" data-stagger>${ARTICLES.map((a) => kbCard(a)).join('')}</div>
      </div></section>
      ${ctaBand()}`;
  },
};
Pages.article = {
  id: 'article', nav: 'kennis',
  meta(ctx) {
    const a = ARTICLE[ctx.params.slug];
    if (!a) return { title: 'Bericht niet gevonden', noindex: true };
    return { title: a.title, description: a.short, jsonLd: [
      { '@context': 'https://schema.org', '@type': 'Article', headline: a.title, description: a.short, author: { '@type': 'Organization', name: COMPANY.name }, publisher: { '@type': 'Organization', name: COMPANY.name } },
      breadcrumbLd([['Home', '#/'], [tt('kb.eyebrow'), '#/kennis'], [a.title, `#/kennis/${a.slug}`]]),
    ].filter(Boolean) };
  },
  render(ctx) {
    const a = ARTICLE[ctx.params.slug];
    if (!a) return Pages.notFound.render(ctx, { title: 'Dit bericht bestaat niet (meer).', text: 'Bekijk de andere berichten of ga verder via de homepage.' });
    const others = ARTICLES.filter((x) => x.slug !== a.slug).slice(0, 3);
    return `${UI.pageHeader({ crumbs: [[tt('kb.eyebrow'), '#/kennis'], [a.title]], eyebrow: a.tag, title: esc(a.title), lead: esc(a.short), compact: true })}
      <section class="section section--first"><div class="container article-layout">
        <article class="article">
          ${a.body.map(richBlockHtml).join('')}
          ${a.links && a.links.length ? `<div class="article-links">${a.links.map(([l, h]) => `<a class="ink-link" href="${attr(h)}">${esc(l)}</a>`).join('')}</div>` : ''}
        </article>
        <aside class="article-aside" aria-labelledby="ask-title">
          <h2 class="h4" id="ask-title">${tx('kb.aside.title')}</h2>
          <p>${tx('kb.aside.text')}</p>
          <div class="aside-actions">
            <a class="btn btn--primary btn--block" href="#/contact">${tx('kb.aside.btn')}</a>
            <a class="btn btn--whatsapp btn--block" href="${WhatsApp.generic()}" target="_blank" rel="noopener" data-action="whatsapp" data-wa-generic>${icon('whatsapp')} WhatsApp</a>
          </div>
        </aside>
      </div></section>
      ${others.length ? `<section class="section section--soft section--sm" aria-labelledby="more-kb-title"><div class="container">
        <div class="section-head" style="margin-bottom:28px"><h2 class="h3" id="more-kb-title">Meer berichten</h2><a class="link" href="#/kennis">Alle berichten ${icon('arrow')}</a></div>
        <div class="kb-grid">${others.map((x) => kbCard(x, 'h3')).join('')}</div>
      </div></section>` : ''}
      ${ctaBand()}`;
  },
};

/* ---------- Productinformatie ---------- */
Pages.productInfo = {
  id: 'productinfo', nav: 'productinformatie',
  meta: { title: 'Productinformatie — onderdelen, garantie en compatibiliteit', description: 'Hoe CarTronic werkt: originele OEM-onderdelen, garantie, prijzen en aanbiedingen, en hoe u ziet of een optie bij uw auto past.' },
  render() {
    const st = (k) => `<li>${Compat.badge({ key: k })}<span>${tx(`pi.st.${k}`)}</span></li>`;
    const blocks = [['box', 1], ['shield', 2], ['euro', 3], ['sliders', 4]];
    return `${UI.pageHeader({ crumbs: [[tt('pi.eyebrow')]], eyebrow: tt('pi.eyebrow'), title: tx('pi.title'), lead: tx('pi.lead') })}
      <section class="section section--first"><div class="container">
        <div class="info-grid" data-stagger>
          ${blocks.map(([ic, n]) => `<article class="info-block"><span class="ib-icon">${icon(ic)}</span><h2>${tx(`pi.b${n}.title`)}</h2>
            <p>${tx(`pi.b${n}.text`)}</p></article>`).join(`
          `)}
        </div>
      </div></section>
      <section class="section section--soft" aria-labelledby="fit-title"><div class="container split split--top">
        <div>
          <p class="eyebrow">${tx('pi.fit.eyebrow')}</p>
          <h2 class="h2 mt-16" id="fit-title" data-split>${tx('pi.fit.title')}</h2>
          <p class="lead mt-24" data-reveal>${tx('pi.fit.lead')}</p>
          <p class="mt-32" data-reveal><button class="btn btn--primary" type="button" data-action="open-vehicle">${icon('car')} Kies uw auto</button></p>
        </div>
        <ul class="status-legend" data-reveal>
          ${st('ok')}
          ${st('variant')}
          ${st('check')}
          ${st('contact')}
        </ul>
      </div></section>
      <section class="section" aria-labelledby="optlist-title"><div class="container split split--top">
        <div>
          <p class="eyebrow">${tx('pi.opt.eyebrow')}</p>
          <h2 class="h2 mt-16" id="optlist-title" data-split>${tx('pi.opt.title')}</h2>
        </div>
        <div class="prose" data-reveal>
          <p>${tx('pi.opt.p1')}</p>
          <p>${tx('pi.opt.p2')}</p>
          <p class="mt-24"><a class="ink-link" href="#/contact?onderwerp=optielijst">${tx('pi.opt.link')}</a></p>
        </div>
      </div></section>
      ${Content.shopOn() ? `<section class="section section--soft section--sm" aria-labelledby="shopinfo-title"><div class="container">
        <div class="note-rule"><strong id="shopinfo-title">${tx('pi.shop.title')}</strong> ${tx('pi.shop.text')}</div>
      </div></section>` : ''}
      ${ctaBand()}`;
  },
};

/* ---------- Privacy ---------- */
Pages.privacy = {
  id: 'privacy', nav: '',
  meta: { title: 'Privacy — wat deze website bewaart', description: 'Welke gegevens deze website in uw browser bewaart, wat er naar de RDW gaat bij het opzoeken van een kenteken, en hoe u alles wist.' },
  render() {
    return `${UI.pageHeader({ crumbs: [[tt('priv.eyebrow')]], eyebrow: tt('priv.eyebrow'), title: tx('priv.title'), lead: tx('priv.lead'), compact: true })}
      <section class="section section--first"><div class="container article-layout">
        <article class="article">
          ${tx('priv.body')}
          <p class="mt-24"><button class="btn btn--dark" type="button" data-action="wipe-local">${icon('trash')} Alles wissen uit deze browser</button></p>
        </article>
        <aside class="article-aside" aria-labelledby="privacy-q-title">
          <h2 class="h4" id="privacy-q-title">${tx('priv.aside.title')}</h2>
          <p>Neem contact op met CarTronic via <a class="text-link" href="mailto:${attr(COMPANY.email)}">${esc(COMPANY.email)}</a> of ${esc(COMPANY.phoneDisplay)}.</p>
        </aside>
      </div></section>`;
  },
};

/* ---------- Mijn auto & bewaard ---------- */
Pages.garage = {
  id: 'garage', nav: 'mijn-auto',
  meta: { title: 'Mijn auto en bewaarde opties', description: 'Uw gekozen auto, bewaarde opties en producten en recent bekeken items — alleen opgeslagen in deze browser.', noindex: true },
  render() {
    const v = VehicleStore.get();
    const plate = VehicleStore.plate();
    const own = v ? Compat.forVehicle(v) : [];
    const savedR = Saved.retrofits(); const savedP = Saved.products(); const recent = Recent.list();
    const shop = Content.shopOn();
    const ownProducts = v && shop ? Repo.products().filter((p) => isPublicProduct(p) && UI.productFit(p, v) === 'model') : [];
    const byCat = CATEGORIES.map((c) => [c, own.filter((x) => x.item.cat === c.id)]).filter(([, l]) => l.length);
    return `${UI.pageHeader({ crumbs: [[tt('garage.eyebrow')]], eyebrow: tt('garage.eyebrow'), title: tx('garage.title'), lead: tx('garage.lead') })}
      <section class="section section--sm" style="padding-top:56px"><div class="container">
        ${v ? `<div class="vehicle-hero">
            <div><div class="vh-kicker">Uw auto</div><h2>${esc(VehicleStore.name(v))}</h2>
              <div class="vh-meta">${plate ? plateChip(plate) : ''}<span>${esc(VehicleStore.meta(v))}</span><span>${esc(VehicleStore.sourceLabel(v))}</span></div></div>
            <div class="vh-actions">
              <a class="btn btn--primary btn--sm" href="#/mogelijkheden">${plural(own.length, 'mogelijkheid', 'mogelijkheden')}</a>
              <button class="btn btn--light btn--sm" type="button" data-action="open-vehicle">Wijzig auto</button>
              ${plate ? '<button class="btn btn--ghost btn--sm" type="button" data-action="forget-plate">Kenteken vergeten</button>' : ''}
            </div></div>`
          : `<div class="panel" style="padding:28px"><h2 class="h3" style="margin-bottom:20px">Kies uw auto</h2>${VehicleFinder.html({ context: 'garage' })}</div>`}

        ${v ? `<div class="mt-48"><div class="section-head" style="margin-bottom:20px"><h2 class="h3">Mogelijkheden voor uw auto</h2><a class="link" href="#/mogelijkheden">Bekijk als overzicht ${icon('arrow')}</a></div>
          ${byCat.length ? `<div class="grid grid-2">${byCat.map(([c, l]) => `<div class="panel"><div class="panel-head"><h3 class="h4" style="font-size:15px;display:flex;gap:10px;align-items:center">${icon(c.icon).replace('<svg', '<svg style="width:18px;height:18px;color:var(--red)"')} ${esc(c.name)}</h3><span class="pill">${l.length}</span></div>
            <div class="panel-body" style="display:grid;gap:10px">${l.map(({ item, st }) => `<a class="flex justify-between items-center gap-12" href="#/mogelijkheden/${item.slug}" style="font-size:14px;font-weight:550"><span>${esc(item.name)}</span>${Compat.badge(st)}</a>`).join('')}</div></div>`).join('')}</div>`
          : UI.empty({ icon: 'car', title: 'Voor dit voertuig hebben we momenteel geen online mogelijkheden beschikbaar.', text: 'Neem contact op of kies een andere auto.', actions: '<a class="btn btn--dark btn--sm" href="#/contact">Contact opnemen</a>' })}</div>` : ''}

        ${ownProducts.length ? `<div class="mt-48"><h2 class="h3" style="margin-bottom:20px">Producten voor uw auto</h2><div class="shop-grid">${ownProducts.slice(0, 3).map((p) => UI.productCard(p)).join('')}</div></div>` : ''}

        <div class="mt-48" id="bewaard"><div class="section-head" style="margin-bottom:20px"><h2 class="h3">Bewaarde opties</h2>${savedR.length ? '<a class="link" href="#/contact">Vraag deze opties aan ' + icon('arrow') + '</a>' : ''}</div>
          ${savedR.length ? `<div class="results-grid">${savedR.map((r) => UI.retrofitCard(r, { vehicle: v })).join('')}</div>`
            : UI.empty({ icon: 'bookmark', title: 'Nog geen bewaarde opties', text: 'Gebruik het bladwijzer-icoon bij een optie om die hier te bewaren. Uw bewaarde opties worden meegestuurd bij uw aanvraag.', actions: '<a class="btn btn--dark btn--sm" href="#/mogelijkheden">Naar de mogelijkheden</a>' })}</div>

        ${shop ? `<div class="mt-48"><h2 class="h3" style="margin-bottom:20px">Bewaarde producten</h2>
          ${savedP.length ? `<div class="shop-grid">${savedP.map((p) => UI.productCard(p)).join('')}</div>`
            : UI.empty({ icon: 'box', title: 'Nog geen bewaarde producten', text: 'Bewaar producten uit de webshop om ze later te vergelijken of te bestellen.', actions: '<a class="btn btn--dark btn--sm" href="#/webshop">Naar de webshop</a>' })}</div>` : ''}

        <div class="mt-48"><div class="section-head" style="margin-bottom:20px"><h2 class="h3">Recent bekeken</h2>${recent.length ? '<button class="btn btn--ghost btn--sm" type="button" data-action="clear-recent">Wis geschiedenis</button>' : ''}</div>
          ${recent.length ? `<div class="mini-list">${recent.map((e) => UI.miniItem(e)).join('')}</div>` : UI.empty({ icon: 'history', title: 'Nog niets bekeken', text: 'Opties en producten die u bekijkt, verschijnen hier.' })}</div>

        <div class="mt-48">${UI.notice('<strong>Privacy.</strong> Uw auto, bewaarde items en geschiedenis staan alleen in deze browser. Een kenteken bewaren we uitsluitend in deze browsersessie, maximaal 24 uur. Er wordt geen profiel van u opgebouwd.', { ic: 'lock', actions: '<button class="btn btn--light btn--xs" type="button" data-action="wipe-local">Alles wissen</button>' })}</div>
      </div></section>`;
  },
  mount(root) {
    const f = $('[data-finder]', root);
    if (f) VehicleFinder.mount(f, { onDone: () => Router.render() });
  },
};

/* ---------- Search results ---------- */
Pages.search = {
  id: 'search', nav: '',
  meta(ctx) { return { title: ctx.query.q ? `Zoeken: ${ctx.query.q}` : 'Zoeken', noindex: true }; },
  render(ctx) {
    const q = (ctx.query.q || '').trim();
    const type = ctx.query.type || '';
    const all = q.length >= 2 ? Search.query(q, { limit: 200, perType: 0 }) : [];
    const counts = {}; all.forEach((r) => { counts[r.type] = (counts[r.type] || 0) + 1; });
    const list = type ? all.filter((r) => r.type === type) : all;
    return `${UI.pageHeader({ crumbs: [['Zoeken']], eyebrow: 'Zoeken', title: q ? `Resultaten voor “${esc(q)}”` : 'Waar bent u naar op zoek?', compact: true,
      extra: `<form class="mt-24" data-search-form role="search" style="max-width:620px"><div class="input-icon">${icon('search')}<input class="input" name="q" type="search" value="${attr(q)}" placeholder="Bijv. camera, CarPlay, ACC, trekhaak" aria-label="Zoekterm"></div></form>` })}
      <section class="section section--sm"><div class="container">
        ${all.length ? `<div class="chips" style="margin-bottom:28px" role="group" aria-label="Filter op type">
          <a class="chip${!type ? ' is-active' : ''}" href="${Router.buildHash('/zoeken', { q })}"${!type ? ' aria-current="true"' : ''}>Alles <span class="n">${all.length}</span></a>
          ${Search.TYPE_ORDER.filter((t) => counts[t]).map((t) => `<a class="chip${type === t ? ' is-active' : ''}" href="${Router.buildHash('/zoeken', { q, type: t })}"${type === t ? ' aria-current="true"' : ''}>${Search.TYPE_LABEL[t]} <span class="n">${counts[t]}</span></a>`).join('')}
        </div>
        <div class="table-wrap"><div style="padding:8px">${list.map((r) => `<a class="search-option" href="${attr(r.href)}"><span class="so-type" data-type="${r.type}">${Search.TYPE_LABEL[r.type]}</span><span><span class="so-title">${Search.highlight(r.title, q)}</span><span class="so-sub" style="display:block;white-space:normal">${esc(r.sub || '')}</span></span>${icon('arrow', 'so-go')}</a>`).join('')}</div></div>`
          : (q ? UI.empty({ icon: 'search', title: `Geen resultaten voor “${q}”`, text: 'Probeer een andere of algemenere zoekterm, bijvoorbeeld “camera” of “trekhaak”. Of vraag het ons direct.', actions: '<a class="btn btn--dark btn--sm" href="#/mogelijkheden">Alle mogelijkheden</a><a class="btn btn--light btn--sm" href="#/contact">Contact</a>' })
            : `<div class="chips">${['Achteruitrijcamera', 'CarPlay', 'ACC', 'Virtual Cockpit', 'Trekhaak', 'Alarm'].map((s) => `<a class="chip" href="${Router.buildHash('/zoeken', { q: s })}">${s}</a>`).join('')}</div>`)}
      </div></section>`;
  },
  mount(root) {
    const f = $('[data-search-form]', root);
    f.addEventListener('submit', (e) => { e.preventDefault(); const q = f.q.value.trim(); Router.go('/zoeken', q ? { q } : {}); });
  },
};

/* ---------- Not found & error ---------- */
Pages.notFound = {
  id: 'notfound', nav: '',
  meta: { title: 'Pagina niet gevonden', noindex: true },
  render(ctx, { title = tt('nf.title'), text = tt('nf.text') } = {}) {
    return `${UI.pageHeader({ eyebrow: '404', title: esc(title), lead: esc(text), compact: true })}
      <section class="section section--sm"><div class="container"><div class="flex wrap gap-12">
        <a class="btn btn--primary" href="#/mogelijkheden">Bekijk de mogelijkheden</a><a class="btn btn--light" href="#/">Naar de homepage</a><button class="btn btn--light" type="button" data-action="open-search">${icon('search')} Zoeken</button>
      </div></div></section>`;
  },
};
Pages.error = {
  id: 'error', nav: '',
  render() {
    return `${UI.pageHeader({ eyebrow: 'Er ging iets mis', title: 'Deze pagina kon niet worden geladen.', lead: 'Probeer het opnieuw. Blijft het probleem bestaan? Neem gerust contact op.', compact: true })}
      <section class="section section--sm"><div class="container"><div class="flex wrap gap-12"><a class="btn btn--primary" href="#/">Naar de homepage</a><a class="btn btn--light" href="#/contact">Contact</a></div></div></section>`;
  },
};
