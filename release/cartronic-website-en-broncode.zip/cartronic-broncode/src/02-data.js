/* =====================================================================
   DATA
   Company facts: from cartronic.nl (contact page / footer). Verify before going live:
   the opening hours are published as "dinsdag – zaterdag 9:30 – 17:00" on cartronic.nl,
   while new.cartronic.nl lists 09:00 – 17:00.
   Retrofit catalog: the CarTronic catalog (cartronic.nl / new.cartronic.nl), merged from the
   approved selection and the full product list. Most retrofits are "prijs op aanvraag"; a price is
   only shown where CarTronic publishes one for that option.
   ===================================================================== */
const COMPANY = {
  name: 'CarTronic',
  street: 'Patrijsweg 22',
  postal: '2289 EX',
  city: 'Rijswijk',
  phoneDisplay: '070 383 9836',
  phoneHref: 'tel:+31703839836',
  whatsapp: '31703839836', // WhatsApp number published on cartronic.nl: 070-3839836
  email: 'info@cartronic.nl',
  hours: [
    ['Maandag', 'Gesloten'],
    ['Dinsdag – vrijdag', '09:30 – 17:00'],
    ['Zaterdag', '09:30 – 17:00'],
    ['Zondag', 'Gesloten'],
  ],
  mapsUrl: 'https://www.google.com/maps/search/?api=1&query=CarTronic%2C+Patrijsweg+22%2C+2289+EX+Rijswijk',
  website: 'https://www.cartronic.nl',
};

/* ---------- Brands ---------- */
const BRANDS = [
  { id: 'volkswagen', name: 'Volkswagen', rdw: ['VOLKSWAGEN', 'VW'], wordmark: 'wordmark--vw',
    intro: 'Van up! tot Transporter: originele opties voor de Volkswagen-modellen in onze catalogus.' },
  { id: 'audi', name: 'Audi', rdw: ['AUDI'], wordmark: 'wordmark--audi',
    intro: 'Virtual Cockpit, MMI-navigatie, assistentiesystemen en parkeerhulp voor Audi.' },
  { id: 'seat', name: 'SEAT', rdw: ['SEAT'], wordmark: 'wordmark--seat',
    intro: 'Camera, parkeerhulp, inklapbare spiegels en trekhaken voor SEAT.' },
  { id: 'skoda', name: 'Škoda', rdw: ['SKODA', 'ŠKODA'], wordmark: 'wordmark--skoda',
    intro: 'Originele achteruitrijcamera’s en meer voor de Škoda-modellen in onze catalogus.' },
];
const BRAND = byKey(BRANDS);

/* ---------- Models / generations ----------
   match: tokens matched against the RDW "handelsbenaming" (normalised, brand prefix removed).
   from/to: first-registration years used to infer the generation from RDW data.
   types: EU type codes (RDW field "type") used only to disambiguate overlapping years.
   matchTo: last registration year for a token that a later, different model reuses (T7 Multivan). */
const MODELS = [
  // Volkswagen
  { id: 'golf-7', brand: 'volkswagen', name: 'Golf 7', base: 'Golf', from: 2012, to: 2020, match: ['GOLF'], exclude: ['GOLFSPORTSVAN', 'GOLFPLUS'], types: ['AU'] },
  { id: 'golf-sportsvan', brand: 'volkswagen', name: 'Golf 7 Sportsvan', base: 'Golf Sportsvan', from: 2014, to: 2020, match: ['GOLFSPORTSVAN'], types: [] },
  { id: 'golf-8', brand: 'volkswagen', name: 'Golf 8', base: 'Golf', from: 2020, to: null, match: ['GOLF'], exclude: ['GOLFSPORTSVAN', 'GOLFPLUS'], types: ['CD'] },
  { id: 'polo-aw', brand: 'volkswagen', name: 'Polo AW', base: 'Polo', from: 2017, to: null, match: ['POLO'], types: ['AW'] },
  { id: 't-roc', brand: 'volkswagen', name: 'T-Roc', base: 'T-Roc', from: 2017, to: null, match: ['TROC'], types: ['A1'] },
  { id: 'tiguan-ad', brand: 'volkswagen', name: 'Tiguan AD', base: 'Tiguan', from: 2016, to: 2024, match: ['TIGUAN'], types: [] },
  { id: 'sharan', brand: 'volkswagen', name: 'Sharan', base: 'Sharan', from: 2010, to: 2022, match: ['SHARAN'], types: [] },
  { id: 'passat-b8', brand: 'volkswagen', name: 'Passat B8', base: 'Passat', from: 2014, to: 2023, match: ['PASSAT'], types: [] },
  { id: 'id-3', brand: 'volkswagen', name: 'ID.3', base: 'ID.3', from: 2020, to: null, match: ['ID3'], types: [] },
  { id: 'id-4', brand: 'volkswagen', name: 'ID.4', base: 'ID.4', from: 2021, to: null, match: ['ID4'], types: [] },
  { id: 'up', brand: 'volkswagen', name: 'up!', base: 'up!', from: 2011, to: 2023, match: ['UP'], types: [] },
  // Caddy SA = Caddy 4 (2015–2020); the Caddy 5 (SB) is not in the catalog.
  { id: 'caddy-sa', brand: 'volkswagen', name: 'Caddy SA', base: 'Caddy', from: 2015, to: 2020, match: ['CADDY'], types: [] },
  { id: 'transporter-t6', brand: 'volkswagen', name: 'Transporter T6', base: 'Transporter', from: 2015, to: 2024, match: ['TRANSPORTER', 'MULTIVAN', 'CARAVELLE'], matchTo: { MULTIVAN: 2021 }, types: [] },
  { id: 'crafter-sy', brand: 'volkswagen', name: 'Crafter SY', base: 'Crafter', from: 2017, to: null, match: ['CRAFTER'], types: [] },
  // Audi
  { id: 'a1-8x', brand: 'audi', name: 'A1 8X', base: 'A1', from: 2010, to: 2018, match: ['A1', 'S1'], types: ['8X'] },
  { id: 'a1-gb', brand: 'audi', name: 'A1 GB', base: 'A1', from: 2018, to: null, match: ['A1'], types: ['GB'] },
  { id: 'a3-8v', brand: 'audi', name: 'A3 8V', base: 'A3', from: 2012, to: 2020, match: ['A3', 'S3', 'RS3'], types: ['8V'] },
  { id: 'a3-8y', brand: 'audi', name: 'A3 8Y', base: 'A3', from: 2020, to: null, match: ['A3', 'S3', 'RS3'], types: ['GY'] },
  { id: 'a4-b9', brand: 'audi', name: 'A4 B9/8W', base: 'A4', from: 2015, to: 2024, match: ['A4', 'S4', 'RS4'], types: ['8W'] },
  { id: 'a5-f5', brand: 'audi', name: 'A5 F5', base: 'A5', from: 2016, to: 2024, match: ['A5', 'S5', 'RS5'], types: ['F5'] },
  { id: 'a6-c8', brand: 'audi', name: 'A6 C8', base: 'A6', from: 2018, to: 2024, match: ['A6', 'S6', 'RS6'], exclude: ['A6ETRON', 'A6AVANTETRON', 'A6SPORTBACKETRON', 'S6ETRON', 'S6AVANTETRON', 'S6SPORTBACKETRON', 'RS6ETRON', 'RS6AVANTETRON', 'RS6SPORTBACKETRON'], types: ['4A'] },
  { id: 'a7-c8', brand: 'audi', name: 'A7 C8', base: 'A7', from: 2018, to: null, match: ['A7', 'S7', 'RS7'], types: ['4K'] },
  { id: 'q2-ga', brand: 'audi', name: 'Q2 GA', base: 'Q2', from: 2016, to: null, match: ['Q2', 'SQ2'], types: ['GA'] },
  { id: 'q3-f3', brand: 'audi', name: 'Q3 F3', base: 'Q3', from: 2018, to: null, match: ['Q3', 'RSQ3'], types: ['F3'] },
  { id: 'q4-etron', brand: 'audi', name: 'Q4 e-tron', base: 'Q4 e-tron', from: 2021, to: null, match: ['Q4'], types: ['F4'] },
  { id: 'q5-fy', brand: 'audi', name: 'Q5 FY', base: 'Q5', from: 2017, to: 2024, match: ['Q5', 'SQ5'], types: ['FY'] },
  { id: 'q7-4m', brand: 'audi', name: 'Q7 4M', base: 'Q7', from: 2015, to: null, match: ['Q7', 'SQ7'], types: ['4M'] },
  { id: 'q8', brand: 'audi', name: 'Q8', base: 'Q8', from: 2018, to: null, match: ['Q8', 'SQ8', 'RSQ8'], exclude: ['Q8ETRON', 'Q8SPORTBACKETRON', 'SQ8ETRON', 'SQ8SPORTBACKETRON'], types: [] },
  // SEAT
  { id: 'ibiza-kj', brand: 'seat', name: 'Ibiza KJ', base: 'Ibiza', from: 2017, to: null, match: ['IBIZA'], types: ['KJ'] },
  { id: 'arona', brand: 'seat', name: 'Arona', base: 'Arona', from: 2017, to: null, match: ['ARONA'], types: [] },
  { id: 'leon-5f', brand: 'seat', name: 'Leon 5F', base: 'Leon', from: 2013, to: 2020, match: ['LEON'], types: ['5F'] },
  { id: 'ateca', brand: 'seat', name: 'Ateca', base: 'Ateca', from: 2016, to: null, match: ['ATECA'], types: [] },
  { id: 'tarraco', brand: 'seat', name: 'Tarraco', base: 'Tarraco', from: 2018, to: null, match: ['TARRACO'], types: [] },
  { id: 'mii', brand: 'seat', name: 'Mii', base: 'Mii', from: 2012, to: 2021, match: ['MII'], types: [] },
  // Škoda
  { id: 'octavia-5e', brand: 'skoda', name: 'Octavia 5E', base: 'Octavia', from: 2013, to: 2020, match: ['OCTAVIA'], types: ['5E'] },
  { id: 'kodiaq', brand: 'skoda', name: 'Kodiaq', base: 'Kodiaq', from: 2017, to: null, match: ['KODIAQ'], types: [] },
  { id: 'karoq', brand: 'skoda', name: 'Karoq', base: 'Karoq', from: 2017, to: null, match: ['KAROQ'], types: [] },
  { id: 'superb-3v', brand: 'skoda', name: 'Superb 3V', base: 'Superb', from: 2015, to: 2024, match: ['SUPERB'], types: ['3V'] },
  { id: 'fabia-6v', brand: 'skoda', name: 'Fabia 6V', base: 'Fabia', from: 2015, to: 2021, match: ['FABIA'], types: [] },
  { id: 'kamiq', brand: 'skoda', name: 'Kamiq', base: 'Kamiq', from: 2019, to: null, match: ['KAMIQ'], types: [] },
  { id: 'enyaq', brand: 'skoda', name: 'Enyaq', base: 'Enyaq', from: 2021, to: null, match: ['ENYAQ'], types: [] },
  { id: 'citigo', brand: 'skoda', name: 'Citigo', base: 'Citigo', from: 2012, to: 2020, match: ['CITIGO'], types: [] },
  { id: 'yeti', brand: 'skoda', name: 'Yeti', base: 'Yeti', from: 2009, to: 2017, match: ['YETI'], types: [] },
];
const MODEL = byKey(MODELS);
const modelYears = (m) => `${m.from}–${m.to || 'heden'}`;
const modelLabel = (id) => { const m = MODEL[id]; return m ? `${BRAND[m.brand].name} ${m.name}` : ''; };

/* ---------- Retrofit categories ("Upgrade") ---------- */
const CATEGORIES = [
  { id: 'camera-parkeren', name: 'Camera’s & parkeren', icon: 'camera', group: 'parkeren', art: 'camera',
    tagline: 'Meer zicht. Beter parkeren.', text: 'Achteruitrijcamera’s, 360°-camera’s en parkeerhulp voor- en achterzijde.' },
  { id: 'infotainment', name: 'Infotainment & connectiviteit', icon: 'monitor', group: 'connectiviteit', art: 'connect',
    tagline: 'Uw apps. Het originele systeem.', text: 'App Connect, smartphone-integratie en originele navigatie.' },
  { id: 'cockpit', name: 'Digitale cockpit', icon: 'gauge', group: 'connectiviteit', art: 'cockpit',
    tagline: 'Alle informatie in één oogopslag.', text: 'Virtual Cockpit en Active Info Display.' },
  { id: 'assistentie', name: 'Cruisecontrol & assistentie', icon: 'radar', group: 'assistentie', art: 'assist',
    tagline: 'Originele ondersteuning onderweg.', text: 'Cruisecontrol, dodehoekassistent, Lane Assist en verkeersbordherkenning.' },
  { id: 'comfort', name: 'Comfort', icon: 'comfort', group: 'comfort', art: 'mirror',
    tagline: 'Gemak zoals af fabriek.', text: 'Inklapbare spiegels, elektrische achterklep, keyless entry en meer.' },
  { id: 'verlichting', name: 'Verlichting', icon: 'light', group: 'comfort', art: 'light',
    tagline: 'Zien en gezien worden.', text: 'Originele LED-verlichting, koplampen en achterlichten.' },
  { id: 'trekhaken', name: 'Trekhaken', icon: 'tow', group: 'comfort', art: 'towbar',
    tagline: 'Klaar voor fietsdrager en aanhanger.', text: 'Afneembare en zwenkbare (wegklapbare) trekhaken.' },
  { id: 'beveiliging', name: 'Beveiliging', icon: 'shield', group: 'beveiliging', art: 'alarm',
    tagline: 'Origineel alarm, met SCM-certificaat.', text: 'Origineel af-fabriek alarm met SCM-certificaat.' },
];
const CATEGORY = byKey(CATEGORIES);

/* Discovery groups — for orientation only (no package pricing). */
const GROUPS = [
  { id: 'parkeren', name: 'Parkeren', icon: 'camera', text: 'Zien en gewaarschuwd worden rond de auto: camera en parkeerhulp.' },
  { id: 'connectiviteit', name: 'Connectiviteit', icon: 'phoneDevice', text: 'Smartphone-integratie, navigatie en een digitaal instrumentenpaneel.' },
  { id: 'comfort', name: 'Comfort', icon: 'comfort', text: 'Spiegels, achterklep, verlichting en trekhaken — zoals af fabriek.' },
  { id: 'assistentie', name: 'Assistentie', icon: 'radar', text: 'Rijhulpsystemen inbouwen, afstellen en kalibreren.' },
];
const GROUP = byKey(GROUPS);

/* ---------- Retrofit catalog ----------
   One dataset (RETROFITS) for every catalog page. It merges the approved selection with the full
   CarTronic catalog (2026 reconciliation): an entry names its `feature`, and FEATURES supplies the
   shared name, category, illustration, description and search terms. Anything set on an entry
   itself (title, text, years, specs, price…) always wins over the feature defaults.
   Descriptions follow the product texts on cartronic.nl; prices are only shown where CarTronic
   publishes one, otherwise "Op aanvraag". `aliases` are older/archived URLs that redirect.

   status rules (computed per vehicle, see Compat):
   - listed for the model (and year in range)          → BESCHIKBAAR VOOR DIT MODEL
   - listed, but with a variant note                    → UITVOERING AFHANKELIJK
   - listed with a year range, vehicle year unknown     → CONTROLE VEREIST
   - brand-wide entry ("de meeste modellen")            → CONTROLE VEREIST
   - listed for the model, vehicle year outside range   → NEEM CONTACT OP */
const KW_CAMERA = ['camera', 'achteruitrijcamera', 'parkeercamera', 'rear view'];
const KW_PDC = ['parkeerhulp', 'parkeersensoren', 'pdc', 'park assist', 'sensoren'];
const KW_CRUISE = ['cruise control', 'cruise', 'cruisecontrol', 'snelheidsregelaar'];
const KW_LED = ['led', 'verlichting'];
const FEATURES = {
  achteruitrijcamera: { name: 'Achteruitrijcamera', cat: 'camera-parkeren', art: 'camera', keywords: KW_CAMERA,
    short: 'Originele camera die de ruimte achter de auto toont op het multimediascherm.' },
  'achteruitrijcamera-achterdeuren': { name: 'Achteruitrijcamera (achterdeuren)', cat: 'camera-parkeren', art: 'camera', keywords: [...KW_CAMERA, 'achterdeuren', 'bus', 'bestelauto'],
    short: 'Originele camera voor auto’s met achterdeuren, ingebouwd in de linker achterdeur. Het beeld verschijnt op het multimediascherm.',
    variantNote: 'Uitvoering voor auto’s met achterdeuren; voor een achterklep is er een aparte uitvoering.' },
  'achteruitrijcamera-achterklep': { name: 'Achteruitrijcamera (achterklep)', cat: 'camera-parkeren', art: 'camera', keywords: [...KW_CAMERA, 'achterklep', 'bus', 'bestelauto'],
    short: 'Originele camera voor auto’s met een achterklep. Het beeld verschijnt op het multimediascherm.',
    variantNote: 'Uitvoering voor auto’s met een achterklep; voor achterdeuren is er een aparte uitvoering.' },
  'area-view': { name: 'Area View 360°-camera', cat: 'camera-parkeren', art: 'camera', keywords: [...KW_CAMERA, '360 camera', '360 graden', 'area view', 'rondomzicht'],
    short: 'Origineel parkeerhulpsysteem met vier camera’s rondom de auto. Het nauwkeurige beeld van de omgeving maakt parkeren en manoeuvreren eenvoudiger.' },
  'top-view': { name: 'Top View 360°-camera', cat: 'camera-parkeren', art: 'camera', keywords: [...KW_CAMERA, '360 camera', '360 graden', 'top view', 'rondomzicht'],
    short: 'Origineel parkeerhulpsysteem met vier camera’s rondom de auto. Het nauwkeurige beeld van de omgeving maakt parkeren en manoeuvreren eenvoudiger.' },
  'parkeerhulp-achter': { name: 'Parkeerhulp achterzijde', cat: 'camera-parkeren', art: 'sensor', keywords: KW_PDC,
    short: 'Parkeerhulpsysteem met ultrasone sensoren voor achteruit parkeren.' },
  'parkeerhulp-voor-achter': { name: 'Parkeerhulp voor- en achterzijde', cat: 'camera-parkeren', art: 'sensor', keywords: KW_PDC,
    short: 'Parkeerhulp met ultrasone sensoren aan de voor- en achterzijde.' },
  'parkeerhulp-voor-upgrade': { name: 'Parkeerhulp voorzijde', title: 'Parkeerhulp voorzijde (upgrade)', cat: 'camera-parkeren', art: 'sensor', keywords: [...KW_PDC, 'parkeersensoren voor'],
    short: 'Uitbreiding van de bestaande parkeerhulp met sensoren aan de voorzijde.', variantNote: 'Upgrade voor auto’s met parkeerhulp achter.' },
  'app-connect': { name: 'App Connect', cat: 'infotainment', art: 'connect', image: 'cat_appconnect', keywords: ['carplay', 'apple carplay', 'android auto', 'app connect'],
    short: 'Apple CarPlay en Android Auto op het originele multimediasysteem.', variantNote: 'Afhankelijk van het aanwezige multimediasysteem.' },
  'smartphone-interface': { name: 'Smartphone Interface', cat: 'infotainment', art: 'connect', image: 'cat_audi_carplay', keywords: ['carplay', 'apple carplay', 'android auto', 'smartphone interface', 'mmi'],
    short: 'Apple CarPlay en Android Auto via het originele MMI: uw smartphone verbindt via USB, waarna u navigatie, muziek en apps via het MMI bedient.',
    variantNote: 'Afhankelijk van model, bouwjaar en het aanwezige MMI-systeem.' },
  'discover-media': { name: 'Discover Media', cat: 'infotainment', art: 'nav', keywords: ['navigatie', 'navi', 'discover media', 'multimedia'],
    short: 'Origineel Volkswagen-navigatiesysteem: navigatie, multimedia en telefoon bedient u via een 8-inch kleurentouchscreen.' },
  'discover-pro': { name: 'Discover Pro', cat: 'infotainment', art: 'nav', image: 'cat_nav', keywords: ['navigatie', 'navi', 'discover pro'],
    short: 'Origineel Discover Pro navigatie- en multimediasysteem.' },
  'discover-carplay': { name: 'Discover navigatie met CarPlay', cat: 'infotainment', art: 'nav', keywords: ['navigatie', 'navi', 'discover', 'carplay', 'android auto', 'aanbieding'],
    short: 'Het originele Volkswagen Discover-navigatiesysteem van de nieuwe generatie, met Apple CarPlay en Android Auto. Bedoeld voor wie een oudere Discover Pro heeft; het originele scherm blijft zitten.' },
  'mmi-plus': { name: 'MMI Navigatie plus', cat: 'infotainment', art: 'nav', keywords: ['navigatie', 'mmi', 'navi', 'mmi plus'],
    short: 'Het MMI Navigatie plus-systeem, origineel ingebouwd: navigeren, handsfree bellen en muziek afspelen.' },
  'active-info-display': { name: 'Active Info Display', cat: 'cockpit', art: 'cockpit', keywords: ['active info display', 'aid', 'virtual cockpit', 'digitale cockpit', 'digitaal dashboard'],
    short: 'Origineel digitaal instrumentenpaneel in plaats van de analoge tellers.', variantNote: 'Afhankelijk van bouwjaar en het aanwezige multimediasysteem.' },
  'virtual-cockpit': { name: 'Virtual Cockpit', cat: 'cockpit', art: 'cockpit', keywords: ['virtual cockpit', 'digitale cockpit', 'digitaal dashboard'],
    short: 'Volledig digitaal instrumentenpaneel met een 12,3-inch TFT-scherm: navigatie, muziek, telefoon en assistentiesystemen in uw gezichtsveld.' },
  dodehoek: { name: 'Dodehoekassistent', titleByBrand: { volkswagen: 'Dodehoekassistent (Side Assist)', audi: 'Dodehoekassistent (Audi side assist)' }, cat: 'assistentie', art: 'assist',
    keywords: ['side assist', 'dode hoek', 'blind spot', 'dodehoekassistent'], short: 'Waarschuwt voor voertuigen in de dode hoek.' },
  'lane-assist': { name: 'Active Lane Assist', cat: 'assistentie', art: 'assist', keywords: ['lane assist', 'rijstrookassistent', 'lane keeping', 'rijbaan'],
    short: 'Helpt u binnen de rijstrook te blijven door de auto met korte, subtiele stuurcorrecties bij te sturen.' },
  verkeersbordherkenning: { name: 'Verkeersbordherkenning', cat: 'assistentie', art: 'assist', keywords: ['verkeersborden', 'snelheidsborden', 'bordherkenning'],
    short: 'Herkent verkeersborden en toont ze in het instrumentenpaneel.' },
  wegrijassistent: { name: 'Wegrijassistent', cat: 'assistentie', art: 'assist', keywords: ['wegrijassistent', 'auto hold', 'helling', 'hellingproef'],
    short: 'Origineel Audi-assistentiesysteem dat met Auto Hold voorkomt dat de auto op een helling achteruit rolt. U schakelt het in met een druk op de knop; het blijft actief tot u het uitschakelt.' },
  'cruise-control': { name: 'Cruise control', cat: 'assistentie', art: 'gauge', keywords: KW_CRUISE,
    short: 'Originele cruisecontrol om een ingestelde snelheid vast te houden.' },
  'cruise-control-stuur': { name: 'Cruise control (bediening op het stuur)', cat: 'assistentie', art: 'gauge', keywords: [...KW_CRUISE, 'stuur', 'stuurknoppen'],
    short: 'Originele cruisecontrol die u met de knoppen op het stuur bedient: snelheid vasthouden, verhogen of verlagen.',
    variantNote: 'Uitvoering met bediening op het stuur; er is ook een uitvoering met bediening via de knipperlichthendel.' },
  'cruise-control-hendel': { name: 'Cruise control (bediening via hendel)', cat: 'assistentie', art: 'gauge', keywords: [...KW_CRUISE, 'hendel'],
    short: 'Originele cruisecontrol die u bedient via de knipperlichthendel.',
    variantNote: 'Uitvoering met bediening via de knipperlichthendel; er is ook een uitvoering met bediening op het stuur.' },
  'inklapbare-spiegels': { name: 'Inklapbare spiegels', cat: 'comfort', art: 'mirror', image: 'cat_mirror', keywords: ['inklapbare spiegels', 'inklapspiegels', 'spiegels', 'buitenspiegels'],
    short: 'Elektrisch inklapbare buitenspiegels. Inklapbare spiegels helpen schade aan de buitenspiegels te voorkomen.' },
  'dimmende-binnenspiegel': { name: 'Dimmende binnenspiegel', title: 'Automatisch dimmende binnenspiegel', cat: 'comfort', art: 'mirrorInterior', keywords: ['binnenspiegel', 'dimmend', 'spiegel'],
    short: 'Originele, automatisch dimmende binnenspiegel die verblinding door achteropkomend verkeer voorkomt.' },
  achterklep: { name: 'Elektrische achterklep', cat: 'comfort', art: 'tailgate', keywords: ['achterklep', 'kofferklep', 'elektrische achterklep'],
    short: 'Maakt van de handmatige achterklep een volledig elektrische: openen met de greep of de afstandsbediening, sluiten met de knop in de bekleding of via de afstandsbediening.' },
  keyless: { name: 'Comfortsleutel', title: 'Comfortsleutel (keyless entry)', cat: 'comfort', art: 'key', keywords: ['keyless', 'keyless entry', 'comfortsleutel', 'sleutelloos'],
    short: 'De auto herkent de sleutel die u bij u draagt en ontgrendelt zodra u aan de portiergreep trekt. Vergrendelen doet u door over de greep te strijken.' },
  homelink: { name: 'Garagedeuropener', title: 'Garagedeuropener (HomeLink)', cat: 'comfort', art: 'garage', keywords: ['homelink', 'garagedeur', 'garagedeuropener', 'poort'],
    short: 'Volledig geïntegreerde, programmeerbare afstandsbediening voor garagedeuren en toegangspoorten, met de bedieningsknoppen in de dakmodule voorin.' },
  '230v': { name: '230V-aansluiting', cat: 'comfort', art: 'socket', keywords: ['230v', '230 volt', 'stopcontact', 'opladen'],
    short: 'Originele 230V-aansluiting aan de achterzijde van de middenconsole: laad uw apparaten op zoals u thuis gewend bent.' },
  rijprofielen: { name: 'Rijprofielen', title: 'Rijprofielkeuze', cat: 'comfort', art: 'gauge', keywords: ['rijprofiel', 'rijprofielen', 'rijprofielkeuze', 'rijmodus'],
    short: 'Originele Volkswagen-rijprofielkeuze: kies uit vijf rijprofielen — Eco, Sport, Normal, Individual en Comfort.' },
  stuurwiel: { name: 'Multifunctioneel stuurwiel', cat: 'comfort', art: 'wheel', keywords: ['stuurwiel', 'stuur', 'multifunctiestuur'],
    short: 'Origineel multifunctioneel stuurwiel met bedieningsknoppen.' },
  'licht-regensensor': { name: 'Licht- en regensensor', cat: 'comfort', art: 'sensorRain', keywords: ['regensensor', 'lichtsensor'],
    short: 'Automatische verlichting en ruitenwissers.' },
  'led-koplampen': { name: 'LED-koplampen', cat: 'verlichting', art: 'light', keywords: [...KW_LED, 'koplampen', 'led koplampen'],
    short: 'Originele LED-koplampen met LED-dagrijverlichting, ter vervanging van de halogeenkoplampen.' },
  xenon: { name: 'Xenonkoplampen', cat: 'verlichting', art: 'light', keywords: ['xenon', 'koplampen', 'verlichting'],
    short: 'Originele xenonkoplampen met LED-dagrijverlichting, ter vervanging van de halogeenkoplampen.' },
  'led-achterlichten': { name: 'LED-achterlichten', cat: 'verlichting', art: 'light', keywords: [...KW_LED, 'achterlichten'],
    short: 'Originele LED-achterlichten ter vervanging van de huidige achterlichten.' },
  'led-achterlichten-donker': { name: 'LED-achterlichten donker', title: 'LED-achterlichten (donker)', cat: 'verlichting', art: 'light', keywords: [...KW_LED, 'achterlichten', 'donker'],
    short: 'Originele LED-achterlichten in een donkere uitvoering, ter vervanging van de huidige achterlichten.' },
  'led-dynamisch': { name: 'LED-achterlichten dynamisch', title: 'LED-achterlichten met dynamisch knipperlicht', cat: 'verlichting', art: 'light', keywords: [...KW_LED, 'achterlichten', 'dynamisch knipperlicht'],
    short: 'Originele LED-achterlichten met dynamisch knipperlicht.' },
  instapverlichting: { name: 'Instapverlichting Audi-ringen', title: 'Instapverlichting met Audi-ringen', cat: 'verlichting', art: 'light', keywords: ['instapverlichting', 'audi ringen', 'logo projectie', 'portierverlichting'],
    short: 'Originele Audi-instapverlichting die het logo met de Audi-ringen projecteert wanneer u het portier opent.' },
  'trekhaak-afneembaar': { name: 'Afneembare trekhaak', cat: 'trekhaken', art: 'towbar', keywords: ['trekhaak', 'afneembaar', 'afneembare trekhaak'],
    short: 'Originele trekhaak die eenvoudig is aan te brengen en te verwijderen.' },
  'trekhaak-zwenkbaar': { name: 'Zwenkbare trekhaak', title: 'Zwenkbare/wegklapbare trekhaak', cat: 'trekhaken', art: 'towbar', keywords: ['trekhaak', 'wegklapbaar', 'zwenkbaar', 'wegklapbare trekhaak'],
    short: 'Originele trekhaak die wegklapt wanneer u hem niet gebruikt.' },
  alarm: { name: 'Origineel alarm met SCM-certificaat', cat: 'beveiliging', art: 'alarm', keywords: ['alarm', 'beveiliging', 'scm'] },
};
/* Body/generation variants that share a model generation. */
const VARIANTS = {
  avant: { label: 'Avant', body: 'stationwagen', note: 'Vermeld voor de A4 Avant (stationwagen).' },
  limousine: { label: 'Limousine', body: 'sedan', note: 'Vermeld voor de A4 Limousine (sedan).' },
  ii: { label: '', years: [2013, 2017] },
};
const RETROFITS = [
  // ---- Volkswagen
  { slug: 'volkswagen-golf-7-active-info-display', feature: 'active-info-display', brand: 'volkswagen', models: ['golf-7'], years: [2013, 2019], cat: 'cockpit', title: 'Volkswagen Golf 7 – Active Info Display', name: 'Active Info Display', art: 'cockpit', image: 'cat_aid', short: 'Origineel digitaal instrumentenpaneel in plaats van de analoge tellers.', variantNote: 'Afhankelijk van bouwjaar en het aanwezige multimediasysteem.', specs: [['Scherm', '12,3 inch TFT'], ['Geschikt voor', 'Golf 7 2013–2019 (ook GTI, GTD, R en R-line)']], keywords: ['virtual cockpit', 'digitale cockpit', 'aid', 'digitaal dashboard'], warranty: '3 jaar', price: '€ 1.099 excl. btw', offer: '€ 1.499 inclusief montage', aliases: ['aanbieding-1-volkswagen-golf-7-active-info-display'], source: 'https://new.cartronic.nl/producten/' },
  { slug: 'volkswagen-golf-7-app-connect', feature: 'app-connect', brand: 'volkswagen', models: ['golf-7'], cat: 'infotainment', title: 'Volkswagen Golf 7 – App Connect', name: 'App Connect', art: 'connect', image: 'cat_appconnect', short: 'Apple CarPlay en Android Auto op het originele multimediasysteem.', variantNote: 'Afhankelijk van het aanwezige multimediasysteem.', keywords: ['carplay', 'android auto', 'app connect'], warranty: '3 jaar', offer: 'Vanaf € 199 inclusief montage (Golf 2015–2020)', source: 'https://new.cartronic.nl/producten/volkswagen-golf-7-app-connect/' },
  { slug: 'volkswagen-golf-8-app-connect', feature: 'app-connect', brand: 'volkswagen', models: ['golf-8'], cat: 'infotainment', title: 'Volkswagen Golf 8 – App Connect', name: 'App Connect', art: 'connect', image: 'cat_appconnect', short: 'Apple CarPlay en Android Auto op het originele multimediasysteem.', variantNote: 'Afhankelijk van het aanwezige multimediasysteem.', keywords: ['carplay', 'android auto'], source: 'https://new.cartronic.nl/producten/volkswagen-golf-8-app-connect/' },
  { slug: 'volkswagen-golf-8-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'volkswagen', models: ['golf-8'], cat: 'camera-parkeren', title: 'Volkswagen Golf 8 – Parkeerhulp voor- en achterzijde', name: 'Parkeerhulp voor- en achterzijde', art: 'sensor', short: 'Parkeerhulp met ultrasone sensoren aan de voor- en achterzijde.', keywords: ['parkeersensoren', 'pdc', 'park assist'], source: 'https://new.cartronic.nl/producten/volkswagen-golf-8-parkeerhulp-voor-en-achterzijde/' },
  { slug: 'volkswagen-golf-8-zwenkbare-wegklapbare-trekhaak', feature: 'trekhaak-zwenkbaar', brand: 'volkswagen', models: ['golf-8'], cat: 'trekhaken', title: 'Volkswagen Golf 8 – Zwenkbare/wegklapbare trekhaak', name: 'Zwenkbare trekhaak', art: 'towbar', short: 'Originele trekhaak die wegklapt wanneer u hem niet gebruikt.', keywords: ['trekhaak', 'wegklapbaar'], source: 'https://new.cartronic.nl/producten/volkswagen-golf-8-zwenkbare-wegklapbare-trekhaak/' },
  { slug: 'volkswagen-golf-8-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'volkswagen', models: ['golf-8'], cat: 'comfort', title: 'Volkswagen Golf 8 – Inklapbare spiegels', name: 'Inklapbare spiegels', art: 'mirror', image: 'cat_mirror', short: 'Buitenspiegels die inklappen bij het vergrendelen en weer uitklappen bij het starten.', keywords: ['inklapspiegels', 'spiegels'], warranty: '3 jaar', source: 'https://new.cartronic.nl/producten/volkswagen-golf-8-inklapbare-spiegels/' },
  { slug: 'volkswagen-polo-aw-app-connect', feature: 'app-connect', brand: 'volkswagen', models: ['polo-aw'], cat: 'infotainment', title: 'Volkswagen Polo AW – App Connect', name: 'App Connect', art: 'connect', image: 'cat_appconnect', short: 'Apple CarPlay en Android Auto op het originele multimediasysteem.', variantNote: 'Afhankelijk van het aanwezige multimediasysteem.', keywords: ['carplay', 'android auto'], warranty: '3 jaar', offer: 'Vanaf € 199 inclusief montage (Polo t/m 2020)', source: 'https://www.cartronic.nl/producten/volkswagen-polo-aw-app-connect/' },
  { slug: 'volkswagen-t-roc-app-connect', feature: 'app-connect', brand: 'volkswagen', models: ['t-roc'], cat: 'infotainment', title: 'Volkswagen T-Roc – App Connect', name: 'App Connect', art: 'connect', image: 'cat_appconnect', short: 'Apple CarPlay en Android Auto op het originele multimediasysteem.', variantNote: 'Afhankelijk van het aanwezige multimediasysteem.', keywords: ['carplay', 'android auto'], warranty: '3 jaar', offer: 'Vanaf € 199 inclusief montage', aliases: ['aanbieding-3-volkswagen-app-connect'], source: 'https://www.cartronic.nl/producten/volkswagen-t-roc-app-connect/' },
  { slug: 'volkswagen-t-roc-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'volkswagen', models: ['t-roc'], cat: 'camera-parkeren', title: 'Volkswagen T-Roc – Achteruitrijcamera', name: 'Achteruitrijcamera', art: 'camera', short: 'Originele camera die de ruimte achter de auto toont op het multimediascherm.', keywords: ['camera', 'rear view'], warranty: '3 jaar', source: 'https://new.cartronic.nl/producten/volkswagen-t-roc-achteruitrijcamera/' },
  { slug: 'volkswagen-t-roc-elektrische-achterklep', feature: 'achterklep', brand: 'volkswagen', models: ['t-roc'], cat: 'comfort', title: 'Volkswagen T-Roc – Elektrische achterklep', name: 'Elektrische achterklep', art: 'tailgate', short: 'Achterklep elektrisch openen en sluiten.', keywords: ['achterklep', 'kofferklep'], warranty: '3 jaar', source: 'https://www.cartronic.nl/producten/volkswagen-t-roc-elektrische-achterklep/' },
  { slug: 'volkswagen-tiguan-ad-app-connect', feature: 'app-connect', brand: 'volkswagen', models: ['tiguan-ad'], cat: 'infotainment', title: 'Volkswagen Tiguan AD – App Connect', name: 'App Connect', art: 'connect', image: 'cat_appconnect', short: 'Apple CarPlay en Android Auto op het originele multimediasysteem.', variantNote: 'Afhankelijk van het aanwezige multimediasysteem.', keywords: ['carplay', 'android auto'], offer: 'Vanaf € 199 inclusief montage (Tiguan 2017–2020)', source: 'https://www.cartronic.nl/producten/volkswagen-tiguan-ad-app-connect/' },
  { slug: 'volkswagen-tiguan-ad-dode-hoek-assistent', feature: 'dodehoek', brand: 'volkswagen', models: ['tiguan-ad'], cat: 'assistentie', title: 'Volkswagen Tiguan AD – Dodehoekassistent (Side Assist)', name: 'Dodehoekassistent', art: 'assist', short: 'Waarschuwt voor voertuigen in de dode hoek.', keywords: ['side assist', 'dode hoek', 'blind spot'], source: 'https://new.cartronic.nl/producten/volkswagen-tiguan-ad-dode-hoek-assistent/' },
  { slug: 'volkswagen-passat-b8-app-connect', feature: 'app-connect', brand: 'volkswagen', models: ['passat-b8'], cat: 'infotainment', title: 'Volkswagen Passat B8 – App Connect', name: 'App Connect', art: 'connect', image: 'cat_appconnect', short: 'Smartphone via USB verbinden en navigatie, muziek en apps bedienen via het scherm.', variantNote: 'Afhankelijk van het aanwezige multimediasysteem.', keywords: ['carplay', 'android auto'], warranty: '3 jaar', offer: 'Vanaf € 199 inclusief montage (Passat 2015–2020)', source: 'https://www.cartronic.nl/producten/volkswagen-passat-b8-app-connect/' },
  { slug: 'volkswagen-passat-b8-discover-pro', feature: 'discover-pro', brand: 'volkswagen', models: ['passat-b8'], cat: 'infotainment', title: 'Volkswagen Passat B8 – Discover Pro', name: 'Discover Pro', art: 'nav', image: 'cat_nav', short: 'Origineel Discover Pro navigatie- en multimediasysteem.', keywords: ['navigatie', 'navi', 'discover pro'], source: 'https://www.cartronic.nl/producten/volkswagen-passat-b8-discover-pro/' },
  { slug: 'volkswagen-passat-b8-dode-hoek-assistent', feature: 'dodehoek', brand: 'volkswagen', models: ['passat-b8'], cat: 'assistentie', title: 'Volkswagen Passat B8 – Dodehoekassistent (Side Assist)', name: 'Dodehoekassistent', art: 'assist', short: 'Waarschuwt voor voertuigen in de dode hoek.', keywords: ['side assist', 'dode hoek', 'blind spot'], warranty: '3 jaar', source: 'https://www.cartronic.nl/producten/volkswagen-passat-b8-dode-hoek-assistent/' },
  { slug: 'volkswagen-id3-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'volkswagen', models: ['id-3'], cat: 'camera-parkeren', title: 'Volkswagen ID.3 – Parkeerhulp voor- en achterzijde', name: 'Parkeerhulp voor- en achterzijde', art: 'sensor', short: 'Parkeerhulp met ultrasone sensoren aan de voor- en achterzijde.', keywords: ['parkeersensoren', 'pdc'], source: 'https://new.cartronic.nl/producten/volkswagen-id3-parkeerhulp-voor-en-achterzijde/' },
  { slug: 'volkswagen-id3-zwenkbare-wegklapbare-trekhaak', feature: 'trekhaak-zwenkbaar', brand: 'volkswagen', models: ['id-3'], cat: 'trekhaken', title: 'Volkswagen ID.3 – Zwenkbare/wegklapbare trekhaak', name: 'Zwenkbare trekhaak', art: 'towbar', short: 'Originele trekhaak die wegklapt wanneer u hem niet gebruikt.', keywords: ['trekhaak'], source: 'https://new.cartronic.nl/producten/volkswagen-id3-zwenkbare-wegklapbare-trekhaak/' },
  { slug: 'volkswagen-id4-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'volkswagen', models: ['id-4'], cat: 'camera-parkeren', title: 'Volkswagen ID.4 – Parkeerhulp voor- en achterzijde', name: 'Parkeerhulp voor- en achterzijde', art: 'sensor', short: 'Parkeerhulp met ultrasone sensoren aan de voor- en achterzijde.', keywords: ['parkeersensoren', 'pdc'], source: 'https://new.cartronic.nl/producten/volkswagen-id4-parkeerhulp-voor-en-achterzijde/' },
  { slug: 'volkswagen-id4-zwenkbare-wegklapbare-trekhaak', feature: 'trekhaak-zwenkbaar', brand: 'volkswagen', models: ['id-4'], cat: 'trekhaken', title: 'Volkswagen ID.4 – Zwenkbare/wegklapbare trekhaak', name: 'Zwenkbare trekhaak', art: 'towbar', short: 'Originele trekhaak die wegklapt wanneer u hem niet gebruikt.', keywords: ['trekhaak'], source: 'https://new.cartronic.nl/producten/volkswagen-id4-zwenkbare-wegklapbare-trekhaak/' },
  { slug: 'volkswagen-up-multifunctioneel-stuurwiel', feature: 'stuurwiel', brand: 'volkswagen', models: ['up'], cat: 'comfort', title: 'Volkswagen up! – Multifunctioneel stuurwiel', name: 'Multifunctioneel stuurwiel', art: 'wheel', short: 'Origineel multifunctioneel stuurwiel met bedieningsknoppen.', keywords: ['stuurwiel', 'stuur'], warranty: '3 jaar', source: 'https://www.cartronic.nl/producten/volkswagen-up-multifunctioneel-stuurwiel/' },
  { slug: 'volkswagen-transporter-t6-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'volkswagen', models: ['transporter-t6'], cat: 'comfort', title: 'Volkswagen Transporter T6 – Inklapbare spiegels', name: 'Inklapbare spiegels', art: 'mirror', image: 'cat_mirror', short: 'Elektrisch inklapbare buitenspiegels.', keywords: ['inklapspiegels', 'spiegels', 'bus'], warranty: '3 jaar', source: 'https://new.cartronic.nl/producten/volkswagen-transporter-t6-inklapbare-spiegels/' },
  // ---- Audi
  { slug: 'audi-a3-8v-virtual-cockpit', feature: 'virtual-cockpit', brand: 'audi', models: ['a3-8v'], years: [2017, 2019], cat: 'cockpit', title: 'Audi A3 8V – Virtual Cockpit', name: 'Virtual Cockpit', art: 'cockpit', short: 'Volledig digitaal instrumentenpaneel met een 12,3-inch TFT-scherm: navigatie, muziek, telefoon en assistentiesystemen in uw gezichtsveld.', variantNote: 'Vermeld voor de A3 8V van 2017 tot en met 2019, ook voor S3, RS3 en S-line.', specs: [['Scherm', '12,3 inch TFT'], ['Geschikt voor', 'A3 8V 2017–2019 (ook S3, RS3, S-line)'], ['Garantie', '3 jaar (volgens CarTronic-productinformatie)'], ['Prijs', 'Op aanvraag']], keywords: ['digitale cockpit', 'virtual cockpit', 'digitaal dashboard'], warranty: '3 jaar', source: 'https://www.cartronic.nl/producten/audi-a3-8v-virtual-cockpit/' },
  { slug: 'audi-a3-8v-verkeersbordherkenning', feature: 'verkeersbordherkenning', brand: 'audi', models: ['a3-8v'], cat: 'assistentie', title: 'Audi A3 8V – Verkeersbordherkenning', name: 'Verkeersbordherkenning', art: 'assist', short: 'Herkent verkeersborden en toont ze in het instrumentenpaneel.', keywords: ['verkeersborden', 'snelheidsborden'], warranty: '3 jaar', source: 'https://www.cartronic.nl/producten/audi-a3-8v-verkeersbordherkenning/' },
  { slug: 'audi-a3-8v-cruise-control', feature: 'cruise-control', brand: 'audi', models: ['a3-8v'], cat: 'assistentie', title: 'Audi A3 8V – Cruise control', name: 'Cruise control', art: 'gauge', short: 'Originele cruise control om een ingestelde snelheid vast te houden.', keywords: ['cruise', 'snelheidsregelaar'], warranty: '3 jaar', source: 'https://www.cartronic.nl/producten/audi-a3-8v-cruise-control/' },
  { slug: 'audi-a3-8v-mmi-plus-navigatiesysteem', feature: 'mmi-plus', brand: 'audi', models: ['a3-8v'], years: [2012, 2019], cat: 'infotainment', title: 'Audi A3 8V – MMI Navigatie plus', name: 'MMI Navigatie plus', art: 'nav', short: 'Origineel MMI Navigatie plus-systeem.', specs: [['Geschikt voor', 'A3 8V 2012–2019 (ook S3, RS3 en S-line)']], keywords: ['navigatie', 'mmi', 'navi'], warranty: '3 jaar', source: 'https://new.cartronic.nl/producten/audi-a3-8v-mmi-plus-navigatiesysteem/' },
  { slug: 'audi-a3-8v-licht-en-regensensor', feature: 'licht-regensensor', brand: 'audi', models: ['a3-8v'], cat: 'comfort', title: 'Audi A3 8V – Licht- en regensensor', name: 'Licht- en regensensor', art: 'sensorRain', short: 'Automatische verlichting en ruitenwissers.', keywords: ['regensensor', 'lichtsensor'], warranty: '3 jaar', source: 'https://www.cartronic.nl/producten/audi-a3-8v-licht-en-regensensor/' },
  { slug: 'audi-a3-8v-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'audi', models: ['a3-8v'], cat: 'camera-parkeren', title: 'Audi A3 8V – Parkeerhulp plus (voor- en achterzijde)', name: 'Parkeerhulp plus', art: 'sensor', short: 'Parkeerhulpsysteem met ultrasone sensoren aan de voor- en achterzijde.', keywords: ['parkeersensoren', 'pdc', 'park assist'], warranty: '3 jaar', source: 'https://www.cartronic.nl/producten/audi-a3-8v-parkeerhulp-voor-en-achterzijde/' },
  { slug: 'audi-a3-8v-dode-hoek-assistent', feature: 'dodehoek', brand: 'audi', models: ['a3-8v'], cat: 'assistentie', title: 'Audi A3 8V – Dodehoekassistent (Audi side assist)', name: 'Dodehoekassistent', art: 'assist', short: 'Waarschuwt voor voertuigen in de dode hoek.', keywords: ['side assist', 'dode hoek', 'blind spot'], warranty: '3 jaar', source: 'https://new.cartronic.nl/producten/audi-a3-8v-dode-hoek-assistent/' },
  { slug: 'audi-a3-8y-dode-hoek-assistent', feature: 'dodehoek', brand: 'audi', models: ['a3-8y'], cat: 'assistentie', title: 'Audi A3 8Y – Dodehoekassistent (Audi side assist)', name: 'Dodehoekassistent', art: 'assist', short: 'Waarschuwt voor voertuigen in de dode hoek.', keywords: ['side assist', 'dode hoek', 'blind spot'], source: 'https://new.cartronic.nl/producten/audi-a3-8y-dode-hoek-assistent/' },
  { slug: 'audi-a3-8y-zwenkbare-wegklapbare-trekhaak', feature: 'trekhaak-zwenkbaar', brand: 'audi', models: ['a3-8y'], cat: 'trekhaken', title: 'Audi A3 8Y – Zwenkbare/wegklapbare trekhaak', name: 'Zwenkbare trekhaak', art: 'towbar', short: 'Originele trekhaak die wegklapt wanneer u hem niet gebruikt.', keywords: ['trekhaak'], source: 'https://new.cartronic.nl/producten/audi-a3-8y-zwenkbare-wegklapbare-trekhaak/' },
  { slug: 'audi-a4-b9-avant-elektrische-achterklep', feature: 'achterklep', brand: 'audi', models: ['a4-b9'], body: 'stationwagen', cat: 'comfort', title: 'Audi A4 B9/8W Avant – Elektrische achterklep', name: 'Elektrische achterklep', art: 'tailgate', short: 'Achterklep elektrisch openen en sluiten.', variantNote: 'Vermeld voor de A4 Avant (stationwagen).', keywords: ['achterklep', 'kofferklep'], warranty: '3 jaar', aliases: ['audi-a4-b9-8w-avant-elektrische-achterklep'], source: 'https://www.cartronic.nl/producten/audi-a4-b9-8w-avant-elektrische-achterklep/' },
  { slug: 'audi-a4-b9-led-dynamische-achterlichten', feature: 'led-dynamisch', brand: 'audi', models: ['a4-b9'], cat: 'verlichting', title: 'Audi A4 B9/8W – LED-achterlichten met dynamisch knipperlicht', name: 'LED-achterlichten dynamisch', art: 'light', short: 'Originele LED-achterlichten met dynamisch knipperlicht.', keywords: ['achterlichten', 'led', 'dynamisch knipperlicht'], warranty: '3 jaar', aliases: ['audi-a4-b9-8w-led-dynamische-achterlichten'], source: 'https://www.cartronic.nl/producten/audi-a4-b9-8w-led-dynamische-achterlichten/' },
  { slug: 'audi-a4-b9-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'audi', models: ['a4-b9'], cat: 'camera-parkeren', title: 'Audi A4 B9/8W – Parkeerhulp voorzijde (upgrade)', name: 'Parkeerhulp voorzijde', art: 'sensor', short: 'Uitbreiding van de bestaande parkeerhulp met sensoren aan de voorzijde.', variantNote: 'Upgrade voor auto’s met parkeerhulp achter.', keywords: ['parkeersensoren voor', 'pdc'], warranty: '3 jaar', aliases: ['audi-a4-b9-8w-parkeerhulp-voorzijde-upgrade'], source: 'https://new.cartronic.nl/producten/audi-a4-b9-8w-parkeerhulp-voorzijde-upgrade/' },
  { slug: 'audi-a5-f5-zwenkbare-wegklapbare-trekhaak', feature: 'trekhaak-zwenkbaar', brand: 'audi', models: ['a5-f5'], cat: 'trekhaken', title: 'Audi A5 F5 – Zwenkbare/wegklapbare trekhaak', name: 'Zwenkbare trekhaak', art: 'towbar', short: 'Originele trekhaak die wegklapt wanneer u hem niet gebruikt.', keywords: ['trekhaak'], warranty: '3 jaar', source: 'https://www.cartronic.nl/producten/audi-a5-f5-zwenkbare-wegklapbare-trekhaak/' },
  { slug: 'audi-q2-ga-dimmende-binnenspiegel', feature: 'dimmende-binnenspiegel', brand: 'audi', models: ['q2-ga'], years: [2016, 2019], cat: 'comfort', title: 'Audi Q2 GA – Automatisch dimmende binnenspiegel', name: 'Dimmende binnenspiegel', art: 'mirrorInterior', short: 'Binnenspiegel die automatisch dimt bij verblinding.', specs: [['Geschikt voor', 'Q2 GA 2016–2019 (ook SQ2 en S-line)']], keywords: ['binnenspiegel', 'dimmend'], warranty: '3 jaar', source: 'https://new.cartronic.nl/producten/audi-q2-ga-dimmende-binnenspiegel/' },
  { slug: 'audi-q4-e-tron-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'audi', models: ['q4-etron'], cat: 'camera-parkeren', title: 'Audi Q4 e-tron – Parkeerhulp plus (voor- en achterzijde)', name: 'Parkeerhulp plus', art: 'sensor', short: 'Parkeerhulpsysteem met ultrasone sensoren aan de voor- en achterzijde.', keywords: ['parkeersensoren', 'pdc'], source: 'https://new.cartronic.nl/producten/audi-q4-e-tron-parkeerhulp-voor-en-achterzijde/' },
  { slug: 'audi-q4-e-tron-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'audi', models: ['q4-etron'], cat: 'camera-parkeren', title: 'Audi Q4 e-tron – Parkeerhulp voorzijde (upgrade)', name: 'Parkeerhulp voorzijde', art: 'sensor', short: 'Uitbreiding van de bestaande parkeerhulp met sensoren aan de voorzijde.', variantNote: 'Upgrade voor auto’s met parkeerhulp achter.', keywords: ['parkeersensoren voor'], source: 'https://new.cartronic.nl/producten/audi-q4-e-tron-parkeerhulp-voorzijde-upgrade/' },
  { slug: 'audi-q4-e-tron-zwenkbare-wegklapbare-trekhaak', feature: 'trekhaak-zwenkbaar', brand: 'audi', models: ['q4-etron'], cat: 'trekhaken', title: 'Audi Q4 e-tron – Zwenkbare/wegklapbare trekhaak', name: 'Zwenkbare trekhaak', art: 'towbar', short: 'Originele trekhaak die wegklapt wanneer u hem niet gebruikt.', keywords: ['trekhaak'], source: 'https://new.cartronic.nl/producten/audi-q4-e-tron-f4-zwenkbare-wegklapbare-trekhaak/' },
  // ---- Meerdere merken/modellen
  { slug: 'audi-smartphone-interface-carplay', feature: 'smartphone-interface', brand: 'audi', models: [], scope: 'brand', cat: 'infotainment', title: 'Audi Smartphone Interface – CarPlay', name: 'Audi Smartphone Interface', art: 'connect', image: 'cat_audi_carplay', short: 'Apple CarPlay en Android Auto via het originele MMI-systeem.', variantNote: 'Mogelijk voor diverse Audi-modellen; afhankelijk van model, bouwjaar en MMI-systeem.', keywords: ['carplay', 'android auto', 'smartphone interface', 'mmi'], warranty: '3 jaar', offer: 'Vanaf € 349 inclusief montage (prijs verschilt per model)', aliases: ['aanbieding-2-audi-smartphone-interface-carplay'], source: 'https://www.cartronic.nl/' },
  // ---- SEAT
  { slug: 'seat-ibiza-kj-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'seat', models: ['ibiza-kj'], cat: 'camera-parkeren', title: 'SEAT Ibiza KJ – Achteruitrijcamera', name: 'Achteruitrijcamera', art: 'camera', image: 'proj_ibiza', imageNote: 'Foto: CarTronic-werkplaats', short: 'Originele camera die de ruimte achter de auto toont op het multimediascherm.', keywords: ['camera', 'rear view', 'meesturende lijnen'], project: 'seat-ibiza-camera-meesturende-lijnen', warranty: '3 jaar', source: 'https://www.cartronic.nl/producten/seat-ibiza-kj-achteruitrijcamera/' },
  { slug: 'seat-ibiza-kj-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'seat', models: ['ibiza-kj'], cat: 'comfort', title: 'SEAT Ibiza KJ – Inklapbare spiegels', name: 'Inklapbare spiegels', art: 'mirror', image: 'cat_mirror', short: 'Spiegels klappen in bij het vergrendelen en automatisch uit bij het starten.', keywords: ['inklapspiegels', 'spiegels'], warranty: '3 jaar', source: 'https://www.cartronic.nl/producten/seat-ibiza-kj-inklapbare-spiegels/' },
  { slug: 'seat-ibiza-kj-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'seat', models: ['ibiza-kj'], cat: 'camera-parkeren', title: 'SEAT Ibiza KJ – Parkeerhulp voorzijde (upgrade)', name: 'Parkeerhulp voorzijde', art: 'sensor', short: 'Parkeerhulp met ultrasone sensoren, uitgebreid naar de voorzijde.', variantNote: 'Upgrade voor auto’s met parkeerhulp achter.', keywords: ['parkeersensoren voor', 'pdc'], warranty: '3 jaar', source: 'https://www.cartronic.nl/producten/seat-ibiza-kj-parkeerhulp-voorzijde-upgrade/' },
  { slug: 'seat-ibiza-kj-afneembare-trekhaak', feature: 'trekhaak-afneembaar', brand: 'seat', models: ['ibiza-kj'], cat: 'trekhaken', title: 'SEAT Ibiza KJ – Afneembare trekhaak', name: 'Afneembare trekhaak', art: 'towbar', short: 'Originele trekhaak die eenvoudig is aan te brengen en te verwijderen.', keywords: ['trekhaak', 'afneembaar'], warranty: '3 jaar', source: 'https://www.cartronic.nl/producten/seat-ibiza-kj-afneembare-trekhaak/' },
  { slug: 'seat-leon-5f-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'seat', models: ['leon-5f'], cat: 'camera-parkeren', title: 'SEAT Leon 5F – Achteruitrijcamera', name: 'Achteruitrijcamera', art: 'camera', short: 'Originele camera die de ruimte achter de auto correct weergeeft op het multimediascherm.', keywords: ['camera', 'rear view'], warranty: '3 jaar', source: 'https://www.cartronic.nl/producten/seat-leon-5f-achteruitrijcamera/' },
  { slug: 'seat-leon-5f-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'seat', models: ['leon-5f'], cat: 'camera-parkeren', title: 'SEAT Leon 5F – Parkeerhulp achterzijde', name: 'Parkeerhulp achterzijde', art: 'sensor', short: 'Parkeerhulpsysteem met ultrasone sensoren voor achteruit parkeren.', keywords: ['parkeersensoren', 'pdc'], warranty: '3 jaar', source: 'https://www.cartronic.nl/producten/seat-leon-5f-parkeerhulp-achterzijde/' },
  { slug: 'seat-leon-5f-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'seat', models: ['leon-5f'], cat: 'comfort', title: 'SEAT Leon 5F – Inklapbare spiegels', name: 'Inklapbare spiegels', art: 'mirror', image: 'cat_mirror', short: 'Inklapbare spiegels helpen schade aan de buitenspiegels te voorkomen.', keywords: ['inklapspiegels', 'spiegels'], warranty: '3 jaar', source: 'https://www.cartronic.nl/producten/seat-leon-5f-inklapbare-spiegels/' },
  { slug: 'seat-leon-5f-afneembare-trekhaak', feature: 'trekhaak-afneembaar', brand: 'seat', models: ['leon-5f'], cat: 'trekhaken', title: 'SEAT Leon 5F – Afneembare trekhaak', name: 'Afneembare trekhaak', art: 'towbar', short: 'Originele trekhaak die eenvoudig is aan te brengen en te verwijderen.', keywords: ['trekhaak', 'afneembaar'], warranty: '3 jaar', source: 'https://www.cartronic.nl/producten/seat-leon-5f-afneembare-trekhaak/' },
  { slug: 'seat-arona-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'seat', models: ['arona'], cat: 'camera-parkeren', title: 'SEAT Arona – Achteruitrijcamera', name: 'Achteruitrijcamera', art: 'camera', short: 'Originele camera die de ruimte achter de auto toont op het multimediascherm.', keywords: ['camera', 'rear view'], warranty: '3 jaar', source: 'https://new.cartronic.nl/producten/seat-arona-achteruitrijcamera/' },
  { slug: 'seat-tarraco-zwenkbare-wegklapbare-trekhaak', feature: 'trekhaak-zwenkbaar', brand: 'seat', models: ['tarraco'], cat: 'trekhaken', title: 'SEAT Tarraco – Zwenkbare/wegklapbare trekhaak', name: 'Zwenkbare trekhaak', art: 'towbar', short: 'Originele trekhaak die wegklapt wanneer u hem niet gebruikt.', keywords: ['trekhaak'], source: 'https://new.cartronic.nl/producten/seat-tarraco-zwenkbare-wegklapbare-trekhaak/' },
  // ---- Škoda
  { slug: 'skoda-octavia-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'skoda', models: ['octavia-5e'], years: [2014, 2015], cat: 'camera-parkeren', title: 'Škoda Octavia (2014–2015) – Achteruitrijcamera', name: 'Achteruitrijcamera', art: 'camera', short: 'Originele camera die de ruimte achter de auto toont op het multimediascherm.', keywords: ['camera', 'rear view'], source: 'https://www.cartronic.nl/skoda-octavia-2014-achteruitrijcamera/' },
  { slug: 'skoda-kodiaq-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'skoda', models: ['kodiaq'], years: [2017, 2019], cat: 'camera-parkeren', title: 'Škoda Kodiaq – Achteruitrijcamera', name: 'Achteruitrijcamera', art: 'camera', short: 'Originele camera die de ruimte achter de auto toont op het multimediascherm.', keywords: ['camera', 'rear view'], warranty: '3 jaar', source: 'https://www.cartronic.nl/producten/skoda-kodiaq-achteruitrijcamera/' },
  { slug: 'skoda-karoq-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'skoda', models: ['karoq'], years: [2017, 2019], cat: 'camera-parkeren', title: 'Škoda Karoq – Achteruitrijcamera', name: 'Achteruitrijcamera', art: 'camera', short: 'Originele camera die de ruimte achter de auto toont op het multimediascherm.', keywords: ['camera', 'rear view'], warranty: '3 jaar', source: 'https://www.cartronic.nl/producten/skoda-karoq-achteruitrijcamera/' },
  { slug: 'skoda-superb-3v-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'skoda', models: ['superb-3v'], years: [2015, 2019], cat: 'camera-parkeren', title: 'Škoda Superb 3V – Achteruitrijcamera', name: 'Achteruitrijcamera', art: 'camera', short: 'Originele camera die de ruimte achter de auto toont op het multimediascherm.', keywords: ['camera', 'rear view'], warranty: '3 jaar', source: 'https://www.cartronic.nl/producten/skoda-superb-3v-achteruitrijcamera/' },
  { slug: 'skoda-fabia-6v-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'skoda', models: ['fabia-6v'], years: [2015, 2019], cat: 'camera-parkeren', title: 'Škoda Fabia 6V – Achteruitrijcamera', name: 'Achteruitrijcamera', art: 'camera', short: 'Originele camera die de ruimte achter de auto toont op het multimediascherm.', keywords: ['camera', 'rear view'], warranty: '3 jaar', aliases: ['skoda-fabia-6v0-achteruitrijcamera'], source: 'https://www.cartronic.nl/producten/skoda-fabia-6v0-achteruitrijcamera/' },
  { slug: 'skoda-citigo-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'skoda', models: ['citigo'], years: [2016, 2019], cat: 'camera-parkeren', title: 'Škoda Citigo – Achteruitrijcamera', name: 'Achteruitrijcamera', art: 'camera', short: 'Originele camera die de ruimte achter de auto toont op het multimediascherm.', keywords: ['camera', 'rear view'], warranty: '3 jaar', source: 'https://www.cartronic.nl/producten/skoda-citigo-achteruitrijcamera/' },
  { slug: 'skoda-yeti-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'skoda', models: ['yeti'], years: [2013, 2017], cat: 'camera-parkeren', title: 'Škoda Yeti – Achteruitrijcamera', name: 'Achteruitrijcamera', art: 'camera', short: 'Originele camera die de ruimte achter de auto toont op het multimediascherm.', keywords: ['camera', 'rear view'], warranty: '3 jaar', aliases: ['skoda-yeti-ii-achteruitrijcamera'], source: 'https://www.cartronic.nl/producten/skoda-yeti-ii-achteruitrijcamera/' },
  { slug: 'skoda-kamiq-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'skoda', models: ['kamiq'], cat: 'camera-parkeren', title: 'Škoda Kamiq – Achteruitrijcamera', name: 'Achteruitrijcamera', art: 'camera', short: 'Originele camera die de ruimte achter de auto toont op het multimediascherm.', keywords: ['camera', 'rear view'], source: 'https://new.cartronic.nl/producten/skoda-kamiq-achteruitrijcamera/' },
  // ---- Meerdere merken/modellen
  { slug: 'origineel-af-fabriek-alarm-scm', feature: 'alarm', brand: null, brands: ['volkswagen', 'audi', 'seat', 'skoda'], models: [], scope: 'brand', cat: 'beveiliging', title: 'Origineel af-fabriek alarm met SCM-certificaat', name: 'Origineel alarm met SCM-certificaat', art: 'alarm', short: 'Het originele alarmsysteem, inclusief SCM-certificaat voor uw verzekeraar. Bediening zoals af fabriek: vergrendelen schakelt het alarm in, ontgrendelen schakelt het uit.', variantNote: 'Volgens CarTronic mogelijk op de meeste modellen van Audi, SEAT, Škoda en Volkswagen, ook nieuwere modellen. Controle per auto vereist.', keywords: ['alarm', 'beveiliging', 'scm', 'diefstal', 'verzekering'], source: 'https://www.cartronic.nl/origineel-af-fabriek-alarm-incl-scm-certificaat/' },
  // ---- Aanvulling uit de volledige catalogus – Volkswagen
  { slug: 'volkswagen-golf-7-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'volkswagen', models: ['golf-7'], warranty: '2 jaar' },
  { slug: 'volkswagen-golf-7-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'volkswagen', models: ['golf-7'], warranty: '3 jaar' },
  { slug: 'volkswagen-golf-7-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'volkswagen', models: ['golf-7'], warranty: '3 jaar' },
  { slug: 'volkswagen-golf-7-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'volkswagen', models: ['golf-7'], warranty: '3 jaar' },
  { slug: 'volkswagen-golf-7-discover-media', feature: 'discover-media', brand: 'volkswagen', models: ['golf-7'], years: [2013, 2019], specs: [['Scherm', '8 inch kleurentouchscreen'], ['Geschikt voor', 'Golf 7 2013–2019 (ook GTI, GTD, R en R-line)']], warranty: '3 jaar' },
  { slug: 'volkswagen-golf-7-discover-pro', feature: 'discover-pro', brand: 'volkswagen', models: ['golf-7'], years: [2013, 2019], specs: [['Scherm', '9,2 inch kleurentouchscreen'], ['Geschikt voor', 'Golf 7 2013–2019 (ook GTI, GTD, R en R-line)']], warranty: '3 jaar' },
  { slug: 'volkswagen-golf-7-dode-hoek-assistent', feature: 'dodehoek', brand: 'volkswagen', models: ['golf-7'], warranty: '3 jaar' },
  { slug: 'volkswagen-golf-7-cruise-control-op-stuur', feature: 'cruise-control-stuur', brand: 'volkswagen', models: ['golf-7'], years: [2013, 2019], specs: [['Geschikt voor', 'Golf 7 2013–2019 (ook GTI, GTD, R en R-line)']], warranty: '3 jaar' },
  { slug: 'volkswagen-golf-7-cruise-control-via-hendel', feature: 'cruise-control-hendel', brand: 'volkswagen', models: ['golf-7'], years: [2013, 2019], specs: [['Geschikt voor', 'Golf 7 2013–2019 (ook GTI, GTD, R en R-line)']], warranty: '3 jaar' },
  { slug: 'volkswagen-golf-7-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'volkswagen', models: ['golf-7'], warranty: '3 jaar' },
  { slug: 'volkswagen-golf-7-rijprofielen', feature: 'rijprofielen', brand: 'volkswagen', models: ['golf-7'], years: [2013, 2019], specs: [['Geschikt voor', 'Golf 7 2013–2019 (ook GTI, GTD, R en R-line)']], warranty: '3 jaar' },
  { slug: 'volkswagen-golf-7-led-dynamische-achterlichten', feature: 'led-dynamisch', brand: 'volkswagen', models: ['golf-7'], warranty: '3 jaar' },
  { slug: 'volkswagen-golf-7-afneembare-trekhaak', feature: 'trekhaak-afneembaar', brand: 'volkswagen', models: ['golf-7'], warranty: '3 jaar' },
  { slug: 'volkswagen-golf-7-zwenkbare-wegklapbare-trekhaak', feature: 'trekhaak-zwenkbaar', brand: 'volkswagen', models: ['golf-7'], warranty: '3 jaar' },
  { slug: 'volkswagen-discover-navigatie-met-carplay', feature: 'discover-carplay', brand: 'volkswagen', models: ['golf-7', 'polo-aw', 'passat-b8'], yearsByModel: { 'golf-7': [2014, 2019], 'polo-aw': [2017, 2020], 'passat-b8': [2015, 2018] }, title: 'Volkswagen – Discover navigatie met CarPlay (aanbieding)', variantNote: 'Volgens CarTronic bedoeld voor auto’s met een oudere Discover Pro: Golf 2014–2019, Polo 2015–2020, Passat B8 2015–2018 en Touran 2015–2017 (ook GTE en R-line).', warranty: '3 jaar', price: '€ 899', aliases: ['aanbieding-4-volkswagen-discover-navigatie-met-carplay'] },
  { slug: 'volkswagen-golf-7-sportsvan-led-achterlichten', feature: 'led-achterlichten', brand: 'volkswagen', models: ['golf-sportsvan'], years: [2014, 2019], warranty: '3 jaar' },
  { slug: 'volkswagen-golf-8-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'volkswagen', models: ['golf-8'], short: 'Originele camera, verwerkt in het VW-logo op de achterklep. Het beeld van de ruimte achter de auto verschijnt op het multimediascherm.', specs: [['Geschikt voor', 'Golf 8 2020–heden (ook GTI, R en R-line)']] },
  { slug: 'volkswagen-golf-8-cruise-control-op-stuur', feature: 'cruise-control-stuur', brand: 'volkswagen', models: ['golf-8'], variantNote: 'Uitvoering met bediening via de knoppen op het stuur.' },
  { slug: 'volkswagen-polo-aw-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'volkswagen', models: ['polo-aw'], warranty: '3 jaar' },
  { slug: 'volkswagen-polo-aw-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'volkswagen', models: ['polo-aw'], warranty: '3 jaar' },
  { slug: 'volkswagen-polo-aw-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'volkswagen', models: ['polo-aw'], warranty: '3 jaar' },
  { slug: 'volkswagen-polo-aw-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'volkswagen', models: ['polo-aw'], warranty: '3 jaar' },
  { slug: 'volkswagen-polo-aw-discover-media', feature: 'discover-media', brand: 'volkswagen', models: ['polo-aw'], years: [2018, 2019], specs: [['Scherm', '8 inch kleurentouchscreen'], ['Geschikt voor', 'Polo AW 2018–2019 (ook GTI en R-line)']], warranty: '3 jaar' },
  { slug: 'volkswagen-polo-aw-active-info-display', feature: 'active-info-display', brand: 'volkswagen', models: ['polo-aw'], warranty: '3 jaar' },
  { slug: 'volkswagen-polo-aw-dode-hoek-assistent', feature: 'dodehoek', brand: 'volkswagen', models: ['polo-aw'], warranty: '3 jaar' },
  { slug: 'volkswagen-polo-aw-cruise-control-op-stuur', feature: 'cruise-control-stuur', brand: 'volkswagen', models: ['polo-aw'], years: [2018, 2019], specs: [['Geschikt voor', 'Polo AW 2018–2019 (ook GTI en R-line)']], warranty: '3 jaar' },
  { slug: 'volkswagen-polo-aw-cruise-control-via-hendel', feature: 'cruise-control-hendel', brand: 'volkswagen', models: ['polo-aw'], years: [2018, 2019], specs: [['Geschikt voor', 'Polo AW 2018–2019 (ook GTI en R-line)']], warranty: '3 jaar' },
  { slug: 'volkswagen-polo-aw-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'volkswagen', models: ['polo-aw'], warranty: '3 jaar' },
  { slug: 'volkswagen-polo-aw-led-achterlichten', feature: 'led-achterlichten', brand: 'volkswagen', models: ['polo-aw'], years: [2018, 2019], warranty: '3 jaar' },
  { slug: 'volkswagen-polo-aw-led-achterlichten-donker', feature: 'led-achterlichten-donker', brand: 'volkswagen', models: ['polo-aw'], warranty: '3 jaar' },
  { slug: 'volkswagen-polo-aw-afneembare-trekhaak', feature: 'trekhaak-afneembaar', brand: 'volkswagen', models: ['polo-aw'], warranty: '3 jaar' },
  { slug: 'volkswagen-t-roc-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'volkswagen', models: ['t-roc'], warranty: '3 jaar' },
  { slug: 'volkswagen-t-roc-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'volkswagen', models: ['t-roc'], warranty: '3 jaar' },
  { slug: 'volkswagen-t-roc-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'volkswagen', models: ['t-roc'], warranty: '3 jaar' },
  { slug: 'volkswagen-t-roc-discover-media', feature: 'discover-media', brand: 'volkswagen', models: ['t-roc'], years: [2017, 2019], specs: [['Scherm', '8 inch kleurentouchscreen'], ['Geschikt voor', 'T-Roc 2017–2019 (ook R-line)']], warranty: '3 jaar' },
  { slug: 'volkswagen-t-roc-active-info-display', feature: 'active-info-display', brand: 'volkswagen', models: ['t-roc'], warranty: '3 jaar' },
  { slug: 'volkswagen-t-roc-dode-hoek-assistent', feature: 'dodehoek', brand: 'volkswagen', models: ['t-roc'], warranty: '3 jaar' },
  { slug: 'volkswagen-t-roc-cruise-control-op-stuur', feature: 'cruise-control-stuur', brand: 'volkswagen', models: ['t-roc'], years: [2017, 2019], specs: [['Geschikt voor', 'T-Roc 2017–2019 (ook R-line)']], warranty: '3 jaar' },
  { slug: 'volkswagen-t-roc-cruise-control-via-hendel', feature: 'cruise-control-hendel', brand: 'volkswagen', models: ['t-roc'], years: [2017, 2019], specs: [['Geschikt voor', 'T-Roc 2017–2019 (ook R-line)']], warranty: '3 jaar' },
  { slug: 'volkswagen-t-roc-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'volkswagen', models: ['t-roc'], warranty: '3 jaar' },
  { slug: 'volkswagen-t-roc-afneembare-trekhaak', feature: 'trekhaak-afneembaar', brand: 'volkswagen', models: ['t-roc'], warranty: '3 jaar' },
  { slug: 'volkswagen-tiguan-ad-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'volkswagen', models: ['tiguan-ad'], short: 'Originele camera in de greep van de achterklep. Zodra u de achteruit inschakelt, verschijnt het beeld automatisch op het scherm.' },
  { slug: 'volkswagen-tiguan-ad-area-view-360-camera', feature: 'area-view', brand: 'volkswagen', models: ['tiguan-ad'], years: [2016, 2019], specs: [['Geschikt voor', 'Tiguan AD 2016–2019 (ook R-line en Allspace)']] },
  { slug: 'volkswagen-tiguan-ad-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'volkswagen', models: ['tiguan-ad'] },
  { slug: 'volkswagen-tiguan-ad-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'volkswagen', models: ['tiguan-ad'] },
  { slug: 'volkswagen-tiguan-ad-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'volkswagen', models: ['tiguan-ad'] },
  { slug: 'volkswagen-tiguan-ad-discover-media', feature: 'discover-media', brand: 'volkswagen', models: ['tiguan-ad'], short: 'Origineel Volkswagen Discover Media navigatie- en multimediasysteem.' },
  { slug: 'volkswagen-tiguan-ad-discover-pro', feature: 'discover-pro', brand: 'volkswagen', models: ['tiguan-ad'], years: [2016, 2019], short: 'Origineel Discover Pro navigatiesysteem: navigatie, media en telefoon bedient u via een 9,2-inch touchscreen.', specs: [['Scherm', '9,2 inch touchscreen'], ['Geschikt voor', 'Tiguan AD 2016–2019 (ook R-line en Allspace)']], warranty: '3 jaar' },
  { slug: 'volkswagen-tiguan-ad-active-info-display', feature: 'active-info-display', brand: 'volkswagen', models: ['tiguan-ad'], short: 'Origineel, volledig digitaal instrumentenpaneel in plaats van de analoge tellers.', warranty: '3 jaar' },
  { slug: 'volkswagen-tiguan-ad-verkeersbordherkenning', feature: 'verkeersbordherkenning', brand: 'volkswagen', models: ['tiguan-ad'] },
  { slug: 'volkswagen-tiguan-ad-cruise-control-op-stuur', feature: 'cruise-control-stuur', brand: 'volkswagen', models: ['tiguan-ad'], short: 'Originele cruise control om een ingestelde snelheid vast te houden.', variantNote: 'Uitvoering met bediening op het stuur; de juiste uitvoering voor uw Tiguan stemmen we vooraf af.' },
  { slug: 'volkswagen-tiguan-ad-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'volkswagen', models: ['tiguan-ad'], short: 'Elektrisch inklapbare buitenspiegels die inklappen bij het vergrendelen. De schakelaar in het bestuurdersportier wordt daarvoor vervangen.' },
  { slug: 'volkswagen-tiguan-ad-elektrische-achterklep', feature: 'achterklep', brand: 'volkswagen', models: ['tiguan-ad'] },
  { slug: 'volkswagen-tiguan-ad-led-achterlichten', feature: 'led-achterlichten', brand: 'volkswagen', models: ['tiguan-ad'], short: 'Originele LED-achterlichten ter vervanging van de halogeen-achterlichten.' },
  { slug: 'volkswagen-tiguan-ad-zwenkbare-wegklapbare-trekhaak', feature: 'trekhaak-zwenkbaar', brand: 'volkswagen', models: ['tiguan-ad'], short: 'Originele zwenkbare trekhaak die u met een schakelaar in de kofferbak uitzwenkt, met 13-polige contactdoos. Met een aangesloten aanhanger schakelt de parkeerhulp achter automatisch uit.' },
  { slug: 'volkswagen-sharan-app-connect', feature: 'app-connect', brand: 'volkswagen', models: ['sharan'] },
  { slug: 'volkswagen-passat-b8-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'volkswagen', models: ['passat-b8'], warranty: '3 jaar' },
  { slug: 'volkswagen-passat-b8-area-view-360-camera', feature: 'area-view', brand: 'volkswagen', models: ['passat-b8'], years: [2014, 2019], specs: [['Geschikt voor', 'Passat B8 2014–2019 (ook GTE en R-line)']], warranty: '3 jaar' },
  { slug: 'volkswagen-passat-b8-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'volkswagen', models: ['passat-b8'], warranty: '3 jaar' },
  { slug: 'volkswagen-passat-b8-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'volkswagen', models: ['passat-b8'], warranty: '3 jaar' },
  { slug: 'volkswagen-passat-b8-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'volkswagen', models: ['passat-b8'], warranty: '3 jaar' },
  { slug: 'volkswagen-passat-b8-discover-media', feature: 'discover-media', brand: 'volkswagen', models: ['passat-b8'], years: [2014, 2019], specs: [['Scherm', '8 inch kleurentouchscreen'], ['Geschikt voor', 'Passat B8 2014–2019 (ook GTE en R-line)']], warranty: '3 jaar' },
  { slug: 'volkswagen-passat-b8-active-info-display', feature: 'active-info-display', brand: 'volkswagen', models: ['passat-b8'], warranty: '3 jaar' },
  { slug: 'volkswagen-passat-b8-cruise-control-op-stuur', feature: 'cruise-control-stuur', brand: 'volkswagen', models: ['passat-b8'], years: [2014, 2019], specs: [['Geschikt voor', 'Passat B8 2014–2019 (ook R-line)']], warranty: '3 jaar' },
  { slug: 'volkswagen-passat-b8-cruise-control-via-hendel', feature: 'cruise-control-hendel', brand: 'volkswagen', models: ['passat-b8'], years: [2014, 2019], specs: [['Geschikt voor', 'Passat B8 2014–2019 (ook R-line)']], warranty: '3 jaar' },
  { slug: 'volkswagen-passat-b8-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'volkswagen', models: ['passat-b8'], warranty: '3 jaar' },
  { slug: 'volkswagen-passat-b8-elektrische-achterklep', feature: 'achterklep', brand: 'volkswagen', models: ['passat-b8'], years: [2014, 2019], specs: [['Geschikt voor', 'Passat B8 2014–2019 (ook GTE en R-line)']], warranty: '3 jaar' },
  { slug: 'volkswagen-passat-b8-afneembare-trekhaak', feature: 'trekhaak-afneembaar', brand: 'volkswagen', models: ['passat-b8'], warranty: '3 jaar' },
  { slug: 'volkswagen-passat-b8-zwenkbare-wegklapbare-trekhaak', feature: 'trekhaak-zwenkbaar', brand: 'volkswagen', models: ['passat-b8'], warranty: '3 jaar' },
  { slug: 'volkswagen-id3-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'volkswagen', models: ['id-3'], short: 'Originele Volkswagen-camera die automatisch inschakelt zodra u de achteruit inschakelt. CarTronic was een van de eersten die deze camera in een ID.3 inbouwde.' },
  { slug: 'volkswagen-id3-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'volkswagen', models: ['id-3'] },
  { slug: 'volkswagen-id4-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'volkswagen', models: ['id-4'] },
  { slug: 'volkswagen-id4-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'volkswagen', models: ['id-4'] },
  { slug: 'volkswagen-up-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'volkswagen', models: ['up'], warranty: '3 jaar' },
  { slug: 'volkswagen-up-cruise-control', feature: 'cruise-control', brand: 'volkswagen', models: ['up'], warranty: '3 jaar' },
  { slug: 'volkswagen-caddy-sa-achteruitrijcamera-achterdeuren', feature: 'achteruitrijcamera-achterdeuren', brand: 'volkswagen', models: ['caddy-sa'], years: [2015, 2019], short: 'Originele camera, onopvallend ingebouwd in de slotplaat van de linker achterdeur. Zodra u de achteruit inschakelt, verschijnt het beeld automatisch op het multimediascherm.', warranty: '3 jaar' },
  { slug: 'volkswagen-caddy-sa-achteruitrijcamera-achterklep', feature: 'achteruitrijcamera-achterklep', brand: 'volkswagen', models: ['caddy-sa'], years: [2015, 2019], short: 'Originele camera, onopvallend ingebouwd in de greep van de achterklep. Zodra u de achteruit inschakelt, verschijnt het beeld automatisch op het multimediascherm.', warranty: '3 jaar' },
  { slug: 'volkswagen-caddy-sa-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'volkswagen', models: ['caddy-sa'], warranty: '3 jaar' },
  { slug: 'volkswagen-caddy-sa-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'volkswagen', models: ['caddy-sa'], warranty: '3 jaar' },
  { slug: 'volkswagen-caddy-sa-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'volkswagen', models: ['caddy-sa'], warranty: '3 jaar' },
  { slug: 'volkswagen-transporter-t6-achteruitrijcamera-achterdeuren', feature: 'achteruitrijcamera-achterdeuren', brand: 'volkswagen', models: ['transporter-t6'], years: [2015, 2019], short: 'Originele camera, onopvallend ingebouwd in de slotplaat van de linker achterdeur. Zodra u de achteruit inschakelt, verschijnt het beeld automatisch op het multimediascherm.', warranty: '3 jaar' },
  { slug: 'volkswagen-transporter-t6-achteruitrijcamera-achterklep', feature: 'achteruitrijcamera-achterklep', brand: 'volkswagen', models: ['transporter-t6'], years: [2015, 2019], short: 'Originele camera, onopvallend ingebouwd in de achterklep. Zodra u de achteruit inschakelt, verschijnt het beeld automatisch op het multimediascherm.', specs: [['Geschikt voor', 'Transporter T6 2015–2019 (ook Multivan)']], warranty: '3 jaar' },
  { slug: 'volkswagen-transporter-t6-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'volkswagen', models: ['transporter-t6'], warranty: '3 jaar' },
  { slug: 'volkswagen-transporter-t6-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'volkswagen', models: ['transporter-t6'], warranty: '3 jaar' },
  { slug: 'volkswagen-transporter-t6-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'volkswagen', models: ['transporter-t6'], warranty: '3 jaar' },
  { slug: 'volkswagen-transporter-t6-dode-hoek-assistent', feature: 'dodehoek', brand: 'volkswagen', models: ['transporter-t6'], warranty: '3 jaar' },
  { slug: 'volkswagen-transporter-t6-led-koplampen', feature: 'led-koplampen', brand: 'volkswagen', models: ['transporter-t6'], years: [2015, 2019], specs: [['Geschikt voor', 'Transporter T6 2015–2019 (ook Multivan)']], warranty: '3 jaar' },
  { slug: 'volkswagen-crafter-sy-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'volkswagen', models: ['crafter-sy'], warranty: '3 jaar' },
  { slug: 'volkswagen-crafter-sy-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'volkswagen', models: ['crafter-sy'], warranty: '3 jaar' },
  { slug: 'volkswagen-crafter-sy-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'volkswagen', models: ['crafter-sy'], warranty: '3 jaar' },
  { slug: 'volkswagen-crafter-sy-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'volkswagen', models: ['crafter-sy'], warranty: '3 jaar' },
  // ---- Aanvulling uit de volledige catalogus – Audi
  { slug: 'audi-a1-8x-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'audi', models: ['a1-8x'], warranty: '3 jaar' },
  { slug: 'audi-a1-8x-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'audi', models: ['a1-8x'], warranty: '3 jaar' },
  { slug: 'audi-a1-8x-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'audi', models: ['a1-8x'], warranty: '3 jaar' },
  { slug: 'audi-a1-8x-cruise-control', feature: 'cruise-control', brand: 'audi', models: ['a1-8x'], warranty: '3 jaar' },
  { slug: 'audi-a1-8x-dimmende-binnenspiegel', feature: 'dimmende-binnenspiegel', brand: 'audi', models: ['a1-8x'], warranty: '3 jaar' },
  { slug: 'audi-a1-8x-xenon-koplampen', feature: 'xenon', brand: 'audi', models: ['a1-8x'], specs: [['Geschikt voor', 'A1 8X 2010–2018 (ook S1 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-a1-8x-led-achterlichten', feature: 'led-achterlichten', brand: 'audi', models: ['a1-8x'], short: 'Originele LED-achterlichten ter vervanging van de halogeen-achterlichten.', specs: [['Geschikt voor', 'A1 8X 2010–2018 (ook S1 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-a1-gb-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'audi', models: ['a1-gb'], years: [2019, 2024], short: 'Originele Audi-camera, onopvallend geïntegreerd in de greep van de achterklep. Het beeld van de ruimte achter de auto verschijnt op het MMI-scherm.', specs: [['Geschikt voor', 'A1 GB 2019–2024 (ook S-line)']], warranty: '3 jaar' },
  { slug: 'audi-a1-gb-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'audi', models: ['a1-gb'], warranty: '3 jaar' },
  { slug: 'audi-a1-gb-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'audi', models: ['a1-gb'], warranty: '3 jaar' },
  { slug: 'audi-a1-gb-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'audi', models: ['a1-gb'], warranty: '3 jaar' },
  { slug: 'audi-a1-gb-smartphone-interface', feature: 'smartphone-interface', brand: 'audi', models: ['a1-gb'], years: [2019, 2020], specs: [['Geschikt voor', 'A1 GB 2019–2020 (ook S-line)']], warranty: '3 jaar' },
  { slug: 'audi-a1-gb-verkeersbordherkenning', feature: 'verkeersbordherkenning', brand: 'audi', models: ['a1-gb'], warranty: '3 jaar' },
  { slug: 'audi-a1-gb-cruise-control', feature: 'cruise-control', brand: 'audi', models: ['a1-gb'], warranty: '3 jaar' },
  { slug: 'audi-a1-gb-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'audi', models: ['a1-gb'], warranty: '3 jaar' },
  { slug: 'audi-a1-gb-dimmende-binnenspiegel', feature: 'dimmende-binnenspiegel', brand: 'audi', models: ['a1-gb'], years: [2019, 2020], specs: [['Geschikt voor', 'A1 GB 2019–2020 (ook S-line)']], warranty: '3 jaar' },
  { slug: 'audi-a1-gb-led-koplampen', feature: 'led-koplampen', brand: 'audi', models: ['a1-gb'], years: [2019, 2020], specs: [['Geschikt voor', 'A1 GB 2019–2020 (ook S-line)']], warranty: '3 jaar' },
  { slug: 'audi-a1-gb-led-dynamische-achterlichten', feature: 'led-dynamisch', brand: 'audi', models: ['a1-gb'], warranty: '3 jaar' },
  { slug: 'audi-a3-8v-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'audi', models: ['a3-8v'], warranty: '3 jaar' },
  { slug: 'audi-a3-8v-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'audi', models: ['a3-8v'], warranty: '3 jaar' },
  { slug: 'audi-a3-8v-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'audi', models: ['a3-8v'], warranty: '3 jaar' },
  { slug: 'audi-a3-8v-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'audi', models: ['a3-8v'], warranty: '3 jaar' },
  { slug: 'audi-a3-8v-dimmende-binnenspiegel', feature: 'dimmende-binnenspiegel', brand: 'audi', models: ['a3-8v'], years: [2012, 2019], specs: [['Geschikt voor', 'A3 8V 2012–2019 (ook S3, RS3 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-a3-8v-led-dynamische-achterlichten', feature: 'led-dynamisch', brand: 'audi', models: ['a3-8v'], warranty: '3 jaar' },
  { slug: 'audi-a3-8v-instapverlichting-audi-ringen', feature: 'instapverlichting', brand: 'audi', models: ['a3-8v'], years: [2012, 2019], specs: [['Geschikt voor', 'A3 8V 2012–2019 (ook S3, RS3 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-a3-8v-afneembare-trekhaak', feature: 'trekhaak-afneembaar', brand: 'audi', models: ['a3-8v'], warranty: '3 jaar' },
  { slug: 'audi-a3-8v-zwenkbare-wegklapbare-trekhaak', feature: 'trekhaak-zwenkbaar', brand: 'audi', models: ['a3-8v'], warranty: '3 jaar' },
  { slug: 'audi-a3-8y-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'audi', models: ['a3-8y'], years: [2020, 2024], short: 'Originele Audi-camera in de greep van de achterklep. Het beeld met hulplijnen verschijnt op het MMI-scherm.', specs: [['Geschikt voor', 'A3 8Y 2020–2024 (ook S3, RS3 en S-line)']] },
  { slug: 'audi-a3-8y-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'audi', models: ['a3-8y'], years: [2020, 2024], specs: [['Geschikt voor', 'A3 8Y 2020–2024 (ook S3, RS3 en S-line)']] },
  { slug: 'audi-a4-b9-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'audi', models: ['a4-b9'], warranty: '3 jaar', aliases: ['audi-a4-b9-8w-achteruitrijcamera'] },
  { slug: 'audi-a4-b9-top-view-360-graden-camera', feature: 'top-view', brand: 'audi', models: ['a4-b9'], years: [2015, 2024], specs: [['Geschikt voor', 'A4 B9/8W 2015–2024 (ook S4, RS4 en S-line)']], warranty: '3 jaar', aliases: ['audi-a4-b9-8w-top-view-360-graden-camera'] },
  { slug: 'audi-a4-b9-smartphone-interface', feature: 'smartphone-interface', brand: 'audi', models: ['a4-b9'], years: [2015, 2019], variantNote: 'Werkt alleen als de auto MMI-navigatie heeft; zowel de basisversie als MMI Navigatie plus is geschikt.', specs: [['Geschikt voor', 'A4 B9/8W 2015–2019 (ook S4, RS4 en S-line)']], warranty: '3 jaar', price: '€ 399', aliases: ['audi-a4-b9-8w-smartphone-interface'] },
  { slug: 'audi-a4-b9-virtual-cockpit', feature: 'virtual-cockpit', brand: 'audi', models: ['a4-b9'], years: [2015, 2019], specs: [['Scherm', '12,3 inch TFT'], ['Geschikt voor', 'A4 B9/8W 2015–2019 (ook S4, RS4 en S-line)']], warranty: '3 jaar', aliases: ['audi-a4-b9-8w-virtual-cockpit'] },
  { slug: 'audi-a4-b9-dode-hoek-assistent', feature: 'dodehoek', brand: 'audi', models: ['a4-b9'], warranty: '3 jaar', aliases: ['audi-a4-b9-8w-dode-hoek-assistent'] },
  { slug: 'audi-a4-b9-active-lane-assist', feature: 'lane-assist', brand: 'audi', models: ['a4-b9'], years: [2015, 2019], specs: [['Geschikt voor', 'A4 B9/8W 2015–2019 (ook S4, RS4 en S-line)']], warranty: '3 jaar', aliases: ['audi-a4-b9-8w-active-lane-assist'] },
  { slug: 'audi-a4-b9-verkeersbordherkenning', feature: 'verkeersbordherkenning', brand: 'audi', models: ['a4-b9'], warranty: '3 jaar', aliases: ['audi-a4-b9-8w-verkeersbordherkenning'] },
  { slug: 'audi-a4-b9-wegrijassistent', feature: 'wegrijassistent', brand: 'audi', models: ['a4-b9'], years: [2015, 2019], specs: [['Geschikt voor', 'A4 B9/8W 2015–2019 (ook S4, RS4 en S-line)']], warranty: '3 jaar', aliases: ['audi-a4-b9-8w-wegrijassistent'] },
  { slug: 'audi-a4-b9-cruise-control', feature: 'cruise-control', brand: 'audi', models: ['a4-b9'], warranty: '3 jaar', aliases: ['audi-a4-b9-8w-cruise-control'] },
  { slug: 'audi-a4-b9-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'audi', models: ['a4-b9'], warranty: '3 jaar', aliases: ['audi-a4-b9-8w-inklapbare-spiegels'] },
  { slug: 'audi-a4-b9-dimmende-binnenspiegel', feature: 'dimmende-binnenspiegel', brand: 'audi', models: ['a4-b9'], years: [2015, 2019], specs: [['Geschikt voor', 'A4 B9/8W 2015–2019 (ook S4, RS4 en S-line)']], warranty: '3 jaar', aliases: ['audi-a4-b9-8w-dimmende-binnenspiegel'] },
  { slug: 'audi-a4-b9-comfortsleutel-keyless-entry', feature: 'keyless', brand: 'audi', models: ['a4-b9'], warranty: '3 jaar', aliases: ['audi-a4-b9-8w-comfortsleutel-keyless-entry'] },
  { slug: 'audi-a4-b9-garagedeuropener-homelink', feature: 'homelink', brand: 'audi', models: ['a4-b9'], years: [2015, 2019], specs: [['Geschikt voor', 'A4 B9/8W 2015–2019 (ook S4, RS4 en S-line)']], warranty: '3 jaar', aliases: ['audi-a4-b9-8w-garagedeuropener-homelink'] },
  { slug: 'audi-a4-b9-zwenkbare-wegklapbare-trekhaak', feature: 'trekhaak-zwenkbaar', brand: 'audi', models: ['a4-b9'], warranty: '3 jaar', aliases: ['audi-a4-b9-8w-zwenkbare-wegklapbare-trekhaak'] },
  { slug: 'audi-a4-b9-limousine-led-achterlichten-donker', feature: 'led-achterlichten-donker', brand: 'audi', models: ['a4-b9'], variant: 'limousine', years: [2015, 2019], specs: [['Geschikt voor', 'A4 B9/8W Limousine 2015–2019']], warranty: '3 jaar', aliases: ['audi-a4-b9-8w-limousine-led-achterlichten-donker'] },
  { slug: 'audi-a4-b9-avant-led-achterlichten-donker', feature: 'led-achterlichten-donker', brand: 'audi', models: ['a4-b9'], variant: 'avant', years: [2015, 2019], specs: [['Geschikt voor', 'A4 B9/8W Avant 2015–2019']], warranty: '3 jaar', aliases: ['audi-a4-b9-8w-avant-led-achterlichten-donker'] },
  { slug: 'audi-a5-f5-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'audi', models: ['a5-f5'], warranty: '3 jaar' },
  { slug: 'audi-a5-f5-top-view-360-graden-camera', feature: 'top-view', brand: 'audi', models: ['a5-f5'], years: [2016, 2024], specs: [['Geschikt voor', 'A5 F5 2016–2024 (ook S5, RS5 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-a5-f5-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'audi', models: ['a5-f5'], warranty: '3 jaar' },
  { slug: 'audi-a5-f5-smartphone-interface', feature: 'smartphone-interface', brand: 'audi', models: ['a5-f5'], warranty: '3 jaar' },
  { slug: 'audi-a5-f5-virtual-cockpit', feature: 'virtual-cockpit', brand: 'audi', models: ['a5-f5'], years: [2016, 2019], specs: [['Scherm', '12,3 inch TFT'], ['Geschikt voor', 'A5 F5 2016–2019 (ook S5, RS5 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-a5-f5-dode-hoek-assistent', feature: 'dodehoek', brand: 'audi', models: ['a5-f5'], warranty: '3 jaar' },
  { slug: 'audi-a5-f5-active-lane-assist', feature: 'lane-assist', brand: 'audi', models: ['a5-f5'], years: [2016, 2019], specs: [['Geschikt voor', 'A5 F5 2016–2019 (ook S5, RS5 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-a5-f5-verkeersbordherkenning', feature: 'verkeersbordherkenning', brand: 'audi', models: ['a5-f5'], warranty: '3 jaar' },
  { slug: 'audi-a5-f5-wegrijassistent', feature: 'wegrijassistent', brand: 'audi', models: ['a5-f5'], warranty: '3 jaar' },
  { slug: 'audi-a5-f5-cruise-control', feature: 'cruise-control', brand: 'audi', models: ['a5-f5'], warranty: '3 jaar' },
  { slug: 'audi-a5-f5-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'audi', models: ['a5-f5'], warranty: '3 jaar' },
  { slug: 'audi-a5-f5-dimmende-binnenspiegel', feature: 'dimmende-binnenspiegel', brand: 'audi', models: ['a5-f5'], warranty: '3 jaar' },
  { slug: 'audi-a5-f5-comfortsleutel-keyless-entry', feature: 'keyless', brand: 'audi', models: ['a5-f5'], warranty: '3 jaar' },
  { slug: 'audi-a5-f5-garagedeuropener-homelink', feature: 'homelink', brand: 'audi', models: ['a5-f5'], years: [2016, 2019], specs: [['Geschikt voor', 'A5 F5 2016–2019 (ook S5, RS5 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-a5-f5-led-achterlichten-donker', feature: 'led-achterlichten-donker', brand: 'audi', models: ['a5-f5'], years: [2016, 2019], specs: [['Geschikt voor', 'A5 F5 Sportback, Coupé en Cabriolet 2016–2019']], warranty: '3 jaar' },
  { slug: 'audi-a6-top-view-360-graden-camera', feature: 'top-view', brand: 'audi', models: ['a6-c8'], years: [2018, 2024], specs: [['Geschikt voor', 'A6 2018–2024 (ook S6, RS6 en S-line)']] },
  { slug: 'audi-a6-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'audi', models: ['a6-c8'], years: [2018, 2024], specs: [['Geschikt voor', 'A6 2018–2024 (ook S6, RS6 en S-line)']] },
  { slug: 'audi-a7-active-lane-assist', feature: 'lane-assist', brand: 'audi', models: ['a7-c8'], years: [2018, 2024], specs: [['Geschikt voor', 'A7 2018–2024 (ook S7, RS7 en S-line)']] },
  { slug: 'audi-q2-ga-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'audi', models: ['q2-ga'], warranty: '3 jaar' },
  { slug: 'audi-q2-ga-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'audi', models: ['q2-ga'], warranty: '3 jaar' },
  { slug: 'audi-q2-ga-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'audi', models: ['q2-ga'], warranty: '3 jaar' },
  { slug: 'audi-q2-ga-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'audi', models: ['q2-ga'], warranty: '3 jaar' },
  { slug: 'audi-q2-ga-smartphone-interface', feature: 'smartphone-interface', brand: 'audi', models: ['q2-ga'], years: [2016, 2019], specs: [['Geschikt voor', 'Q2 GA 2016–2019 (ook SQ2 en S-line)']], warranty: '3 jaar', price: '€ 399' },
  { slug: 'audi-q2-ga-mmi-plus-navigatiesysteem', feature: 'mmi-plus', brand: 'audi', models: ['q2-ga'], years: [2016, 2019], specs: [['Geschikt voor', 'Q2 GA 2016–2019 (ook SQ2 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-q2-ga-virtual-cockpit', feature: 'virtual-cockpit', brand: 'audi', models: ['q2-ga'], years: [2016, 2019], specs: [['Scherm', '12,3 inch TFT'], ['Geschikt voor', 'Q2 GA 2016–2019 (ook SQ2 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-q2-ga-dode-hoek-assistent', feature: 'dodehoek', brand: 'audi', models: ['q2-ga'], warranty: '3 jaar' },
  { slug: 'audi-q2-ga-active-lane-assist', feature: 'lane-assist', brand: 'audi', models: ['q2-ga'], years: [2016, 2019], specs: [['Geschikt voor', 'Q2 GA 2016–2019 (ook SQ2 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-q2-ga-verkeersbordherkenning', feature: 'verkeersbordherkenning', brand: 'audi', models: ['q2-ga'], warranty: '3 jaar' },
  { slug: 'audi-q2-ga-cruise-control', feature: 'cruise-control', brand: 'audi', models: ['q2-ga'], warranty: '3 jaar' },
  { slug: 'audi-q2-ga-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'audi', models: ['q2-ga'], warranty: '3 jaar' },
  { slug: 'audi-q2-ga-elektrische-achterklep', feature: 'achterklep', brand: 'audi', models: ['q2-ga'], years: [2016, 2019], specs: [['Geschikt voor', 'Q2 GA 2016–2019 (ook SQ2 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-q2-ga-led-dynamische-achterlichten', feature: 'led-dynamisch', brand: 'audi', models: ['q2-ga'], warranty: '3 jaar' },
  { slug: 'audi-q2-ga-instapverlichting-audi-ringen', feature: 'instapverlichting', brand: 'audi', models: ['q2-ga'], years: [2016, 2019], specs: [['Geschikt voor', 'Q2 GA 2016–2019 (ook SQ2 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-q2-ga-afneembare-trekhaak', feature: 'trekhaak-afneembaar', brand: 'audi', models: ['q2-ga'], warranty: '3 jaar' },
  { slug: 'audi-q3-f3-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'audi', models: ['q3-f3'], warranty: '3 jaar' },
  { slug: 'audi-q3-f3-wegrijassistent', feature: 'wegrijassistent', brand: 'audi', models: ['q3-f3'], years: [2019, 2020], specs: [['Geschikt voor', 'Q3 F3 2019–2020 (ook S-line)']], warranty: '3 jaar' },
  { slug: 'audi-q3-f3-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'audi', models: ['q3-f3'], warranty: '3 jaar' },
  { slug: 'audi-q4-e-tron-top-view-360-graden-camera', feature: 'top-view', brand: 'audi', models: ['q4-etron'] },
  { slug: 'audi-q4-e-tron-smartphone-interface', feature: 'smartphone-interface', brand: 'audi', models: ['q4-etron'] },
  { slug: 'audi-q4-e-tron-dode-hoek-assistent', feature: 'dodehoek', brand: 'audi', models: ['q4-etron'], short: 'Waarschuwt voor voertuigen in de dode hoek, met radarsensoren en een waarschuwingslampje in de buitenspiegels.' },
  { slug: 'audi-q4-e-tron-verkeersbordherkenning', feature: 'verkeersbordherkenning', brand: 'audi', models: ['q4-etron'] },
  { slug: 'audi-q4-e-tron-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'audi', models: ['q4-etron'] },
  { slug: 'audi-q4-e-tron-elektrische-achterklep', feature: 'achterklep', brand: 'audi', models: ['q4-etron'] },
  { slug: 'audi-q4-e-tron-garagedeuropener-homelink', feature: 'homelink', brand: 'audi', models: ['q4-etron'] },
  { slug: 'audi-q5-fy-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'audi', models: ['q5-fy'], warranty: '3 jaar' },
  { slug: 'audi-q5-fy-top-view-360-graden-camera', feature: 'top-view', brand: 'audi', models: ['q5-fy'], years: [2017, 2019], specs: [['Geschikt voor', 'Q5 FY 2017–2019 (ook SQ5 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-q5-fy-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'audi', models: ['q5-fy'], warranty: '3 jaar' },
  { slug: 'audi-q5-fy-smartphone-interface', feature: 'smartphone-interface', brand: 'audi', models: ['q5-fy'], years: [2017, 2019], variantNote: 'Werkt alleen als de auto MMI-navigatie heeft; zowel de basisversie als MMI Navigatie plus is geschikt.', specs: [['Geschikt voor', 'Q5 FY 2017–2019 (ook SQ5 en S-line)']], warranty: '3 jaar', price: '€ 299' },
  { slug: 'audi-q5-fy-virtual-cockpit', feature: 'virtual-cockpit', brand: 'audi', models: ['q5-fy'], years: [2017, 2019], specs: [['Scherm', '12,3 inch TFT'], ['Geschikt voor', 'Q5 FY 2017–2019 (ook SQ5 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-q5-fy-dode-hoek-assistent', feature: 'dodehoek', brand: 'audi', models: ['q5-fy'], warranty: '3 jaar' },
  { slug: 'audi-q5-fy-active-lane-assist', feature: 'lane-assist', brand: 'audi', models: ['q5-fy'], years: [2017, 2019], specs: [['Geschikt voor', 'Q5 FY 2017–2019 (ook SQ5 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-q5-fy-verkeersbordherkenning', feature: 'verkeersbordherkenning', brand: 'audi', models: ['q5-fy'], warranty: '3 jaar' },
  { slug: 'audi-q5-fy-wegrijassistent', feature: 'wegrijassistent', brand: 'audi', models: ['q5-fy'], years: [2017, 2019], specs: [['Geschikt voor', 'Q5 FY 2017–2019 (ook SQ5 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-q5-fy-cruise-control', feature: 'cruise-control', brand: 'audi', models: ['q5-fy'], warranty: '3 jaar' },
  { slug: 'audi-q5-fy-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'audi', models: ['q5-fy'], warranty: '3 jaar' },
  { slug: 'audi-q5-fy-dimmende-binnenspiegel', feature: 'dimmende-binnenspiegel', brand: 'audi', models: ['q5-fy'], years: [2017, 2019], specs: [['Geschikt voor', 'Q5 FY 2017–2019 (ook SQ5 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-q5-fy-elektrische-achterklep', feature: 'achterklep', brand: 'audi', models: ['q5-fy'], years: [2017, 2019], specs: [['Geschikt voor', 'Q5 FY 2017–2019 (ook SQ5 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-q5-fy-comfortsleutel-keyless-entry', feature: 'keyless', brand: 'audi', models: ['q5-fy'], years: [2017, 2019], specs: [['Geschikt voor', 'Q5 FY 2017–2019 (ook SQ5 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-q5-fy-garagedeuropener-homelink', feature: 'homelink', brand: 'audi', models: ['q5-fy'], years: [2017, 2019], specs: [['Geschikt voor', 'Q5 FY 2017–2019 (ook SQ5 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-q5-fy-led-dynamische-achterlichten', feature: 'led-dynamisch', brand: 'audi', models: ['q5-fy'], warranty: '3 jaar' },
  { slug: 'audi-q5-fy-zwenkbare-wegklapbare-trekhaak', feature: 'trekhaak-zwenkbaar', brand: 'audi', models: ['q5-fy'], warranty: '3 jaar' },
  { slug: 'audi-q7-4m-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'audi', models: ['q7-4m'], warranty: '3 jaar' },
  { slug: 'audi-q7-4m-top-view-360-graden-camera', feature: 'top-view', brand: 'audi', models: ['q7-4m'], years: [2015, 2019], specs: [['Geschikt voor', 'Q7 4M 2015–2019 (ook SQ7 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-q7-4m-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'audi', models: ['q7-4m'], warranty: '3 jaar' },
  { slug: 'audi-q7-4m-smartphone-interface', feature: 'smartphone-interface', brand: 'audi', models: ['q7-4m'], years: [2015, 2019], variantNote: 'Werkt alleen als de auto MMI-navigatie heeft; zowel de basisversie als MMI Navigatie plus is geschikt.', specs: [['Geschikt voor', 'Q7 4M 2015–2019 (ook SQ7 en S-line)']], warranty: '3 jaar', price: '€ 299' },
  { slug: 'audi-q7-4m-mmi-plus-navigatiesysteem', feature: 'mmi-plus', brand: 'audi', models: ['q7-4m'], years: [2015, 2019], specs: [['Geschikt voor', 'Q7 4M 2015–2019 (ook SQ7 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-q7-4m-virtual-cockpit', feature: 'virtual-cockpit', brand: 'audi', models: ['q7-4m'], years: [2015, 2019], specs: [['Scherm', '12,3 inch TFT'], ['Geschikt voor', 'Q7 4M 2015–2019 (ook SQ7 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-q7-4m-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'audi', models: ['q7-4m'], warranty: '3 jaar' },
  { slug: 'audi-q7-4m-comfortsleutel-keyless-entry', feature: 'keyless', brand: 'audi', models: ['q7-4m'], years: [2015, 2019], specs: [['Geschikt voor', 'Q7 4M 2015–2019 (ook SQ7 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-q7-4m-garagedeuropener-homelink', feature: 'homelink', brand: 'audi', models: ['q7-4m'], years: [2015, 2019], specs: [['Geschikt voor', 'Q7 4M 2015–2019 (ook SQ7 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-q7-4m-instapverlichting-audi-ringen', feature: 'instapverlichting', brand: 'audi', models: ['q7-4m'], years: [2015, 2019], specs: [['Geschikt voor', 'Q7 4M 2015–2019 (ook SQ7 en S-line)']], warranty: '3 jaar' },
  { slug: 'audi-q7-4m-zwenkbare-wegklapbare-trekhaak', feature: 'trekhaak-zwenkbaar', brand: 'audi', models: ['q7-4m'], warranty: '3 jaar' },
  { slug: 'audi-q8-top-view-360-graden-camera', feature: 'top-view', brand: 'audi', models: ['q8'], specs: [['Geschikt voor', 'Q8 (ook SQ8 en RSQ8)']] },
  { slug: 'audi-q8-smartphone-interface', feature: 'smartphone-interface', brand: 'audi', models: ['q8'] },
  { slug: 'audi-q8-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'audi', models: ['q8'] },
  // ---- Aanvulling uit de volledige catalogus – SEAT
  { slug: 'seat-ibiza-kj-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'seat', models: ['ibiza-kj'], warranty: '3 jaar' },
  { slug: 'seat-ibiza-kj-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'seat', models: ['ibiza-kj'], warranty: '3 jaar' },
  { slug: 'seat-arona-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'seat', models: ['arona'], warranty: '3 jaar' },
  { slug: 'seat-arona-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'seat', models: ['arona'], warranty: '3 jaar' },
  { slug: 'seat-arona-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'seat', models: ['arona'], warranty: '3 jaar' },
  { slug: 'seat-arona-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'seat', models: ['arona'], warranty: '3 jaar' },
  { slug: 'seat-arona-afneembare-trekhaak', feature: 'trekhaak-afneembaar', brand: 'seat', models: ['arona'], warranty: '3 jaar' },
  { slug: 'seat-leon-5f-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'seat', models: ['leon-5f'], warranty: '3 jaar' },
  { slug: 'seat-leon-5f-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'seat', models: ['leon-5f'], warranty: '3 jaar' },
  { slug: 'seat-ateca-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'seat', models: ['ateca'], warranty: '3 jaar' },
  { slug: 'seat-ateca-area-view-360-camera', feature: 'area-view', brand: 'seat', models: ['ateca'], years: [2016, 2019], warranty: '3 jaar' },
  { slug: 'seat-ateca-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'seat', models: ['ateca'], warranty: '3 jaar' },
  { slug: 'seat-ateca-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'seat', models: ['ateca'], warranty: '3 jaar' },
  { slug: 'seat-ateca-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'seat', models: ['ateca'], warranty: '3 jaar' },
  { slug: 'seat-ateca-dode-hoek-assistent', feature: 'dodehoek', brand: 'seat', models: ['ateca'], warranty: '3 jaar' },
  { slug: 'seat-ateca-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'seat', models: ['ateca'], warranty: '3 jaar' },
  { slug: 'seat-ateca-zwenkbare-wegklapbare-trekhaak', feature: 'trekhaak-zwenkbaar', brand: 'seat', models: ['ateca'], warranty: '3 jaar' },
  { slug: 'seat-mii-achteruitrijcamera', feature: 'achteruitrijcamera', brand: 'seat', models: ['mii'], warranty: '3 jaar' },
  { slug: 'seat-mii-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'seat', models: ['mii'], warranty: '3 jaar' },
  // ---- Aanvulling uit de volledige catalogus – Škoda
  { slug: 'skoda-fabia-6v-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'skoda', models: ['fabia-6v'], warranty: '3 jaar', aliases: ['skoda-fabia-6v0-parkeerhulp-achterzijde'] },
  { slug: 'skoda-fabia-6v-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'skoda', models: ['fabia-6v'], warranty: '3 jaar', aliases: ['skoda-fabia-6v0-parkeerhulp-voor-en-achterzijde'] },
  { slug: 'skoda-fabia-6v-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'skoda', models: ['fabia-6v'], warranty: '3 jaar', aliases: ['skoda-fabia-6v0-parkeerhulp-voorzijde-upgrade'] },
  { slug: 'skoda-fabia-6v-cruise-control', feature: 'cruise-control', brand: 'skoda', models: ['fabia-6v'], warranty: '3 jaar', aliases: ['skoda-fabia-6v0-cruise-control'] },
  { slug: 'skoda-kamiq-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'skoda', models: ['kamiq'] },
  { slug: 'skoda-kamiq-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'skoda', models: ['kamiq'] },
  { slug: 'skoda-kamiq-zwenkbare-wegklapbare-trekhaak', feature: 'trekhaak-zwenkbaar', brand: 'skoda', models: ['kamiq'] },
  { slug: 'skoda-karoq-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'skoda', models: ['karoq'], warranty: '3 jaar' },
  { slug: 'skoda-karoq-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'skoda', models: ['karoq'], warranty: '3 jaar' },
  { slug: 'skoda-karoq-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'skoda', models: ['karoq'], warranty: '3 jaar' },
  { slug: 'skoda-karoq-cruise-control', feature: 'cruise-control', brand: 'skoda', models: ['karoq'], warranty: '3 jaar' },
  { slug: 'skoda-karoq-elektrische-achterklep', feature: 'achterklep', brand: 'skoda', models: ['karoq'], years: [2017, 2019], warranty: '3 jaar' },
  { slug: 'skoda-karoq-230-volt-aansluiting', feature: '230v', brand: 'skoda', models: ['karoq'], years: [2017, 2019], warranty: '3 jaar' },
  { slug: 'skoda-karoq-zwenkbare-wegklapbare-trekhaak', feature: 'trekhaak-zwenkbaar', brand: 'skoda', models: ['karoq'], warranty: '3 jaar' },
  { slug: 'skoda-kodiaq-area-view-360-camera', feature: 'area-view', brand: 'skoda', models: ['kodiaq'], years: [2017, 2019], warranty: '3 jaar' },
  { slug: 'skoda-kodiaq-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'skoda', models: ['kodiaq'], warranty: '3 jaar' },
  { slug: 'skoda-kodiaq-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'skoda', models: ['kodiaq'], warranty: '3 jaar' },
  { slug: 'skoda-kodiaq-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'skoda', models: ['kodiaq'], warranty: '3 jaar' },
  { slug: 'skoda-kodiaq-dode-hoek-assistent', feature: 'dodehoek', brand: 'skoda', models: ['kodiaq'], warranty: '3 jaar' },
  { slug: 'skoda-kodiaq-cruise-control', feature: 'cruise-control', brand: 'skoda', models: ['kodiaq'], warranty: '3 jaar' },
  { slug: 'skoda-kodiaq-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'skoda', models: ['kodiaq'], warranty: '3 jaar' },
  { slug: 'skoda-kodiaq-elektrische-achterklep', feature: 'achterklep', brand: 'skoda', models: ['kodiaq'], years: [2017, 2019], warranty: '3 jaar' },
  { slug: 'skoda-kodiaq-230-volt-aansluiting', feature: '230v', brand: 'skoda', models: ['kodiaq'], years: [2017, 2019], warranty: '3 jaar' },
  { slug: 'skoda-kodiaq-zwenkbare-wegklapbare-trekhaak', feature: 'trekhaak-zwenkbaar', brand: 'skoda', models: ['kodiaq'], warranty: '3 jaar' },
  { slug: 'skoda-enyaq-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'skoda', models: ['enyaq'], aliases: ['skoda-enyak-parkeerhulp-achterzijde'] },
  { slug: 'skoda-enyaq-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'skoda', models: ['enyaq'], aliases: ['skoda-enyak-inklapbare-spiegels'] },
  { slug: 'skoda-enyaq-zwenkbare-wegklapbare-trekhaak', feature: 'trekhaak-zwenkbaar', brand: 'skoda', models: ['enyaq'], short: 'Originele zwenkbare trekhaak met 13-polige contactdoos. Met een aangesloten aanhanger schakelt de parkeerhulp achter automatisch uit.', aliases: ['skoda-enyak-zwenkbare-wegklapbare-trekhaak'] },
  { slug: 'skoda-superb-3v-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'skoda', models: ['superb-3v'], warranty: '3 jaar' },
  { slug: 'skoda-superb-3v-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'skoda', models: ['superb-3v'], warranty: '3 jaar' },
  { slug: 'skoda-superb-3v-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'skoda', models: ['superb-3v'], warranty: '3 jaar' },
  { slug: 'skoda-superb-3v-dode-hoek-assistent', feature: 'dodehoek', brand: 'skoda', models: ['superb-3v'], warranty: '3 jaar' },
  { slug: 'skoda-superb-3v-cruise-control', feature: 'cruise-control', brand: 'skoda', models: ['superb-3v'], warranty: '3 jaar' },
  { slug: 'skoda-superb-3v-inklapbare-spiegels', feature: 'inklapbare-spiegels', brand: 'skoda', models: ['superb-3v'], warranty: '3 jaar' },
  { slug: 'skoda-superb-3v-230-volt-aansluiting', feature: '230v', brand: 'skoda', models: ['superb-3v'], years: [2015, 2019], warranty: '3 jaar' },
  { slug: 'skoda-citigo-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'skoda', models: ['citigo'], warranty: '3 jaar' },
  { slug: 'skoda-yeti-parkeerhulp-achterzijde', feature: 'parkeerhulp-achter', brand: 'skoda', models: ['yeti'], warranty: '3 jaar' },
  { slug: 'skoda-yeti-parkeerhulp-voor-en-achterzijde', feature: 'parkeerhulp-voor-achter', brand: 'skoda', models: ['yeti'], variant: 'ii', warranty: '3 jaar', aliases: ['skoda-yeti-ii-parkeerhulp-voor-en-achterzijde'] },
  { slug: 'skoda-yeti-parkeerhulp-voorzijde-upgrade', feature: 'parkeerhulp-voor-upgrade', brand: 'skoda', models: ['yeti'], variant: 'ii', warranty: '3 jaar', aliases: ['skoda-yeti-ii-parkeerhulp-voorzijde-upgrade'] },
  { slug: 'skoda-yeti-cruise-control', feature: 'cruise-control', brand: 'skoda', models: ['yeti'], variant: 'ii', warranty: '3 jaar', aliases: ['skoda-yeti-ii-cruise-control'] },
];
const RETROFIT = byKey(RETROFITS, 'slug');
/* Fill feature defaults; explicit fields on an entry always win. Also used for options added in Beheer. */
function normalizeRetrofit(r) {
  const f = FEATURES[r.feature] || {};
  const vr = r.variant ? VARIANTS[r.variant] : null;
  r.cat = r.cat || f.cat;
  r.art = r.art || f.art || (CATEGORY[r.cat] || {}).art;
  r.name = r.name || (vr && vr.label ? `${f.name} (${vr.label})` : f.name);
  if (!r.image && f.image) r.image = f.image;
  r.short = r.short || f.short || '';
  if (vr) {
    if (vr.body && !r.body) r.body = vr.body;
    if (vr.years && !r.years) r.years = vr.years;
  }
  if (r.variantNote === undefined) r.variantNote = (vr && vr.note) || f.variantNote || '';
  if (!r.title) {
    const m = MODEL[r.models[0]];
    const label = `${BRAND[r.brand].name} ${m.name}${vr && vr.label ? ` ${vr.label}` : ''}`;
    r.title = `${label} – ${(f.titleByBrand && f.titleByBrand[r.brand]) || f.title || f.name}`;
  }
  r.keywords = uniq([...(r.keywords || []), ...(f.keywords || [])]);
  r.aliases = r.aliases || [];
  return r;
}
RETROFITS.forEach(normalizeRetrofit);
/* Older / archived URLs → current slug (handled by the retrofit route). */
const RETROFIT_ALIAS = Object.create(null);
RETROFITS.forEach((r) => r.aliases.forEach((a) => { RETROFIT_ALIAS[a] = r.slug; }));

/* Category-level copy for technical panels and benefits. Deliberately general: no claims
   beyond what CarTronic publishes. Option-specific facts live on the option itself. */
const CATEGORY_COPY = {
  'camera-parkeren': {
    install: 'Originele onderdelen voor camera of parkeerhulp, met de bijbehorende bekabeling. Het beeld of de parkeerweergave verschijnt op het bestaande scherm van de auto.',
    benefits: ['Meer overzicht rond de auto bij het parkeren', 'Originele onderdelen, afgestemd op uw model', 'Bediening en weergave zoals af fabriek'],
  },
  infotainment: {
    install: 'De functie of het systeem wordt toegevoegd aan het originele multimediasysteem. Waar onderdelen nodig zijn, gebruiken we originele componenten.',
    benefits: ['Bediening via het originele scherm en stuurwiel', 'Geen losse houders of kabels in het interieur', 'Geïntegreerd zoals af fabriek'],
  },
  cockpit: {
    install: 'Een origineel digitaal instrumentenpaneel ter vervanging van de bestaande tellers.',
    benefits: ['Navigatie, media en rijinformatie in uw gezichtsveld', 'Origineel instrumentenpaneel, geen namaak', 'Geprogrammeerd en aangemeld in de auto'],
  },
  assistentie: {
    install: 'De originele sensoren, bedieningselementen en componenten van het betreffende rijhulpsysteem.',
    benefits: ['Originele rijhulpsystemen, geen universele oplossing', 'Correct geprogrammeerd en aangemeld', 'Afstelling en kalibratie in eigen werkplaats'],
    calibrate: 'Rijhulpsystemen met radar of camera moeten correct zijn afgesteld. CarTronic beschikt over een complete uitlijn- en kalibratieset voor onder meer ACC, Lane Assist en Night Vision. Of afstelling voor deze optie nodig is, bevestigen we bij de controle van uw auto.',
  },
  comfort: {
    install: 'De originele onderdelen van de betreffende comfortfunctie, met de bijbehorende bekabeling.',
    benefits: ['Comfortfunctie zoals af fabriek', 'Originele onderdelen, afgestemd op uw model', 'Bediening via de originele knoppen en menu’s'],
  },
  verlichting: {
    install: 'Originele verlichtingsunits met de bijbehorende bekabeling.',
    benefits: ['Originele verlichting, passend bij uw model', 'Correct gecodeerd in de auto', 'Afgewerkt zoals af fabriek'],
  },
  trekhaken: {
    install: 'Een originele trekhaak met de bijbehorende kabelset.',
    benefits: ['Originele trekhaak voor uw model', 'Afneembaar of wegklapbaar, afhankelijk van de uitvoering', 'Netjes weggewerkt, zoals af fabriek'],
  },
  beveiliging: {
    install: 'Het originele alarmsysteem met interieursensoren, uit het zicht ingebouwd. Er komt geen losse led op de ruit of het dashboard: het alarm gebruikt de originele led in de deur.',
    program: 'Het alarm werkt daarna zoals af fabriek: bij vergrendelen wordt het ingeschakeld, bij ontgrendelen automatisch uitgeschakeld. Er zijn geen extra handelingen of losse afstandsbedieningen nodig.',
    benefits: ['Inclusief SCM-certificaat voor uw verzekeraar', 'Bediening via de originele sleutel', 'Geen zichtbare losse onderdelen'],
  },
};

/* ---------- Services (DIENST) — from cartronic.nl ("Reparatie & storingen") ---------- */
const SERVICES = [
  { slug: 'fabrieksopties-inbouwen', title: 'Originele fabrieksopties inbouwen', icon: 'cpu', card: 'OEM-retrofits',
    cardText: 'Originele fabrieksopties achteraf monteren. Met originele onderdelen, volgens de fabrieksnormen en passend bij de systemen in uw auto.',
    points: ['Camera’s, parkeersensoren en rijassistentie', 'Infotainment en digitale instrumentenpanelen', 'Comfort, verlichting en trekhaken'],
    cta: ['Vind opties voor uw auto', '#/mogelijkheden'],
    short: 'Achteraf monteren van originele fabrieksopties, met originele OEM-onderdelen en volgens fabrieksnormen.',
    body: ['CarTronic bouwt originele fabrieksopties in op vrijwel elk model van Volkswagen, Audi, SEAT en Škoda — van navigatie, camera en parkeersensoren tot inklapbare spiegels, beveiliging, Apple CarPlay en trekhaken.', 'We werken uitsluitend met originele OEM-onderdelen. De montage gebeurt in onze werkplaats in Rijswijk.'],
    keywords: ['retrofit', 'inbouwen', 'opties', 'oem'], cats: ['camera-parkeren', 'infotainment', 'comfort', 'trekhaken'] },
  { slug: 'online-programmeren', title: 'Online programmeren & software-updates', icon: 'settings2', card: 'Programmeren & coderen',
    cardText: 'Via de online verbinding met de fabriek programmeren we geïnstalleerde opties en melden we ze correct aan in de auto — zoals bij een dealer.',
    points: ['Geïnstalleerde opties programmeren', 'Correct aanmelden in de auto', 'Software-updates van modules'],
    cta: ['Meer over programmeren', '#/diensten/online-programmeren'],
    short: 'Modules online programmeren en software bijwerken via de verbinding met de fabriek.',
    body: ['Net als grote Volkswagen- en Audi-dealers hebben we toegang tot de online database van de fabriek. Daarmee programmeren we geïnstalleerde opties en melden we ze correct aan in de auto.', 'Ook software-updates van modules voeren we online uit.'],
    keywords: ['coderen', 'programmeren', 'software update', 'activeren'], cats: ['infotainment', 'cockpit'] },
  { slug: 'kalibratie-rijhulpsystemen', title: 'Kalibratie rijhulpsystemen', icon: 'target', card: 'Kalibratie rijhulpsystemen',
    cardText: 'Na schade of het vervangen van de voorruit moet een rijhulpsysteem opnieuw worden afgesteld. Daarvoor beschikken we over een complete uitlijn- en kalibratieset.',
    points: ['Adaptieve cruisecontrol (ACC)', 'Lane Assist', 'Night Vision'],
    cta: ['Meer over kalibratie', '#/diensten/kalibratie-rijhulpsystemen'],
    short: 'Uitlijnen en kalibreren van adaptieve cruisecontrol, Lane Assist en Night Vision.',
    body: ['Na schade of het vervangen van de voorruit kan een rijhulpsysteem zoals adaptieve cruisecontrol niet meer goed werken. CarTronic kalibreert deze systemen opnieuw.', 'Voor het afstellen van adaptieve cruisecontrol, Lane Assist en Night Vision beschikken we over een complete VW/Audi uitlijn- en kalibratieset — apparatuur die verder vooral bij grote dealers staat.'],
    keywords: ['acc', 'adaptive cruise control', 'adaptieve cruise control', 'lane assist', 'night vision', 'kalibreren', 'uitlijnen', 'voorruit'], cats: ['assistentie'], image: 'about' },
  { slug: 'diagnose-storingen', title: 'Diagnose & storingen', icon: 'activity', card: 'Diagnose & storingen',
    cardText: 'Een storingslampje of een systeem dat niet meer werkt? We stellen de diagnose met apparatuur op dealerniveau en zoeken de oorzaak.',
    points: ['Storingsdiagnose op dealerniveau', 'Volkswagen, Audi, SEAT en Škoda', 'Advies over de oplossing'],
    cta: ['Meer over diagnose', '#/diensten/diagnose-storingen'],
    short: 'Elektronische storingsdiagnose voor Volkswagen, Audi, SEAT en Škoda, met apparatuur op dealerniveau.',
    body: ['Een storingslampje of een systeem dat niet meer werkt? We stellen de diagnose met diagnoseapparatuur op dealerniveau en zoeken de oorzaak.'],
    keywords: ['storing', 'diagnose', 'foutcode', 'uitlezen', 'reparatie'], cats: [] },
  { slug: 'modules-vervangen', title: 'Modules vervangen', icon: 'box', card: 'Modules vervangen',
    cardText: 'Een defecte module vervangen we en melden we correct aan in de auto, zodat alle functies weer werken zoals bedoeld.',
    points: ['Defecte module vervangen', 'Correct aanmelden in de auto', 'Functies weer zoals bedoeld'],
    cta: ['Meer over modules', '#/diensten/modules-vervangen'],
    short: 'Defecte modules vervangen en correct aanmelden in de auto.',
    body: ['Een defecte module vervangen we en melden we correct aan in de auto, zodat alle functies weer werken zoals bedoeld.'],
    keywords: ['module', 'regelapparaat', 'vervangen'], cats: [] },
  { slug: 'reparatie-assistentiesystemen', title: 'Reparatie assistentiesystemen', icon: 'radar', card: 'Reparatie assistentiesystemen',
    cardText: 'Werkt een assistentiesysteem niet zoals het hoort? We controleren, repareren en kalibreren assistentiesystemen van Volkswagen, Audi, SEAT en Škoda.',
    points: ['Controleren', 'Repareren', 'Kalibreren'],
    cta: ['Meer over reparatie', '#/diensten/reparatie-assistentiesystemen'],
    short: 'Kalibratie en reparatie van assistentiesystemen.',
    body: ['Werkt een assistentiesysteem niet zoals het hoort? We controleren, repareren en kalibreren assistentiesystemen van Volkswagen, Audi, SEAT en Škoda.'],
    keywords: ['assistentie', 'reparatie', 'lane assist', 'acc'], cats: ['assistentie'] },
];
const SERVICE = byKey(SERVICES, 'slug');
/* Contact form: what the enquiry is about (shown as choices, included in the message). */
const ENQUIRY_TOPICS = [
  { id: 'inbouw', label: 'Optie laten inbouwen' },
  { id: 'programmeren', label: 'Programmeren of software-update' },
  { id: 'kalibratie', label: 'Kalibratie of reparatie rijhulpsystemen' },
  { id: 'storing', label: 'Storing, diagnose of module' },
  { id: 'optielijst', label: 'Optielijst van mijn auto (€ 10,00)' },
  { id: 'webshop', label: 'Vraag over de webshop' },
  { id: 'anders', label: 'Iets anders' },
];
const ENQUIRY_TOPIC = byKey(ENQUIRY_TOPICS, 'id');
const SERVICE_TOPIC = {
  'fabrieksopties-inbouwen': 'inbouw', 'online-programmeren': 'programmeren', 'kalibratie-rijhulpsystemen': 'kalibratie',
  'reparatie-assistentiesystemen': 'kalibratie', 'diagnose-storingen': 'storing', 'modules-vervangen': 'storing',
};

/* ---------- Projects (portfolio) — from the approved design screens ----------
   before/after: only set when REAL before and after photography exists. */
const DEFAULT_PROJECTS = [
  { id: 'prj_ibiza', slug: 'seat-ibiza-camera-meesturende-lijnen', title: 'Camera met meesturende lijnen', vehicle: 'SEAT Ibiza', brands: ['seat'], models: ['ibiza-kj'], type: 'camera-parkeren', tag: 'Originele camera',
    short: 'Originele High-camera, getest en gemonteerd in de SEAT Ibiza.',
    body: 'Een originele High-camera met meesturende hulplijnen, getest en gemonteerd in de SEAT Ibiza. Het beeld verschijnt op het originele multimediascherm, met hulplijnen die meebewegen met het stuur.',
    image: 'img:proj_ibiza', before: '', after: '', related: ['seat-ibiza-kj-achteruitrijcamera'], services: [], active: true },
  { id: 'prj_golf8', slug: 'golf-8-originele-grille-met-led', title: 'Originele grille met LED', vehicle: 'Volkswagen Golf 8', brands: ['volkswagen'], models: ['golf-8'], type: 'verlichting', tag: 'OEM-verlichting',
    short: 'LED-grille gemonteerd in de Volkswagen Golf 8.',
    body: 'Een originele grille met LED-lichtbalk, gemonteerd in de Volkswagen Golf 8.',
    image: 'img:proj_golf8', before: '', after: '', related: [], services: ['fabrieksopties-inbouwen'], active: true },
  { id: 'prj_kalibratie', slug: 'precisie-in-kalibratie', title: 'Precisie in kalibratie', vehicle: 'Volkswagen · Audi', brands: ['volkswagen', 'audi'], models: [], type: 'kalibratie', tag: 'Kalibratie',
    short: 'Uitlijnen en kalibreren van ACC, Lane Assist en Night Vision.',
    body: 'Op de uitlijnbrug in onze werkplaats worden rijhulpsystemen zoals adaptieve cruisecontrol, Lane Assist en Night Vision uitgelijnd en gekalibreerd — bijvoorbeeld na schade of het vervangen van de voorruit.',
    image: 'img:proj_kalibratie', gallery: ['img:about'], before: '', after: '', related: [], services: ['kalibratie-rijhulpsystemen'], active: true },
];
const PROJECT_TYPES = [
  ...CATEGORIES.map((c) => ({ id: c.id, name: c.name })),
  { id: 'kalibratie', name: 'Kalibratie' },
  { id: 'diagnose', name: 'Diagnose & reparatie' },
];

/* ---------- Social & reviews ----------
   Facebook: CarTronic's own page. Reviews: public Klantenvertellen profile (score, count and the
   quotes below as published there; checked 2026-10). Quotes are verbatim; "…" marks a cut. */
const FACEBOOK_URL = 'https://www.facebook.com/Cartronic-382532161837663/';
const REVIEWS = {
  score: '9,4', scale: 10, count: 229, source: 'Klantenvertellen',
  url: 'https://www.klantenvertellen.nl/reviews/1053077/cartronic',
  writeUrl: 'https://www.klantenvertellen.nl/add-review/1053077/cartronic?lang=nl',
  items: [
    { title: 'Top werk!', name: 'Steven', place: 'Den Haag', date: '2025-09-15', score: 10,
      text: 'Cartronic heeft voor mij een achteruit rijcamera geïnstalleerd in mijn VW polo van bouwjaar 2018. Binnen 2 uur was de operatie geslaagd en ik ben zeer tevreden. … Bedankt Cartronic en team.' },
    { title: 'Perfecte inbouw', name: 'Ad', place: 'Houten', date: '2025-10-23', score: 10,
      text: 'Enkele weken geleden adaptieve cruisecontrol laten inbouwen in mijn volkswagen T-Roc. Snel en net werk geleverd, en tot slot nog een duidelijke uitleg gekregen.' },
    { title: 'Top service', name: 'Mark', place: 'Valburg', date: '2025-09-21', score: 10,
      text: 'Inbouw parkeersensoren voor op mijn audi Q4 etron vlot en netjes uitgevoerd. Ook hebben ze mij en de dealer belangeloos (en kosteloos) geholpen toen 9 maanden later een software update vastliep.' },
    { title: 'Vakmensen!', name: 'F.', place: 'Dordrecht', date: '2018-03-24', score: 10,
      text: 'Zeer vriendelijk personeel, goed ontvangen. Golf 7 facelift dynamische led achterlichten in laten bouwen. Binnen 1,5 uur ingebouwd.' },
  ],
};

/* "Meer van ons werk" — portfolio items published on CarTronic's Facebook page. */
const MORE_WORK = [
  { title: 'Škoda Octavia IV', text: 'Een originele achteruitrijcamera ingebouwd in de vierde generatie Octavia. Bekijk de foto’s in het Facebook-portfolio.',
    links: [['Bekijk het portfolio op Facebook', FACEBOOK_URL]] },
  { title: 'Volkswagen ID.3 & Golf 8', text: 'Originele Volkswagen-camera’s ingebouwd. Het Facebook-portfolio bevat foto’s en video’s van deze werkzaamheden.',
    links: [['Bekijk het portfolio op Facebook', FACEBOOK_URL]] },
  { title: 'Audi RS6', text: 'Een Audi RS6 in de CarTronic-werkplaats. Bekijk de originele foto en het bijbehorende bericht in het portfolio.',
    links: [['Bekijk het portfolio op Facebook', FACEBOOK_URL]] },
  { title: 'De camera’s in beeld', text: 'Video’s van CarTronic op Facebook: parkassist en een originele camera in de nieuwste Audi Q7, en uitleg over de werking van de 360-gradencamera.',
    links: [['Bekijk de eerste video', 'https://www.facebook.com/Cartronic-382532161837663/videos/de-nieuwste-q7-ook-parkassist-en-originele-camera-inbouw-mogelijk-bij-cartronic-/1177318202359051/'],
      ['Bekijk de tweede video', 'https://www.facebook.com/Cartronic-382532161837663/videos/uitleg-over-de-werking-van-360-graden-camera/1537344069689794/']] },
];

/* ---------- Berichten & kennis ----------
   Short articles built from what CarTronic publishes (news pages, product and service texts). */
const ARTICLES = [
  { slug: 'online-verbinding-met-de-fabriek', tag: 'Techniek', icon: 'refresh', title: 'Online verbinding met de fabriek', keywords: ['online', 'programmeren', 'coderen', 'software update', 'activeren'],
    short: 'Net als grote Volkswagen- en Audi-dealers heeft CarTronic toegang tot de online database van de fabriek.',
    body: [
      ['p', 'Een originele optie is pas af als de auto haar herkent. Daarvoor heeft CarTronic, net als grote Volkswagen- en Audi-dealers, een online verbinding met de database van de fabriek.'],
      ['p', 'Via die verbinding programmeren we ingebouwde opties en melden we ze correct aan in de auto. Ook software-updates van modules voeren we online uit.'],
      ['h', 'Wat betekent dat voor u?'],
      ['ul', ['De optie werkt zoals af fabriek: via de originele schermen, knoppen en menu’s.', 'Opties worden geprogrammeerd en correct aangemeld in de auto, net als bij een dealer.', 'Ook software-updates van modules voeren we online uit.']],
    ], links: [['Meer over programmeren', '#/diensten/online-programmeren']] },
  { slug: 'acc-en-lane-assist-kalibreren', tag: 'Kalibratie', icon: 'target', title: 'Adaptieve cruisecontrol en Lane Assist kalibreren', keywords: ['acc', 'lane assist', 'night vision', 'kalibratie', 'uitlijnen', 'voorruit'],
    short: 'Na schade of het vervangen van de voorruit moet een rijhulpsysteem opnieuw worden afgesteld.',
    body: [
      ['p', 'Rijhulpsystemen zoals adaptieve cruisecontrol (ACC), Lane Assist en Night Vision werken met een radar of camera. Na schade of het vervangen van de voorruit kan zo’n systeem niet meer goed werken.'],
      ['p', 'Voor het opnieuw afstellen beschikt CarTronic over een complete VW/Audi uitlijn- en kalibratieset — apparatuur die verder vooral bij grote dealers staat.'],
      ['h', 'Welke systemen?'],
      ['ul', ['Adaptieve cruisecontrol (ACC)', 'Lane Assist', 'Night Vision']],
    ], links: [['Meer over kalibratie', '#/diensten/kalibratie-rijhulpsystemen'], ['Bekijk het kalibratieproject', '#/projecten/precisie-in-kalibratie']] },
  { slug: 'origineel-alarm-met-scm-certificaat', tag: 'Beveiliging', icon: 'shield', title: 'Zo werkt het originele alarm met SCM-certificaat', keywords: ['alarm', 'scm', 'diefstal', 'verzekering'],
    short: 'Het originele alarmsysteem, inclusief SCM-certificaat voor uw verzekeraar.',
    body: [
      ['p', 'CarTronic bouwt het originele alarmsysteem in, inclusief SCM-certificaat voor uw verzekeraar. Volgens CarTronic is dat mogelijk op de meeste modellen van Audi, SEAT, Škoda en Volkswagen, ook nieuwere modellen.'],
      ['p', 'Het alarm werkt daarna zoals af fabriek: vergrendelen schakelt het in, ontgrendelen schakelt het uit. Er zijn geen extra handelingen of losse afstandsbedieningen nodig.'],
      ['p', 'De interieursensoren worden uit het zicht ingebouwd. Er komt geen losse led op de ruit of het dashboard: het alarm gebruikt de originele led in de deur.'],
    ], links: [['Bekijk de optie', '#/mogelijkheden/origineel-af-fabriek-alarm-scm']] },
  { slug: 'apple-carplay-en-android-auto', tag: 'Connectiviteit', icon: 'phoneDevice', title: 'Apple CarPlay en Android Auto in uw Volkswagen of Audi', keywords: ['carplay', 'android auto', 'app connect', 'smartphone interface'],
    short: 'Met App Connect of de Audi Smartphone Interface gebruikt u uw apps via het originele scherm.',
    body: [
      ['p', 'Met App Connect (Volkswagen) of de Audi Smartphone Interface gebruikt u Apple CarPlay en Android Auto op het originele multimediasysteem. Navigatie, muziek en apps bedient u daarna via het scherm in de auto.'],
      ['p', 'Wat nodig is, verschilt per model. Bij een aantal Audi-modellen, zoals de A4 (B9), Q5 (FY) en Q7 (4M), werkt de Smartphone Interface alleen als de auto MMI-navigatie heeft; zowel de basisversie als MMI Navigatie plus is dan geschikt.'],
      ['p', 'Of het voor uw auto mogelijk is, ziet u per model in de catalogus. CarTronic controleert de uitvoering van uw auto altijd vooraf.'],
    ], links: [['Bekijk de opties', '#/mogelijkheden?q=carplay']] },
  { slug: 'modellen-die-niet-op-de-website-staan', tag: 'Catalogus', icon: 'car', title: 'Modellen die niet op de website staan', keywords: ['model niet gevonden', 'ander model', 'chassisnummer'],
    short: 'Staat uw model of de gewenste optie niet in de catalogus? Vraag het CarTronic gewoon.',
    body: [
      ['p', 'De online catalogus toont per model en generatie de opties die CarTronic op de website beschrijft. Staat uw model of de gewenste optie er niet bij, neem dan contact op.'],
      ['p', 'Stuur uw kenteken of chassisnummer en de gewenste optie via WhatsApp, e-mail of het contactformulier. CarTronic bekijkt wat er voor uw uitvoering mogelijk is.'],
    ], links: [['Vraag naar de mogelijkheden', '#/contact']] },
  { slug: 'optielijst-van-uw-auto', tag: 'Service', icon: 'file', title: 'Welke opties heeft uw auto al?', keywords: ['optielijst', 'chassisnummer', 'vin', 'fabrieksopties', 'pdf'],
    short: 'CarTronic levert een overzicht van de fabrieksopties van uw auto, op basis van het chassisnummer.',
    body: [
      ['p', 'Twijfelt u welke systemen al in uw auto zitten? CarTronic levert een optielijst van uw Audi, Volkswagen, SEAT of Škoda: een overzicht van de fabrieksopties op basis van het chassisnummer, als PDF of Word-bestand.'],
      ['p', 'Volgens CarTronic is dit mogelijk voor bouwjaren 1990 tot en met 2025. De prijs is € 10,00.'],
    ], links: [['Vraag een optielijst aan', '#/contact?onderwerp=optielijst']] },
];
const ARTICLE = byKey(ARTICLES, 'slug');

/* ---------- Search synonyms ---------- */
const SYNONYMS = [
  ['camera', 'achteruitrijcamera', 'parkeercamera', 'rear view', 'high camera'],
  ['carplay', 'apple carplay', 'android auto', 'app connect', 'smartphone interface', 'smartphone integratie', 'smartphone'],
  ['acc', 'adaptive cruise control', 'adaptieve cruise control', 'adaptieve cruisecontrol'],
  ['cruise control', 'cruisecontrol', 'snelheidsregelaar'],
  ['virtual cockpit', 'digitale cockpit', 'active info display', 'digitaal instrumentenpaneel', 'digitaal dashboard', 'aid'],
  ['park assist', 'parkeersensoren', 'parkeerhulp', 'pdc', 'parkeersensor', 'parking sensors', 'parkeren'],
  ['trekhaak', 'towbar', 'trekhaken', 'wegklapbare trekhaak', 'afneembare trekhaak'],
  ['inklapbare spiegels', 'inklapspiegels', 'spiegels', 'buitenspiegels'],
  ['dode hoek', 'dodehoekassistent', 'side assist', 'blind spot', 'dodehoek'],
  ['navigatie', 'navi', 'discover pro', 'discover media', 'mmi navigatie', 'mmi navigatie plus', 'gps'],
  ['alarm', 'beveiliging', 'scm', 'diefstalbeveiliging'],
  ['kalibratie', 'kalibreren', 'uitlijnen', 'afstellen'],
  ['coderen', 'programmeren', 'activeren', 'software'],
  ['diagnose', 'storing', 'foutcode', 'uitlezen'],
  ['achterklep', 'kofferklep', 'elektrische achterklep'],
  ['360 camera', '360 graden camera', 'area view', 'top view', 'rondomzicht'],
  ['keyless', 'keyless entry', 'comfortsleutel', 'sleutelloos'],
  ['homelink', 'garagedeuropener', 'garagedeur'],
  ['230v', '230 volt', '230 volt aansluiting', 'stopcontact'],
  ['lane assist', 'active lane assist', 'rijstrookassistent'],
  ['wegrijassistent', 'auto hold'],
  ['rijprofielen', 'rijprofiel', 'rijprofielkeuze', 'driving profile'],
  ['binnenspiegel', 'dimmende binnenspiegel', 'automatisch dimmende binnenspiegel'],
  ['koplampen', 'led koplampen', 'xenon', 'xenonkoplampen'],
  ['achterlichten', 'led achterlichten', 'dynamisch knipperlicht'],
];

/* =====================================================================
   WEBSHOP SEED — DEMO DATA
   These products and prices are TEST/DEMO data for the prototype. They are not
   CarTronic products or prices and are not taken from cartronic.nl.
   Money is stored in integer cents.
   ===================================================================== */
const PRODUCT_TYPES = { PHYSICAL_PRODUCT: 'Product', SERVICE: 'Dienst', RETROFIT_PACKAGE: 'Retrofit-pakket' };
const DEFAULT_SHOP_CATEGORIES = [
  { id: 'scat_camera', name: 'Camera & parkeren', slug: 'camera-parkeren', order: 1 },
  { id: 'scat_info', name: 'Infotainment & connectiviteit', slug: 'infotainment-connectiviteit', order: 2 },
  { id: 'scat_oem', name: 'OEM-onderdelen', slug: 'oem-onderdelen', order: 3 },
  { id: 'scat_comfort', name: 'Comfort', slug: 'comfort', order: 4 },
  { id: 'scat_light', name: 'Verlichting', slug: 'verlichting', order: 5 },
  { id: 'scat_sets', name: 'Retrofit-sets', slug: 'retrofit-sets', order: 6 },
];
function seedProducts() {
  const t = Date.now();
  const iso = (d) => new Date(t - d * 86400000).toISOString();
  const future = (d) => new Date(t + d * 86400000).toISOString().slice(0, 10);
  const base = {
    discountType: 'none', salePrice: null, discountValue: null, startDate: '', endDate: '',
    trackStock: true, active: true, featured: false, archived: false, isDemo: true,
    type: 'PHYSICAL_PRODUCT', installationIncluded: false,
  };
  return [
    { ...base, id: 'prd_cam_set', name: 'Achteruitrijcamera retrofit-set', slug: 'achteruitrijcamera-retrofit-set', sku: 'DEMO-CAM-001',
      shortDescription: 'Complete set met camera, bekabeling en montagedelen voor montage achteraf.',
      description: 'Retrofit-set voor het achteraf toevoegen van een achteruitrijcamera. De set bevat de camera, de bekabeling en de montagedelen. Het camerabeeld verschijnt op het bestaande multimediascherm, mits het systeem dit ondersteunt.\n\nInbouw en programmeren zijn niet inbegrepen. CarTronic controleert vooraf of uw auto geschikt is.',
      regularPrice: 29900, discountType: 'sale', salePrice: 24900, category: 'scat_sets', brand: 'volkswagen', model: 'golf-7',
      compatibility: { brands: ['volkswagen'], models: ['golf-7', 'golf-8'], note: 'Bedoeld voor Volkswagen Golf 7 en Golf 8 met een geschikt multimediasysteem.' },
      images: ['art:camera:0', 'art:camera:1', 'art:camera:2'], stock: 6, featured: true, createdAt: iso(40), updatedAt: iso(3) },
    { ...base, id: 'prd_carplay', name: 'Smartphone-integratiemodule (CarPlay / Android Auto)', slug: 'smartphone-integratiemodule', sku: 'DEMO-INF-002',
      shortDescription: 'Module voor Apple CarPlay en Android Auto op een geschikt origineel multimediasysteem.',
      description: 'Module waarmee Apple CarPlay en Android Auto beschikbaar worden op een geschikt origineel multimediasysteem. Bediening via het originele scherm.\n\nOf uw multimediasysteem geschikt is, hangt af van model, bouwjaar en uitvoering. Inbouw is niet inbegrepen.',
      regularPrice: 19900, category: 'scat_info', brand: '', model: '',
      compatibility: { brands: ['volkswagen', 'audi', 'seat', 'skoda'], models: [], note: 'Volkswagen, Audi, SEAT en Škoda met een geschikt multimediasysteem.' },
      images: ['art:connect:0', 'art:connect:1'], stock: 12, featured: true, createdAt: iso(32), updatedAt: iso(10) },
    { ...base, id: 'prd_pdc_set', name: 'Parkeersensor retrofit-set', slug: 'parkeersensor-retrofit-set', sku: 'DEMO-PDC-003',
      shortDescription: 'Set met ultrasone parkeersensoren en kabelboom voor montage achteraf.',
      description: 'Set met ultrasone parkeersensoren, kabelboom en bevestigingsmateriaal voor het achteraf toevoegen van parkeerhulp.\n\nGeschiktheid hangt af van bumper, uitvoering en aanwezige systemen. Inbouw en programmeren zijn niet inbegrepen.',
      regularPrice: 17900, discountType: 'percent', discountValue: 10, category: 'scat_camera', brand: '', model: '',
      compatibility: { brands: ['volkswagen', 'audi', 'seat', 'skoda'], models: [], note: 'Afhankelijk van bumper en uitvoering.' },
      images: ['art:sensor:0', 'art:sensor:1', 'art:sensor:2'], stock: 8, featured: true, createdAt: iso(25), updatedAt: iso(2) },
    { ...base, id: 'prd_usb', name: 'USB-connectiviteitsmodule', slug: 'usb-connectiviteitsmodule', sku: 'DEMO-USB-004',
      shortDescription: 'USB-aansluiting voor het laden en verbinden van uw smartphone.',
      description: 'USB-module voor het verbinden en laden van een smartphone via het originele systeem.\n\nInbouw is niet inbegrepen.',
      regularPrice: 7900, discountType: 'percent', discountValue: 15, startDate: future(7), endDate: future(21), category: 'scat_info', brand: '', model: '',
      compatibility: { brands: ['volkswagen', 'seat', 'skoda'], models: [], note: 'Controle vereist.' },
      images: ['art:usb:0', 'art:usb:1'], stock: 3, createdAt: iso(18), updatedAt: iso(1) },
    { ...base, id: 'prd_cam_module', name: 'Cameramodule (component)', slug: 'cameramodule-component', sku: 'DEMO-OEM-005',
      shortDescription: 'Losse cameramodule als vervangend onderdeel.',
      description: 'Losse cameramodule, bedoeld als vervangend onderdeel.\n\nControleer vooraf het onderdeelnummer of laat CarTronic de juiste uitvoering bepalen.',
      regularPrice: 12900, category: 'scat_oem', brand: 'seat', model: 'ibiza-kj',
      compatibility: { brands: ['seat'], models: ['ibiza-kj', 'leon-5f'], note: 'Onderdeelnummer controleren.' },
      images: ['art:module:0', 'art:camera:1'], stock: 0, createdAt: iso(14), updatedAt: iso(4) },
    { ...base, id: 'prd_mirror', name: 'Inklapmodule buitenspiegels', slug: 'inklapmodule-buitenspiegels', sku: 'DEMO-COM-006',
      shortDescription: 'Module voor het automatisch in- en uitklappen van de buitenspiegels.',
      description: 'Module voor het automatisch inklappen van de buitenspiegels bij het vergrendelen en uitklappen bij het starten.\n\nVereist elektrisch inklapbare spiegels. Inbouw is niet inbegrepen.',
      regularPrice: 8900, discountType: 'fixed', discountValue: 1500, category: 'scat_comfort', brand: 'seat', model: '',
      compatibility: { brands: ['seat', 'skoda'], models: ['ibiza-kj', 'leon-5f'], note: 'Vereist elektrisch inklapbare spiegels.' },
      images: ['art:mirror:0', 'art:mirror:1'], stock: 5, createdAt: iso(9), updatedAt: iso(9) },
    { ...base, id: 'prd_led_cable', name: 'Kabelset LED-achterlichten', slug: 'kabelset-led-achterlichten', sku: 'DEMO-LED-007',
      shortDescription: 'Kabelset voor het aansluiten van LED-achterlichten.',
      description: 'Kabelset voor het aansluiten van originele LED-achterlichten. (Inactief demoproduct: niet zichtbaar in de webshop.)',
      regularPrice: 18900, category: 'scat_light', brand: 'audi', model: 'a4-b9',
      compatibility: { brands: ['audi'], models: ['a4-b9'], note: '' },
      images: ['art:light:0'], stock: 4, active: false, createdAt: iso(6), updatedAt: iso(6) },
  ];
}
/* Demo orders refer to the demo products; orders whose products no longer exist are skipped. */
function seedOrders(products) {
  const P = byKey(products);
  const t = Date.now();
  const iso = (h) => new Date(t - h * 3600000).toISOString();
  const line = (id, qty, unitPrice) => {
    const p = P[id];
    if (!p || !Number.isInteger(p.regularPrice)) return null;
    return { productId: id, sku: p.sku, name: p.name, image: p.images[0], qty, unitRegular: p.regularPrice, unitPrice,
      discountLabel: unitPrice < p.regularPrice ? `−${Money.pct(p.regularPrice - unitPrice, p.regularPrice)}%` : '',
      lineRegular: p.regularPrice * qty, lineTotal: unitPrice * qty };
  };
  const make = (n, hoursAgo, customer, lines, delivery, paymentStatus, orderStatus) => {
    const items = lines.filter(Boolean);
    if (!items.length || items.length !== lines.length) return null;
    const subtotalRegular = items.reduce((s, l) => s + l.lineRegular, 0);
    const subtotal = items.reduce((s, l) => s + l.lineTotal, 0);
    const total = subtotal + delivery.price;
    const created = iso(hoursAgo);
    return {
      id: `ord_demo_${n}`, orderNumber: `CT-DEMO-${String(n).padStart(4, '0')}`, idempotencyKey: `seed_${n}`, isDemo: true,
      customer, delivery, vehicle: null, note: '', items,
      subtotalRegular, discountTotal: subtotalRegular - subtotal, subtotal, shipping: delivery.price, total,
      vat: { rate: 21, amount: Math.round((total * 21) / 121), included: true }, currency: 'EUR',
      paymentStatus, orderStatus, paymentId: `tr_demo_seed${n}`,
      payments: [{ id: `tr_demo_seed${n}`, status: paymentStatus, amount: total, createdAt: created, updatedAt: created }],
      history: [{ at: created, status: 'WACHT_OP_BETALING', note: 'Bestelling aangemaakt (demodata)' }]
        .concat(orderStatus !== 'WACHT_OP_BETALING' ? [{ at: created, status: orderStatus, note: 'Status bijgewerkt (demodata)' }] : []),
      stockApplied: true, createdAt: created, updatedAt: created,
    };
  };
  const pickup = { method: 'afhalen', label: 'Afhalen in Rijswijk', price: 0 };
  const ship = { method: 'verzenden', label: 'Verzenden (testtarief)', price: 695 };
  return [
    make(1, 190, { firstName: 'Mark', lastName: 'Jansen', email: 'mark.jansen@example.com', phone: '0612345678', address: null },
      [line('prd_carplay', 1, 19900)], pickup, 'paid', 'AFGEROND'),
    make(2, 30, { firstName: 'Lisa', lastName: 'de Vries', email: 'lisa.devries@example.com', phone: '0687654321', address: { street: 'Voorbeeldstraat', houseNumber: '12', postal: '2280 AB', city: 'Rijswijk' } },
      [line('prd_cam_set', 1, 24900), line('prd_usb', 2, 7900)], ship, 'paid', 'BETAALD'),
    make(3, 3, { firstName: 'Ahmed', lastName: 'Bakker', email: 'a.bakker@example.com', phone: '0611122233', address: null },
      [line('prd_pdc_set', 1, 16110)], pickup, 'open', 'WACHT_OP_BETALING'),
    make(4, 52, { firstName: 'Sanne', lastName: 'Visser', email: 'sanne.visser@example.com', phone: '0699988877', address: null },
      [line('prd_mirror', 1, 7400)], pickup, 'failed', 'BETALING_MISLUKT'),
  ].filter(Boolean);
}
const DEFAULT_SETTINGS = {
  shipping: [
    { id: 'afhalen', label: 'Afhalen in Rijswijk', description: 'Ophalen bij CarTronic, Patrijsweg 22', price: 0, enabled: true, requiresAddress: false },
    { id: 'verzenden', label: 'Verzenden (testtarief)', description: 'Testconfiguratie — geen vastgesteld CarTronic-tarief', price: 695, enabled: true, requiresAddress: true },
  ],
  vat: { rate: 21, pricesIncludeVat: true, showBreakdown: true },
  lowStockThreshold: 3,
  vehicleLookupMode: 'live', // 'live' = RDW Open Data (+ test plates), 'demo' = test plates only
  orderSeq: 0,
};
