/* =====================================================================
   ADMIN (DEMO)
   Functional business software. All mutations go through Repo; in production every
   mutation is an authenticated, authorised API call validated again on the server.
   ===================================================================== */
/* Sidebar: [key, label, icon, href]; a single-item entry is a group heading. */
const ADMIN_NAV = [
  ['dashboard', 'Dashboard', 'dashboard', '#/admin'],
  ['Website'],
  ['website', 'Publiceren', 'upload', '#/admin/website'],
  ['bedrijf', 'Bedrijfsgegevens', 'store', '#/admin/bedrijf'],
  ['teksten', 'Teksten', 'pencil', '#/admin/teksten'],
  ['weergave', 'Weergave', 'eye', '#/admin/weergave'],
  ['seo', 'SEO', 'search', '#/admin/seo'],
  ['Catalogus & inhoud'],
  ['opties', 'Opties', 'layers', '#/admin/opties'],
  ['catalogus', 'Categorieën & merken', 'grid', '#/admin/catalogus'],
  ['diensten', 'Diensten', 'wrench', '#/admin/diensten'],
  ['projecten', 'Projecten', 'camera', '#/admin/projecten'],
  ['meer-werk', 'Meer van ons werk', 'link', '#/admin/meer-werk'],
  ['kennis', 'Berichten & kennis', 'file', '#/admin/kennis'],
  ['beoordelingen', 'Beoordelingen', 'star', '#/admin/beoordelingen'],
  ['Webshop'],
  ['producten', 'Producten', 'box', '#/admin/producten'],
  ['categorieen', 'Shopcategorieën', 'folder', '#/admin/categorieen'],
  ['bestellingen', 'Bestellingen', 'receipt', '#/admin/bestellingen'],
  ['acties', 'Acties', 'percent', '#/admin/acties'],
  ['voorraad', 'Voorraad', 'box', '#/admin/voorraad'],
  ['instellingen', 'Instellingen', 'settings', '#/admin/instellingen'],
];
const lowStock = () => Repo.products().filter((p) => !p.archived && p.trackStock && p.stock <= Stock.threshold());
const productInOrders = (id) => Repo.orders().some((o) => o.items.some((l) => l.productId === id));
const productStatusPills = (p) => {
  if (p.archived) return '<span class="pill">Gearchiveerd</span>';
  const parts = [p.active ? '<span class="pill pill--ok">Actief</span>' : '<span class="pill">Inactief</span>'];
  if (p.featured) parts.push(`<span class="pill pill--dark">${icon('star')} Uitgelicht</span>`);
  const ps = Pricing.promoState(p);
  if (ps === 'active') parts.push('<span class="pill pill--red">In actie</span>');
  if (ps === 'scheduled') parts.push('<span class="pill pill--info">Actie gepland</span>');
  return parts.join(' ');
};

function adminShell(active, title, content, { actions = '' } = {}) {
  const toProcess = Repo.orders().filter((o) => o.orderStatus === 'BETAALD').length;
  const low = lowStock().length;
  const counts = { bestellingen: toProcess, voorraad: low, website: SiteStatus.changes().length };
  return `<div class="admin" data-admin>
    <aside class="admin-side" aria-label="Beheer">
      <div class="as-brand">${logoSvg({ light: true })}<span class="lbl">Beheer</span></div>
      <nav aria-label="Beheernavigatie"><ul class="admin-nav">
        ${ADMIN_NAV.map(([k, l, ic, h]) => (!l ? `<li class="an-group">${esc(k)}</li>` : `<li><a href="${h}"${k === active ? ' aria-current="page"' : ''}>${icon(ic)}<span>${l}</span>${counts[k] ? `<span class="an-count" aria-label="${counts[k]} aandachtspunten">${counts[k]}</span>` : ''}</a></li>`)).join('')}
      </ul></nav>
      <div class="as-foot"><strong style="color:#fff">Demo-omgeving.</strong> Gegevens staan alleen in deze browser. Deze login is géén beveiliging. <a href="#/admin/instellingen?section=architectuur">Architectuur</a></div>
    </aside>
    <div class="admin-scrim" data-admin-close></div>
    <div class="admin-main">
      <header class="admin-top">
        <button class="icon-btn admin-menu-btn" type="button" data-admin-menu aria-label="Menu" aria-expanded="false">${icon('menu')}</button>
        <h1>${title}</h1>
        <div class="at-right">${actions}<span class="hide-sm">${SiteStatus.topPill()}</span><span class="pill pill--warn hide-sm">Demo · lokaal</span><a class="btn btn--light btn--sm hide-sm" href="#/">${icon('external')} Website</a><button class="btn btn--ghost btn--sm" type="button" data-admin-logout aria-label="Uitloggen">${icon('logout')}<span class="hide-sm">Uitloggen</span></button></div>
      </header>
      <div class="admin-content"><div data-site-notice>${SiteStatus.parkedNotice()}</div>${content}</div>
    </div>
  </div>`;
}
function mountShell(root) {
  const admin = $('[data-admin]', root); if (!admin) return;
  const btn = $('[data-admin-menu]', admin);
  const set = (open) => { admin.classList.toggle('side-open', open); btn.setAttribute('aria-expanded', String(open)); };
  btn.addEventListener('click', () => set(!admin.classList.contains('side-open')));
  $('[data-admin-close]', admin).addEventListener('click', () => set(false));
  $$('.admin-nav a', admin).forEach((a) => a.addEventListener('click', () => set(false)));
  $('[data-admin-logout]', admin).addEventListener('click', () => { DemoAuth.logout(); Toast.show('U bent uitgelogd.'); Router.go('/admin'); });
}
/** Wraps an admin page with the demo auth gate. */
function adminPage(def) {
  return {
    id: `admin-${def.key}`, admin: true, mobileBar: false, nav: '',
    meta: { title: `Beheer — ${def.title}`, noindex: true },
    render(ctx) {
      if (!DemoAuth.isAuthed()) return loginHtml();
      return adminShell(def.key, typeof def.heading === 'function' ? def.heading(ctx) : (def.heading || def.title), def.render(ctx), { actions: def.actions ? def.actions(ctx) : '' });
    },
    mount(root, ctx) {
      if (!DemoAuth.isAuthed()) return mountLogin(root);
      mountShell(root);
      Behaviours.mount(root);
      return def.mount ? def.mount(root, ctx) : null;
    },
  };
}
function loginHtml() {
  return `<div class="login-wrap"><div class="login-card">
    <div class="lc-logo">${logoSvg()}</div>
    <h1>Beheer</h1>
    <div class="notice notice--warn mt-16">${icon('alert')}<div class="n-body"><strong>Demo-login, geen beveiliging.</strong> Deze controle gebeurt in de browser. Productie vereist server-side authenticatie.<br>Gebruikersnaam <span class="code">${DemoAuth.USER}</span> · wachtwoord <span class="code">${DemoAuth.PASS}</span></div></div>
    <form data-login novalidate>
      <div class="field"><label for="lg-u">Gebruikersnaam</label><input class="input" id="lg-u" name="u" autocomplete="username" required></div>
      <div class="field"><label for="lg-p">Wachtwoord</label><input class="input" id="lg-p" name="p" type="password" autocomplete="current-password" required></div>
      <span class="field-error" data-login-err role="alert"></span>
      <button class="btn btn--primary btn--block" type="submit">Inloggen</button>
      <button class="btn btn--light btn--block" type="button" data-fill>Demogegevens invullen</button>
    </form>
    <p class="mt-24 text-small"><a class="text-link" href="#/">← Terug naar de website</a></p>
  </div></div>`;
}
function mountLogin(root) {
  const f = $('[data-login]', root); if (!f) return;
  $('[data-fill]', f).addEventListener('click', () => { f.u.value = DemoAuth.USER; f.p.value = DemoAuth.PASS; f.querySelector('[type="submit"]').focus(); });
  f.addEventListener('submit', (e) => {
    e.preventDefault();
    if (DemoAuth.login(f.u.value, f.p.value)) {
      // This browser now edits the website: its drafts are kept until they are published or discarded.
      Storage.set('editor', true);
      Content.recheckVersion(); // another version may have been opened in this browser since this page loaded
      Toast.show('Ingelogd in de demo-beheeromgeving.'); Router.render({ force: true });
    }
    else { $('[data-login-err]', f).textContent = 'Onjuiste gebruikersnaam of wachtwoord.'; f.p.value = ''; f.p.focus(); }
  });
  f.u.focus();
}

/* ---------- Validation ---------- */
function validateProduct(p, list = Repo.products()) {
  const e = {};
  const L = Content.LIMITS;
  const txt = (v) => typeof v === 'string';
  if (typeof p.id !== 'string' || !p.id || p.id.length > 80) e.id = 'Dit product heeft geen geldige id.';
  if (!txt(p.name) || !p.name.trim()) e.name = 'Vul een productnaam in.';
  else if (p.name.length > 120) e.name = 'Gebruik maximaal 120 tekens.';
  if (!txt(p.slug) || !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(p.slug)) e.slug = 'Gebruik alleen kleine letters, cijfers en koppeltekens.';
  else if (!Content.isSlug(p.slug)) e.slug = 'Gebruik maximaal 120 tekens.';
  else if (list.some((x) => x.slug === p.slug && x.id !== p.id)) e.slug = 'Deze slug is al in gebruik.';
  if (!txt(p.sku) || !p.sku.trim()) e.sku = 'Vul een artikelnummer (SKU) in.';
  else if (!/^[A-Za-z0-9._-]{2,40}$/.test(p.sku)) e.sku = 'Gebruik 2–40 letters, cijfers, punten of koppeltekens.';
  else if (list.some((x) => typeof x.sku === 'string' && x.sku.toLowerCase() === p.sku.toLowerCase() && x.id !== p.id)) e.sku = 'Dit artikelnummer is al in gebruik.';
  if (!txt(p.shortDescription) || !p.shortDescription.trim()) e.shortDescription = 'Vul een korte omschrijving in.';
  else if (p.shortDescription.length > 200) e.shortDescription = 'Gebruik maximaal 200 tekens.';
  if (!txt(p.description)) e.description = 'Ongeldige omschrijving.';
  else if (p.description.length > L.productDescription) e.description = `Gebruik maximaal ${L.productDescription.toLocaleString('nl-NL')} tekens (nu ${p.description.length.toLocaleString('nl-NL')}).`;
  const c = p.compatibility;
  if (!c || typeof c !== 'object' || !Array.isArray(c.brands) || !Array.isArray(c.models) || !txt(c.note)
    || c.brands.some((b) => !BRAND[b]) || c.models.some((m) => !MODEL[m])) e.compatibility = 'Ongeldige compatibiliteit (merken, modellen of informatie).';
  else if (c.note.length > L.productNote) e.cnote = `Gebruik maximaal ${L.productNote} tekens (nu ${c.note.length}).`;
  if (p.brand && !BRAND[p.brand]) e.brand = 'Onbekend merk.';
  if (p.model && !MODEL[p.model]) e.model = 'Onbekend model.';
  ['active', 'featured', 'archived', 'trackStock', 'isDemo', 'installationIncluded'].forEach((k) => { if (typeof p[k] !== 'boolean') e[k] = 'Ongeldige waarde (ja/nee verwacht).'; });
  if (!isInt(p.regularPrice) || p.regularPrice < 1) e.regularPrice = 'Vul een geldige prijs in, bijvoorbeeld 249,00.';
  else if (p.regularPrice > 9999999) e.regularPrice = 'Deze prijs is te hoog.';
  if (p.discountType === 'sale') {
    if (!isInt(p.salePrice) || p.salePrice < 1) e.salePrice = 'Vul een geldige actieprijs in.';
    else if (isInt(p.regularPrice) && p.salePrice >= p.regularPrice) e.salePrice = 'De actieprijs moet lager zijn dan de normale prijs.';
  }
  if (p.discountType === 'percent' && (!isInt(p.discountValue) || p.discountValue < 1 || p.discountValue > 90)) e.discountValue = 'Kies een percentage tussen 1 en 90.';
  if (p.discountType === 'fixed') {
    if (!isInt(p.discountValue) || p.discountValue < 1) e.discountValue = 'Vul een geldig kortingsbedrag in.';
    else if (isInt(p.regularPrice) && p.discountValue >= p.regularPrice) e.discountValue = 'De korting moet lager zijn dan de normale prijs.';
  }
  if (!['none', 'sale', 'percent', 'fixed'].includes(p.discountType)) e.discountType = 'Ongeldig kortingstype.';
  if (p.startDate && !/^\d{4}-\d{2}-\d{2}$/.test(p.startDate)) e.startDate = 'Ongeldige datum.';
  if (p.endDate && !/^\d{4}-\d{2}-\d{2}$/.test(p.endDate)) e.endDate = 'Ongeldige datum.';
  if (p.startDate && p.endDate && p.endDate < p.startDate) e.endDate = 'De einddatum ligt vóór de startdatum.';
  if (p.trackStock && (!isInt(p.stock) || p.stock < 0 || p.stock > 99999)) e.stock = 'Vul een geldige voorraad in (0 of meer).';
  if (!Repo.shopCategory(p.category)) e.category = 'Kies een categorie.';
  if (!Array.isArray(p.images) || p.images.some((i) => !Content.isMediaRef(i))) e.images = 'Een afbeelding heeft een ongeldig adres.';
  else if (p.images.length > L.productImages) e.images = `Gebruik maximaal ${L.productImages} afbeeldingen.`;
  if (!Object.keys(PRODUCT_TYPES).includes(p.type)) e.type = 'Ongeldig producttype.';
  return e;
}
const ADMIN_FIELD_LABELS = { name: 'Productnaam', slug: 'Slug', sku: 'SKU', shortDescription: 'Korte omschrijving', description: 'Volledige omschrijving', regularPrice: 'Normale prijs', salePrice: 'Actieprijs', discountValue: 'Korting', startDate: 'Startdatum', endDate: 'Einddatum', stock: 'Voorraad', category: 'Categorie', images: 'Afbeeldingen', type: 'Soort', discountType: 'Kortingstype', compatibility: 'Compatibiliteit', cnote: 'Compatibiliteitsinformatie', brand: 'Merk', model: 'Model', id: 'Id', active: 'Actief', featured: 'Uitgelicht', archived: 'Gearchiveerd', trackStock: 'Voorraad bijhouden', isDemo: 'Demoproduct', installationIncluded: 'Inbouw inbegrepen' };
/** "Label: message" of the first problem (for messages outside the full product form). */
const firstProductError = (e) => { const k = Object.keys(e)[0]; return k ? `${ADMIN_FIELD_LABELS[k] || k}: ${e[k]}` : ''; };

/* Demo image handling. NOT a secure upload: production uploads go to protected storage with
   server-side validation of file type (magic bytes), size, safe file names and permissions.
   Re-encoding through a canvas here also strips metadata and any non-image payload. */
async function readImageFile(file, maxSide = 1400) {
  const ALLOWED = ['image/png', 'image/jpeg', 'image/webp'];
  if (!file || !ALLOWED.includes(file.type)) throw new Error('Kies een PNG-, JPG- of WebP-afbeelding.');
  if (file.size > 5 * 1024 * 1024) throw new Error('De afbeelding is groter dan 5 MB.');
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('De afbeelding kon niet worden gelezen.')); i.src = url; });
    const scale = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(img.naturalWidth * scale)); c.height = Math.max(1, Math.round(img.naturalHeight * scale));
    const ctx2 = c.getContext('2d'); ctx2.fillStyle = '#fff'; ctx2.fillRect(0, 0, c.width, c.height); ctx2.drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', 0.84);
  } finally { URL.revokeObjectURL(url); }
}
function downloadJson(name, data) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
}

/* ---------- Dashboard ---------- */
Pages.adminDashboard = adminPage({
  key: 'dashboard', title: 'Dashboard',
  actions: () => `<a class="btn btn--primary btn--sm" href="#/admin/producten/nieuw">${icon('plus')}<span class="hide-sm">Nieuw product</span></a>`,
  render() {
    const products = Repo.products().filter((p) => !p.archived);
    const orders = Repo.orders().slice().sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
    const active = products.filter((p) => p.active);
    const promos = products.filter((p) => Pricing.promoState(p) === 'active');
    const scheduled = products.filter((p) => Pricing.promoState(p) === 'scheduled');
    const low = lowStock();
    const toProcess = orders.filter((o) => o.orderStatus === 'BETAALD');
    const waiting = orders.filter((o) => o.orderStatus === 'WACHT_OP_BETALING');
    const paidTotal = orders.filter((o) => ['BETAALD', 'IN_BEHANDELING', 'AFGEROND'].includes(o.orderStatus)).reduce((s, o) => s + o.total, 0);
    const kpi = (label, value, sub, href, alert = false) => `<div class="kpi${alert ? ' kpi--alert' : ''}"><div class="k-label">${label}</div><div class="k-value">${value}</div><div class="k-sub">${sub}</div><a class="stretch" href="${href}" aria-label="${label}"></a></div>`;
    return `
      <div class="kpis">
        ${kpi('Actieve producten', active.length, `van ${products.length} niet-gearchiveerd`, '#/admin/producten')}
        ${kpi('Te verwerken', toProcess.length, 'betaalde bestellingen', '#/admin/bestellingen?status=BETAALD', toProcess.length > 0)}
        ${kpi('Wacht op betaling', waiting.length, 'bestellingen', '#/admin/bestellingen?status=WACHT_OP_BETALING')}
        ${kpi('Producten in actie', promos.length, scheduled.length ? `${scheduled.length} gepland` : 'geen geplande acties', '#/admin/acties')}
        ${kpi('Lage voorraad', low.length, `drempel ≤ ${Stock.threshold()}`, '#/admin/voorraad?f=laag', low.length > 0)}
      </div>
      ${websiteStatusPanel()}
      <p class="hint">Alle cijfers zijn afgeleid van de (demo)gegevens in deze browser. Totaal betaald: <strong class="tabular">${Money.fmt(paidTotal)}</strong>.</p>
      <div class="dash-grid">
        <section class="panel"><div class="panel-head"><div><h2>Recente bestellingen</h2><p>De vijf meest recente bestellingen</p></div><a class="btn btn--light btn--sm" href="#/admin/bestellingen">Alle bestellingen</a></div>
          <div class="panel-body panel-body--flush">${orders.length ? `<div class="table-wrap rtable"><table class="table admin-table"><thead><tr><th>Bestelling</th><th>Klant</th><th class="num">Totaal</th><th>Status</th></tr></thead><tbody>
            ${orders.slice(0, 5).map((o) => `<tr class="clickable" data-href="#/admin/bestellingen/${o.id}"><td class="cell-main" data-label="Bestelling"><a class="text-link" href="#/admin/bestellingen/${o.id}"><strong>${esc(o.orderNumber)}</strong></a><div class="text-small text-muted">${fmtDateTime(o.createdAt)}</div></td><td data-label="Klant">${esc(`${o.customer.firstName} ${o.customer.lastName}`)}</td><td class="num" data-label="Totaal">${Money.fmt(o.total)}</td><td data-label="Status">${orderBadge(o.orderStatus)}</td></tr>`).join('')}
          </tbody></table></div>` : `<div class="panel-body">${UI.empty({ icon: 'receipt', title: 'Nog geen bestellingen' })}</div>`}</div></section>
        <div class="form-col">
          <section class="panel"><div class="panel-head"><div><h2>Voorraad</h2><p>Producten op of onder de drempel</p></div><a class="btn btn--light btn--sm" href="#/admin/voorraad">Beheren</a></div>
            <div class="panel-body" style="display:grid;gap:12px">${low.length ? low.map((p) => `<div class="flex justify-between items-center gap-12"><a class="text-link" href="#/admin/producten/${p.id}" style="font-size:14px;font-weight:550">${esc(p.name)}</a>${Stock.html(p)}</div>`).join('') : '<p class="text-muted text-small">Geen producten met lage voorraad.</p>'}</div></section>
          <section class="panel"><div class="panel-head"><div><h2>Acties</h2><p>Lopend en gepland</p></div><a class="btn btn--light btn--sm" href="#/admin/acties">Beheren</a></div>
            <div class="panel-body" style="display:grid;gap:12px">${promos.concat(scheduled).length ? promos.concat(scheduled).map((p) => `<div class="flex justify-between items-center gap-12"><span style="font-size:14px;font-weight:550">${esc(p.name)}</span><span class="pill ${Pricing.promoState(p) === 'active' ? 'pill--red' : 'pill--info'}">${esc(Pricing.describe(p))}</span></div>`).join('') : '<p class="text-muted text-small">Geen lopende acties.</p>'}</div></section>
        </div>
      </div>`;
  },
  mount(root) { root.addEventListener('click', (e) => { const tr = e.target.closest('tr[data-href]'); if (tr && !e.target.closest('a,button')) Router.go(tr.dataset.href); }); },
});

/* ---------- Products list ---------- */
Pages.adminProducts = adminPage({
  key: 'producten', title: 'Producten',
  actions: () => `<a class="btn btn--primary btn--sm" href="#/admin/producten/nieuw">${icon('plus')}<span class="hide-sm">Nieuw product</span></a>`,
  render(ctx) {
    const f = ctx.query.f || 'alle';
    return `<div class="toolbar">
        <div class="input-icon">${icon('search')}<input class="input input--sm" type="search" data-q placeholder="Zoek op naam of SKU" aria-label="Zoek producten" value="${attr(ctx.query.q || '')}"></div>
        <label class="sr-only" for="ap-f">Status</label>
        <select class="select select--sm" id="ap-f" data-f style="width:auto">${[['alle', 'Alle producten'], ['actief', 'Actief'], ['inactief', 'Inactief'], ['actie', 'In actie'], ['uitgelicht', 'Uitgelicht'], ['uitverkocht', 'Uitverkocht'], ['archief', 'Gearchiveerd']].map(([k, l]) => `<option value="${k}"${f === k ? ' selected' : ''}>${l}</option>`).join('')}</select>
        <label class="sr-only" for="ap-c">Categorie</label>
        <select class="select select--sm" id="ap-c" data-c style="width:auto"><option value="">Alle categorieën</option>${Repo.shopCategories().map((c) => `<option value="${c.id}"${ctx.query.c === c.id ? ' selected' : ''}>${esc(c.name)}</option>`).join('')}</select>
      </div>
      <section class="panel"><div class="panel-body panel-body--flush" data-list></div></section>
      <p class="hint">Tip: gebruik <strong>Snel bewerken</strong> om prijs, korting, voorraad en status aan te passen — ook handig op uw telefoon.</p>`;
  },
  mount(root, ctx) {
    const st = { q: ctx.query.q || '', f: ctx.query.f || 'alle', c: ctx.query.c || '', open: null };
    const list = $('[data-list]', root);
    const filtered = () => Repo.products().filter((p) => {
      if (st.f === 'archief' ? !p.archived : (p.archived && st.f !== 'alle')) return false;
      if (st.f === 'actief' && !p.active) return false;
      if (st.f === 'inactief' && p.active) return false;
      if (st.f === 'actie' && Pricing.promoState(p) !== 'active') return false;
      if (st.f === 'uitgelicht' && !p.featured) return false;
      if (st.f === 'uitverkocht' && !(p.trackStock && p.stock <= 0)) return false;
      if (st.c && p.category !== st.c) return false;
      if (st.q && !normText(`${p.name} ${p.sku}`).includes(normText(st.q))) return false;
      return true;
    }).sort((a, b) => (a.archived - b.archived) || a.name.localeCompare(b.name, 'nl'));
    const qeHtml = (p) => {
      const raw = { regular: Money.toInput(p.regularPrice), value: p.discountType === 'sale' ? Money.toInput(p.salePrice) : (p.discountType === 'fixed' ? Money.toInput(p.discountValue) : (p.discountType === 'percent' ? String(p.discountValue) : '')) };
      return `<tr class="qe-row"><td colspan="6"><form class="quick-edit" data-qe="${p.id}" novalidate>
        <div class="field"><label for="qe-r-${p.id}">Normale prijs (€)</label><input class="input input--sm" id="qe-r-${p.id}" name="regular" inputmode="decimal" value="${attr(raw.regular)}"><span class="field-error" data-e="regularPrice"></span></div>
        <div class="field"><label for="qe-t-${p.id}">Korting</label><select class="select select--sm" id="qe-t-${p.id}" name="type">${[['none', 'Geen korting'], ['sale', 'Actieprijs (€)'], ['percent', 'Percentage (%)'], ['fixed', 'Vast bedrag (€)']].map(([k, l]) => `<option value="${k}"${p.discountType === k ? ' selected' : ''}>${l}</option>`).join('')}</select></div>
        <div class="field"><label for="qe-v-${p.id}">Waarde</label><input class="input input--sm" id="qe-v-${p.id}" name="value" inputmode="decimal" value="${attr(raw.value)}"${p.discountType === 'none' ? ' disabled' : ''}><span class="field-error" data-e="discount"></span></div>
        <div class="field"><label for="qe-s-${p.id}">Voorraad</label><input class="input input--sm" id="qe-s-${p.id}" name="stock" type="number" min="0" inputmode="numeric" value="${p.stock}"${p.trackStock ? '' : ' disabled'}><span class="field-error" data-e="stock"></span></div>
        <div class="qe-actions">
          <div class="qe-switches">
            <label class="switch"><input type="checkbox" name="active"${p.active ? ' checked' : ''}${p.archived ? ' disabled' : ''}><span class="track"></span>Actief</label>
            <label class="switch"><input type="checkbox" name="featured"${p.featured ? ' checked' : ''}><span class="track"></span>Uitgelicht</label>
            <label class="switch"><input type="checkbox" name="track"${p.trackStock ? ' checked' : ''}><span class="track"></span>Voorraad bijhouden</label>
          </div>
          <div class="flex gap-8 items-center"><span class="text-small text-muted" data-preview></span><button class="btn btn--light btn--sm" type="button" data-qe-cancel>Annuleren</button><button class="btn btn--primary btn--sm" type="submit">Opslaan</button></div>
        </div>
      </form></td></tr>`;
    };
    const draw = () => {
      const items = filtered();
      if (!items.length) { list.innerHTML = `<div class="panel-body">${UI.empty({ icon: 'box', title: 'Geen producten gevonden', text: 'Pas de filters aan of voeg een nieuw product toe.', actions: '<a class="btn btn--primary btn--sm" href="#/admin/producten/nieuw">Nieuw product</a>' })}</div>`; return; }
      list.innerHTML = `<div class="table-wrap rtable"><table class="table admin-table"><thead><tr><th>Product</th><th>Categorie</th><th class="num">Prijs</th><th class="num">Voorraad</th><th>Status</th><th class="num"><span class="sr-only">Acties</span></th></tr></thead><tbody>
        ${items.map((p) => {
          const pr = Pricing.calc(p);
          const inOrders = productInOrders(p.id);
          return `<tr class="${p.archived ? 'is-archived' : ''}">
            <td class="cell-main" data-label="Product"><div class="prod"><div class="thumb">${Media.html(p.images[0], '', { kind: productArtKind(p) })}</div><div><a class="p-name text-link" href="#/admin/producten/${p.id}">${esc(p.name)}</a><div class="p-sub">${esc(p.sku)}${p.isDemo ? ' · demo' : ''}</div></div></div></td>
            <td data-label="Categorie">${esc((Repo.shopCategory(p.category) || {}).name || '—')}</td>
            <td class="num" data-label="Prijs">${pr.onSale ? `<div class="text-muted" style="text-decoration:line-through;font-size:12.5px">${Money.fmt(pr.regular)}</div><strong style="color:var(--red)">${Money.fmt(pr.price)}</strong>` : Money.fmt(pr.regular)}</td>
            <td class="num" data-label="Voorraad">${p.trackStock ? `<span class="${p.stock <= 0 ? 'stock stock--out' : (p.stock <= Stock.threshold() ? 'stock stock--low' : '')}">${p.stock}</span>` : '<span class="text-muted">—</span>'}</td>
            <td data-label="Status">${productStatusPills(p)}</td>
            <td class="num cell-actions"><div class="row-actions">
              ${p.archived ? '' : `<button class="btn btn--light btn--xs" type="button" data-qe-open="${p.id}" aria-expanded="${st.open === p.id}">Snel bewerken</button>`}
              <a class="icon-btn icon-btn--sm" href="#/admin/producten/${p.id}" title="Bewerken" aria-label="Bewerken: ${attr(p.name)}">${icon('pencil')}</a>
              ${p.archived ? `<button class="icon-btn icon-btn--sm" type="button" data-restore="${p.id}" title="Herstellen" aria-label="Herstellen: ${attr(p.name)}">${icon('refresh')}</button>` : `<button class="icon-btn icon-btn--sm" type="button" data-archive="${p.id}" title="Archiveren" aria-label="Archiveren: ${attr(p.name)}">${icon('archive')}</button>`}
              <button class="icon-btn icon-btn--sm" type="button" data-delete="${p.id}"${inOrders ? ' disabled aria-disabled="true"' : ''} title="${inOrders ? 'Komt voor in bestellingen — archiveer in plaats van verwijderen' : 'Verwijderen'}" aria-label="Verwijderen: ${attr(p.name)}">${icon('trash')}</button>
            </div></td></tr>${st.open === p.id ? qeHtml(p) : ''}`;
        }).join('')}</tbody></table></div>`;
      const form = st.open && $(`[data-qe="${st.open}"]`, list);
      if (form) bindQuickEdit(form);
    };
    const bindQuickEdit = (form) => {
      const id = form.dataset.qe;
      const read = () => {
        const p = withProductDefaults(deepClone(Repo.product(id)));
        p.regularPrice = Money.parse(form.regular.value);
        p.discountType = form.type.value;
        const val = form.value.value.trim();
        p.salePrice = null; p.discountValue = null;
        if (p.discountType === 'sale') p.salePrice = Money.parse(val);
        if (p.discountType === 'fixed') p.discountValue = Money.parse(val);
        if (p.discountType === 'percent') p.discountValue = /^\d{1,2}$/.test(val) ? parseInt(val, 10) : NaN;
        if (p.discountType === 'none') { p.startDate = ''; p.endDate = ''; }
        p.trackStock = form.track.checked;
        p.stock = form.stock.value === '' ? NaN : Number(form.stock.value);
        if (!p.trackStock && !Number.isFinite(p.stock)) p.stock = 0;
        p.active = form.active.checked; p.featured = form.featured.checked;
        return p;
      };
      const preview = () => {
        const p = read(); const e = validateProduct(p);
        $('[data-e="regularPrice"]', form).textContent = e.regularPrice || '';
        $('[data-e="discount"]', form).textContent = e.salePrice || e.discountValue || '';
        $('[data-e="stock"]', form).textContent = e.stock || '';
        form.regular.setAttribute('aria-invalid', String(!!e.regularPrice));
        form.value.setAttribute('aria-invalid', String(!!(e.salePrice || e.discountValue)));
        const pv = $('[data-preview]', form);
        if (!Object.keys(e).length) { const c = Pricing.calc(p); pv.innerHTML = `Klantprijs: <strong>${Money.fmt(c.price)}</strong>${c.onSale ? ` (−${c.pct}%)` : ''}${Pricing.promoState(p) === 'scheduled' ? ' · actie gepland' : ''}`; } else pv.textContent = '';
        return e;
      };
      form.type.addEventListener('change', () => { form.value.disabled = form.type.value === 'none'; if (form.type.value === 'none') form.value.value = ''; form.value.placeholder = form.type.value === 'percent' ? 'bijv. 10' : 'bijv. 249,00'; preview(); });
      form.track.addEventListener('change', () => { form.stock.disabled = !form.track.checked; preview(); });
      form.addEventListener('input', preview);
      $('[data-qe-cancel]', form).addEventListener('click', () => { st.open = null; draw(); });
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const errs = preview();
        if (Object.keys(errs).length) { Toast.show(['regularPrice', 'salePrice', 'discountValue', 'stock'].some((k) => errs[k]) ? 'Controleer de invoer.' : `${firstProductError(errs)} Pas dit aan in het productformulier.`, { error: true }); return; }
        Repo.saveProduct(read());
        st.open = null; draw();
        Toast.show('Product bijgewerkt.');
      });
      preview();
      form.regular.focus();
    };
    root.addEventListener('click', async (e) => {
      const o = e.target.closest('[data-qe-open]');
      if (o) { st.open = st.open === o.dataset.qeOpen ? null : o.dataset.qeOpen; draw(); return; }
      const a = e.target.closest('[data-archive]');
      if (a) {
        const p = Repo.product(a.dataset.archive);
        if (await Overlay.confirm({ title: 'Product archiveren?', message: `“${esc(p.name)}” verdwijnt uit de webshop. Bestellingen behouden hun gegevens. U kunt het product later herstellen.`, confirmLabel: 'Archiveren' })) {
          Repo.saveProduct({ ...p, archived: true, active: false, featured: false }); draw(); Toast.show('Product gearchiveerd.');
        }
        return;
      }
      const r = e.target.closest('[data-restore]');
      if (r) { const p = Repo.product(r.dataset.restore); Repo.saveProduct({ ...p, archived: false }); draw(); Toast.show('Product hersteld (inactief). Activeer het om het te tonen.'); return; }
      const d = e.target.closest('[data-delete]');
      if (d) {
        const p = Repo.product(d.dataset.delete);
        if (productInOrders(p.id)) { Toast.show('Dit product komt voor in bestellingen. Archiveer het in plaats van verwijderen.', { error: true }); return; }
        if (await Overlay.confirm({ title: 'Product definitief verwijderen?', message: `“${esc(p.name)}” wordt permanent verwijderd. Dit kan niet ongedaan worden gemaakt.`, confirmLabel: 'Verwijderen', danger: true })) {
          Repo.deleteProduct(p.id); draw(); Toast.show('Product verwijderd.');
        }
      }
    });
    const syncQ = () => Router.setQuery({ q: st.q, f: st.f !== 'alle' ? st.f : '', c: st.c });
    $('[data-q]', root).addEventListener('input', debounce((e) => { st.q = e.target.value.trim(); syncQ(); draw(); }, 200));
    $('[data-f]', root).addEventListener('change', (e) => { st.f = e.target.value; syncQ(); draw(); });
    $('[data-c]', root).addEventListener('change', (e) => { st.c = e.target.value; syncQ(); draw(); });
    draw();
  },
});

/* ---------- Product form (new / edit) ---------- */
function blankProduct() {
  return {
    id: uid('prd'), name: '', slug: '', sku: '', shortDescription: '', description: '',
    regularPrice: NaN, discountType: 'none', salePrice: null, discountValue: null, startDate: '', endDate: '',
    category: (Repo.shopCategories()[0] || {}).id || '', brand: '', model: '',
    compatibility: { brands: [], models: [], note: '' }, images: [], stock: 0, trackStock: true,
    active: false, featured: false, archived: false, isDemo: true, type: 'PHYSICAL_PRODUCT', installationIncluded: false,
    createdAt: null, updatedAt: null,
  };
}
/** Products saved by an older version may miss a field: fill in the defaults a publication would use
    (nothing is shortened), so the forms can always show and save them. */
function withProductDefaults(p) {
  const q = { ...p };
  const DEF = { active: true, featured: false, archived: false, trackStock: true, isDemo: false, installationIncluded: false };
  Object.keys(DEF).forEach((k) => { if (typeof q[k] !== 'boolean') q[k] = DEF[k]; });
  const c = q.compatibility && typeof q.compatibility === 'object' && !Array.isArray(q.compatibility) ? q.compatibility : {};
  q.compatibility = {
    brands: Array.isArray(c.brands) ? c.brands.filter((b) => typeof b === 'string' && BRAND[b]) : [],
    models: Array.isArray(c.models) ? c.models.filter((m) => typeof m === 'string' && MODEL[m]) : [],
    note: typeof c.note === 'string' ? c.note : '',
  };
  if (!Array.isArray(q.images)) q.images = [];
  ['sku', 'shortDescription', 'description', 'brand', 'model', 'startDate', 'endDate'].forEach((k) => { if (typeof q[k] !== 'string') q[k] = ''; });
  return q;
}
Pages.adminProductForm = adminPage({
  key: 'producten', title: 'Product',
  heading: (ctx) => (ctx.params.id ? 'Product bewerken' : 'Nieuw product'),
  render(ctx) {
    const isNew = !ctx.params.id;
    const p = isNew ? blankProduct() : Repo.product(ctx.params.id);
    if (!p) return UI.empty({ icon: 'box', title: 'Product niet gevonden', actions: '<a class="btn btn--dark btn--sm" href="#/admin/producten">Terug naar producten</a>' });
    return `<p><a class="link link--ink" href="#/admin/producten">${icon('arrowLeft')} Alle producten</a></p><div data-form-host></div>`;
  },
  mount(root, ctx) {
    const isNew = !ctx.params.id;
    const original = isNew ? blankProduct() : Repo.product(ctx.params.id);
    if (!original) return null;
    const p = withProductDefaults(deepClone(original));
    if (!Number.isFinite(p.regularPrice)) p.regularPrice = NaN;
    const raw = {
      regularPrice: Number.isFinite(p.regularPrice) ? Money.toInput(p.regularPrice) : '',
      salePrice: p.discountType === 'sale' ? Money.toInput(p.salePrice) : '',
      percent: p.discountType === 'percent' ? String(p.discountValue) : '',
      fixed: p.discountType === 'fixed' ? Money.toInput(p.discountValue) : '',
      stock: String(p.stock ?? 0),
    };
    let slugTouched = !isNew;
    let errors = {}; let dirty = false; let showErrors = false;
    const host = $('[data-form-host]', root);
    Router.setGuard(() => (dirty ? 'U heeft wijzigingen die nog niet zijn opgeslagen.' : null));
    const err = (k) => (showErrors && errors[k] ? `<span class="field-error" id="pf-${k}-e">${esc(errors[k])}</span>` : `<span class="field-error" id="pf-${k}-e"></span>`);
    const inv = (k) => (showErrors && errors[k] ? ' aria-invalid="true"' : '');
    const draw = () => {
      const promo = Pricing.promoState(p);
      const valid = !Object.keys(validateProduct(p)).length;
      host.innerHTML = `
        ${showErrors && Object.keys(errors).length ? `<div class="error-summary" role="alert" tabindex="-1" data-errsum><strong>Het product kan nog niet worden opgeslagen:</strong><ul>${Object.entries(errors).map(([k, m]) => `<li><a href="#pf-${k}" data-focus="pf-${k}">${ADMIN_FIELD_LABELS[k] || k}: ${esc(m)}</a></li>`).join('')}</ul></div>` : ''}
        <form class="form-layout" data-pform novalidate>
          <div class="form-col">
            <section class="panel"><div class="panel-head"><h2>Basisgegevens</h2>${p.isDemo ? '<span class="demo-flag">Demo</span>' : '<span class="pill pill--ok">Echt product</span>'}</div><div class="panel-body"><div class="form-grid">
              <div class="field span-2"><label for="pf-name">Productnaam</label><input class="input" id="pf-name" data-k="name" value="${attr(p.name)}" maxlength="120"${inv('name')}>${err('name')}</div>
              <div class="field"><label for="pf-slug">Slug</label><div class="input-affix"><span class="affix">/webshop/</span><input class="input" id="pf-slug" data-k="slug" value="${attr(p.slug)}"${inv('slug')}></div>${err('slug')}</div>
              <div class="field"><label for="pf-sku">SKU</label><input class="input" id="pf-sku" data-k="sku" value="${attr(p.sku)}"${inv('sku')}>${err('sku')}</div>
              <div class="field span-2"><label for="pf-shortDescription">Korte omschrijving</label><input class="input" id="pf-shortDescription" data-k="shortDescription" value="${attr(p.shortDescription)}" maxlength="200"${inv('shortDescription')}>${err('shortDescription')}</div>
              <div class="field span-2"><label for="pf-description">Volledige omschrijving</label><textarea class="textarea" id="pf-description" data-k="description" style="min-height:160px"${inv('description')}>${esc(p.description)}</textarea><span class="hint">Lege regel = nieuwe alinea. Vermeld of inbouw inbegrepen is. Maximaal ${Content.LIMITS.productDescription.toLocaleString('nl-NL')} tekens.</span>${err('description')}</div>
            </div></div></section>

            <section class="panel"><div class="panel-head"><div><h2>Afbeeldingen</h2><p>De eerste afbeelding is de hoofdafbeelding.</p></div></div><div class="panel-body">
              ${p.images.length ? `<div class="image-list">${p.images.map((src, i) => `<div class="image-item"><div class="ii-media">${Media.html(src, '', { kind: productArtKind(p) })}</div>${i === 0 ? '<span class="pill pill--dark ii-primary">Hoofd</span>' : ''}
                <div class="ii-actions">${i > 0 ? `<button class="btn btn--ghost btn--xs" type="button" data-img-primary="${i}">Maak hoofd</button>` : '<span></span>'}<button class="icon-btn icon-btn--sm" type="button" data-img-remove="${i}" aria-label="Verwijder afbeelding ${i + 1}">${icon('trash')}</button></div></div>`).join('')}</div>`
                : '<p class="text-muted text-small">Nog geen afbeeldingen. Zonder afbeelding toont de webshop een illustratie.</p>'}
              ${err('images')}
              <div class="form-grid mt-24">
                <div class="field span-2"><label for="pf-imgurl">Afbeelding-URL</label><div class="input-affix"><input class="input" id="pf-imgurl" data-img-url placeholder="https://…" style="border-radius:var(--radius) 0 0 var(--radius)"><button class="btn btn--dark" type="button" data-img-add style="border-radius:0 var(--radius) var(--radius) 0">Toevoegen</button></div></div>
                <div class="field"><label for="pf-imgfile">Uploaden <span class="opt">(PNG, JPG, WebP · max 5 MB)</span></label><input class="input" id="pf-imgfile" type="file" accept="image/png,image/jpeg,image/webp" data-img-file style="padding-top:12px"></div>
                <div class="field"><label for="pf-imgart">Illustratie toevoegen</label><select class="select" id="pf-imgart" data-img-art><option value="">Kies…</option>${Object.keys(ART_SHAPES).map((k) => `<option value="${k}">${k}</option>`).join('')}</select></div>
              </div>
              <p class="hint mt-8">Demo: geüploade afbeeldingen worden verkleind en in deze browser opgeslagen. In productie gaan uploads naar beveiligde opslag met controle op bestandstype, grootte en bestandsnaam.</p>
            </div></section>

            <section class="panel"><div class="panel-head"><div><h2>Compatibiliteit</h2><p>Informatief: de webshop belooft nooit gegarandeerde geschiktheid.</p></div></div><div class="panel-body">
              <span class="label">Merken</span>
              <div class="flex wrap gap-16 mt-8">${BRANDS.map((b) => `<label class="check"><input type="checkbox" data-cb="${b.id}"${p.compatibility.brands.includes(b.id) ? ' checked' : ''}><span class="box">${icon('check')}</span>${b.name}</label>`).join('')}</div>
              <span class="label mt-24" style="display:block">Modellen <span class="opt">(optioneel)</span></span>
              <div class="model-checks mt-8">${BRANDS.filter((b) => !p.compatibility.brands.length || p.compatibility.brands.includes(b.id)).map((b) => `<span class="mc-brand">${b.name}</span>${MODELS.filter((m) => m.brand === b.id).map((m) => `<label class="check"><input type="checkbox" data-cm="${m.id}"${p.compatibility.models.includes(m.id) ? ' checked' : ''}><span class="box">${icon('check')}</span>${esc(m.name)}</label>`).join('')}`).join('')}</div>
              <div class="field mt-24"><label for="pf-cnote">Compatibiliteitsinformatie</label><input class="input" id="pf-cnote" data-cnote value="${attr(p.compatibility.note)}" placeholder="Bijv. vereist een geschikt multimediasysteem"${inv('cnote')}>${err('cnote')}</div>
            </div></section>
          </div>

          <div class="form-col">
            <section class="panel"><div class="panel-head"><h2>Status</h2></div><div class="panel-body" style="display:grid;gap:16px">
              <label class="switch"><input type="checkbox" data-sw="active"${p.active ? ' checked' : ''}${p.archived ? ' disabled' : ''}><span class="track"></span>Actief (zichtbaar in de webshop)</label>
              <label class="switch"><input type="checkbox" data-sw="featured"${p.featured ? ' checked' : ''}><span class="track"></span>Uitgelicht</label>
              <label class="switch"><input type="checkbox" data-sw="installationIncluded"${p.installationIncluded ? ' checked' : ''}><span class="track"></span>Inbouw inbegrepen</label>
              <label class="switch"><input type="checkbox" data-sw="isDemo"${p.isDemo ? ' checked' : ''}><span class="track"></span>Demoproduct (intern)</label>
              <div class="field"><label for="pf-type">Soort</label><select class="select" id="pf-type" data-k="type">${Object.entries(PRODUCT_TYPES).map(([k, l]) => `<option value="${k}"${p.type === k ? ' selected' : ''}>${l}</option>`).join('')}</select></div>
              ${p.archived ? UI.notice('Dit product is gearchiveerd en niet zichtbaar in de webshop.', { ic: 'archive' }) : ''}
            </div></section>

            <section class="panel"><div class="panel-head"><h2>Prijs en korting</h2></div><div class="panel-body" style="display:grid;gap:18px">
              <div class="field"><label for="pf-regularPrice">Normale prijs</label><div class="input-affix"><span class="affix">€</span><input class="input" id="pf-regularPrice" data-raw="regularPrice" inputmode="decimal" value="${attr(raw.regularPrice)}" placeholder="249,00"${inv('regularPrice')}></div>${err('regularPrice')}</div>
              <div class="field"><span class="label">Korting</span><div class="radio-row" role="radiogroup" aria-label="Kortingstype">${[['none', 'Geen'], ['sale', 'Actieprijs'], ['percent', 'Percentage'], ['fixed', 'Vast bedrag']].map(([k, l]) => `<label class="radio-tile"><input type="radio" name="dtype" value="${k}"${p.discountType === k ? ' checked' : ''} data-dtype><span>${l}</span></label>`).join('')}</div></div>
              ${p.discountType === 'sale' ? `<div class="field"><label for="pf-salePrice">Actieprijs</label><div class="input-affix"><span class="affix">€</span><input class="input" id="pf-salePrice" data-raw="salePrice" inputmode="decimal" value="${attr(raw.salePrice)}"${inv('salePrice')}></div>${err('salePrice')}</div>` : ''}
              ${p.discountType === 'percent' ? `<div class="field"><label for="pf-discountValue">Kortingspercentage</label><div class="input-affix"><input class="input" id="pf-discountValue" data-raw="percent" inputmode="numeric" value="${attr(raw.percent)}"${inv('discountValue')} style="border-radius:var(--radius) 0 0 var(--radius)"><span class="affix affix--end">%</span></div>${err('discountValue')}</div>` : ''}
              ${p.discountType === 'fixed' ? `<div class="field"><label for="pf-discountValue">Vaste korting</label><div class="input-affix"><span class="affix">€</span><input class="input" id="pf-discountValue" data-raw="fixed" inputmode="decimal" value="${attr(raw.fixed)}"${inv('discountValue')}></div>${err('discountValue')}</div>` : ''}
              ${p.discountType !== 'none' ? `<div class="form-grid"><div class="field"><label for="pf-startDate">Startdatum <span class="opt">(optioneel)</span></label><input class="input" type="date" id="pf-startDate" data-k="startDate" value="${attr(p.startDate)}"${inv('startDate')}>${err('startDate')}</div>
                <div class="field"><label for="pf-endDate">Einddatum <span class="opt">(optioneel)</span></label><input class="input" type="date" id="pf-endDate" data-k="endDate" value="${attr(p.endDate)}"${inv('endDate')}>${err('endDate')}</div></div>` : ''}
              <div class="price-preview" aria-live="polite"><div class="pp-label">Zo ziet de klant het${promo === 'scheduled' ? ' (vanaf de startdatum)' : ''}</div>
                ${Number.isFinite(p.regularPrice) && valid ? Pricing.html(promo === 'scheduled' ? { ...p, startDate: '' } : p) : '<span class="text-muted text-small">Vul geldige prijzen in voor een voorbeeld.</span>'}
                ${promo === 'scheduled' ? `<p class="hint mt-8">Actie gepland vanaf ${fmtDate(`${p.startDate}T12:00:00`)}. Tot die tijd geldt de normale prijs.</p>` : ''}
                ${promo === 'expired' ? '<p class="hint mt-8">Deze actie is verlopen; de normale prijs geldt.</p>' : ''}
              </div>
            </div></section>

            <section class="panel"><div class="panel-head"><h2>Voorraad</h2></div><div class="panel-body" style="display:grid;gap:16px">
              <label class="switch"><input type="checkbox" data-sw="trackStock"${p.trackStock ? ' checked' : ''}><span class="track"></span>Voorraad bijhouden</label>
              ${p.trackStock ? `<div class="field"><label for="pf-stock">Voorraad</label><input class="input" id="pf-stock" type="number" min="0" max="99999" inputmode="numeric" data-raw="stock" value="${attr(raw.stock)}"${inv('stock')}>${err('stock')}<span class="hint">Bij 0 toont de webshop “Uitverkocht”.</span></div>` : '<p class="hint">Zonder voorraadbeheer toont de webshop “Levertijd op aanvraag”.</p>'}
            </div></section>

            <section class="panel"><div class="panel-head"><h2>Organisatie</h2></div><div class="panel-body" style="display:grid;gap:16px">
              <div class="field"><label for="pf-category">Categorie</label><select class="select" id="pf-category" data-k="category"${inv('category')}><option value="">Kies…</option>${Repo.shopCategories().map((c) => `<option value="${c.id}"${p.category === c.id ? ' selected' : ''}>${esc(c.name)}</option>`).join('')}</select>${err('category')}</div>
              <div class="field"><label for="pf-brand">Merk</label><select class="select" id="pf-brand" data-k="brand"><option value="">Meerdere / geen</option>${BRANDS.map((b) => `<option value="${b.id}"${p.brand === b.id ? ' selected' : ''}>${b.name}</option>`).join('')}</select></div>
              <div class="field"><label for="pf-model">Model</label><select class="select" id="pf-model" data-k="model"><option value="">Meerdere / geen</option>${MODELS.filter((m) => !p.brand || m.brand === p.brand).map((m) => `<option value="${m.id}"${p.model === m.id ? ' selected' : ''}>${esc(modelLabel(m.id))}</option>`).join('')}</select></div>
            </div></section>
            ${!isNew ? `<section class="panel"><div class="panel-head"><h2>Beheer</h2></div><div class="panel-body" style="display:grid;gap:10px">
              ${p.archived ? '<button class="btn btn--light btn--sm" type="button" data-restore>Herstellen uit archief</button>' : '<button class="btn btn--light btn--sm" type="button" data-archive>Archiveren</button>'}
              <button class="btn btn--ghost btn--sm" type="button" data-delete${productInOrders(p.id) ? ' disabled' : ''}>${icon('trash')} Definitief verwijderen</button>
              ${productInOrders(p.id) ? '<p class="hint">Dit product komt voor in bestellingen en kan daarom alleen worden gearchiveerd. Bestellingen behouden hun eigen momentopname.</p>' : ''}
              <p class="hint">Aangemaakt ${fmtDateTime(p.createdAt)} · gewijzigd ${fmtDateTime(p.updatedAt)}</p>
            </div></section>` : ''}
          </div>
        </form>
        <div class="save-bar"><span class="sb-status${dirty ? ' is-dirty' : ''}" data-sb>${dirty ? 'Niet-opgeslagen wijzigingen' : (isNew ? 'Nieuw product' : 'Alle wijzigingen opgeslagen')}</span>
          <div class="sb-actions"><a class="btn btn--light btn--sm" href="#/admin/producten">Annuleren</a><button class="btn btn--primary btn--sm" type="button" data-save>${isNew ? 'Product aanmaken' : 'Opslaan'}</button></div></div>`;
    };
    const markDirty = () => { dirty = true; const sb = $('[data-sb]', host); if (sb) { sb.textContent = 'Niet-opgeslagen wijzigingen'; sb.classList.add('is-dirty'); } };
    const parseRaw = () => {
      p.regularPrice = Money.parse(raw.regularPrice);
      if (p.discountType === 'sale') { p.salePrice = Money.parse(raw.salePrice); p.discountValue = null; }
      else if (p.discountType === 'percent') { p.discountValue = /^\d{1,2}$/.test(raw.percent.trim()) ? parseInt(raw.percent, 10) : NaN; p.salePrice = null; }
      else if (p.discountType === 'fixed') { p.discountValue = Money.parse(raw.fixed); p.salePrice = null; }
      else { p.salePrice = null; p.discountValue = null; }
      p.stock = p.trackStock ? (raw.stock.trim() === '' ? NaN : Number(raw.stock)) : (Number.isFinite(Number(raw.stock)) ? Number(raw.stock) : 0);
      errors = validateProduct(p);
    };
    const redraw = (focusSel) => {
      const active = document.activeElement && document.activeElement.id;
      parseRaw(); draw();
      const target = focusSel ? $(focusSel, host) : (active ? document.getElementById(active) : null);
      if (target) { target.focus(); if (target.setSelectionRange && target.type === 'text') { const l = target.value.length; try { target.setSelectionRange(l, l); } catch (e) { /* ignore */ } } }
    };
    parseRaw(); draw();
    host.addEventListener('input', (e) => {
      const t = e.target;
      if (t.dataset.k) {
        p[t.dataset.k] = t.value;
        if (t.dataset.k === 'name' && !slugTouched) { p.slug = slugify(t.value); const s = $('#pf-slug', host); if (s) s.value = p.slug; }
        if (t.dataset.k === 'slug') slugTouched = true;
      }
      if (t.dataset.raw) raw[t.dataset.raw] = t.value;
      if (t.matches('[data-cnote]')) p.compatibility.note = t.value;
      parseRaw(); markDirty();
      if (showErrors) { // live inline error updates without full redraw
        $$('.field-error[id^="pf-"]', host).forEach((el) => { const k = el.id.slice(3, -2); el.textContent = errors[k] || ''; });
      }
      const pv = $('.price-preview', host);
      if (pv && (t.dataset.raw || t.dataset.k === 'startDate' || t.dataset.k === 'endDate')) {
        const valid = !Object.keys(errors).length || !['regularPrice', 'salePrice', 'discountValue', 'startDate', 'endDate'].some((k) => errors[k]);
        const promo = Pricing.promoState(p);
        pv.innerHTML = `<div class="pp-label">Zo ziet de klant het${promo === 'scheduled' ? ' (vanaf de startdatum)' : ''}</div>${Number.isFinite(p.regularPrice) && valid ? Pricing.html(promo === 'scheduled' ? { ...p, startDate: '' } : p) : '<span class="text-muted text-small">Vul geldige prijzen in voor een voorbeeld.</span>'}`;
      }
    });
    host.addEventListener('change', async (e) => {
      const t = e.target;
      if (t.matches('[data-dtype]')) { p.discountType = t.value; if (t.value === 'none') { p.startDate = ''; p.endDate = ''; } markDirty(); redraw(`[data-dtype][value="${t.value}"]`); return; }
      if (t.dataset.sw) { p[t.dataset.sw] = t.checked; markDirty(); if (t.dataset.sw === 'trackStock') redraw(`[data-sw="trackStock"]`); return; }
      if (t.matches('[data-cb]')) {
        const b = t.dataset.cb;
        p.compatibility.brands = t.checked ? uniq([...p.compatibility.brands, b]) : p.compatibility.brands.filter((x) => x !== b);
        p.compatibility.models = p.compatibility.models.filter((m) => !p.compatibility.brands.length || p.compatibility.brands.includes(MODEL[m].brand));
        markDirty(); redraw(`[data-cb="${b}"]`); return;
      }
      if (t.matches('[data-cm]')) { const m = t.dataset.cm; p.compatibility.models = t.checked ? uniq([...p.compatibility.models, m]) : p.compatibility.models.filter((x) => x !== m); markDirty(); return; }
      if (t.dataset.k === 'brand') { p.brand = t.value; if (p.model && MODEL[p.model].brand !== p.brand) p.model = ''; markDirty(); redraw('#pf-brand'); return; }
      if (t.dataset.k === 'category' || t.dataset.k === 'model' || t.dataset.k === 'type' || t.dataset.k === 'startDate' || t.dataset.k === 'endDate') { p[t.dataset.k] = t.value; markDirty(); if (t.dataset.k.endsWith('Date')) redraw(`#${t.id}`); return; }
      const full = () => { if (p.images.length < Content.LIMITS.productImages) return false; Toast.show(`Een product heeft maximaal ${Content.LIMITS.productImages} afbeeldingen. Verwijder er eerst een.`, { error: true }); return true; };
      if (t.matches('[data-img-art]') && t.value) { if (full()) { t.value = ''; return; } p.images.push(`art:${t.value}:${p.images.length % 3}`); markDirty(); redraw('[data-img-art]'); return; }
      if (t.matches('[data-img-file]') && t.files && t.files[0]) {
        if (full()) { t.value = ''; return; }
        try {
          const dataUrl = await readImageFile(t.files[0]);
          p.images.push(dataUrl); markDirty(); redraw('[data-img-file]');
          Toast.show('Afbeelding toegevoegd (verkleind voor de demo).');
        } catch (er) { Toast.show(er.message, { error: true }); t.value = ''; }
      }
    });
    host.addEventListener('click', async (e) => {
      const f = e.target.closest('[data-focus]'); if (f) { e.preventDefault(); document.getElementById(f.dataset.focus)?.focus(); return; }
      if (e.target.closest('[data-img-add]')) {
        const inp = $('[data-img-url]', host); const url = inp.value.trim();
        if (!/^https:\/\/[^\s"'<>]+$/i.test(url)) { Toast.show('Gebruik een volledige https-URL naar een afbeelding.', { error: true }); inp.focus(); return; }
        if (p.images.length >= Content.LIMITS.productImages) { Toast.show(`Een product heeft maximaal ${Content.LIMITS.productImages} afbeeldingen. Verwijder er eerst een.`, { error: true }); return; }
        p.images.push(url); markDirty(); redraw('[data-img-url]'); return;
      }
      const pr = e.target.closest('[data-img-primary]');
      if (pr) { const i = Number(pr.dataset.imgPrimary); const [img] = p.images.splice(i, 1); p.images.unshift(img); markDirty(); redraw(); return; }
      const rm = e.target.closest('[data-img-remove]');
      if (rm) { p.images.splice(Number(rm.dataset.imgRemove), 1); markDirty(); redraw(); return; }
      if (e.target.closest('[data-archive]')) {
        if (await Overlay.confirm({ title: 'Product archiveren?', message: 'Het product verdwijnt uit de webshop. Bestellingen behouden hun gegevens.', confirmLabel: 'Archiveren' })) {
          Repo.saveProduct({ ...Repo.product(p.id), archived: true, active: false, featured: false }); dirty = false; Router.setGuard(null); Toast.show('Product gearchiveerd.'); Router.go('/admin/producten');
        }
        return;
      }
      if (e.target.closest('[data-restore]')) { Repo.saveProduct({ ...Repo.product(p.id), archived: false }); dirty = false; Toast.show('Product hersteld (inactief).'); Router.render(); return; }
      if (e.target.closest('[data-delete]')) {
        if (productInOrders(p.id)) return;
        if (await Overlay.confirm({ title: 'Product definitief verwijderen?', message: 'Dit kan niet ongedaan worden gemaakt.', confirmLabel: 'Verwijderen', danger: true })) {
          Repo.deleteProduct(p.id); dirty = false; Router.setGuard(null); Toast.show('Product verwijderd.'); Router.go('/admin/producten');
        }
        return;
      }
      if (e.target.closest('[data-save]')) {
        parseRaw();
        if (Object.keys(errors).length) { showErrors = true; draw(); const s = $('[data-errsum]', host); if (s) s.focus(); Toast.show('Controleer de gemarkeerde velden.', { error: true }); return; }
        const toSave = { ...p, name: p.name.trim(), sku: p.sku.trim(), shortDescription: p.shortDescription.trim() };
        if (toSave.discountType === 'none') { toSave.startDate = ''; toSave.endDate = ''; }
        if (toSave.archived) toSave.active = false;
        const saved = Repo.saveProduct(toSave);
        dirty = false; Router.setGuard(null);
        Toast.show(isNew ? 'Product aangemaakt.' : 'Product opgeslagen.');
        if (isNew) Router.go(`/admin/producten/${saved.id}`); else Router.render();
      }
    });
    return () => Router.setGuard(null);
  },
});

/* ---------- Categories ---------- */
Pages.adminCategories = adminPage({
  key: 'categorieen', title: 'Categorieën',
  render() {
    return `<section class="panel"><div class="panel-head"><div><h2>Webshopcategorieën</h2><p>Hernoem, sorteer of verwijder categorieën. Een categorie met producten kan niet worden verwijderd.</p></div></div>
      <div class="panel-body panel-body--flush" data-cats></div></section>
      <section class="panel"><div class="panel-head"><h2>Nieuwe categorie</h2></div><div class="panel-body">
        <form class="toolbar" data-newcat novalidate><div class="field grow"><label for="nc-name">Naam</label><input class="input" id="nc-name" name="name" maxlength="60" placeholder="Bijv. Trekhaken"></div><button class="btn btn--primary" type="submit" style="align-self:flex-end">${icon('plus')} Toevoegen</button></form>
        <span class="field-error" data-nc-err></span>
      </div></section>`;
  },
  mount(root) {
    const host = $('[data-cats]', root);
    const draw = () => {
      const cats = Repo.shopCategories();
      const counts = Object.fromEntries(cats.map((c) => [c.id, Repo.products().filter((p) => p.category === c.id).length]));
      host.innerHTML = cats.length ? `<div class="table-wrap rtable"><table class="table admin-table"><thead><tr><th>Naam</th><th>Slug</th><th class="num">Producten</th><th class="num">Volgorde / acties</th></tr></thead><tbody>
        ${cats.map((c, i) => `<tr><td class="cell-main" data-label="Naam"><input class="input input--sm" value="${attr(c.name)}" data-rename="${c.id}" aria-label="Naam van ${attr(c.name)}" maxlength="60"></td>
          <td data-label="Slug"><span class="code">${esc(c.slug)}</span></td>
          <td class="num" data-label="Producten">${counts[c.id]}</td>
          <td class="num cell-actions"><div class="row-actions">
            <button class="icon-btn icon-btn--sm" type="button" data-move="${c.id}" data-dir="-1" aria-label="Omhoog"${i === 0 ? ' disabled' : ''}>${icon('down').replace('<svg', '<svg style="transform:rotate(180deg)"')}</button>
            <button class="icon-btn icon-btn--sm" type="button" data-move="${c.id}" data-dir="1" aria-label="Omlaag"${i === cats.length - 1 ? ' disabled' : ''}>${icon('down')}</button>
            <button class="btn btn--ghost btn--xs" type="button" data-del="${c.id}"${counts[c.id] ? ` disabled title="Bevat ${counts[c.id]} product(en)"` : ''}>${icon('trash')} Verwijderen</button>
          </div></td></tr>`).join('')}</tbody></table></div>` : `<div class="panel-body">${UI.empty({ icon: 'layers', title: 'Nog geen categorieën' })}</div>`;
    };
    const save = (list) => Repo.saveShopCategories(list.map((c, i) => ({ ...c, order: i + 1 })));
    host.addEventListener('change', (e) => {
      const id = e.target.dataset.rename; if (!id) return;
      const name = e.target.value.trim();
      const cats = Repo.shopCategories();
      if (!name) { Toast.show('Een categorie heeft een naam nodig.', { error: true }); draw(); return; }
      if (cats.some((c) => c.id !== id && c.name.toLowerCase() === name.toLowerCase())) { Toast.show('Deze naam bestaat al.', { error: true }); draw(); return; }
      save(cats.map((c) => (c.id === id ? { ...c, name } : c))); Toast.show('Categorie hernoemd.');
    });
    host.addEventListener('click', async (e) => {
      const m = e.target.closest('[data-move]');
      if (m) {
        const cats = Repo.shopCategories(); const i = cats.findIndex((c) => c.id === m.dataset.move); const j = i + Number(m.dataset.dir);
        if (j < 0 || j >= cats.length) return;
        [cats[i], cats[j]] = [cats[j], cats[i]]; save(cats); draw();
        $(`[data-move="${m.dataset.move}"][data-dir="${m.dataset.dir}"]`, host)?.focus();
        return;
      }
      const d = e.target.closest('[data-del]');
      if (d) {
        const c = Repo.shopCategory(d.dataset.del);
        if (Repo.products().some((p) => p.category === c.id)) return;
        if (await Overlay.confirm({ title: 'Categorie verwijderen?', message: `“${esc(c.name)}” wordt verwijderd.`, confirmLabel: 'Verwijderen', danger: true })) {
          save(Repo.shopCategories().filter((x) => x.id !== c.id)); draw(); Toast.show('Categorie verwijderd.');
        }
      }
    });
    $('[data-newcat]', root).addEventListener('submit', (e) => {
      e.preventDefault();
      const name = e.target.name.value.trim(); const errEl = $('[data-nc-err]', root);
      const slug = slugify(name);
      const cats = Repo.shopCategories();
      if (!name || !slug) { errEl.textContent = 'Vul een naam in.'; return; }
      if (cats.some((c) => c.slug === slug || c.name.toLowerCase() === name.toLowerCase())) { errEl.textContent = 'Deze categorie bestaat al.'; return; }
      errEl.textContent = '';
      save([...cats, { id: `scat_${slug}`.slice(0, 40), name, slug, order: cats.length + 1 }]);
      e.target.reset(); draw(); Toast.show('Categorie toegevoegd.');
    });
    draw();
  },
});

/* ---------- Orders ---------- */
Pages.adminOrders = adminPage({
  key: 'bestellingen', title: 'Bestellingen',
  render(ctx) {
    const orders = Repo.orders();
    const status = ctx.query.status || '';
    const count = (s) => orders.filter((o) => o.orderStatus === s).length;
    return `<div class="chips" role="group" aria-label="Filter op status">
        <a class="chip${!status ? ' is-active' : ''}" href="#/admin/bestellingen"${!status ? ' aria-current="true"' : ''}>Alle <span class="n">${orders.length}</span></a>
        ${Object.entries(ORDER_STATUS).map(([k, s]) => `<a class="chip${status === k ? ' is-active' : ''}" href="#/admin/bestellingen?status=${k}"${status === k ? ' aria-current="true"' : ''}>${s.label} <span class="n">${count(k)}</span></a>`).join('')}
      </div>
      <div class="toolbar"><div class="input-icon">${icon('search')}<input class="input input--sm" type="search" data-q placeholder="Zoek op bestelnummer, naam of e-mail" aria-label="Zoek bestellingen"></div></div>
      <section class="panel"><div class="panel-body panel-body--flush" data-orders></div></section>`;
  },
  mount(root, ctx) {
    const status = ctx.query.status || '';
    let q = '';
    const host = $('[data-orders]', root);
    const draw = () => {
      const list = Repo.orders().filter((o) => (!status || o.orderStatus === status)
        && (!q || normText(`${o.orderNumber} ${o.customer.firstName} ${o.customer.lastName} ${o.customer.email}`).includes(normText(q))))
        .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
      host.innerHTML = list.length ? `<div class="table-wrap rtable"><table class="table admin-table"><thead><tr><th>Bestelnummer</th><th>Datum</th><th>Klant</th><th class="num">Totaal</th><th>Betaalstatus</th><th>Orderstatus</th></tr></thead><tbody>
        ${list.map((o) => `<tr class="clickable" data-href="#/admin/bestellingen/${o.id}">
          <td class="cell-main" data-label="Bestelnummer"><a class="text-link" href="#/admin/bestellingen/${o.id}"><strong>${esc(o.orderNumber)}</strong></a>${o.isDemo ? ' <span class="pill" style="height:20px;font-size:10.5px">demo</span>' : ''}</td>
          <td data-label="Datum" class="tabular">${fmtDateTime(o.createdAt)}</td>
          <td data-label="Klant">${esc(`${o.customer.firstName} ${o.customer.lastName}`)}<div class="text-small text-muted">${esc(o.customer.email)}</div></td>
          <td class="num" data-label="Totaal">${Money.fmt(o.total)}</td>
          <td data-label="Betaalstatus"><span class="pill">${esc(PAYMENT_STATUS[o.paymentStatus] || o.paymentStatus)}</span></td>
          <td data-label="Orderstatus">${orderBadge(o.orderStatus)}</td></tr>`).join('')}</tbody></table></div>`
        : `<div class="panel-body">${UI.empty({ icon: 'receipt', title: 'Geen bestellingen', text: status ? 'Er zijn geen bestellingen met deze status.' : 'Bestellingen uit de webshop verschijnen hier.' })}</div>`;
    };
    $('[data-q]', root).addEventListener('input', debounce((e) => { q = e.target.value.trim(); draw(); }, 200));
    host.addEventListener('click', (e) => { const tr = e.target.closest('tr[data-href]'); if (tr && !e.target.closest('a,button')) Router.go(tr.dataset.href); });
    draw();
  },
});
Pages.adminOrder = adminPage({
  key: 'bestellingen', title: 'Bestelling',
  heading: (ctx) => { const o = Repo.order(ctx.params.id); return o ? `Bestelling ${esc(o.orderNumber)}` : 'Bestelling'; },
  render(ctx) {
    const o = Repo.order(ctx.params.id);
    if (!o) return UI.empty({ icon: 'receipt', title: 'Bestelling niet gevonden', actions: '<a class="btn btn--dark btn--sm" href="#/admin/bestellingen">Alle bestellingen</a>' });
    const next = ORDER_TRANSITIONS[o.orderStatus] || [];
    const c = o.customer;
    return `<p><a class="link link--ink" href="#/admin/bestellingen">${icon('arrowLeft')} Alle bestellingen</a></p>
      <section class="panel"><div class="panel-body flex wrap justify-between items-center gap-16">
        <div class="flex wrap gap-12 items-center">${orderBadge(o.orderStatus)}<span class="pill">Betaling: ${esc(PAYMENT_STATUS[o.paymentStatus] || o.paymentStatus)}</span>${o.isDemo ? '<span class="demo-flag">Demo</span>' : ''}<span class="text-small text-muted">${fmtDateTime(o.createdAt)}</span></div>
        <form class="flex wrap gap-8 items-center" data-status-form>
          ${next.length ? `<label class="sr-only" for="os-next">Nieuwe status</label><select class="select select--sm" id="os-next" name="next" style="width:auto">${next.map((s) => `<option value="${s}">${ORDER_STATUS[s].label}</option>`).join('')}</select><button class="btn btn--dark btn--sm" type="submit">Status wijzigen</button>` : '<span class="text-small text-muted">Eindstatus — geen wijzigingen mogelijk.</span>'}
          <button class="btn btn--light btn--sm" type="button" data-poll>${icon('refresh')} Betaalstatus opvragen</button>
        </form>
      </div></section>
      <div class="dash-grid">
        <div class="form-col">
          <section class="panel"><div class="panel-head"><div><h2>Artikelen</h2><p>Momentopname van het moment van bestellen — latere productwijzigingen veranderen deze bestelling niet.</p></div></div>
            <div class="panel-body panel-body--flush"><div class="table-wrap rtable"><table class="table admin-table"><thead><tr><th>Product</th><th class="num">Aantal</th><th class="num">Prijs</th><th class="num">Totaal</th></tr></thead><tbody>
            ${o.items.map((l) => {
              const cur = Repo.product(l.productId);
              const curPrice = cur ? Pricing.calc(cur).price : null;
              return `<tr><td class="cell-main" data-label="Product"><div class="prod"><div class="thumb">${Media.html(l.image, '', { kind: 'box' })}</div><div><div class="p-name">${esc(l.name)}</div><div class="p-sub">${esc(l.sku)}${!cur ? ' · product verwijderd' : (curPrice !== l.unitPrice ? ` · huidige prijs ${Money.fmt(curPrice)}` : '')}</div></div></div></td>
                <td class="num" data-label="Aantal">${l.qty}</td>
                <td class="num" data-label="Prijs">${l.unitRegular !== l.unitPrice ? `<div class="text-muted" style="text-decoration:line-through;font-size:12.5px">${Money.fmt(l.unitRegular)}</div>` : ''}${Money.fmt(l.unitPrice)}${l.discountLabel ? `<div style="color:var(--red);font-size:11.5px;font-weight:700">${esc(l.discountLabel)}</div>` : ''}</td>
                <td class="num" data-label="Totaal"><strong>${Money.fmt(l.lineTotal)}</strong></td></tr>`;
            }).join('')}</tbody></table></div>
            <div class="panel-body" style="border-top:1px solid var(--line)">${CartUI.totalsHtml({ subtotalRegular: o.subtotalRegular, discountTotal: o.discountTotal, subtotal: o.subtotal, shipping: o.shipping, total: o.total, vat: o.vat }, { shippingLabel: o.delivery.label, shippingKnown: true })}</div></div></section>
          <section class="panel"><div class="panel-head"><h2>Tijdlijn</h2></div><div class="panel-body"><ol class="timeline">${o.history.slice().reverse().map((h) => `<li><div><strong>${esc(ORDER_STATUS[h.status] ? ORDER_STATUS[h.status].label : h.status)}</strong> — ${esc(h.note || '')}</div><div class="tl-time">${fmtDateTime(h.at)}</div></li>`).join('')}</ol></div></section>
        </div>
        <div class="form-col">
          <section class="panel"><div class="panel-head"><h2>Klant</h2></div><div class="panel-body"><dl class="kv">
            <dt>Naam</dt><dd>${esc(`${c.firstName} ${c.lastName}`)}</dd><dt>E-mail</dt><dd><a class="text-link" href="mailto:${attr(c.email)}">${esc(c.email)}</a></dd><dt>Telefoon</dt><dd>${esc(c.phone)}</dd>
            ${c.address ? `<dt>Adres</dt><dd>${esc(`${c.address.street} ${c.address.houseNumber}`)}<br>${esc(`${c.address.postal} ${c.address.city}`)}</dd>` : ''}
          </dl></div></section>
          <section class="panel"><div class="panel-head"><h2>Levering en voertuig</h2></div><div class="panel-body"><dl class="kv">
            <dt>Levering</dt><dd>${esc(o.delivery.label)} (${o.delivery.price ? Money.fmt(o.delivery.price) : 'gratis'})</dd>
            <dt>Voertuig</dt><dd>${o.vehicle ? esc(`${o.vehicle.label}${o.vehicle.year ? ` (${o.vehicle.year})` : ''}`) : '—'}</dd>
            <dt>Opmerking</dt><dd>${esc(o.note || '—')}</dd>
          </dl></div></section>
          <section class="panel"><div class="panel-head"><h2>Betaling</h2><span class="pill pill--warn">Testmodus</span></div><div class="panel-body"><dl class="kv">
            <dt>Provider</dt><dd>Demo-adapter (Mollie-ready)</dd><dt>Betaal-ID</dt><dd><span class="code">${esc(o.paymentId || '—')}</span></dd><dt>Status</dt><dd>${esc(PAYMENT_STATUS[o.paymentStatus] || o.paymentStatus)}</dd>
            <dt>Aangemaakt</dt><dd>${fmtDateTime(o.createdAt)}</dd><dt>Bijgewerkt</dt><dd>${fmtDateTime(o.updatedAt)}</dd>
          </dl>
          ${(o.payments || []).length > 1 ? `<p class="label mt-16" style="margin-bottom:8px">Betaalpogingen</p><ul class="timeline">${o.payments.slice().reverse().map((p) => `<li><span class="code">${esc(p.id)}</span> — ${esc(PAYMENT_STATUS[p.status] || p.status)}<div class="tl-time">${fmtDateTime(p.createdAt)}</div></li>`).join('')}</ul>` : ''}
          </div></section>
        </div>
      </div>`;
  },
  mount(root, ctx) {
    const f = $('[data-status-form]', root); if (!f) return;
    f.addEventListener('submit', async (e) => {
      e.preventDefault();
      const next = f.next.value;
      const ok = await Overlay.confirm({ title: 'Status wijzigen?', message: `De status wordt gewijzigd naar “${esc(ORDER_STATUS[next].label)}”.${next === 'GEANNULEERD' && Repo.order(ctx.params.id).paymentStatus === 'paid' ? ' Let op: in productie vereist dit ook een terugbetaling via de betaalprovider.' : ''}`, confirmLabel: 'Wijzigen' });
      if (!ok) return;
      const r = OrderService.setStatus(ctx.params.id, next);
      if (r.ok) { Toast.show('Status gewijzigd.'); Router.render(); } else Toast.show(r.message, { error: true });
    });
    $('[data-poll]', root).addEventListener('click', async (e) => {
      const b = e.currentTarget; b.classList.add('is-loading');
      const o = Repo.order(ctx.params.id);
      await sleep(400);
      if (o.paymentId) await OrderService.onPaymentWebhook(o.paymentId);
      b.classList.remove('is-loading');
      Toast.show('Betaalstatus opgevraagd bij de (demo)provider.');
      Router.render();
    });
  },
});

/* ---------- Promotions ---------- */
Pages.adminPromos = adminPage({
  key: 'acties', title: 'Acties',
  render() {
    const products = Repo.products().filter((p) => !p.archived);
    return `<section class="panel"><div class="panel-head"><div><h2>Korting instellen</h2><p>Actieprijs, percentage of vast bedrag — met optionele start- en einddatum.</p></div></div>
        <div class="panel-body"><form class="form-grid" data-promo-form novalidate>
          <div class="field span-2"><label for="pr-prod">Product</label><select class="select" id="pr-prod" name="product"><option value="">Kies een product…</option>${products.map((p) => `<option value="${p.id}">${esc(p.name)} — ${Money.fmt(p.regularPrice)}</option>`).join('')}</select></div>
          <div class="field"><label for="pr-type">Soort korting</label><select class="select" id="pr-type" name="type"><option value="sale">Actieprijs (€)</option><option value="percent">Percentage (%)</option><option value="fixed">Vast bedrag (€)</option></select></div>
          <div class="field"><label for="pr-val">Waarde</label><input class="input" id="pr-val" name="value" inputmode="decimal" placeholder="bijv. 249,00"><span class="field-error" data-pe="value"></span></div>
          <div class="field"><label for="pr-start">Startdatum <span class="opt">(optioneel)</span></label><input class="input" type="date" id="pr-start" name="start"></div>
          <div class="field"><label for="pr-end">Einddatum <span class="opt">(optioneel)</span></label><input class="input" type="date" id="pr-end" name="end"><span class="field-error" data-pe="end"></span></div>
          <div class="span-2 flex wrap justify-between items-center gap-12"><div class="price-preview" style="flex:1;min-width:220px" data-pp><span class="text-muted text-small">Kies een product voor een voorbeeld.</span></div><button class="btn btn--primary" type="submit">Korting opslaan</button></div>
        </form></div></section>
      <section class="panel"><div class="panel-head"><h2>Producten met korting</h2></div><div class="panel-body panel-body--flush" data-promos></div></section>`;
  },
  mount(root) {
    const form = $('[data-promo-form]', root); const host = $('[data-promos]', root);
    const read = () => {
      const p = Repo.product(form.product.value); if (!p) return null;
      const d = deepClone(p); const v = form.value.value.trim();
      d.discountType = form.type.value; d.salePrice = null; d.discountValue = null;
      if (d.discountType === 'sale') d.salePrice = Money.parse(v);
      if (d.discountType === 'fixed') d.discountValue = Money.parse(v);
      if (d.discountType === 'percent') d.discountValue = /^\d{1,2}$/.test(v) ? parseInt(v, 10) : NaN;
      d.startDate = form.start.value; d.endDate = form.end.value;
      return d;
    };
    const preview = () => {
      const d = read(); const pp = $('[data-pp]', form);
      $('[data-pe="value"]', form).textContent = ''; $('[data-pe="end"]', form).textContent = '';
      if (!d) { pp.innerHTML = '<span class="text-muted text-small">Kies een product voor een voorbeeld.</span>'; return null; }
      const e = validateProduct(d);
      if (form.value.value.trim()) $('[data-pe="value"]', form).textContent = e.salePrice || e.discountValue || '';
      $('[data-pe="end"]', form).textContent = e.endDate || '';
      const state = Pricing.promoState(d);
      pp.innerHTML = Object.keys(e).length ? '<span class="text-muted text-small">Vul een geldige korting in.</span>' : `${Pricing.html(state === 'scheduled' ? { ...d, startDate: '' } : d)}${state === 'scheduled' ? '<p class="hint mt-8">Gepland: de korting start op de startdatum.</p>' : ''}${state === 'expired' ? '<p class="hint mt-8">Let op: deze periode is al verlopen.</p>' : ''}`;
      return e;
    };
    form.addEventListener('input', preview); form.addEventListener('change', (e) => {
      if (e.target.name === 'type') form.value.placeholder = e.target.value === 'percent' ? 'bijv. 15' : 'bijv. 249,00';
      if (e.target.name === 'product') {
        const p = Repo.product(form.product.value);
        if (p && p.discountType !== 'none') {
          form.type.value = p.discountType;
          form.value.value = p.discountType === 'sale' ? Money.toInput(p.salePrice) : (p.discountType === 'fixed' ? Money.toInput(p.discountValue) : String(p.discountValue));
          form.start.value = p.startDate || ''; form.end.value = p.endDate || '';
        }
      }
      preview();
    });
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const d = read(); if (!d) { Toast.show('Kies een product.', { error: true }); form.product.focus(); return; }
      const errs = preview();
      if (Object.keys(errs).length) { Toast.show(errs.salePrice || errs.discountValue || errs.endDate || 'Controleer de invoer.', { error: true }); return; }
      Repo.saveProduct(d); Toast.show('Korting opgeslagen.'); form.reset(); preview(); draw();
    });
    const draw = () => {
      const list = Repo.products().filter((p) => !p.archived && p.discountType !== 'none');
      host.innerHTML = list.length ? `<div class="table-wrap rtable"><table class="table admin-table"><thead><tr><th>Product</th><th>Korting</th><th>Periode</th><th>Status</th><th class="num">Klantprijs</th><th class="num"><span class="sr-only">Acties</span></th></tr></thead><tbody>
        ${list.map((p) => { const s = Pricing.promoState(p); const c = Pricing.calc(p); return `<tr>
          <td class="cell-main" data-label="Product"><a class="text-link" href="#/admin/producten/${p.id}">${esc(p.name)}</a></td>
          <td data-label="Korting">${esc(Pricing.describe(p))}</td>
          <td data-label="Periode" class="tabular">${p.startDate || p.endDate ? `${p.startDate ? fmtDate(`${p.startDate}T12:00:00`) : 'nu'} – ${p.endDate ? fmtDate(`${p.endDate}T12:00:00`) : 'onbepaald'}` : 'Doorlopend'}</td>
          <td data-label="Status"><span class="pill ${s === 'active' ? 'pill--red' : (s === 'scheduled' ? 'pill--info' : '')}">${{ active: 'Actief', scheduled: 'Gepland', expired: 'Verlopen' }[s]}</span></td>
          <td class="num" data-label="Klantprijs">${c.onSale ? `<span class="text-muted" style="text-decoration:line-through;font-size:12.5px">${Money.fmt(c.regular)}</span> ` : ''}<strong>${Money.fmt(c.price)}</strong></td>
          <td class="num cell-actions"><div class="row-actions"><button class="btn btn--ghost btn--xs" type="button" data-edit="${p.id}">${icon('pencil')} Wijzigen</button><button class="btn btn--ghost btn--xs" type="button" data-remove="${p.id}">${icon('x')} Korting verwijderen</button></div></td></tr>`; }).join('')}
        </tbody></table></div>` : `<div class="panel-body">${UI.empty({ icon: 'percent', title: 'Geen kortingen', text: 'Stel hierboven een korting in.' })}</div>`;
    };
    host.addEventListener('click', async (e) => {
      const ed = e.target.closest('[data-edit]');
      if (ed) { form.product.value = ed.dataset.edit; form.product.dispatchEvent(new Event('change', { bubbles: true })); form.scrollIntoView({ behavior: 'smooth', block: 'start' }); form.value.focus(); return; }
      const rm = e.target.closest('[data-remove]');
      if (rm) {
        const p = Repo.product(rm.dataset.remove);
        if (await Overlay.confirm({ title: 'Korting verwijderen?', message: `De normale prijs (${Money.fmt(p.regularPrice)}) van “${esc(p.name)}” geldt weer.`, confirmLabel: 'Verwijderen' })) {
          Repo.saveProduct({ ...p, discountType: 'none', salePrice: null, discountValue: null, startDate: '', endDate: '' }); draw(); Toast.show('Korting verwijderd.');
        }
      }
    });
    draw();
  },
});

/* ---------- Stock ---------- */
Pages.adminStock = adminPage({
  key: 'voorraad', title: 'Voorraad',
  render(ctx) {
    const f = ctx.query.f || 'alle';
    return `<div class="toolbar"><div class="chips" role="group" aria-label="Filter">${[['alle', 'Alle'], ['laag', 'Lage voorraad'], ['uit', 'Uitverkocht'], ['niet', 'Niet bijgehouden']].map(([k, l]) => `<a class="chip${f === k ? ' is-active' : ''}" href="#/admin/voorraad${k === 'alle' ? '' : `?f=${k}`}"${f === k ? ' aria-current="true"' : ''}>${l}</a>`).join('')}</div>
      <span class="text-small text-muted">Lage voorraad: ≤ ${Stock.threshold()} (<a class="text-link" href="#/admin/instellingen">instelbaar</a>)</span></div>
      <section class="panel"><div class="panel-body panel-body--flush" data-stock></div></section>`;
  },
  mount(root, ctx) {
    const f = ctx.query.f || 'alle';
    const host = $('[data-stock]', root);
    const draw = () => {
      const list = Repo.products().filter((p) => !p.archived).filter((p) => {
        if (f === 'laag') return p.trackStock && p.stock <= Stock.threshold();
        if (f === 'uit') return p.trackStock && p.stock <= 0;
        if (f === 'niet') return !p.trackStock;
        return true;
      });
      host.innerHTML = list.length ? `<div class="table-wrap rtable"><table class="table admin-table"><thead><tr><th>Product</th><th>Bijhouden</th><th>Voorraad</th><th>Status</th></tr></thead><tbody>
        ${list.map((p) => `<tr><td class="cell-main" data-label="Product"><div class="prod"><div class="thumb">${Media.html(p.images[0], '', { kind: productArtKind(p) })}</div><div><a class="p-name text-link" href="#/admin/producten/${p.id}">${esc(p.name)}</a><div class="p-sub">${esc(p.sku)}</div></div></div></td>
          <td data-label="Bijhouden"><label class="switch"><input type="checkbox" data-track="${p.id}"${p.trackStock ? ' checked' : ''}><span class="track"></span><span class="sr-only">Voorraad bijhouden voor ${attr(p.name)}</span></label></td>
          <td data-label="Voorraad">${p.trackStock ? UI.qty({ id: p.id, value: Math.max(0, p.stock), max: 99999, size: 'sm', label: `Voorraad ${p.name}` }).replace('min="1"', 'min="0"') : '<span class="text-muted">—</span>'}</td>
          <td data-label="Status">${Stock.html(p)}</td></tr>`).join('')}</tbody></table></div>`
        : `<div class="panel-body">${UI.empty({ icon: 'grid', title: 'Geen producten in deze selectie' })}</div>`;
      // Stock steppers allow 0, so we handle them here instead of the generic behaviour.
      $$('[data-qty]', host).forEach((q) => {
        const input = $('input', q);
        $('[data-step="-1"]', q).disabled = Number(input.value) <= 0;
      });
    };
    const setStock = debounce((id, value) => {
      const p = Repo.product(id); if (!p) return;
      Repo.saveProduct({ ...p, stock: value }); draw(); Toast.show(`Voorraad van “${p.name}” is nu ${value}.`);
    }, 450);
    host.addEventListener('click', (e) => {
      const b = e.target.closest('[data-step]'); if (!b) return;
      const q = b.closest('[data-qty]'); const input = $('input', q);
      const v = clamp((parseInt(input.value, 10) || 0) + Number(b.dataset.step), 0, 99999);
      input.value = v; $('[data-step="-1"]', q).disabled = v <= 0;
      setStock(q.dataset.qty, v);
    });
    host.addEventListener('change', (e) => {
      if (e.target.dataset.track) { const p = Repo.product(e.target.dataset.track); Repo.saveProduct({ ...p, trackStock: e.target.checked }); draw(); Toast.show(e.target.checked ? 'Voorraad wordt bijgehouden.' : 'Voorraad wordt niet meer bijgehouden.'); return; }
      const q = e.target.closest('[data-qty]');
      if (q) { const raw = e.target.value.trim(); if (!/^\d{1,5}$/.test(raw)) { Toast.show('Vul een geldig aantal in (0 of meer).', { error: true }); draw(); return; } setStock(q.dataset.qty, parseInt(raw, 10)); }
    });
    draw();
  },
});

/* ---------- Projects ---------- */
Pages.adminProjects = adminPage({
  key: 'projecten', title: 'Projecten',
  actions: () => `<a class="btn btn--primary btn--sm" href="#/admin/projecten/nieuw">${icon('plus')}<span class="hide-sm">Nieuw project</span></a>`,
  render() {
    const list = Repo.projects();
    return `<section class="panel"><div class="panel-head"><div><h2>Portfolio</h2><p>Gebruik alleen echte foto’s uit de werkplaats. Een voor/na-vergelijking verschijnt alleen als beide foto’s zijn ingesteld.</p></div></div>
      <div class="panel-body panel-body--flush">${list.length ? `<div class="table-wrap rtable"><table class="table admin-table"><thead><tr><th>Project</th><th>Type</th><th>Voor/na</th><th>Status</th><th class="num"><span class="sr-only">Acties</span></th></tr></thead><tbody>
        ${list.map((p) => `<tr><td class="cell-main" data-label="Project"><div class="prod"><div class="thumb">${Media.html(p.image, '', { kind: 'camera' })}</div><div><a class="p-name text-link" href="#/admin/projecten/${p.id}">${esc(p.title)}</a><div class="p-sub">${esc(p.vehicle)}</div></div></div></td>
          <td data-label="Type">${esc((PROJECT_TYPES.find((t) => t.id === p.type) || {}).name || p.type)}</td>
          <td data-label="Voor/na">${p.before && p.after ? '<span class="pill pill--ok">Ja</span>' : '<span class="pill">Nee</span>'}</td>
          <td data-label="Status">${p.active ? '<span class="pill pill--ok">Zichtbaar</span>' : '<span class="pill">Verborgen</span>'}</td>
          <td class="num cell-actions"><div class="row-actions"><a class="btn btn--ghost btn--xs" href="#/projecten/${p.slug}">${icon('eye')} Bekijk</a><a class="btn btn--ghost btn--xs" href="#/admin/projecten/${p.id}">${icon('pencil')} Bewerken</a><button class="btn btn--ghost btn--xs" type="button" data-del="${p.id}">${icon('trash')} Verwijderen</button></div></td></tr>`).join('')}
      </tbody></table></div>` : `<div class="panel-body">${UI.empty({ icon: 'camera', title: 'Nog geen projecten' })}</div>`}</div></section>`;
  },
  mount(root) {
    root.addEventListener('click', async (e) => {
      const d = e.target.closest('[data-del]'); if (!d) return;
      const p = Repo.projects().find((x) => x.id === d.dataset.del);
      if (await Overlay.confirm({ title: 'Project verwijderen?', message: `“${esc(p.title)}” wordt verwijderd uit het portfolio.`, confirmLabel: 'Verwijderen', danger: true })) {
        Repo.saveProjects(Repo.projects().filter((x) => x.id !== p.id)); Toast.show('Project verwijderd.'); Router.render();
      }
    });
  },
});
Pages.adminProjectForm = adminPage({
  key: 'projecten', title: 'Project',
  heading: (ctx) => (ctx.params.id ? 'Project bewerken' : 'Nieuw project'),
  render(ctx) {
    const isNew = !ctx.params.id;
    const p = isNew ? { id: uid('prj'), slug: '', title: '', vehicle: '', brands: [], models: [], type: 'camera-parkeren', tag: '', short: '', body: '', image: '', before: '', after: '', related: [], services: [], active: true }
      : Repo.projects().find((x) => x.id === ctx.params.id);
    if (!p) return UI.empty({ icon: 'camera', title: 'Project niet gevonden', actions: '<a class="btn btn--dark btn--sm" href="#/admin/projecten">Alle projecten</a>' });
    const imgField = (k, label, hint) => `<div class="field span-2"><label for="pj-${k}">${label}</label>
      <div class="flex gap-12 items-center wrap">${p[k] ? `<div style="width:120px;aspect-ratio:4/3;border-radius:2px;overflow:hidden;border:1px solid var(--line)">${Media.html(p[k], '', { kind: 'camera' })}</div>` : ''}
      <input class="input" id="pj-${k}" name="${k}" value="${attr(p[k].startsWith('data:') ? '(geüploade afbeelding)' : p[k])}" placeholder="https://… of img:sleutel" style="flex:1;min-width:200px" ${p[k].startsWith('data:') ? 'data-keep="1"' : ''}>
      <input type="file" accept="image/png,image/jpeg,image/webp" data-upload="${k}" aria-label="${label} uploaden" style="max-width:240px"></div>${hint ? `<span class="hint">${hint}</span>` : ''}</div>`;
    return `<p><a class="link link--ink" href="#/admin/projecten">${icon('arrowLeft')} Alle projecten</a></p>
      <form class="panel" data-pj-form novalidate data-id="${p.id}" data-new="${isNew}"><div class="panel-body"><div class="form-grid">
        <div class="field"><label for="pj-title">Titel</label><input class="input" id="pj-title" name="title" value="${attr(p.title)}" required></div>
        <div class="field"><label for="pj-slug">Slug</label><input class="input" id="pj-slug" name="slug" value="${attr(p.slug)}"></div>
        <div class="field"><label for="pj-vehicle">Voertuig</label><input class="input" id="pj-vehicle" name="vehicle" value="${attr(p.vehicle)}" placeholder="Bijv. SEAT Ibiza"></div>
        <div class="field"><label for="pj-tag">Label op foto</label><input class="input" id="pj-tag" name="tag" value="${attr(p.tag)}" placeholder="Bijv. Originele camera"></div>
        <div class="field"><label for="pj-type">Type werk</label><select class="select" id="pj-type" name="type">${PROJECT_TYPES.map((t) => `<option value="${t.id}"${p.type === t.id ? ' selected' : ''}>${esc(t.name)}</option>`).join('')}</select></div>
        <div class="field"><span class="label">Merken</span><div class="flex wrap gap-16 mt-8">${BRANDS.map((b) => `<label class="check"><input type="checkbox" name="brands" value="${b.id}"${(p.brands || []).includes(b.id) ? ' checked' : ''}><span class="box">${icon('check')}</span>${b.name}</label>`).join('')}</div></div>
        <div class="field span-2"><label for="pj-short">Korte omschrijving</label><input class="input" id="pj-short" name="short" value="${attr(p.short)}" maxlength="160"></div>
        <div class="field span-2"><label for="pj-body">Tekst</label><textarea class="textarea" id="pj-body" name="body">${esc(p.body || '')}</textarea></div>
        <div class="field span-2"><label for="pj-related">Gerelateerde optie <span class="opt">(optioneel)</span></label><select class="select" id="pj-related" name="related"><option value="">Geen</option>${RETROFITS.map((r) => `<option value="${r.slug}"${(p.related || [])[0] === r.slug ? ' selected' : ''}>${esc(r.title)}</option>`).join('')}</select></div>
        ${imgField('image', 'Hoofdfoto', '')}
        ${imgField('before', 'Voor-foto', 'Alleen een échte foto van vóór de werkzaamheden.')}
        ${imgField('after', 'Na-foto', 'Dezelfde auto en hoek, na de werkzaamheden.')}
        <label class="switch span-2"><input type="checkbox" name="active"${p.active ? ' checked' : ''}><span class="track"></span>Zichtbaar in het portfolio</label>
      </div><span class="field-error" data-pj-err></span></div>
      <div class="modal-foot" style="border-radius:0 0 var(--radius) var(--radius)"><a class="btn btn--light btn--sm" href="#/admin/projecten">Annuleren</a><button class="btn btn--primary btn--sm" type="submit">Opslaan</button></div></form>`;
  },
  mount(root, ctx) {
    const f = $('[data-pj-form]', root); if (!f) return;
    const isNew = f.dataset.new === 'true';
    const existing = Repo.projects().find((x) => x.id === f.dataset.id);
    const uploads = {};
    f.title.addEventListener('input', () => { if (isNew) f.slug.value = slugify(f.title.value); });
    f.addEventListener('change', async (e) => {
      const k = e.target.dataset.upload; if (!k || !e.target.files[0]) return;
      try { uploads[k] = await readImageFile(e.target.files[0], 1600); f[k].value = '(geüploade afbeelding)'; f[k].dataset.keep = ''; Toast.show('Foto toegevoegd.'); }
      catch (er) { Toast.show(er.message, { error: true }); e.target.value = ''; }
    });
    f.addEventListener('submit', (e) => {
      e.preventDefault();
      const errEl = $('[data-pj-err]', f);
      const img = (k) => {
        if (uploads[k]) return uploads[k];
        if (f[k].dataset.keep === '1' && existing) return existing[k];
        const v = f[k].value.trim();
        return v;
      };
      const data = {
        ...(existing || {}), id: f.dataset.id, title: f.title.value.trim(), slug: slugify(f.slug.value || f.title.value), vehicle: f.vehicle.value.trim(),
        tag: f.tag.value.trim(), type: f.type.value, brands: $$('input[name="brands"]:checked', f).map((x) => x.value),
        short: f.short.value.trim(), body: f.body.value.trim(), related: f.related.value ? [f.related.value] : [],
        image: img('image'), before: img('before'), after: img('after'), active: f.active.checked,
        models: existing ? existing.models || [] : [], services: existing ? existing.services || [] : [],
      };
      const bad = ['image', 'before', 'after'].find((k) => data[k] && (!Media.src(data[k]) || !Content.isMediaRef(data[k])));
      const L = Content.LIMITS;
      const tooLong = [['title', 'De titel', L.projectTitle], ['vehicle', 'Het voertuig', L.projectVehicle], ['tag', 'Het label', L.projectTag], ['short', 'De korte omschrijving', L.projectShort], ['body', 'De tekst', L.projectBody]]
        .find(([k, , max]) => data[k].length > max);
      const err = !data.title ? 'Vul een titel in.' : (!data.vehicle ? 'Vul het voertuig in.' : (!data.tag ? 'Vul een label in.' : (!data.short ? 'Vul een korte omschrijving in.' : (!data.image ? 'Kies een hoofdfoto.' : (bad ? 'Een foto-adres is ongeldig (gebruik https://…).' : ((data.before && !data.after) || (!data.before && data.after) ? 'Voor een voor/na-vergelijking zijn beide foto’s nodig.' : (!Content.isSlug(data.slug) ? 'Vul een geldige slug in (kleine letters, cijfers en koppeltekens).' : (Repo.projects().some((x) => x.slug === data.slug && x.id !== data.id) ? 'Deze slug is al in gebruik.' : (tooLong ? `${tooLong[1]} is te lang: maximaal ${tooLong[2].toLocaleString('nl-NL')} tekens (nu ${data[tooLong[0]].length.toLocaleString('nl-NL')}).` : '')))))))));
      if (err) { errEl.textContent = err; Toast.show(err, { error: true }); return; }
      const list = Repo.projects().filter((x) => x.id !== data.id);
      Repo.saveProjects(isNew ? [...list, data] : Repo.projects().map((x) => (x.id === data.id ? data : x)));
      Toast.show('Project opgeslagen.');
      Router.go('/admin/projecten');
    });
  },
});

/* ---------- Settings ---------- */
Pages.adminSettings = adminPage({
  key: 'instellingen', title: 'Instellingen',
  render() {
    const s = Repo.settings();
    return `<section class="panel"><div class="panel-head"><div><h2>Verzending</h2><p>Testconfiguratie — geen vastgestelde CarTronic-tarieven.</p></div></div><div class="panel-body">
        <form data-ship novalidate><div class="table-wrap rtable"><table class="table admin-table"><thead><tr><th>Naam</th><th>Omschrijving</th><th class="num">Prijs (€)</th><th>Adres nodig</th><th>Actief</th></tr></thead><tbody>
          ${s.shipping.map((m, i) => `<tr><td class="cell-main" data-label="Naam"><input class="input input--sm" name="label-${i}" value="${attr(m.label)}" aria-label="Naam"></td><td data-label="Omschrijving"><input class="input input--sm" name="desc-${i}" value="${attr(m.description || '')}" aria-label="Omschrijving"></td>
            <td class="num" data-label="Prijs"><input class="input input--sm" name="price-${i}" value="${attr(Money.toInput(m.price))}" inputmode="decimal" style="max-width:110px" aria-label="Prijs in euro"></td>
            <td data-label="Adres nodig"><label class="switch"><input type="checkbox" name="addr-${i}"${m.requiresAddress ? ' checked' : ''}><span class="track"></span><span class="sr-only">Adres nodig</span></label></td>
            <td data-label="Actief"><label class="switch"><input type="checkbox" name="on-${i}"${m.enabled ? ' checked' : ''}><span class="track"></span><span class="sr-only">Actief</span></label></td></tr>`).join('')}
        </tbody></table></div><div class="mt-16 flex justify-between items-center wrap gap-12"><span class="field-error" data-ship-err></span><button class="btn btn--dark btn--sm" type="submit">Verzending opslaan</button></div></form>
      </div></section>
      <div class="dash-grid">
        <section class="panel"><div class="panel-head"><div><h2>Btw en voorraad</h2><p>Btw-regels moeten door de boekhouding worden bevestigd.</p></div></div><div class="panel-body">
          <form class="form-grid" data-general novalidate>
            <div class="field"><label for="st-vat">Btw-tarief (%)</label><input class="input" id="st-vat" name="vat" inputmode="numeric" value="${s.vat.rate}"></div>
            <div class="field"><label for="st-low">Drempel lage voorraad</label><input class="input" id="st-low" name="low" type="number" min="0" max="999" value="${s.lowStockThreshold}"></div>
            <label class="switch span-2"><input type="checkbox" name="breakdown"${s.vat.showBreakdown ? ' checked' : ''}><span class="track"></span>Toon “waarvan btw” in winkelmand en afrekenen</label>
            <p class="hint span-2">Consumentenprijzen worden inclusief btw getoond. Het btw-bedrag wordt per bestelling berekend en vastgelegd.</p>
            <div class="span-2"><button class="btn btn--dark btn--sm" type="submit">Opslaan</button></div>
          </form></div></section>
        <section class="panel"><div class="panel-head"><div><h2>Kentekenherkenning</h2><p>Bron voor voertuiggegevens</p></div></div><div class="panel-body">
          <form data-lookup style="display:grid;gap:12px">
            <label class="check"><input type="radio" name="mode" value="live"${s.vehicleLookupMode === 'live' ? ' checked' : ''}><span class="box"></span><span><strong>RDW Open Data (live)</strong><br><span class="text-muted text-small">Echte voertuiggegevens. Testkentekens (TE-ST-xx) blijven beschikbaar.</span></span></label>
            <label class="check"><input type="radio" name="mode" value="demo"${s.vehicleLookupMode === 'demo' ? ' checked' : ''}><span class="box"></span><span><strong>Alleen demo-gegevens</strong><br><span class="text-muted text-small">Geen externe verzoeken; alleen testkentekens worden herkend.</span></span></label>
          </form></div></section>
      </div>
      <section class="panel" id="architectuur"><div class="panel-head"><div><h2>Betalingen en architectuur</h2><p>Hoe dit prototype straks veilig in productie gaat</p></div><span class="pill pill--warn">Testmodus</span></div><div class="panel-body">
        <div class="dash-grid">
          <div><h3 class="h4" style="font-size:15px;margin-bottom:12px">Productie: Mollie-betaalstroom (server-side)</h3>
            <ol class="flow"><li>Winkelmand → afrekenen in de browser</li><li>Server valideert producten, actief-status en voorraad</li><li>Server berekent zelf prijzen, korting, verzending en btw (nooit de bedragen uit de browser)</li><li>Server maakt de bestelling met momentopnames (Wacht op betaling)</li><li>Server maakt een Mollie-betaling aan in <strong>testmodus</strong></li><li>Klant betaalt in Mollie Checkout</li><li>Klant keert terug; de pagina toont de status volgens de server</li><li>Mollie roept de webhook aan; de server haalt de echte betaalstatus op</li><li>Pas dan wordt de bestelling “Betaald”. Live-modus wordt handmatig geactiveerd.</li></ol></div>
          <div style="display:grid;gap:12px;align-content:start">
            ${UI.notice('<strong>Geen geheimen in de browser.</strong> Mollie-API-sleutels, databasegegevens en webhooks horen uitsluitend op de server.', { ic: 'lock' })}
            ${UI.notice('<strong>Demo-login ≠ beveiliging.</strong> Productie: server-side authenticatie (HttpOnly-sessie, gehashte wachtwoorden, 2FA, rate limiting) en autorisatie van elke wijziging.', { ic: 'shield' })}
            ${UI.notice('<strong>Uploads.</strong> Productie: controle op bestandstype (magic bytes), grootte en veilige bestandsnamen; opslag met beperkte rechten.', { ic: 'upload' })}
            ${UI.notice('<strong>Dubbele bestellingen.</strong> Elke afrekenpoging heeft een idempotency-sleutel; dubbelklikken, verversen en terugnavigeren leveren geen tweede bestelling op.', { ic: 'refresh' })}
          </div>
        </div></div></section>
      <section class="panel"><div class="panel-head"><div><h2>Gegevens</h2><p>Exporteren, importeren en demodata herstellen</p></div></div><div class="panel-body" style="display:grid;gap:16px">
        <div class="flex wrap gap-8">
          <button class="btn btn--light btn--sm" type="button" data-export>${icon('download')} Exporteer producten (JSON)</button>
          <label class="btn btn--light btn--sm" style="cursor:pointer">${icon('upload')} Importeer producten (JSON)<input type="file" accept="application/json,.json" data-import class="sr-only"></label>
          <button class="btn btn--ghost btn--sm" type="button" data-reset style="color:var(--red)">${icon('refresh')} Reset demodata</button>
        </div>
        <p class="hint">De export bevat producten en categorieën. Bij import wordt elk product gevalideerd; bestellingen blijven ongewijzigd.</p>
      </div></section>
      <section class="panel"><div class="panel-head"><div><h2>Eventlog (deze sessie)</h2><p>Analytics-ready events — er wordt niets verzonden en geen kentekens of persoonsgegevens vastgelegd.</p></div></div><div class="panel-body"><div class="event-log" data-events></div></div></section>`;
  },
  mount(root) {
    const s = Repo.settings();
    const logEl = $('[data-events]', root);
    const drawLog = () => { logEl.innerHTML = Analytics.events.length ? Analytics.events.slice().reverse().slice(0, 60).map((e) => `<div>${esc(e.at.slice(11, 19))}  ${esc(e.name)}  ${esc(JSON.stringify(e.props))}</div>`).join('') : '<div>Nog geen events in deze sessie.</div>'; };
    drawLog();
    const onEvt = () => drawLog();
    window.addEventListener('ct:analytics', onEvt);
    $('[data-ship]', root).addEventListener('submit', (e) => {
      e.preventDefault();
      const f = e.target; const errEl = $('[data-ship-err]', root);
      const next = s.shipping.map((m, i) => ({ ...m, label: f[`label-${i}`].value.trim(), description: f[`desc-${i}`].value.trim(), price: Money.parse(f[`price-${i}`].value || '0'), requiresAddress: f[`addr-${i}`].checked, enabled: f[`on-${i}`].checked }));
      if (next.some((m) => !m.label)) { errEl.textContent = 'Elke methode heeft een naam nodig.'; return; }
      if (next.some((m) => m.label.length > Content.LIMITS.shipLabel)) { errEl.textContent = `Een naam mag maximaal ${Content.LIMITS.shipLabel} tekens hebben.`; return; }
      if (next.some((m) => m.description.length > Content.LIMITS.shipDescription)) { errEl.textContent = `Een omschrijving mag maximaal ${Content.LIMITS.shipDescription} tekens hebben.`; return; }
      if (next.some((m) => !Number.isInteger(m.price) || m.price < 0)) { errEl.textContent = 'Vul geldige prijzen in (0 of meer).'; return; }
      if (!next.some((m) => m.enabled)) { errEl.textContent = 'Zet minimaal één leveringsmethode aan.'; return; }
      errEl.textContent = '';
      Repo.saveSettings({ ...Repo.settings(), shipping: next }); Toast.show('Verzending opgeslagen.');
    });
    $('[data-general]', root).addEventListener('submit', (e) => {
      e.preventDefault();
      const f = e.target; const vat = Number(f.vat.value); const low = Number(f.low.value);
      if (!Number.isInteger(vat) || vat < 0 || vat > 50) { Toast.show('Vul een geldig btw-percentage in (0–50).', { error: true }); return; }
      if (!Number.isInteger(low) || low < 0 || low > 999) { Toast.show('Vul een geldige drempel in.', { error: true }); return; }
      const cur = Repo.settings();
      Repo.saveSettings({ ...cur, vat: { ...cur.vat, rate: vat, showBreakdown: f.breakdown.checked }, lowStockThreshold: low });
      Toast.show('Instellingen opgeslagen.');
    });
    $('[data-lookup]', root).addEventListener('change', (e) => { Repo.saveSettings({ ...Repo.settings(), vehicleLookupMode: e.target.value }); Toast.show(e.target.value === 'live' ? 'Kentekens worden opgezocht via RDW Open Data.' : 'Alleen demo-kentekens worden herkend.'); });
    $('[data-export]', root).addEventListener('click', () => {
      downloadJson(`cartronic-producten-${new Date().toISOString().slice(0, 10)}.json`, { format: 'cartronic-products', version: 1, exportedAt: nowIso(), categories: Repo.shopCategories(), products: Repo.products() });
      Toast.show('Export gedownload.');
    });
    $('[data-import]', root).addEventListener('change', async (e) => {
      const file = e.target.files[0]; e.target.value = '';
      if (!file) return;
      if (file.size > 8 * 1024 * 1024) { Toast.show('Het bestand is te groot (max 8 MB).', { error: true }); return; }
      let data;
      try { data = JSON.parse(await file.text()); } catch (er) { Toast.show('Dit is geen geldig JSON-bestand.', { error: true }); return; }
      if (!data || data.format !== 'cartronic-products' || !Array.isArray(data.products) || !Array.isArray(data.categories)) { Toast.show('Onbekend formaat. Gebruik een export uit dit beheer.', { error: true }); return; }
      const cats = data.categories.filter((c) => c && typeof c.id === 'string' && typeof c.name === 'string').map((c, i) => ({ id: c.id, name: c.name.slice(0, 60), slug: slugify(c.slug || c.name), order: i + 1 }));
      const prevCats = Repo.shopCategories();
      Repo.saveShopCategories(cats); // temporary, to validate category references
      const problems = [];
      const products = data.products.map((x) => (x && typeof x === 'object' && !Array.isArray(x) ? x : {}))
        .map((p) => ({ ...blankProduct(), ...p, compatibility: { brands: [], models: [], note: '', ...(p.compatibility && typeof p.compatibility === 'object' ? p.compatibility : {}) }, images: Array.isArray(p.images) ? p.images : [] }));
      products.forEach((p, i) => {
        const er = validateProduct(p, products);
        if (!er.id && products.some((x, j) => j !== i && x.id === p.id)) er.id = 'Deze id komt twee keer voor.';
        if (Object.keys(er).length) problems.push(`${typeof p.name === 'string' && p.name ? p.name : `Product ${i + 1}`}: ${firstProductError(er)}`);
      });
      Repo.saveShopCategories(prevCats);
      if (problems.length) {
        Overlay.open({ title: 'Import afgebroken', size: 'sm', body: `<p class="text-small" style="margin-bottom:12px">${problems.length} product(en) zijn ongeldig. Er is niets gewijzigd.</p><ul class="text-small" style="padding-left:18px;display:grid;gap:6px">${problems.slice(0, 8).map((x) => `<li>${esc(x)}</li>`).join('')}</ul>`, foot: '<button class="btn btn--dark btn--sm" type="button" data-close>Sluiten</button>' });
        return;
      }
      if (await Overlay.confirm({ title: 'Producten importeren?', message: `${products.length} producten en ${cats.length} categorieën vervangen de huidige catalogus. Bestellingen blijven ongewijzigd.`, confirmLabel: 'Importeren' })) {
        // Stored in exactly the shape a publication uses (validated above, so nothing is shortened).
        Repo.saveShopCategories(cats); Repo.replaceProducts(products.map((p) => Content.cleanProduct(p))); Toast.show('Import voltooid.');
      }
    });
    $('[data-reset]', root).addEventListener('click', async () => {
      if (Content.stale) { Toast.show(RELOAD_FIRST, { error: true }); return; }
      if (await Overlay.confirm({ title: 'Demodata herstellen?', message: 'Producten, categorieën, bestellingen, projecten en instellingen worden teruggezet naar de gepubliceerde versie (of de oorspronkelijke demodata als er nog niets is gepubliceerd). Dit kan niet ongedaan worden gemaakt.', confirmLabel: 'Reset demodata', danger: true })) {
        Repo.reset(); Cart.clear(); Toast.show('Demodata hersteld.'); Router.render();
      }
    });
    return () => window.removeEventListener('ct:analytics', onEvt);
  },
});
