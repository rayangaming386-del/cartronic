/* =====================================================================
   ADMIN — WEBSITE (publiceren, bedrijfsgegevens, teksten, weergave, SEO)
   Edits are stored as a draft in this browser (Content.update) and show on the site straight
   away for the editor. "Publiceren" turns the draft into a new website file (zip) to upload.
   Production: the same bundle is saved through an authenticated CMS/API instead.
   ===================================================================== */

/* ---------- Shared helpers ---------- */
const SITE_IMAGE_LABELS = {
  about: 'Werkplaats — uitlijnbrug', hero: 'Audi MMI (homepage)', cat_aid: 'Active Info Display', cat_appconnect: 'App Connect',
  cat_audi_carplay: 'Audi Smartphone Interface', cat_mirror: 'Inklapbare spiegel', cat_nav: 'Navigatie', proj_golf8: 'Golf 8 — grille met LED',
  proj_ibiza: 'SEAT Ibiza — camera', proj_kalibratie: 'Kalibratie',
};
const UNSAVED_MSG = 'U heeft wijzigingen die nog niet zijn opgeslagen.';

/** Form field markup. o: { name, label, value, hint, multi, rows, max, placeholder, type, half, opt, attrs, id } */
function saField(o) {
  const id = `sa-${String(o.id || o.name).replace(/[^a-z0-9_-]/gi, '-')}`;
  // A multi-line field gets no maxlength (a pasted text would be cut off unseen): showErrors checks data-max.
  const common = `id="${id}" name="${attr(o.name)}"${o.max ? (o.multi ? ` data-max="${o.max}"` : ` maxlength="${o.max}"`) : ''}${o.placeholder ? ` placeholder="${attr(o.placeholder)}"` : ''}${o.attrs || ''}`;
  const control = o.multi
    ? `<textarea class="textarea${(o.rows || 3) <= 3 ? ' textarea--sm' : ''}" rows="${o.rows || 3}" ${common}>${esc(o.value == null ? '' : o.value)}</textarea>`
    : `<input class="input" type="${o.type || 'text'}" ${common} value="${attr(o.value == null ? '' : o.value)}">`;
  return `<div class="field${o.half ? '' : ' span-2'}"><label for="${id}">${esc(o.label)}${o.opt ? ' <span class="opt">(optioneel)</span>' : ''}</label>${control}${o.hint ? `<span class="hint">${o.hint}</span>` : ''}<span class="field-error" data-err="${attr(o.name)}"></span></div>`;
}
const saSwitch = (name, label, on, hint = '') => `<div class="span-2"><label class="switch"><input type="checkbox" name="${attr(name)}"${on ? ' checked' : ''}><span class="track"></span>${esc(label)}</label>${hint ? `<p class="hint mt-8">${hint}</p>` : ''}</div>`;
/** Sticky save bar at the bottom of a form page; `inline` puts it at the foot of a panel instead. */
const saveBar = (label = 'Opslaan', extra = '', { inline = false } = {}) => `<div class="${inline ? 'panel-save' : 'save-bar'}"><span class="sb-status" data-sb>Alle wijzigingen opgeslagen</span><div class="sb-actions">${extra}<button class="btn btn--primary btn--sm" type="submit">${esc(label)}</button></div></div>`;
/** Marks a form dirty on input and keeps unsaved work from being lost by navigating away. */
function trackDirty(form) {
  const st = { dirty: false };
  const sb = $('[data-sb]', form);
  st.set = (v) => {
    st.dirty = v;
    if (sb) { sb.textContent = v ? 'Niet-opgeslagen wijzigingen' : 'Alle wijzigingen opgeslagen'; sb.classList.toggle('is-dirty', v); }
  };
  form.addEventListener('input', (e) => { st.set(true); if (e.target.dataset && e.target.dataset.max) overMax(form, e.target); });
  form.addEventListener('change', (e) => { if (!e.target.matches('[type="file"]')) st.set(true); });
  Router.setGuard(() => (st.dirty ? UNSAVED_MSG : null));
  return st;
}
const maxMsg = (el) => `Maximaal ${Number(el.dataset.max).toLocaleString('nl-NL')} tekens (nu ${el.value.length.toLocaleString('nl-NL')}). Maak de tekst korter.`;
/** Live message on a multi-line field that is longer than its maximum (nothing is cut off). */
function overMax(form, el) {
  const box = form.querySelector(`[data-err="${CSS.escape(el.name)}"]`);
  const over = el.value.length > Number(el.dataset.max);
  if (box && (over || box.dataset.maxShown)) { box.textContent = over ? maxMsg(el) : ''; box.dataset.maxShown = over ? '1' : ''; }
  if (over) el.setAttribute('aria-invalid', 'true'); else if (box && !box.textContent) el.removeAttribute('aria-invalid');
}
/** Shows field errors ({name: message}); focuses the first. Returns true when there are none.
    Multi-line fields longer than their maximum (data-max) are reported here too. */
function showErrors(form, errs) {
  const fromMax = new Set();
  $$('[data-max]', form).forEach((el) => { if (el.name && el.value.length > Number(el.dataset.max) && !errs[el.name]) { errs[el.name] = maxMsg(el); fromMax.add(el.name); } });
  // A length message keeps updating while the text is edited (see overMax); other messages stay until the next save.
  $$('[data-err]', form).forEach((el) => { el.textContent = errs[el.dataset.err] || ''; el.dataset.maxShown = fromMax.has(el.dataset.err) ? '1' : ''; });
  $$('[aria-invalid]', form).forEach((el) => el.removeAttribute('aria-invalid'));
  const keys = Object.keys(errs);
  keys.forEach((k) => { const el = form.elements[k]; if (el && el.setAttribute) el.setAttribute('aria-invalid', 'true'); });
  if (keys.length) {
    const first = form.elements[keys[0]];
    const det = first && first.closest && first.closest('details'); if (det) det.open = true; // a closed panel (Categorieën)
    if (first && first.focus) first.focus();
    Toast.show(Object.values(errs)[0], { error: true });
  }
  return !keys.length;
}
const DECIDE_FIRST = 'Kies eerst met welke versie u verder wilt werken (zie de melding bovenaan).';
const RELOAD_FIRST = 'In deze browser is een andere versie van de website geopend. Er is niets opgeslagen; zie de melding bovenaan.';
/** Applies a change to the website draft; false (with a message) while a decision on a newer publication is pending. */
function saveContent(fn, message = 'Opgeslagen. De wijziging staat direct op de website in deze browser.') {
  if (Content.stale) { Toast.show(RELOAD_FIRST, { error: true }); return false; }
  if (Content.parked || !Content.update(fn)) { Toast.show(Content.stale ? RELOAD_FIRST : DECIDE_FIRST, { error: true }); return false; }
  if (message) Toast.show(message);
  return true;
}
/** The fields of a form whose value differs from when it was shown. Saving only those keeps
    changes that were saved meanwhile (for example in another tab) in the other fields. */
const changedKeys = (shown, next) => Object.keys(next).filter((k) => stableStringify(next[k]) !== stableStringify(shown[k]));
const isObj = (o) => !!o && typeof o === 'object' && !Array.isArray(o);
/** First message for a list that is too long or has too long items, or ''. */
function listLimit(list, max, maxLen, what) {
  if (list.length > max) return `Gebruik maximaal ${max} ${what}.`;
  const long = list.find((x) => String(x).length > maxLen);
  return long ? `Maximaal ${maxLen} tekens per regel; deze is te lang: “${String(long).slice(0, 40)}…”.` : '';
}
const linkLabelError = (links) => ((links || []).some(([l]) => l.length > 80) ? 'Een linktekst mag maximaal 80 tekens hebben.' : '');
const lines = (s) => String(s || '').split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
const csv = (s) => uniq(String(s || '').split(',').map((x) => x.trim()).filter(Boolean));
/** "Label | adres" per line → [[label, href]]; returns null when a line is invalid. */
function parseLinks(text) {
  const out = [];
  for (const l of lines(text)) {
    const [label, url] = l.split('|').map((x) => (x || '').trim());
    const href = Content.safeHref(url || '');
    if (!label || !href) return null;
    out.push([label, href]);
  }
  return out;
}
const linksText = (links) => (links || []).map(([l, h]) => `${l} | ${h}`).join('\n');

/* ---------- Image picker: built-in photo, upload, web address or illustration ---------- */
function imagePicker(name, value, { label = 'Foto', kind = 'camera', hint = '' } = {}) {
  const v = value || '';
  const builtIn = !!v && !v.includes(':') ? v : (v.startsWith('img:') ? v.slice(4) : '');
  const custom = v && !builtIn ? v : '';
  const keys = Object.keys(window.CT_IMAGES || {}).sort();
  return `<div class="field span-2" data-picker="${attr(name)}"><span class="label">${esc(label)}</span>
    <div class="picker">
      <div class="picker-preview" data-picker-preview>${Media.html(v ? imgRef(v) : `art:${kind}:0`, '', { kind })}</div>
      <div class="picker-controls">
        <label class="sr-only" for="pk-${attr(name)}">${esc(label)}: keuze</label>
        <select class="select select--sm" id="pk-${attr(name)}" data-picker-select>
          <option value=""${!v ? ' selected' : ''}>Geen foto (illustratie)</option>
          ${keys.map((k) => `<option value="${attr(k)}"${builtIn === k ? ' selected' : ''}>${esc(SITE_IMAGE_LABELS[k] || k)}</option>`).join('')}
          <option value="__custom"${custom ? ' selected' : ''}>${custom.startsWith('data:') ? 'Geüploade foto' : 'Eigen foto (upload of webadres)'}</option>
        </select>
        <div class="picker-custom"${custom ? '' : ' hidden'} data-picker-custom>
          <input class="input input--sm" type="url" data-picker-url placeholder="https://…" value="${attr(custom.startsWith('https:') ? custom : '')}" aria-label="${attr(label)}: webadres">
          <input type="file" accept="image/png,image/jpeg,image/webp" data-picker-file aria-label="${attr(label)} uploaden">
        </div>
        <input type="hidden" name="${attr(name)}" value="${attr(v)}">
        ${hint ? `<span class="hint">${hint}</span>` : ''}
      </div>
    </div></div>`;
}
function mountPickers(root) {
  $$('[data-picker]', root).forEach((box) => {
    const hidden = $(`input[type="hidden"]`, box);
    const sel = $('[data-picker-select]', box); const custom = $('[data-picker-custom]', box);
    const url = $('[data-picker-url]', box); const file = $('[data-picker-file]', box); const prev = $('[data-picker-preview]', box);
    const set = (v) => { hidden.value = v; prev.innerHTML = Media.html(v ? imgRef(v) : 'art:camera:0', '', { kind: 'camera' }); hidden.dispatchEvent(new Event('input', { bubbles: true })); };
    sel.addEventListener('change', () => {
      custom.hidden = sel.value !== '__custom';
      if (sel.value !== '__custom') set(sel.value);
      else if (url.value.trim()) set(url.value.trim());
    });
    url.addEventListener('change', () => { const u = url.value.trim(); if (!u) return; if (!Content.httpsUrl(u)) { Toast.show('Gebruik een webadres dat met https:// begint.', { error: true }); return; } set(u); });
    file.addEventListener('change', async () => {
      if (!file.files[0]) return;
      try { set(await readImageFile(file.files[0], 1200)); url.value = ''; Toast.show('Foto toegevoegd. Vergeet niet op te slaan.'); }
      catch (er) { Toast.show(er.message, { error: true }); } finally { file.value = ''; }
    });
  });
}

/* ---------- Publication status ---------- */
const SiteStatus = {
  changes() { const c = Content.changes(); if (Repo.shopDirty()) c.push('Webshop & projecten'); return c; },
  publishedLabel() { return Content.pubStamp ? fmtDateTime(Content.pubStamp) : 'nog niet gepubliceerd (standaardinhoud)'; },
  topPill() {
    const n = this.changes().length;
    return n ? `<a class="pill pill--warn" href="#/admin/website" title="Bekijk wat nog gepubliceerd moet worden">${icon('upload')} ${n} niet gepubliceerd</a>` : '';
  },
  /** For an editor on a public page of an outdated version: a short note (no change to the page itself). */
  staleHint() {
    if (Content.stale) Toast.show('In deze browser is een andere versie van de website geopend dan deze pagina (bijvoorbeeld na het terugzetten van een oudere versie). Beheer laat zien hoe u verder kunt.', { action: { label: 'Naar Beheer', href: '#/admin' } });
  },
  /** True while publishing must wait: a newer publication awaits the editor's decision, or this tab is outdated. */
  undecided() { return Content.stale || Content.parked || Repo.shopParked; },
  /** Why publishing (or a backup) cannot happen now, or ''. */
  blocked() { return Content.stale ? RELOAD_FIRST : (this.undecided() ? DECIDE_FIRST : ''); },
  parkedNotice() {
    if (Content.stale) {
      return UI.notice('<strong>Deze pagina is verouderd.</strong> In deze browser is een andere versie van de website geopend (bijvoorbeeld de nieuwe versie na het uploaden). Werk verder in die nieuwste versie: open of herlaad die pagina. Wilt u bewust met déze versie verder (bijvoorbeeld omdat u een oudere versie terugzet), kies dan “Met deze versie verder”.',
        { type: 'warn', ic: 'alert', actions: '<button class="btn btn--dark btn--xs" type="button" data-reload>Pagina opnieuw laden</button><button class="btn btn--light btn--xs" type="button" data-adopt>Met deze versie verder</button>' });
    }
    if (!this.undecided()) return '';
    const shown = Repo.shopParked
      ? (Content.parked ? 'Tot u kiest, ziet u de gepubliceerde teksten en inhoud; producten, projecten en webshopinstellingen zijn nog uw eigen concept.' : 'Producten, projecten en webshopinstellingen in deze browser zijn nog uw eigen concept.')
      : 'Tot u kiest, ziet u de gepubliceerde inhoud.';
    // A rollback: the concept (texts, or else the webshop data) is based on a newer version than this page.
    const rollback = Content.parked ? Content.draftBase > Content.pubStamp : (Repo.shopParked && Storage.get('pubStamp', '') > Content.pubStamp);
    return UI.notice(`${rollback ? '<strong>Er is een oudere versie van de website teruggezet.</strong> Uw concept in deze browser is gebaseerd op een nieuwere versie en bevat wijzigingen die nog niet zijn gepubliceerd.' : '<strong>Er staat een nieuwere gepubliceerde versie online.</strong> Uw concept in deze browser is gebaseerd op een oudere versie.'} Kies met welke versie u verder wilt werken; publiceren kan pas daarna. ${shown}`,
      { type: 'warn', ic: 'alert', actions: '<button class="btn btn--dark btn--xs" type="button" data-parked="published">Gepubliceerde versie gebruiken</button><button class="btn btn--light btn--xs" type="button" data-parked="keep">Mijn concept behouden</button>' });
  },
};
document.addEventListener('click', async (e) => {
  if (e.target.closest('[data-reload]')) { location.reload(); return; }
  if (e.target.closest('[data-adopt]')) {
    // One question (also about unsaved text in the open form), asked as an open question: no second dialog.
    const msg = `Deze versie wordt in deze browser de actuele en de pagina wordt opnieuw geladen. Andere tabbladen met een andere versie stoppen dan met opslaan. Publiceert u hierna, dan vervangt deze versie de nieuwere op de website.${Router.hasUnsaved() ? ' Wijzigingen in het formulier die nog niet zijn opgeslagen, gaan verloren.' : ''}`;
    if (!(await Router.whileAsking(() => Overlay.confirm({ title: 'Met deze versie verder?', message: msg, confirmLabel: 'Met deze versie verder' })))) return;
    Router.setGuard(null); // the reload must not be stopped half-way
    Content.adoptVersion(); location.reload(); return;
  }
  const b = e.target.closest('[data-parked]');
  if (!b) return;
  if (Content.stale) { Toast.show(RELOAD_FIRST, { error: true }); return; }
  // The page is rebuilt with the chosen version: text typed in the open form would be lost, so that is asked
  // just before anything changes (after the choice itself is confirmed).
  if (b.dataset.parked === 'published') {
    // Only the part that waits for a decision is thrown away; later changes to the other part stay.
    const content = Content.parked; const shop = Repo.shopParked;
    if (!content && !shop) { Router.render(); return; }
    const what = content && shop ? 'Uw concept in deze browser (website-inhoud én webshopgegevens) wordt weggegooid.'
      : (content ? 'Uw concept van de website-inhoud in deze browser wordt weggegooid. Wijzigingen in producten, projecten en webshopinstellingen blijven staan.'
        : 'Uw concept van producten, projecten en webshopinstellingen in deze browser wordt weggegooid. Wijzigingen in de website-inhoud blijven staan.');
    // One question, also about unsaved text in the open form (the page is rebuilt), asked as an open question.
    const unsaved = Router.hasUnsaved() ? ' Wijzigingen in het formulier die nog niet zijn opgeslagen, gaan ook verloren.' : '';
    if (!(await Router.whileAsking(() => Overlay.confirm({ title: 'Gepubliceerde versie gebruiken?', message: `${what}${unsaved} Dit kan niet ongedaan worden gemaakt.`, confirmLabel: 'Concept weggooien', danger: true })))) return;
    if (Content.stale) { Toast.show(RELOAD_FIRST, { error: true }); return; }
    Router.setGuard(null);
    if (content && Content.parked) Content.discardDraft();
    if (shop && Repo.shopParked) { Repo.loadPublishedShop(); Cart.validate(); }
    Toast.show('U werkt nu met de gepubliceerde versie.');
  } else {
    if (!(await Router.confirmLeave())) return;
    if (Content.parked) Content.resumeParked();
    if (Repo.shopParked) { Storage.set('pubStamp', Content.pubStamp); Repo.shopParked = false; Repo.markShopBase(Content.publishedShop()); }
    Toast.show('Uw concept is weer actief.');
  }
  Router.render();
});
// Another tab opened a different publication: show it at once in Beheer.
Bus.on('content:stale', () => {
  const el = document.querySelector('[data-site-notice]');
  if (el) el.innerHTML = SiteStatus.parkedNotice();
  if (document.body.classList.contains('is-admin')) Toast.show(RELOAD_FIRST, { error: true });
  else SiteStatus.staleHint();
});

/* ---------- Publisher: rebuilds this page as a complete website ---------- */
const Zip = {
  table: null,
  crc(bytes) {
    if (!this.table) {
      this.table = new Uint32Array(256);
      for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; this.table[n] = c >>> 0; }
    }
    let c = 0xFFFFFFFF;
    for (let i = 0; i < bytes.length; i++) c = this.table[(c ^ bytes[i]) & 0xFF] ^ (c >>> 8);
    return (c ^ 0xFFFFFFFF) >>> 0;
  },
  /** Stored (uncompressed) zip with UTF-8 names: files = [{ name, data: string | Uint8Array }]. */
  build(files) {
    const enc = new TextEncoder();
    const d = new Date();
    const time = (d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2);
    const date = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    const out = []; const central = []; let offset = 0;
    files.forEach((f) => {
      const name = enc.encode(f.name);
      const data = typeof f.data === 'string' ? enc.encode(f.data) : f.data;
      const crc = this.crc(data);
      const h = new DataView(new ArrayBuffer(30));
      h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint16(8, 0, true);
      h.setUint16(10, time, true); h.setUint16(12, date, true); h.setUint32(14, crc, true);
      h.setUint32(18, data.length, true); h.setUint32(22, data.length, true); h.setUint16(26, name.length, true); h.setUint16(28, 0, true);
      out.push(new Uint8Array(h.buffer), name, data);
      const c = new DataView(new ArrayBuffer(46));
      c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true); c.setUint16(10, 0, true);
      c.setUint16(12, time, true); c.setUint16(14, date, true); c.setUint32(16, crc, true);
      c.setUint32(20, data.length, true); c.setUint32(24, data.length, true); c.setUint16(28, name.length, true);
      c.setUint16(30, 0, true); c.setUint16(32, 0, true); c.setUint16(34, 0, true); c.setUint16(36, 0, true); c.setUint32(38, 0, true); c.setUint32(42, offset, true);
      central.push(new Uint8Array(c.buffer), name);
      offset += 30 + name.length + data.length;
    });
    const size = central.reduce((s, p) => s + p.length, 0);
    const end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true); end.setUint16(4, 0, true); end.setUint16(6, 0, true);
    end.setUint16(8, files.length, true); end.setUint16(10, files.length, true); end.setUint32(12, size, true); end.setUint32(16, offset, true); end.setUint16(20, 0, true);
    return new Blob([...out, ...central, new Uint8Array(end.buffer)], { type: 'application/zip' });
  },
};
function downloadBlob(name, blob) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
}
/** Every indexable page of the site (also the basis of sitemap.xml and the SEO overview). */
function sitePages() {
  const out = [];
  const add = (path, label, group) => out.push({ path, label, group });
  add('/', 'Home', 'Pagina’s');
  add('/mogelijkheden', 'Mogelijkheden', 'Pagina’s');
  add('/merken', 'Merken', 'Pagina’s');
  add('/projecten', 'Projecten', 'Pagina’s');
  add('/expertise', 'Expertise', 'Pagina’s');
  add('/over', 'Over CarTronic', 'Pagina’s');
  add('/contact', 'Contact', 'Pagina’s');
  add('/beoordelingen', 'Beoordelingen', 'Pagina’s');
  add('/kennis', 'Berichten & kennis', 'Pagina’s');
  add('/productinformatie', 'Productinformatie', 'Pagina’s');
  add('/privacy', 'Privacy', 'Pagina’s');
  if (Content.shopOn()) add('/webshop', 'Webshop', 'Pagina’s');
  BRANDS.forEach((b) => add(`/merken/${b.id}`, b.name, 'Merken'));
  SERVICES.forEach((s) => add(`/diensten/${s.slug}`, s.title, 'Diensten'));
  ARTICLES.forEach((a) => add(`/kennis/${a.slug}`, a.title, 'Berichten'));
  Repo.projects().filter((p) => p.active).forEach((p) => add(`/projecten/${p.slug}`, p.title, 'Projecten'));
  if (Content.shopOn()) Repo.products().filter(isPublicProduct).forEach((p) => add(`/webshop/${p.slug}`, p.name, 'Webshop'));
  RETROFITS.forEach((r) => add(`/mogelijkheden/${r.slug}`, r.title, 'Opties'));
  return out;
}
/** Title, description and indexing of a page as search engines will see it. */
function pageSeo(path) {
  const { page, params, found } = Router.resolve(path);
  let meta = {};
  try { meta = typeof page.meta === 'function' ? page.meta({ path, query: {}, params, url: path }) : (page.meta || {}); } catch (e) { meta = {}; }
  const r = Seo.resolve(meta, path);
  return { ...r, found, base: meta };
}
const Publisher = {
  decode(b64) { const bin = atob(b64.trim()); const bytes = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i); return new TextDecoder().decode(bytes); },
  parts() {
    const get = (id) => { const el = document.getElementById(id); if (!el) throw new Error(`Onderdeel "${id}" ontbreekt in deze pagina.`); return el.textContent.trim(); };
    const tpl64 = get('ctTemplate');
    if (!tpl64 || tpl64.includes('__TEMPLATE__')) throw new Error('Deze versie van de pagina bevat geen publicatiesjabloon.');
    return { tpl64, template: this.decode(tpl64), css: get('ctStyles'), js: get('ctApp'), images: get('ctImages') };
  },
  /** The bundle that a publication embeds: the working content plus the webshop data. */
  bundle(stamp) {
    const b = Content.working();
    delete b.base; delete b.baseFp; delete b.updatedAt;
    b.v = 1; b.stamp = stamp;
    b.shop = Repo.shopSnapshot();
    return b;
  },
  base() {
    const site = Content.seo().siteUrl;
    if (!site) return '/';
    try { const p = new URL(site).pathname.replace(/\/+$/, ''); return `${p}/`; } catch (e) { return '/'; }
  },
  head({ ogImage }) {
    const s = Content.seo();
    const home = Seo.resolve(Pages.home.meta(), '/');
    const site = s.siteUrl ? `${s.siteUrl}/` : '';
    const m = (attrName, k, v) => (v ? `<meta ${attrName}="${k}" content="${attr(v)}">` : '');
    const homeOv = s.pages['/'] || {};
    return [
      `<title>${esc(home.title)}</title>`,
      m('name', 'description', home.description),
      m('name', 'robots', s.noindex ? 'noindex, nofollow' : 'index, follow'),
      // No canonical or og:url here: this same file answers every address, so the page sets both per route.
      m('property', 'og:type', 'website'), m('property', 'og:locale', 'nl_NL'), m('property', 'og:site_name', COMPANY.name),
      m('property', 'og:title', homeOv.title || s.ogTitle), m('property', 'og:description', homeOv.description || s.ogDescription),
      ogImage && site ? `${m('property', 'og:image', `${site}og-image.jpg`)}\n${m('property', 'og:image:width', '1200')}\n${m('property', 'og:image:height', '630')}` : '',
      m('name', 'twitter:card', 'summary_large_image'),
      m('name', 'google-site-verification', s.google), m('name', 'msvalidate.01', s.bing),
    ].filter(Boolean).join('\n');
  },
  /** The complete HTML of the website, with the given bundle embedded. */
  html(bundle, { ogImage = false } = {}) {
    const p = this.parts();
    let tpl = p.template;
    const SEO_BLOCK = new RegExp('<!' + '--ct:seo-->[\\s\\S]*?<!' + '--/ct:seo-->');
    const ORG = /<script type="application\/ld\+json" id="ctOrgLd">[\s\S]*?<\/script>/;
    const BASE = /<meta name="ct-base" content="[^"]*">/;
    [[SEO_BLOCK, 'SEO-blok'], [ORG, 'bedrijfsgegevens (JSON-LD)'], [BASE, 'ct-base']].forEach(([re, name]) => { if (!re.test(tpl)) throw new Error(`Het sjabloon mist: ${name}.`); });
    const NOSCRIPT = /(<div class="noscript">\s*)[\s\S]*?(<br>)/;
    if (!NOSCRIPT.test(tpl)) throw new Error('Het sjabloon mist: noscript-tekst.');
    const close = '<' + '/script>';
    // Editor text is inserted before the placeholders are filled, so a "*" in it is written as an
    // equivalent escape: "/*__JS__*" can then never appear in it and be expanded.
    const htmlSafe = (s) => s.replace(/\*/g, '&#42;');
    const org = JSON.stringify(Seo.organization(), null, 2).replace(/</g, '\\u003c').replace(/\*/g, '\\u002a');
    const c = COMPANY;
    tpl = tpl.replace(SEO_BLOCK, () => `<!${'--'}ct:seo-->\n${htmlSafe(this.head({ ogImage }))}\n<!${'--'}/ct:seo-->`)
      .replace(ORG, () => `<script type="application/ld+json" id="ctOrgLd">\n${org}\n${close}`)
      .replace(BASE, () => `<meta name="ct-base" content="${htmlSafe(attr(this.base()))}">`)
      .replace(NOSCRIPT, (mm, a, b) => `${a}${htmlSafe(`<strong>${esc(c.name)}</strong> — ${esc(c.street)}, ${esc(c.postal)} ${esc(c.city)} · ${esc(c.phoneDisplay)} · ${esc(c.email)}`)}${b}`);
    const json = JSON.stringify(bundle).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
    const map = { CSS: p.css, JS: p.js, IMAGES: p.images, CONTENT: json, TEMPLATE: p.tpl64 };
    const filled = new Set();
    const out = tpl.replace(/\/\*__(CSS|JS|IMAGES|CONTENT|TEMPLATE)__\*\//g, (mm, k) => { filled.add(k); return map[k]; });
    if (filled.size !== Object.keys(map).length) throw new Error('Het sjabloon kon niet volledig worden gevuld.');
    return out;
  },
  sitemap(stamp) {
    const s = Content.seo();
    if (!s.siteUrl || s.noindex) return null;
    const day = stamp.slice(0, 10);
    const urls = sitePages().filter((p) => !pageSeo(p.path).noindex).map((p) => Seo.url(p.path));
    if (!pageSeo('/mogelijkheden').noindex) {
      MODELS.forEach((m) => { if (RETROFITS.some((r) => r.models.includes(m.id))) urls.push(Seo.url(`/mogelijkheden?merk=${m.brand}&model=${m.id}`)); });
    }
    const xmlEsc = (u) => u.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${uniq(urls).map((u) => `  <url><loc>${xmlEsc(u)}</loc><lastmod>${day}</lastmod></url>`).join('\n')}\n</urlset>\n`;
  },
  robots() {
    const s = Content.seo();
    const base = this.base();
    if (s.noindex) return 'User-agent: *\nDisallow: /\n';
    return `User-agent: *\nDisallow: ${base}admin\n${s.siteUrl ? `\nSitemap: ${s.siteUrl}/sitemap.xml\n` : ''}`;
  },
  redirects() {
    const b = this.base();
    return `# Netlify: elke pagina wordt door index.html getoond (nette URL's).\n${b === '/' ? '' : `/    ${b}    301\n`}${b}*    ${b}index.html    200\n`;
  },
  /** Vercel: the same clean addresses as _redirects (existing files such as sitemap.xml are served first). */
  vercel() {
    const b = this.base();
    const conf = b === '/'
      ? { rewrites: [{ source: '/(.*)', destination: '/index.html' }] }
      : { redirects: [{ source: '/', destination: b, permanent: true }], rewrites: [{ source: `${b}(.*)`, destination: `${b}index.html` }] };
    return `${JSON.stringify(conf, null, 2)}\n`;
  },
  readme(stamp) {
    return [
      'CarTronic — website', `Gepubliceerd: ${fmtDateTime(stamp)}`, '',
      'Online zetten (Netlify):',
      '1. Pak dit zip-bestand uit. U krijgt de map "cartronic-website".',
      '2. Ga naar app.netlify.com → uw site → Deploys.',
      '3. Sleep de HELE map "cartronic-website" naar het vak "Drag and drop your site output folder here".',
      '4. Wacht tot de deploy klaar is en controleer de website.', '',
      'Online zetten (Vercel, gekoppeld aan GitHub):',
      '1. Pak dit zip-bestand uit en open de map "cartronic-website".',
      '2. Ga op github.com naar uw repository → Add file → Upload files.',
      '3. Sleep ALLE bestanden en mappen uit "cartronic-website" (niet de map zelf) naar het vak en klik op Commit changes.',
      '4. Vercel zet de nieuwe versie daarna vanzelf online. Controleer de website.', '',
      ...(this.base() === '/' ? [] : [`De website staat in de submap "${this.base().slice(1, -1)}" (volgens het website-adres in Beheer → SEO). Laat de mappen en bestanden staan zoals ze in de zip zitten.`, '']),
      'Inhoud van de map:',
      '- index.html   de website (alle inhoud, teksten, foto’s en instellingen zitten erin)',
      '- 404.html     kopie van de website voor servers zonder _redirects',
      '- _redirects   zorgt dat nette adressen zoals /mogelijkheden werken (Netlify)',
      '- vercel.json  hetzelfde voor Vercel',
      '- robots.txt   instructies voor zoekmachines',
      '- sitemap.xml  lijst van alle pagina’s voor zoekmachines (als het website-adres is ingevuld)',
      '- og-image.jpg afbeelding voor links die worden gedeeld via WhatsApp, Facebook en LinkedIn', '',
      'Let op: wijzigingen in Beheer staan eerst alleen in uw browser. Pas na publiceren en uploaden ziet iedereen ze.', '',
    ].join('\n');
  },
  /** 1200×630 JPEG of the homepage photo for link previews; null when it cannot be made. */
  async ogImage() {
    const src = Media.src('img:hero');
    if (!src) return null;
    try {
      const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; });
      const c = document.createElement('canvas'); c.width = 1200; c.height = 630;
      const scale = Math.max(1200 / img.naturalWidth, 630 / img.naturalHeight);
      const w = img.naturalWidth * scale; const h = img.naturalHeight * scale;
      c.getContext('2d').drawImage(img, (1200 - w) / 2, (630 - h) / 2, w, h);
      const blob = await new Promise((res) => c.toBlob(res, 'image/jpeg', 0.86));
      return blob ? new Uint8Array(await blob.arrayBuffer()) : null;
    } catch (e) { return null; }
  },
  /** Builds all files of the website. */
  async files() {
    const stamp = nowIso();
    const og = await this.ogImage();
    const bundle = this.bundle(stamp);
    const html = this.html(bundle, { ogImage: !!og });
    const dir = 'cartronic-website/';
    // Host-level files sit at the root; the site itself in the sub-path of the website address (if any).
    const sub = dir + this.base().slice(1);
    const files = [
      { name: `${sub}index.html`, data: html },
      { name: `${dir}404.html`, data: html },
      { name: `${dir}_redirects`, data: this.redirects() },
      { name: `${dir}vercel.json`, data: this.vercel() },
      { name: `${dir}robots.txt`, data: this.robots() },
      { name: `${dir}LEESMIJ.txt`, data: this.readme(stamp) },
    ];
    const sm = this.sitemap(stamp);
    if (sm) files.push({ name: `${sub}sitemap.xml`, data: sm });
    if (og) files.push({ name: `${sub}og-image.jpg`, data: og });
    return { stamp, files, html, bytes: new Blob([html]).size };
  },
};

/* ---------- Dashboard: website status ---------- */
function websiteStatusPanel() {
  const ch = SiteStatus.changes();
  const s = Content.seo();
  return `<section class="panel"><div class="panel-head"><div><h2>Website</h2><p>Gepubliceerd: ${esc(SiteStatus.publishedLabel())}</p></div><a class="btn btn--primary btn--sm" href="#/admin/website">${icon('upload')} Publiceren</a></div>
    <div class="panel-body" style="display:grid;gap:14px">
      ${ch.length ? `<p class="text-small"><strong>Nog niet gepubliceerd:</strong> ${ch.map(esc).join(', ')}.</p>` : '<p class="text-small text-muted">Alle wijzigingen zijn gepubliceerd.</p>'}
      ${s.noindex ? UI.notice('<strong>Zoekmachines staan uit.</strong> De website wordt niet geïndexeerd (Beheer → SEO).', { type: 'warn', ic: 'eyeOff' }) : ''}
      <div class="flex wrap gap-8">
        <a class="btn btn--light btn--sm" href="#/admin/teksten">${icon('pencil')} Teksten</a>
        <a class="btn btn--light btn--sm" href="#/admin/opties">${icon('layers')} Opties</a>
        <a class="btn btn--light btn--sm" href="#/admin/bedrijf">${icon('store')} Bedrijfsgegevens</a>
        <a class="btn btn--light btn--sm" href="#/admin/seo">${icon('search')} SEO</a>
        <a class="btn btn--light btn--sm" href="#/admin/weergave">${icon('eye')} Weergave</a>
      </div>
    </div></section>`;
}

/* ---------- Publiceren ---------- */
Pages.adminWebsite = adminPage({
  key: 'website', title: 'Publiceren',
  render() {
    const ch = SiteStatus.changes();
    const s = Content.seo();
    let used = 0;
    try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k && k.startsWith(Storage.PREFIX)) used += (localStorage.getItem(k) || '').length * 2; } } catch (e) { used = 0; }
    const pct = Math.min(100, Math.round((used / (5 * 1024 * 1024)) * 100));
    return `<section class="panel"><div class="panel-head"><div><h2>Status</h2><p>Gepubliceerde versie: ${esc(SiteStatus.publishedLabel())}</p></div>${ch.length ? `<span class="pill pill--warn">${ch.length} onderdelen gewijzigd</span>` : '<span class="pill pill--ok">Alles gepubliceerd</span>'}</div>
        <div class="panel-body" style="display:grid;gap:16px">
          ${ch.length ? `<p>Gewijzigd sinds de laatste publicatie: <strong>${ch.map(esc).join(', ')}</strong>.</p>` : '<p class="text-muted">Er zijn geen wijzigingen die nog gepubliceerd moeten worden.</p>'}
          ${UI.notice('<strong>Zo werkt publiceren.</strong> Alles wat u in Beheer wijzigt, ziet u direct op de website in déze browser. Bezoekers zien het pas nadat u de nieuwe website downloadt en uploadt. Klik op <em>Download website</em>, pak het zip-bestand uit en sleep de map <em>cartronic-website</em> naar Netlify (Deploys → drag and drop). Gebruikt u Vercel met GitHub, upload dan de inhoud van die map naar uw repository (zie LEESMIJ.txt in de zip).', { ic: 'info' })}
          ${!s.siteUrl ? UI.notice('<strong>Website-adres ontbreekt.</strong> Vul het adres in bij Beheer → SEO, anders worden er geen sitemap en canonieke adressen gemaakt.', { type: 'warn', ic: 'alert' }) : ''}
          ${s.noindex ? UI.notice('<strong>Zoekmachines staan uit.</strong> De gepubliceerde website vraagt zoekmachines om niets te indexeren. Zet dit uit bij Beheer → SEO zodra de website definitief online staat.', { type: 'warn', ic: 'eyeOff' }) : ''}
          <div class="flex wrap gap-8">
            <button class="btn btn--primary" type="button" data-publish>${icon('download')} Download website (zip)</button>
            <button class="btn btn--light" type="button" data-publish-html>${icon('file')} Alleen index.html</button>
          </div>
          <p class="hint">De zip bevat index.html, 404.html, _redirects, vercel.json, robots.txt${s.siteUrl && !s.noindex ? ', sitemap.xml' : ''} en og-image.jpg. Bewaar ook een back-up (hieronder) voordat u grote wijzigingen doet.</p>
          <div data-publish-result></div>
        </div></section>
      <div class="dash-grid">
        <section class="panel"><div class="panel-head"><div><h2>Back-up</h2><p>Alle website-inhoud en webshopgegevens in één bestand</p></div></div><div class="panel-body" style="display:grid;gap:12px">
          <div class="flex wrap gap-8">
            <button class="btn btn--light btn--sm" type="button" data-backup>${icon('download')} Exporteer back-up (JSON)</button>
            <label class="btn btn--light btn--sm" style="cursor:pointer">${icon('upload')} Importeer back-up<input type="file" accept="application/json,.json" data-restore-file class="sr-only"></label>
          </div>
          <p class="hint">Een back-up bevat teksten, bedrijfsgegevens, opties, diensten, berichten, beoordelingen, weergave, SEO, producten, categorieën, projecten en webshopinstellingen. Bestellingen zitten er niet in.</p>
        </div></section>
        <section class="panel"><div class="panel-head"><div><h2>Terugzetten</h2><p>Wijzigingen ongedaan maken</p></div></div><div class="panel-body" style="display:grid;gap:12px">
          <div class="flex wrap gap-8">
            <button class="btn btn--light btn--sm" type="button" data-discard${ch.length ? '' : ' disabled'}>${icon('refresh')} Concept weggooien</button>
            <button class="btn btn--ghost btn--sm" type="button" data-factory style="color:var(--red)">${icon('trash')} Standaardinhoud herstellen</button>
          </div>
          <p class="hint"><strong>Concept weggooien</strong> zet alles terug naar de gepubliceerde versie. <strong>Standaardinhoud herstellen</strong> zet alle website-inhoud en webshopgegevens terug naar de oorspronkelijke inhoud van deze website.</p>
        </div></section>
      </div>
      <section class="panel"><div class="panel-head"><div><h2>Opslag in deze browser</h2><p>Concepten en foto’s die u uploadt, staan in de opslag van deze browser</p></div></div><div class="panel-body">
        <div class="meter" role="img" aria-label="Gebruikte opslag: ongeveer ${pct}%"><span style="width:${pct}%"></span></div>
        <p class="hint mt-8">Ongeveer ${(used / 1024 / 1024).toFixed(1)} MB van circa 5 MB gebruikt. Upload foto’s bij voorkeur kleiner dan 1 MB; grote foto’s worden automatisch verkleind.</p>
      </div></section>`;
  },
  mount(root) {
    const result = $('[data-publish-result]', root);
    const busy = (btn, on) => { btn.disabled = on; btn.setAttribute('aria-busy', String(on)); };
    $('[data-publish]', root).addEventListener('click', async (e) => {
      const why = SiteStatus.blocked(); if (why) { Toast.show(why, { error: true }); return; }
      const btn = e.currentTarget; busy(btn, true);
      try {
        const { stamp, files, bytes } = await Publisher.files();
        downloadBlob(`cartronic-website-${stamp.slice(0, 10)}.zip`, Zip.build(files));
        result.innerHTML = UI.notice(`<strong>Website gedownload</strong> (${(bytes / 1024).toFixed(0)} KB, ${files.length} bestanden). Pak het zip-bestand uit en sleep de map <em>cartronic-website</em> naar Netlify, of upload de inhoud naar GitHub voor Vercel (zie LEESMIJ.txt). Daarna ziet iedereen de nieuwe versie.`, { type: 'ok', ic: 'check' });
        Toast.show('Website gedownload.');
      } catch (er) {
        console.error(er);
        result.innerHTML = UI.notice(`<strong>Publiceren is niet gelukt.</strong> ${esc(er.message || 'Onbekende fout.')}`, { type: 'danger', ic: 'alertCircle' });
      } finally { busy(btn, false); }
    });
    $('[data-publish-html]', root).addEventListener('click', async (e) => {
      const why = SiteStatus.blocked(); if (why) { Toast.show(why, { error: true }); return; }
      const btn = e.currentTarget; busy(btn, true);
      try {
        const html = Publisher.html(Publisher.bundle(nowIso()), { ogImage: false });
        downloadBlob('index.html', new Blob([html], { type: 'text/html' }));
        Toast.show('index.html gedownload.');
      } catch (er) { Toast.show(`Niet gelukt: ${er.message}`, { error: true }); } finally { busy(btn, false); }
    });
    $('[data-backup]', root).addEventListener('click', () => {
      const why = SiteStatus.blocked(); if (why) { Toast.show(why, { error: true }); return; }
      const c = Content.working(); delete c.base; delete c.baseFp;
      downloadJson(`cartronic-backup-${nowIso().slice(0, 10)}.json`, { format: 'cartronic-site', version: 1, exportedAt: nowIso(), content: c, shop: Repo.shopSnapshot() });
      Toast.show('Back-up gedownload.');
    });
    $('[data-restore-file]', root).addEventListener('change', async (e) => {
      const file = e.target.files[0]; e.target.value = '';
      if (!file) return;
      if (file.size > 20 * 1024 * 1024) { Toast.show('Het bestand is te groot (max 20 MB).', { error: true }); return; }
      let data;
      try { data = JSON.parse(await file.text()); } catch (er) { Toast.show('Dit is geen geldig JSON-bestand.', { error: true }); return; }
      if (!data || data.format !== 'cartronic-site' || !data.content || typeof data.content !== 'object') { Toast.show('Onbekend formaat. Gebruik een back-up uit dit beheer.', { error: true }); return; }
      const shop = data.shop ? Content.cleanShop(data.shop) : null;
      if (data.shop && !shop) { Toast.show('De webshopgegevens in deze back-up zijn ongeldig. Er is niets gewijzigd.', { error: true }); return; }
      if (!(await Overlay.confirm({ title: 'Back-up terugzetten?', message: 'De huidige website-inhoud' + (shop ? ' en webshopgegevens worden' : ' wordt') + ' vervangen door de inhoud van de back-up. Bestellingen blijven ongewijzigd.', confirmLabel: 'Terugzetten' }))) return;
      if (!saveContent((d) => { Object.keys(d).forEach((k) => delete d[k]); Object.assign(d, deepClone(data.content)); }, null)) return;
      if (shop) {
        Repo.replaceProducts(shop.products); Repo.saveShopCategories(shop.shopCategories); Repo.saveProjects(shop.projects);
        Repo.saveSettings({ ...shop.settings, orderSeq: Repo.settings().orderSeq || 0 });
      }
      const issues = Content.issues;
      Toast.show(issues.length ? `Back-up teruggezet. Overgeslagen (ongeldig): ${issues.join(', ')}.` : 'Back-up teruggezet.', issues.length ? { error: true } : {});
      Router.render();
    });
    $('[data-discard]', root).addEventListener('click', async () => {
      if (Content.stale) { Toast.show(RELOAD_FIRST, { error: true }); return; }
      if (!(await Overlay.confirm({ title: 'Concept weggooien?', message: 'Alle wijzigingen sinds de laatste publicatie (website-inhoud en webshopgegevens) worden ongedaan gemaakt. Bestellingen blijven bestaan.', confirmLabel: 'Concept weggooien', danger: true }))) return;
      if (Content.stale) { Toast.show(RELOAD_FIRST, { error: true }); return; }
      Content.discardDraft(); Repo.loadPublishedShop(); Cart.validate();
      Toast.show('Het concept is weggegooid.'); Router.render();
    });
    $('[data-factory]', root).addEventListener('click', async () => {
      if (!(await Overlay.confirm({ title: 'Standaardinhoud herstellen?', message: 'Alle teksten, bedrijfsgegevens, opties, diensten, berichten, beoordelingen, weergave- en SEO-instellingen én de webshopgegevens gaan terug naar de oorspronkelijke inhoud. Bestellingen blijven bestaan. Publiceer daarna om dit online te zetten.', confirmLabel: 'Herstellen', danger: true }))) return;
      if (!saveContent((d) => { Object.keys(d).forEach((k) => delete d[k]); }, null)) return;
      Repo.reset({ source: 'defaults', keepOrders: true }); Cart.validate();
      Toast.show('De standaardinhoud is hersteld.'); Router.render();
    });
  },
});

/* ---------- Bedrijfsgegevens ---------- */
Pages.adminCompany = adminPage({
  key: 'bedrijf', title: 'Bedrijfsgegevens',
  render() {
    const c = COMPANY;
    const intl = c.phoneHref.replace(/^tel:/, '');
    return `<form data-company novalidate>
      <section class="panel"><div class="panel-head"><div><h2>Bedrijf en adres</h2><p>Gebruikt in de header, footer, contactpagina, WhatsApp-berichten en de gegevens voor Google</p></div></div><div class="panel-body"><div class="form-grid">
        ${saField({ name: 'name', label: 'Bedrijfsnaam', value: c.name, max: 60, half: true })}
        ${saField({ name: 'street', label: 'Straat en huisnummer', value: c.street, max: 80, half: true })}
        ${saField({ name: 'postal', label: 'Postcode', value: c.postal, max: 10, half: true })}
        ${saField({ name: 'city', label: 'Plaats', value: c.city, max: 60, half: true })}
        ${saField({ name: 'mapsUrl', label: 'Link naar de route (Google Maps)', value: c.mapsUrl, type: 'url', hint: 'Begint met https://' })}
      </div></div></section>
      <section class="panel"><div class="panel-head"><div><h2>Bereikbaarheid</h2></div></div><div class="panel-body"><div class="form-grid">
        ${saField({ name: 'phoneDisplay', label: 'Telefoonnummer (zoals getoond)', value: c.phoneDisplay, max: 30, half: true, placeholder: '070 383 9836' })}
        ${saField({ name: 'phoneIntl', label: 'Telefoonnummer (internationaal, om te bellen)', value: intl, max: 20, half: true, placeholder: '+31703839836', hint: 'Met landcode, zonder spaties.' })}
        ${saField({ name: 'whatsapp', label: 'WhatsApp-nummer', value: c.whatsapp, max: 16, half: true, placeholder: '31703839836', hint: 'Landcode + nummer, alleen cijfers (dus 31…, zonder + of 0).' })}
        ${saField({ name: 'whatsappDisplay', label: 'WhatsApp-nummer (zoals getoond)', value: c.whatsappDisplay || '', max: 30, half: true, opt: true, hint: 'Leeg = hetzelfde als het telefoonnummer.' })}
        ${saField({ name: 'email', label: 'E-mailadres', value: c.email, type: 'email', max: 120 })}
      </div></div></section>
      <section class="panel"><div class="panel-head"><div><h2>Openingstijden</h2><p>Bijvoorbeeld “Dinsdag – vrijdag” en “09:30 – 17:00”, of “Gesloten”</p></div><button class="btn btn--light btn--sm" type="button" data-hours-add>${icon('plus')} Regel toevoegen</button></div>
        <div class="panel-body"><div class="rows-editor" data-hours>${c.hours.map(([d, t]) => this.hourRow(d, t)).join('')}</div>
        <p class="hint mt-16">Google leest de openingstijden mee als ze in deze vorm staan (dag of “dag – dag”, en “uu:mm – uu:mm”).</p></div></section>
      <section class="panel"><div class="panel-head"><div><h2>Online en registratie</h2></div></div><div class="panel-body"><div class="form-grid">
        ${saField({ name: 'website', label: 'Website', value: c.website, type: 'url', half: true })}
        ${saField({ name: 'facebook', label: 'Facebook-pagina', value: c.facebook || '', type: 'url', half: true, opt: true })}
        ${saField({ name: 'social', label: 'Andere profielen (Instagram, LinkedIn, …)', value: (c.social || []).join('\n'), multi: true, rows: 3, opt: true, hint: 'Eén webadres per regel. Alleen voor zoekmachines (“sameAs”); ze worden niet op de pagina getoond.' })}
        ${saField({ name: 'kvk', label: 'KvK-nummer', value: c.kvk || '', max: 12, half: true, opt: true, hint: 'Alleen invullen als het nummer klopt. Wordt dan in de footer getoond.' })}
        ${saField({ name: 'vat', label: 'Btw-nummer', value: c.vat || '', max: 20, half: true, opt: true, hint: 'Wordt in de footer getoond als het is ingevuld.' })}
      </div></div></section>
      ${saveBar()}
    </form>`;
  },
  hourRow(d = '', t = '') {
    return `<div class="row-edit"><input class="input input--sm" data-h="day" value="${attr(d)}" maxlength="60" aria-label="Dag(en)" placeholder="Dinsdag – vrijdag"><input class="input input--sm" data-h="time" value="${attr(t)}" maxlength="60" aria-label="Tijden" placeholder="09:30 – 17:00">
      <div class="row-edit-actions"><button class="icon-btn icon-btn--sm" type="button" data-row-up aria-label="Omhoog">${icon('left').replace('<svg', '<svg style="transform:rotate(90deg)"')}</button><button class="icon-btn icon-btn--sm" type="button" data-row-down aria-label="Omlaag">${icon('right').replace('<svg', '<svg style="transform:rotate(90deg)"')}</button><button class="icon-btn icon-btn--sm" type="button" data-row-del aria-label="Regel verwijderen">${icon('trash')}</button></div></div>`;
  },
  mount(root) {
    const f = $('[data-company]', root);
    const st = trackDirty(f);
    const rowsEl = $('[data-hours]', f);
    bindRowEditor(rowsEl, () => this.hourRow(), () => st.set(true));
    $('[data-hours-add]', root).addEventListener('click', () => { rowsEl.insertAdjacentHTML('beforeend', this.hourRow()); st.set(true); $$('.row-edit', rowsEl).pop().querySelector('input').focus(); });
    const v = (k) => f.elements[k].value.trim();
    const hoursOf = () => $$('.row-edit', rowsEl).map((r) => [$('[data-h="day"]', r).value.trim(), $('[data-h="time"]', r).value.trim()]).filter(([d, t]) => d || t);
    const intlOf = () => v('phoneIntl').replace(/\(0\)/g, '').replace(/[\s().-]/g, '').replace(/^00/, '+');
    const values = () => ({
      name: v('name'), street: v('street'), postal: v('postal'), city: v('city'), mapsUrl: v('mapsUrl'),
      phoneDisplay: v('phoneDisplay'), phoneHref: `tel:${intlOf()}`, whatsapp: v('whatsapp'), whatsappDisplay: v('whatsappDisplay'),
      email: v('email'), website: v('website'), facebook: v('facebook'), kvk: v('kvk'), vat: v('vat'), social: lines(v('social')), hours: hoursOf(),
    });
    let shown = values();
    f.addEventListener('submit', (e) => {
      e.preventDefault();
      const errs = {};
      ['name', 'street', 'postal', 'city', 'phoneDisplay'].forEach((k) => { if (!v(k)) errs[k] = 'Dit veld is verplicht.'; });
      const intl = intlOf();
      if (!/^\+[1-9][0-9]{5,15}$/.test(intl)) errs.phoneIntl = 'Vul het nummer met landcode in, bijvoorbeeld +31703839836.';
      else if (/^\+310/.test(intl)) errs.phoneIntl = 'Laat de 0 na de landcode weg, bijvoorbeeld +31703839836.';
      if (!/^[0-9]{8,15}$/.test(v('whatsapp'))) errs.whatsapp = 'Alleen cijfers, met landcode: bijvoorbeeld 31703839836.';
      if (!/^[^\s@<>"]+@[^\s@<>"]+\.[^\s@<>"]{2,}$/.test(v('email'))) errs.email = 'Vul een geldig e-mailadres in.';
      ['mapsUrl', 'website'].forEach((k) => { if (!Content.httpsUrl(v(k))) errs[k] = 'Gebruik een webadres dat met https:// begint.'; });
      if (v('facebook') && !Content.httpsUrl(v('facebook'))) errs.facebook = 'Gebruik een webadres dat met https:// begint.';
      ['mapsUrl', 'website', 'facebook'].forEach((k) => { if (!errs[k] && v(k).length > 2000) errs[k] = 'Dit webadres is te lang (maximaal 2.000 tekens).'; });
      const social = lines(v('social'));
      if (social.some((u) => !Content.httpsUrl(u))) errs.social = 'Elke regel moet een webadres zijn dat met https:// begint.';
      else if (social.length > 8) errs.social = 'Gebruik maximaal 8 profielen.';
      if (v('kvk') && !/^[0-9]{8}$/.test(v('kvk'))) errs.kvk = 'Een KvK-nummer heeft 8 cijfers.';
      const hours = hoursOf();
      if (!hours.length || hours.some(([d, t]) => !d || !t)) { Toast.show('Vul bij elke regel van de openingstijden zowel de dag als de tijd in.', { error: true }); return; }
      if (hours.length > 10) { Toast.show('Gebruik maximaal 10 regels voor de openingstijden.', { error: true }); return; }
      if (!showErrors(f, errs)) return;
      const next = values();
      const changed = changedKeys(shown, next);
      const def = (k) => (Content.P.company[k] === undefined ? '' : Content.P.company[k]);
      if (saveContent((d) => {
        // Only the fields changed in this form; a value equal to the built-in default is not stored.
        const c = { ...(isObj(d.company) ? d.company : {}) };
        changed.forEach((k) => { if (stableStringify(next[k]) === stableStringify(def(k))) delete c[k]; else c[k] = next[k]; });
        d.company = c;
      })) { st.set(false); shown = next; }
    });
    return () => Router.setGuard(null);
  },
});
/** Up/down/delete buttons of a list of `.row-edit` rows. */
function bindRowEditor(host, makeRow, onChange) {
  host.addEventListener('click', (e) => {
    const row = e.target.closest('.row-edit'); if (!row) return;
    if (e.target.closest('[data-row-del]')) { row.remove(); onChange(); return; }
    if (e.target.closest('[data-row-up]') && row.previousElementSibling) { row.parentNode.insertBefore(row, row.previousElementSibling); onChange(); return; }
    if (e.target.closest('[data-row-down]') && row.nextElementSibling) { row.parentNode.insertBefore(row.nextElementSibling, row); onChange(); }
  });
}

/* ---------- Teksten ---------- */
const TEXT_MAX = 12000;
const TEXT_PAGES = { home: '/', werkwijze: '/expertise', algemeen: '/', mogelijkheden: '/mogelijkheden', merken: '/merken', projecten: '/projecten', expertise: '/expertise', over: '/over', contact: '/contact', beoordelingen: '/beoordelingen', kennis: '/kennis', productinfo: '/productinformatie', webshop: '/webshop', overig: '/privacy' };
Pages.adminTexts = adminPage({
  key: 'teksten', title: 'Teksten',
  render(ctx) {
    const g = TEXT_GROUPS.some(([id]) => id === ctx.query.groep) ? ctx.query.groep : 'home';
    const texts = Content.texts();
    const field = (d) => {
      const custom = typeof texts[d.key] === 'string';
      const value = custom ? texts[d.key] : d.def;
      const id = `tx-${d.key.replace(/\./g, '-')}`;
      const multi = d.multi || d.rich || value.includes('\n') || value.length > 90;
      return `<div class="field span-2 text-field" data-text-field="${attr(d.key)}" data-search="${attr(normText(`${d.label} ${value}`))}">
        <div class="text-field-head"><label for="${id}">${esc(d.label)}</label>${custom ? '<span class="pill pill--info">Aangepast</span>' : ''}${d.optional ? '<span class="pill">Mag leeg</span>' : ''}</div>
        ${multi ? `<textarea class="textarea${d.rich ? '' : ' textarea--sm'}" id="${id}" name="${attr(d.key)}" rows="${d.rich ? 14 : 3}">${esc(value)}</textarea>` : `<input class="input" id="${id}" name="${attr(d.key)}" value="${attr(value)}">`}
        <span class="field-error" data-text-err></span>
        <div class="text-field-foot">${d.vars ? `<span class="hint">Gebruik ${d.vars.map((x) => `<code class="code">{${x}}</code>`).join(' ')} voor de automatische waarde.</span>` : ''}${d.control ? '<span class="hint">Tekst op een knop of link: alleen tekst, links werken hier niet.</span>' : ''}${d.rich ? '<span class="hint"><code class="code">## Kop</code> voor een tussenkop, <code class="code">- </code> voor een opsomming, lege regel = nieuwe alinea.</span>' : ''}
          ${custom ? `<button class="btn btn--ghost btn--xs" type="button" data-text-reset="${attr(d.key)}">${icon('refresh')} Standaardtekst terugzetten</button>` : ''}</div>
      </div>`;
    };
    return `<div class="toolbar">
        <div class="input-icon">${icon('search')}<input class="input input--sm" type="search" data-text-q placeholder="Zoek in alle teksten" aria-label="Zoek in alle teksten"></div>
        <a class="btn btn--light btn--sm" href="${TEXT_PAGES[g] ? `#${TEXT_PAGES[g]}` : '#/'}" target="_blank" rel="noopener">${icon('external')} Bekijk pagina</a>
      </div>
      <div class="chips" role="group" aria-label="Kies een pagina" data-text-groups>${TEXT_GROUPS.map(([id, label, rows]) => {
        const n = rows.filter(([k]) => typeof texts[k] === 'string').length;
        return `<a class="chip${id === g ? ' is-active' : ''}" href="#/admin/teksten?groep=${id}"${id === g ? ' aria-current="true"' : ''}>${esc(label)}${n ? ` <span class="n">${n}</span>` : ''}</a>`;
      }).join('')}</div>
      ${UI.notice('Enter = nieuwe regel · <code class="code">**tekst**</code> = vet · <code class="code">[linktekst](/contact)</code> = link. Laat een veld leeg om de standaardtekst te gebruiken.', { ic: 'info' })}
      <form data-texts novalidate>
        ${TEXT_GROUPS.map(([id, label, rows]) => `<section class="panel" data-text-group="${id}"${id === g ? '' : ' hidden'}><div class="panel-head"><div><h2>${esc(label)}</h2></div></div>
          <div class="panel-body"><div class="form-grid">${rows.map(([k]) => field(TEXT[k])).join('')}</div></div></section>`).join('')}
        <div class="panel" data-text-empty hidden><div class="panel-body">${UI.empty({ icon: 'search', title: 'Geen teksten gevonden' })}</div></div>
        ${saveBar('Teksten opslaan')}
      </form>`;
  },
  mount(root, ctx) {
    const f = $('[data-texts]', root);
    const st = trackDirty(f);
    // The values shown when the screen opened: only fields changed since then are saved, so edits saved
    // meanwhile (for example in another tab) are kept.
    const shown = {};
    Object.keys(TEXT).forEach((k) => { if (f.elements[k]) shown[k] = f.elements[k].value; });
    const q = $('[data-text-q]', root);
    const g = TEXT_GROUPS.some(([id]) => id === ctx.query.groep) ? ctx.query.groep : 'home';
    const filter = () => {
      const term = normText(q.value);
      let shown = 0;
      $$('[data-text-group]', f).forEach((sec) => {
        let any = false;
        $$('[data-text-field]', sec).forEach((fl) => {
          const input = $('input, textarea', fl);
          const ok = !term || fl.dataset.search.includes(term) || normText(input.value).includes(term);
          fl.hidden = !ok; if (ok) any = true;
        });
        sec.hidden = term ? !any : sec.dataset.textGroup !== g;
        if (!sec.hidden) shown++;
      });
      $('[data-text-empty]', f).hidden = shown > 0;
      $('[data-text-groups]', root).hidden = !!term;
    };
    q.addEventListener('input', debounce(filter, 150));
    // Too long: say so right away (nothing is cut off; saving is refused until the text is shorter).
    const checkLength = (el) => {
      const box = el.closest('[data-text-field]'); const msg = box && $('[data-text-err]', box);
      const over = el.value.length > TEXT_MAX;
      if (msg) msg.textContent = over ? `${el.value.length.toLocaleString('nl-NL')} tekens — maximaal ${TEXT_MAX.toLocaleString('nl-NL')}. Maak de tekst korter.` : '';
      if (over) el.setAttribute('aria-invalid', 'true'); else el.removeAttribute('aria-invalid');
    };
    f.addEventListener('input', (e) => { if (e.target.matches('[data-text-field] input, [data-text-field] textarea')) checkLength(e.target); });
    f.addEventListener('click', (e) => {
      const b = e.target.closest('[data-text-reset]'); if (!b) return;
      const el = f.elements[b.dataset.textReset];
      el.value = TEXT[b.dataset.textReset].def; st.set(true); el.focus();
      Toast.show('Standaardtekst ingevuld. Klik op opslaan om te bevestigen.');
    });
    f.addEventListener('submit', (e) => {
      e.preventDefault();
      const tooLong = Object.keys(TEXT).find((k) => f.elements[k] && f.elements[k].value.length > TEXT_MAX);
      if (tooLong) {
        // Show the field (it may sit in another group or be filtered out) and keep what was typed.
        const el = f.elements[tooLong];
        q.value = '';
        $$('[data-text-group]', f).forEach((sec) => { sec.hidden = !sec.contains(el); });
        $$('[data-text-field]', f).forEach((fl) => { fl.hidden = false; });
        $('[data-text-empty]', f).hidden = true;
        checkLength(el); el.focus();
        Toast.show(`“${TEXT[tooLong].label}” is te lang: maximaal ${TEXT_MAX.toLocaleString('nl-NL')} tekens. Er is niets opgeslagen.`, { error: true });
        return;
      }
      const changed = Object.keys(TEXT).filter((k) => f.elements[k] && f.elements[k].value !== shown[k]);
      if (saveContent((d) => {
        const texts = { ...(d.texts && typeof d.texts === 'object' ? d.texts : {}) };
        changed.forEach((k) => {
          const val = f.elements[k].value.replace(/\r\n/g, '\n');
          const def = TEXT[k];
          delete texts[k];
          if (!val.trim()) { if (def.optional) texts[k] = ''; return; }
          if (val.trim() !== def.def.trim()) texts[k] = val.trim();
        });
        d.texts = texts;
      }, 'Teksten opgeslagen.')) { st.set(false); Router.render(); }
    });
    return () => Router.setGuard(null);
  },
});

/* ---------- Weergave ---------- */
const HOME_SECTIONS = [
  ['home.brands', 'Merkenbalk'], ['home.finder', 'Voertuigzoeker (“Welke opties passen bij uw auto?”)'], ['home.categories', 'Categorieën van opties'],
  ['home.services', 'Expertise & diensten'], ['home.tech', 'Techniek-kaart (werkwijze)'], ['home.projects', 'Projecten uit de werkplaats'],
  ['home.reviews', 'Beoordelingen'], ['home.shop', 'Uitgelichte webshopproducten'],
];
Pages.adminDisplay = adminPage({
  key: 'weergave', title: 'Weergave',
  render() {
    const d = Content.display();
    const a = d.announcement;
    return `<form data-display novalidate>
      <section class="panel"><div class="panel-head"><div><h2>Homepage</h2><p>Kies welke onderdelen op de homepage staan</p></div><a class="btn btn--light btn--sm" href="#/" target="_blank" rel="noopener">${icon('external')} Bekijk</a></div><div class="panel-body"><div class="form-grid">
        ${HOME_SECTIONS.map(([k, l]) => saSwitch(`s:${k}`, l, d.sections[k] !== false)).join('')}
      </div></div></section>
      <section class="panel"><div class="panel-head"><div><h2>Overal op de website</h2></div></div><div class="panel-body"><div class="form-grid">
        ${saSwitch('s:cta', 'Afsluitende balk “Wat mist er nog aan uw auto?” onder aan de pagina’s', d.sections.cta !== false)}
        ${saSwitch('s:recent', 'Blok “Recent bekeken”', d.sections.recent !== false, 'Op de homepage, de optiepagina’s en de webshop. Op de pagina “Mijn auto” blijft de geschiedenis van de bezoeker altijd zichtbaar.')}
        ${saSwitch('footerAdmin', 'Link “Beheer” in de footer', d.footerAdmin !== false, 'Beheer blijft bereikbaar via /admin.')}
      </div></div></section>
      <section class="panel"><div class="panel-head"><div><h2>Webshop</h2></div></div><div class="panel-body"><div class="form-grid">
        ${saSwitch('shop', 'Webshop tonen', d.shop !== false, 'Uitgeschakeld verdwijnen de webshop, de winkelmand en productlinks van de website; de webshoppagina’s tonen dan een korte uitleg. Bestaande bestellingen blijven in Beheer. Let op: betalingen in deze versie zijn gesimuleerd.')}
      </div></div></section>
      <section class="panel"><div class="panel-head"><div><h2>Mededeling</h2><p>Een balk boven aan elke pagina, bijvoorbeeld voor vakantiesluiting</p></div></div><div class="panel-body"><div class="form-grid">
        ${saSwitch('a:on', 'Mededeling tonen', a.on)}
        ${saField({ name: 'a:text', label: 'Tekst', value: a.text, max: 300, hint: '<code class="code">**tekst**</code> = vet.' })}
        ${saField({ name: 'a:linkLabel', label: 'Linktekst', value: a.linkLabel, max: 60, half: true, opt: true, placeholder: 'Meer informatie' })}
        ${saField({ name: 'a:link', label: 'Link', value: a.link.startsWith('#/') ? a.link.slice(1) : a.link, max: 300, half: true, opt: true, placeholder: '/contact of https://…' })}
        <div class="field span-2"><span class="label">Kleur</span><div class="radio-row">${[['dark', 'Donker'], ['red', 'Rood'], ['light', 'Licht']].map(([k, l]) => `<label class="radio-tile"><input type="radio" name="a:tone" value="${k}"${a.tone === k ? ' checked' : ''}><span>${l}</span></label>`).join('')}</div></div>
        <div class="span-2"><p class="label" style="margin-bottom:8px">Voorbeeld</p><div class="announce-preview" data-announce-preview></div></div>
      </div></div></section>
      ${saveBar()}
    </form>`;
  },
  mount(root) {
    const f = $('[data-display]', root);
    const st = trackDirty(f);
    const prev = $('[data-announce-preview]', f);
    const read = () => {
      const link = f.elements['a:link'].value.trim();
      return { text: f.elements['a:text'].value.trim(), linkLabel: f.elements['a:linkLabel'].value.trim(), link, tone: (f.querySelector('[name="a:tone"]:checked') || {}).value || 'dark' };
    };
    const draw = () => {
      const a = read();
      prev.innerHTML = a.text ? `<div class="announce announce--${a.tone}"><div class="announce-inner"><p>${fmtText(a.text).replace(/<a\b[^>]*>/g, '<u>').replace(/<\/a>/g, '</u>')}${a.linkLabel && a.link ? ` <u class="announce-link">${esc(a.linkLabel)}</u>` : ''}</p></div></div>` : '<p class="hint">Vul een tekst in om een voorbeeld te zien.</p>';
    };
    f.addEventListener('input', draw); f.addEventListener('change', draw); draw();
    // Every switch and the announcement count as separate fields (see changedKeys).
    const values = () => {
      const a = read(); const out = {};
      Object.keys(Content.DISPLAY_DEFAULTS.sections).forEach((k) => { const el = f.elements[`s:${k}`]; out[`s:${k}`] = el ? el.checked : true; });
      out.shop = f.elements.shop.checked; out.footerAdmin = f.elements.footerAdmin.checked;
      out.announcement = { on: f.elements['a:on'].checked, text: a.text, linkLabel: a.linkLabel, link: a.link ? Content.safeHref(a.link) : '', tone: a.tone };
      return out;
    };
    let shown = values();
    f.addEventListener('submit', (e) => {
      e.preventDefault();
      const a = read();
      const errs = {};
      if (f.elements['a:on'].checked && !a.text) errs['a:text'] = 'Vul een tekst in, of zet de mededeling uit.';
      if (a.link && !Content.safeHref(a.link)) errs['a:link'] = 'Gebruik een pagina van deze site (bijv. /contact) of een webadres met https://.';
      if (a.link && !a.linkLabel) errs['a:linkLabel'] = 'Vul ook een linktekst in.';
      if (!showErrors(f, errs)) return;
      const next = values();
      const changed = changedKeys(shown, next);
      if (saveContent((d) => {
        const disp = { ...(isObj(d.display) ? d.display : {}) };
        disp.sections = { ...(isObj(disp.sections) ? disp.sections : {}) };
        changed.forEach((k) => { if (k.startsWith('s:')) disp.sections[k.slice(2)] = next[k]; else disp[k] = next[k]; });
        d.display = disp;
      }, 'Weergave opgeslagen.')) { st.set(false); shown = next; }
    });
    return () => Router.setGuard(null);
  },
});

/* ---------- SEO ---------- */
const SEO_LIMITS = { title: 60, desc: 160, descMin: 70 };
function seoPreview({ title, description, url }) {
  return `<div class="serp" aria-label="Voorbeeld in Google"><div class="serp-url">${esc(url || 'www.cartronic.nl')}</div><div class="serp-title">${esc(title)}</div><div class="serp-desc">${esc(description)}</div></div>`;
}
const seoIssues = (r) => {
  const out = [];
  if (r.title.length > SEO_LIMITS.title) out.push('titel te lang');
  if (r.description.length > SEO_LIMITS.desc) out.push('omschrijving te lang');
  if (r.description.length < SEO_LIMITS.descMin) out.push('omschrijving kort');
  return out;
};
Pages.adminSeo = adminPage({
  key: 'seo', title: 'SEO',
  render(ctx) {
    const s = Content.seo();
    const counter = (name, max) => `<span class="hint span-2" data-count-for="${name}" data-max="${max}"></span>`;
    return `<form data-seo novalidate>
      <section class="panel"><div class="panel-head"><div><h2>Algemeen</h2><p>Hoe de website in Google en bij gedeelde links verschijnt</p></div></div><div class="panel-body"><div class="form-grid">
        ${saField({ name: 'siteUrl', label: 'Website-adres', value: s.siteUrl, type: 'url', placeholder: 'https://www.cartronic.nl', hint: 'Het definitieve adres, zonder / aan het eind. Nodig voor de sitemap, canonieke adressen en de deelafbeelding.' })}
        ${saField({ name: 'homeTitle', label: 'Titel van de homepage', value: s.homeTitle, max: 120 })}${counter('homeTitle', SEO_LIMITS.title)}
        ${saField({ name: 'description', label: 'Standaardomschrijving', value: s.description, multi: true, rows: 3, max: 300, hint: 'Voor de homepage en voor pagina’s zonder eigen omschrijving.' })}${counter('description', SEO_LIMITS.desc)}
        ${saField({ name: 'suffix', label: 'Achter elke paginatitel', value: s.suffix, max: 40, half: true, hint: 'Bijvoorbeeld “ | CarTronic”. Leeg = niets.' })}
        <div class="field"><span class="label">Voorbeeld in Google</span><div data-serp-home></div></div>
        ${saField({ name: 'ogTitle', label: 'Titel bij delen (WhatsApp, Facebook, LinkedIn)', value: s.ogTitle, max: 120, half: true })}
        ${saField({ name: 'ogDescription', label: 'Omschrijving bij delen', value: s.ogDescription, max: 300, half: true })}
        ${saField({ name: 'google', label: 'Google Search Console-code', value: s.google, max: 120, half: true, opt: true, hint: 'Alleen de code uit de meta-tag “google-site-verification”.' })}
        ${saField({ name: 'bing', label: 'Bing Webmaster-code', value: s.bing, max: 120, half: true, opt: true })}
        ${saSwitch('noindex', 'Zoekmachines tegenhouden (testfase)', s.noindex, 'Aan: de website vraagt zoekmachines om niets te indexeren en robots.txt blokkeert alles. Gebruik dit zolang de website op een tijdelijk adres staat.')}
      </div></div>${saveBar('SEO-instellingen opslaan', '', { inline: true })}</section>
    </form>
    <section class="panel" id="paginas"><div class="panel-head"><div><h2>Pagina’s</h2><p>Titel en omschrijving per pagina. Klik op een pagina om ze aan te passen.</p></div><div data-seo-summary class="flex wrap gap-8"></div></div>
      <div class="panel-body" style="display:grid;gap:14px">
        <div class="toolbar">
          <div class="input-icon">${icon('search')}<input class="input input--sm" type="search" data-sq placeholder="Zoek op titel of adres" aria-label="Zoek pagina’s" value="${attr(ctx.query.q || '')}"></div>
          <label class="sr-only" for="seo-f">Toon</label>
          <select class="select select--sm" id="seo-f" data-sf style="width:auto">${[['alle', 'Alle pagina’s'], ['aangepast', 'Aangepast'], ['problemen', 'Met aandachtspunten'], ['noindex', 'Niet geïndexeerd']].map(([k, l]) => `<option value="${k}"${ctx.query.f === k ? ' selected' : ''}>${l}</option>`).join('')}</select>
          <select class="select select--sm" data-sg style="width:auto" aria-label="Soort pagina"><option value="">Alle soorten</option>${['Pagina’s', 'Merken', 'Diensten', 'Berichten', 'Projecten', 'Webshop', 'Opties'].map((g) => `<option${ctx.query.g === g ? ' selected' : ''}>${g}</option>`).join('')}</select>
        </div>
        <div data-seo-list></div>
      </div></section>`;
  },
  mount(root, ctx) {
    const f = $('[data-seo]', root);
    const st = trackDirty(f);
    const counts = () => $$('[data-count-for]', f).forEach((el) => {
      const n = f.elements[el.dataset.countFor].value.trim().length; const max = Number(el.dataset.max);
      el.textContent = `${n} tekens${n > max ? ` — Google toont er ongeveer ${max}` : ''}`;
      el.style.color = n > max ? 'var(--warn)' : '';
    });
    const serp = () => { $('[data-serp-home]', f).innerHTML = seoPreview({ title: f.elements.homeTitle.value, description: f.elements.description.value, url: f.elements.siteUrl.value.replace(/^https?:\/\//, '') }); };
    f.addEventListener('input', () => { counts(); serp(); });
    counts(); serp();
    const v = (k) => f.elements[k].value.trim();
    const values = () => ({ siteUrl: Content.siteAddress(v('siteUrl')) || v('siteUrl').replace(/\/+$/, ''), suffix: f.elements.suffix.value.slice(0, 40), homeTitle: v('homeTitle'), description: v('description'), ogTitle: v('ogTitle'), ogDescription: v('ogDescription'), noindex: f.elements.noindex.checked, google: v('google'), bing: v('bing') });
    let shown = values();
    f.addEventListener('submit', (e) => {
      e.preventDefault();
      const errs = {};
      const typed = v('siteUrl');
      if (typed && !Content.siteAddress(typed)) errs.siteUrl = 'Vul een volledig adres in, zoals https://www.cartronic.nl of https://www.cartronic.nl/site. Gebruik in een submap alleen letters, cijfers, - en _; zonder ? of #.';
      if (!v('homeTitle')) errs.homeTitle = 'Vul een titel in.';
      if (!v('description')) errs.description = 'Vul een omschrijving in.';
      ['google', 'bing'].forEach((k) => { if (v(k) && !/^[A-Za-z0-9_-]{8,120}$/.test(v(k))) errs[k] = 'Vul alleen de code in (letters, cijfers, - en _).'; });
      if (!showErrors(f, errs)) return;
      const next = values();
      const changed = changedKeys(shown, next);
      if (saveContent((d) => {
        const seo = { ...(isObj(d.seo) ? d.seo : {}) };
        changed.forEach((k) => { seo[k] = next[k]; });
        seo.pages = isObj(seo.pages) ? seo.pages : {};
        d.seo = seo;
      }, 'SEO-instellingen opgeslagen.')) {
        st.set(false); shown = next;
        if (f.elements.siteUrl.value.trim() !== next.siteUrl) f.elements.siteUrl.value = next.siteUrl; // the normalised address
        draw();
      }
    });
    // Per-page list
    const list = $('[data-seo-list]', root);
    const state = { q: ctx.query.q || '', f: ctx.query.f || 'alle', g: ctx.query.g || '', page: 0 };
    const PER = 25;
    const rows = () => {
      const all = sitePages().map((p) => ({ ...p, r: pageSeo(p.path), custom: !!Content.seo().pages[p.path] }));
      const titles = {};
      all.forEach((x) => { titles[x.r.title] = (titles[x.r.title] || 0) + 1; });
      all.forEach((x) => { x.issues = seoIssues(x.r); if (titles[x.r.title] > 1) x.issues.push('dubbele titel'); });
      return all;
    };
    const draw = () => {
      const all = rows();
      const nIssues = all.filter((x) => x.issues.length).length;
      $('[data-seo-summary]', root).innerHTML = `<span class="pill">${all.length} pagina’s</span>${nIssues ? `<span class="pill pill--warn">${nIssues} met aandachtspunten</span>` : '<span class="pill pill--ok">Geen aandachtspunten</span>'}`;
      const term = normText(state.q);
      const items = all.filter((x) => (!state.g || x.group === state.g)
        && (!term || normText(`${x.label} ${x.path} ${x.r.title}`).includes(term))
        && (state.f !== 'aangepast' || x.custom) && (state.f !== 'problemen' || x.issues.length) && (state.f !== 'noindex' || x.r.noindex));
      const pages = Math.max(1, Math.ceil(items.length / PER));
      state.page = Math.min(state.page, pages - 1);
      const slice = items.slice(state.page * PER, state.page * PER + PER);
      list.innerHTML = items.length ? `<div class="table-wrap rtable"><table class="table admin-table"><thead><tr><th>Pagina</th><th>Titel en omschrijving in Google</th><th>Status</th><th class="num"><span class="sr-only">Acties</span></th></tr></thead><tbody>
        ${slice.map((x) => `<tr><td class="cell-main" data-label="Pagina"><strong style="font-weight:600">${esc(x.label)}</strong><div class="text-small text-muted" style="word-break:break-all">${esc(x.path)}</div></td>
          <td data-label="In Google"><div style="font-weight:550;line-height:1.35">${esc(x.r.title)}</div><div class="text-small text-muted" style="margin-top:4px">${esc(x.r.description.length > 170 ? `${x.r.description.slice(0, 167)}…` : x.r.description)}</div></td>
          <td data-label="Status">${x.r.noindex ? '<span class="pill">Niet geïndexeerd</span> ' : ''}${x.custom ? '<span class="pill pill--info">Aangepast</span> ' : ''}${x.issues.map((i) => `<span class="pill pill--warn">${esc(i)}</span>`).join(' ')}</td>
          <td class="num cell-actions"><div class="row-actions"><button class="btn btn--light btn--xs" type="button" data-seo-edit="${attr(x.path)}">Bewerken</button><a class="icon-btn icon-btn--sm" href="#${attr(x.path)}" target="_blank" rel="noopener" aria-label="Bekijk ${attr(x.label)}" title="Bekijk">${icon('external')}</a></div></td></tr>`).join('')}
        </tbody></table></div>
        ${pages > 1 ? `<div class="pager"><button class="btn btn--light btn--sm" type="button" data-pg="-1"${state.page ? '' : ' disabled'}>${icon('left')} Vorige</button><span class="text-small text-muted">Pagina ${state.page + 1} van ${pages} · ${items.length} resultaten</span><button class="btn btn--light btn--sm" type="button" data-pg="1"${state.page < pages - 1 ? '' : ' disabled'}>Volgende ${icon('right')}</button></div>` : ''}`
        : UI.empty({ icon: 'search', title: 'Geen pagina’s gevonden' });
    };
    const sync = () => Router.setQuery({ q: state.q, f: state.f !== 'alle' ? state.f : '', g: state.g });
    $('[data-sq]', root).addEventListener('input', debounce((e) => { state.q = e.target.value.trim(); state.page = 0; sync(); draw(); }, 200));
    $('[data-sf]', root).addEventListener('change', (e) => { state.f = e.target.value; state.page = 0; sync(); draw(); });
    $('[data-sg]', root).addEventListener('change', (e) => { state.g = e.target.value; state.page = 0; sync(); draw(); });
    list.addEventListener('click', (e) => {
      const pg = e.target.closest('[data-pg]');
      if (pg) { state.page += Number(pg.dataset.pg); draw(); list.scrollIntoView({ block: 'start' }); return; }
      const b = e.target.closest('[data-seo-edit]');
      if (b) openSeoEditor(b.dataset.seoEdit, draw);
    });
    draw();
    return () => Router.setGuard(null);
  },
});
/** Modal to set the title, description and indexing of one page. */
function openSeoEditor(path, onSaved) {
  const cur = Content.seo().pages[path] || {};
  const r = pageSeo(path);
  const base = r.base || {};
  Overlay.open({
    title: 'Pagina in Google', size: 'lg',
    body: `<form class="form-grid" data-seo-page novalidate>
      <p class="span-2 text-small text-muted" style="word-break:break-all">${esc(path)}</p>
      ${saField({ name: 'title', label: 'Titel', value: cur.title || '', max: 120, placeholder: base.title || '', hint: path === '/' ? 'De volledige titel van de homepage.' : `Leeg = standaardtitel. “${esc(Content.seo().suffix)}” komt er automatisch achter.` })}
      <span class="hint span-2" data-c="title"></span>
      ${saField({ name: 'description', label: 'Omschrijving', value: cur.description || '', multi: true, rows: 3, max: 300, placeholder: base.description || Content.seo().description, hint: 'Leeg = standaardomschrijving. Ideaal: 70–160 tekens.' })}
      <span class="hint span-2" data-c="description"></span>
      ${saSwitch('noindex', 'Niet laten indexeren door zoekmachines', !!cur.noindex)}
      <div class="span-2"><span class="label">Voorbeeld</span><div class="mt-8" data-serp></div></div>
    </form>`,
    foot: `<button class="btn btn--ghost btn--sm" type="button" data-seo-clear${Content.seo().pages[path] ? '' : ' disabled'}>Standaard gebruiken</button><button class="btn btn--light btn--sm" type="button" data-close>Annuleren</button><button class="btn btn--primary btn--sm" type="button" data-seo-save>Opslaan</button>`,
    onMount(panel, close) {
      const f = $('[data-seo-page]', panel);
      const draw = () => {
        const t = f.elements.title.value.trim(); const d = f.elements.description.value.trim();
        const res = Seo.resolve({ ...base, title: t || base.title, description: d || base.description }, '/__preview');
        const title = path === '/' ? (t || Content.seo().homeTitle) : res.title;
        const desc = d || base.description || Content.seo().description;
        $('[data-serp]', panel).innerHTML = seoPreview({ title, description: desc, url: Seo.url(path).replace(/^https?:\/\//, '') || path });
        $('[data-c="title"]', panel).textContent = `${title.length} tekens in Google${title.length > SEO_LIMITS.title ? ' — waarschijnlijk ingekort' : ''}`;
        $('[data-c="description"]', panel).textContent = `${desc.length} tekens${desc.length > SEO_LIMITS.desc ? ' — waarschijnlijk ingekort' : ''}`;
      };
      f.addEventListener('input', (e) => { draw(); if (e.target.dataset && e.target.dataset.max) overMax(f, e.target); }); draw();
      const save = (entry) => {
        if (!saveContent((d) => {
          d.seo = d.seo || {}; d.seo.pages = { ...(d.seo.pages || {}) };
          if (entry) d.seo.pages[path] = entry; else delete d.seo.pages[path];
        }, 'Opgeslagen.')) return;
        close(); if (onSaved) onSaved();
      };
      $('[data-seo-save]', panel).addEventListener('click', () => {
        if (!showErrors(f, {})) return;
        const entry = { title: f.elements.title.value.trim(), description: f.elements.description.value.trim(), noindex: f.elements.noindex.checked };
        save(entry.title || entry.description || entry.noindex ? entry : null);
      });
      $('[data-seo-clear]', panel).addEventListener('click', () => save(null));
    },
  });
}
