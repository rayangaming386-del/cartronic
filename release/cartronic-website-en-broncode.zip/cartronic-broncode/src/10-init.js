/* =====================================================================
   BOOTSTRAP
   ===================================================================== */
function registerRoutes() {
  Router.add('/', Pages.home);
  Router.add('/mogelijkheden', Pages.catalog);
  Router.add('/mogelijkheden/:slug', Pages.retrofit);
  Router.add('/merken', Pages.brands);
  Router.add('/merken/:brand', Pages.brand);
  Router.add('/projecten', Pages.projects);
  Router.add('/projecten/:slug', Pages.project);
  Router.add('/expertise', Pages.expertise);
  Router.add('/diensten/:slug', Pages.service);
  Router.add('/over', Pages.about);
  Router.add('/contact', Pages.contact);
  Router.add('/mijn-auto', Pages.garage);
  Router.add('/beoordelingen', Pages.reviews);
  Router.add('/kennis', Pages.knowledge);
  Router.add('/kennis/:slug', Pages.article);
  Router.add('/productinformatie', Pages.productInfo);
  Router.add('/privacy', Pages.privacy);
  Router.add('/zoeken', Pages.search);
  Router.add('/webshop', shopGate(Pages.shop));
  Router.add('/webshop/:slug', shopGate(Pages.product));
  Router.add('/winkelmand', shopGate(Pages.cart));
  Router.add('/afrekenen', shopGate(Pages.checkout));
  Router.add('/betaling/:id', Pages.payment);
  Router.add('/bestelling/:id', Pages.orderResult);
  Router.add('/admin', Pages.adminDashboard);
  Router.add('/admin/producten', Pages.adminProducts);
  Router.add('/admin/producten/nieuw', Pages.adminProductForm);
  Router.add('/admin/producten/:id', Pages.adminProductForm);
  Router.add('/admin/categorieen', Pages.adminCategories);
  Router.add('/admin/bestellingen', Pages.adminOrders);
  Router.add('/admin/bestellingen/:id', Pages.adminOrder);
  Router.add('/admin/acties', Pages.adminPromos);
  Router.add('/admin/voorraad', Pages.adminStock);
  Router.add('/admin/projecten', Pages.adminProjects);
  Router.add('/admin/projecten/nieuw', Pages.adminProjectForm);
  Router.add('/admin/projecten/:id', Pages.adminProjectForm);
  Router.add('/admin/instellingen', Pages.adminSettings);
  Router.add('/admin/website', Pages.adminWebsite);
  Router.add('/admin/bedrijf', Pages.adminCompany);
  Router.add('/admin/teksten', Pages.adminTexts);
  Router.add('/admin/weergave', Pages.adminDisplay);
  Router.add('/admin/seo', Pages.adminSeo);
  Router.add('/admin/opties', Pages.adminOptions);
  Router.add('/admin/opties/nieuw', Pages.adminOptionForm);
  Router.add('/admin/opties/:slug', Pages.adminOptionForm);
  Router.add('/admin/catalogus', Pages.adminCatalog);
  Router.add('/admin/diensten', Pages.adminServices);
  Router.add('/admin/diensten/nieuw', Pages.adminServiceForm);
  Router.add('/admin/diensten/:slug', Pages.adminServiceForm);
  Router.add('/admin/kennis', Pages.adminArticles);
  Router.add('/admin/kennis/nieuw', Pages.adminArticleForm);
  Router.add('/admin/kennis/:slug', Pages.adminArticleForm);
  Router.add('/admin/beoordelingen', Pages.adminReviews);
  Router.add('/admin/meer-werk', Pages.adminMoreWork);
  Router.add('*', Pages.notFound);
  // Archived catalog URLs (e.g. cartronic.nl slugs) → the current page for the same option.
  Router.redirect((path) => {
    const m = path.match(/^\/mogelijkheden\/([^/]+)$/);
    return m && !RETROFIT[m[1]] && RETROFIT_ALIAS[m[1]] ? `/mogelijkheden/${RETROFIT_ALIAS[m[1]]}` : null;
  });
}

function bindGlobal() {
  document.addEventListener('click', async (e) => {
    // Skip link: move focus to the content instead of routing to "#main".
    if (e.target.closest('.skip-link')) {
      e.preventDefault();
      const m = document.getElementById('main');
      if (m) { m.focus({ preventScroll: true }); m.scrollIntoView(); }
      return;
    }
    // Any link in the mobile menu closes it, also the link to the page that is already open.
    const navLink = e.target.closest('#mobileNav a[href]');
    if (navLink && plainClick(e)) { // a new-tab click (Ctrl, Shift, middle button) leaves the menu open
      Layout.closeMenu();
      if (Router.isCurrent(navLink.getAttribute('href'))) window.scrollTo(0, 0);
    }
    const el = e.target.closest('[data-action]');
    if (!el) return;
    const act = el.dataset.action;
    switch (act) {
      case 'open-search': e.preventDefault(); Layout.closeMenu(); SearchOverlay.open(); break;
      case 'open-vehicle': e.preventDefault(); Layout.closeMenu(); VehicleModal.open(); break;
      case 'open-cart': e.preventDefault(); Layout.closeMenu(); if (Content.shopOn()) CartUI.openDrawer(); break;
      case 'toggle-menu': e.preventDefault(); Layout.toggleMenu(); break;
      case 'whatsapp': Analytics.track('whatsapp_clicked', { context: Router.current ? Router.current.path : '' }); break;
      case 'scroll-to': {
        const t = document.getElementById(el.dataset.target);
        if (!t) break;
        e.preventDefault();
        t.scrollIntoView({ behavior: reducedMotion() ? 'auto' : 'smooth', block: 'start' });
        const inp = t.querySelector('[data-panel]:not([hidden]) input, [data-panel]:not([hidden]) select');
        setTimeout(() => inp && inp.focus({ preventScroll: true }), reducedMotion() ? 0 : 550);
        break;
      }
      case 'add-to-cart': {
        e.preventDefault();
        const id = el.dataset.id;
        let qty = 1;
        if (el.dataset.qtyFrom) { const inp = $(el.dataset.qtyFrom); qty = parseInt(inp && inp.value, 10) || 1; }
        const res = Cart.add(id, qty);
        if (!res.ok) { Toast.show(res.message, { error: true }); break; }
        CartUI.showAdded(Repo.product(id), res);
        announce(`${Repo.product(id).name} toegevoegd aan winkelmand`);
        if (Router.current && Router.current.path.startsWith('/webshop/')) Router.render();
        break;
      }
      case 'toggle-save': {
        e.preventDefault();
        const on = Saved.toggle(el.dataset.type, el.dataset.id);
        $$(`[data-action="toggle-save"][data-type="${el.dataset.type}"][data-id="${CSS.escape(el.dataset.id)}"]`).forEach((b) => {
          b.setAttribute('aria-pressed', String(on));
          const lbl = $('[data-save-label]', b); if (lbl) lbl.textContent = on ? 'Bewaard' : (el.dataset.type === 'products' ? 'Bewaar' : 'Bewaar optie');
          if (b.classList.contains('save-btn')) { const name = (b.getAttribute('aria-label') || '').split(': ').slice(1).join(': '); b.setAttribute('aria-label', `${on ? 'Verwijder uit bewaard' : 'Bewaar'}: ${name}`); b.title = on ? 'Bewaard' : 'Bewaar'; }
          b.classList.remove('pop'); void b.offsetWidth; b.classList.add('pop');
        });
        Toast.show(on ? 'Bewaard. U vindt het terug onder Mijn auto.' : 'Verwijderd uit bewaard.', on ? { action: { label: 'Bekijk', href: '#/mijn-auto?section=bewaard' } } : {});
        break;
      }
      case 'clear-recent': Recent.clear(); Toast.show('Geschiedenis gewist.'); Router.render(); break;
      case 'forget-plate': VehicleStore.forgetPlate(); Toast.show('Uw kenteken is vergeten.'); Router.render(); break;
      case 'wipe-local': {
        const ok = await Overlay.confirm({ title: 'Alles wissen?', message: 'Uw auto, kenteken, bewaarde opties en producten, geschiedenis, winkelmand, uw demobestellingen en concepten worden uit deze browser verwijderd.', confirmLabel: 'Alles wissen', danger: true });
        if (!ok) break;
        VehicleStore.clear(); Storage.remove('saved'); Recent.clear(); Cart.clear();
        Repo.removeOrders((o) => o.placedHere || !String(o.id).startsWith('ord_demo'));
        Storage.remove('contactDraft', 'session'); Storage.remove('checkoutForm', 'session'); Storage.remove('checkoutKey', 'session');
        Bus.emit('saved:changed'); Toast.show('Uw gegevens zijn uit deze browser verwijderd.'); Router.render();
        break;
      }
      case 'adopt-vehicle': {
        const v = VehicleStore.set({ brandId: el.dataset.brand, modelId: el.dataset.model, source: 'manual', confidence: 'manual' });
        Toast.show(`Uw auto is ingesteld: ${VehicleStore.name(v)}`);
        Router.go('/mogelijkheden');
        break;
      }
      default: break;
    }
  });
  document.addEventListener('keydown', (e) => {
    const typing = e.target.closest && e.target.closest('input, textarea, select, [contenteditable="true"]');
    if ((e.key === 'k' && (e.metaKey || e.ctrlKey)) || (e.key === '/' && !typing)) {
      if (Overlay.count || document.body.classList.contains('is-admin')) return;
      e.preventDefault(); SearchOverlay.open();
    }
    if (e.key === 'Escape' && $('#mobileNav')?.classList.contains('is-open')) Layout.toggleMenu(false);
  });
  ['cart:changed', 'vehicle:changed', 'saved:changed', 'data:changed', 'products:changed'].forEach((evt) => Bus.on(evt, () => Layout.refreshDynamic()));
  // Content edited in Beheer: rebuild the shared chrome (menus, footer, announcement) right away.
  Bus.on('content:changed', () => { Layout.renderHeader(); Layout.renderFooter(); Layout.markNav(); Layout.refreshDynamic(); });
  let lastErr = 0;
  const friendly = () => { if (Date.now() - lastErr < 5000) return; lastErr = Date.now(); Toast.show('Er ging iets mis. Probeer het opnieuw of ververs de pagina.', { error: true }); };
  // A save stopped in an outdated tab already showed its own message.
  window.addEventListener('unhandledrejection', (e) => { if (e.reason && e.reason.ctStale) { e.preventDefault(); return; } console.error(e.reason); friendly(); });
  window.addEventListener('error', (e) => { if (e.target && e.target !== window) return; if (e.error && e.error.ctStale) { e.preventDefault(); return; } console.error(e.error || e.message); friendly(); });
}

function init() {
  Repo.init();
  Media.installFallback();
  Layout.renderHeader();
  Layout.renderFooter();
  registerRoutes();
  bindGlobal();
  Router.start();
  if (Content.stale && !document.body.classList.contains('is-admin')) SiteStatus.staleHint();
  Motion.init();
  // Debug/QA handle (no secrets live in this prototype).
  window.CT = { Repo, Cart, Router, VehicleStore, VehicleLookup, VehicleMatcher, Plate, Pricing, Money, Analytics, Search, Payments, OrderService, CheckoutService, Compat, Content, Seo, Publisher, SiteStatus, fmtText,
    catalog: { RETROFITS, RETROFIT_ALIAS, MODELS, FEATURES, CATEGORIES, ART: Object.keys(ART_SHAPES) } };
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
