/* =====================================================================
   PUBLIC PAGES — Storingen & oplossingen, Beveiliging, Video's
   All content comes from Beheer (Content: STORINGEN, SECURITY, VIDEOS).
   ===================================================================== */
const storingBrand = (x) => (x.brand ? BRAND[x.brand].name : 'Volkswagen, Audi, SEAT en Škoda');
const storingMedia = (x, eager = false) => (x.photos.length ? Media.html(x.photos[0].src, x.photos[0].alt, { kind: x.art, eager }) : Art.html(x.art, 0, x.title));
const visibleStoringen = () => STORINGEN.filter((x) => x.visible);
const storingWa = (x) => WhatsApp.enquiry({ topic: ENQUIRY_TOPIC.storing ? ENQUIRY_TOPIC.storing.label : 'Storing', vehicle: VehicleStore.get() ? VehicleStore.name() : '', plate: VehicleStore.plate(), options: [`Storing: ${x.title}`], question: 'Ik herken deze storing bij mijn auto. Kunt u mij helpen?' });

/* ---------- Storingen: overview ---------- */
Pages.storingen = {
  id: 'storingen', nav: 'storingen',
  meta: () => ({ title: 'Storingen & oplossingen — Volkswagen, Audi, SEAT en Škoda', description: Seo.clamp(`${tt('stor.lead')} Herken de symptomen en vraag CarTronic om hulp.`) }),
  render(ctx) {
    const list = visibleStoringen();
    const brands = BRANDS.filter((b) => list.some((x) => x.brand === b.id || !x.brand));
    const fb = BRAND[ctx.query.merk] ? ctx.query.merk : '';
    return `${UI.pageHeader({ crumbs: [[tt('stor.eyebrow')]], eyebrow: tt('stor.eyebrow'), title: tx('stor.title'), lead: tx('stor.lead') })}
      <section class="section section--first"><div class="container">
        ${list.length && brands.length ? `<div class="chips storing-filter" role="group" aria-label="Filter op merk" data-sf>
          <button class="chip" type="button" data-v="" aria-pressed="${!fb}">Alle merken</button>${brands.map((b) => `<button class="chip" type="button" data-v="${b.id}" aria-pressed="${fb === b.id}">${esc(b.name)}</button>`).join('')}
        </div>` : ''}
        <h2 class="sr-only">Storingen</h2>
        <div class="storing-grid" data-storing-grid>${list.map((x) => `<article class="card storing-card" data-brand="${attr(x.brand)}">
          <div class="card-media">${storingMedia(x)}</div>
          <div class="card-body">
            <p class="card-eyebrow">${esc(storingBrand(x))}</p>
            <h3 class="card-title"><a href="#/storingen/${x.slug}">${esc(x.title)}</a></h3>
            ${x.symptoms.length ? `<ul class="storing-symptoms">${x.symptoms.slice(0, 2).map((t) => `<li>${esc(t)}</li>`).join('')}</ul>` : ''}
            <div class="card-foot"><span class="link">Bekijk de oplossing</span></div>
          </div>
        </article>`).join('')}</div>
        <div data-storing-empty${list.length ? ' hidden' : ''}>${UI.empty({ icon: 'activity', title: list.length ? 'Geen storingen voor dit merk' : 'Er staan nog geen storingen online', text: 'Neem contact op: CarTronic kijkt graag mee.', actions: '<a class="btn btn--dark btn--sm" href="#/contact?onderwerp=storing">Storing melden</a>' })}</div>
        ${tx('stor.note') ? `<div class="note-rule mt-48" data-reveal>${tx('stor.note')}</div>` : ''}
      </div></section>
      ${ctaBand()}`;
  },
  mount(root, ctx) {
    const grid = $('[data-storing-grid]', root); const empty = $('[data-storing-empty]', root);
    let merk = BRAND[ctx.query.merk] ? ctx.query.merk : '';
    const apply = (animate = true) => {
      let shown = 0;
      $$('.storing-card', grid).forEach((c) => { const ok = !merk || !c.dataset.brand || c.dataset.brand === merk; c.hidden = !ok; if (ok) shown++; });
      if (grid.children.length) empty.hidden = shown > 0;
      $$('[data-sf] .chip', root).forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.v === merk)));
      Router.setQuery(merk ? { merk } : {});
      if (animate) { Motion.swap(grid, '.storing-card:not([hidden])'); announce(`${shown} ${shown === 1 ? 'storing' : 'storingen'}`); }
    };
    root.addEventListener('click', (e) => { const b = e.target.closest('[data-sf] .chip'); if (b) { merk = b.dataset.v; apply(); } });
    apply(false);
  },
};

/* ---------- Storing: detail ---------- */
Pages.storing = {
  id: 'storing', nav: 'storingen',
  meta(ctx) {
    const x = visibleStoringen().find((y) => y.slug === ctx.params.slug);
    if (!x) return { title: 'Storing niet gevonden', noindex: true };
    return {
      title: x.title,
      description: Seo.clamp(`${x.symptoms[0] ? `${x.symptoms[0]}. ` : ''}${x.cause || x.solution}`),
      jsonLd: [breadcrumbLd([['Home', '#/'], [tt('stor.eyebrow'), '#/storingen'], [x.title, `#/storingen/${x.slug}`]])].filter(Boolean),
    };
  },
  render(ctx) {
    const x = visibleStoringen().find((y) => y.slug === ctx.params.slug);
    if (!x) return Pages.notFound.render(ctx, { title: 'Deze storing staat niet (meer) online.', text: 'Bekijk de andere storingen of neem contact op.' });
    const svc = x.service ? SERVICE[x.service] : null;
    const product = x.retrofit ? RETROFIT[x.retrofit] : null;
    const models = x.models.filter((m) => MODEL[m]);
    const others = visibleStoringen().filter((y) => y.slug !== x.slug && (!x.brand || !y.brand || y.brand === x.brand)).slice(0, 3);
    const imgs = x.photos.map((p) => p.src);
    return `${UI.pageHeader({ crumbs: [[tt('stor.eyebrow'), '#/storingen'], [x.title]], eyebrow: storingBrand(x), title: esc(x.title), compact: true })}
      <section class="section section--sm"><div class="container split split--top storing-detail">
        <div>
          ${models.length ? `<p class="storing-models">${models.map((m) => `<span class="pill">${esc(modelLabel(m))}</span>`).join('')}</p>` : ''}
          ${x.symptoms.length ? `<div class="detail-block storing-block"><h2>${icon('alertCircle')} ${tx('stor.symptoms')}</h2><ul class="benefits">${x.symptoms.map((t) => `<li>${icon('check')}${esc(t)}</li>`).join('')}</ul></div>` : ''}
          ${x.cause ? `<div class="detail-block storing-block"><h2>${icon('search')} ${tx('stor.cause')}</h2><p>${esc(x.cause)}</p></div>` : ''}
          ${x.solution ? `<div class="detail-block storing-block"><h2>${icon('wrench')} ${tx('stor.solution')}</h2><p>${esc(x.solution)}</p></div>` : ''}
          <div class="storing-ask">
            <h2 class="h4">${tx('stor.cta.title')}</h2>
            <p>${tx('stor.cta.text')}</p>
            <div class="detail-actions">
              <a class="btn btn--whatsapp" href="${attr(WhatsApp.url(storingWa(x)))}" target="_blank" rel="noopener" data-action="whatsapp">${icon('whatsapp')} WhatsApp over deze storing</a>
              <a class="btn btn--primary" href="#/contact?onderwerp=storing&amp;storing=${x.slug}">Contactformulier</a>
              <a class="btn btn--light" href="${attr(COMPANY.phoneHref)}">${icon('phone')} Bel ons</a>
            </div>
          </div>
          ${svc || product ? `<div class="detail-block"><h2>Gerelateerd</h2><div class="grid">
            ${svc ? `<a class="mini-item" href="#/diensten/${svc.slug}" style="grid-template-columns:40px minmax(0,1fr) auto"><span class="icon-circle icon-circle--sm">${icon(svc.icon)}</span><span><span class="mi-type">Dienst</span><span class="mi-title" style="display:block">${esc(svc.title)}</span></span>${icon('arrow').replace('<svg', '<svg style="width:16px;height:16px;color:var(--muted)"')}</a>` : ''}
            ${product ? `<a class="mini-item" href="#/producten/${product.slug}" style="grid-template-columns:40px minmax(0,1fr) auto"><span class="icon-circle icon-circle--sm">${icon(CATEGORY[product.cat].icon)}</span><span><span class="mi-type">Product</span><span class="mi-title" style="display:block">${esc(product.title)}</span></span>${icon('arrow').replace('<svg', '<svg style="width:16px;height:16px;color:var(--muted)"')}</a>` : ''}
          </div></div>` : ''}
        </div>
        <div>${imgs.length ? UI.gallery(imgs, x.title, x.art, x.photos.map((p) => p.alt))
          : `<div class="split-media" style="aspect-ratio:4/3">${Art.html(x.art, 1, x.title)}</div>`}</div>
      </div></section>
      ${others.length ? `<section class="section section--soft section--sm" aria-labelledby="more-storing"><div class="container">
        <div class="section-head" style="margin-bottom:28px"><h2 class="h3" id="more-storing">Andere storingen</h2><a class="link" href="#/storingen">Alle storingen ${icon('arrow')}</a></div>
        <div class="storing-grid">${others.map((y) => `<article class="card storing-card"><div class="card-media">${storingMedia(y)}</div><div class="card-body"><p class="card-eyebrow">${esc(storingBrand(y))}</p><h3 class="card-title"><a href="#/storingen/${y.slug}">${esc(y.title)}</a></h3><div class="card-foot"><span class="link">Bekijk de oplossing</span></div></div></article>`).join('')}</div>
      </div></section>` : ''}
      ${ctaBand()}`;
  },
  mount(root) { Behaviours.mount(root); },
};

/* ---------- Beveiliging ---------- */
const SECURITY_PRODUCT = 'origineel-af-fabriek-alarm-scm';
Pages.security = {
  id: 'security', nav: 'beveiliging',
  meta: () => ({ title: 'Beveiliging — klasse 1 tot en met 5, peilsystemen en SCM', description: Seo.clamp(tt('sec.lead')) }),
  render() {
    const S = SECURITY;
    const classes = S.classes.filter((c) => c.visible);
    const oem = RETROFIT[SECURITY_PRODUCT];
    const wa = WhatsApp.enquiry({ topic: 'Beveiliging', vehicle: VehicleStore.get() ? VehicleStore.name() : '', plate: VehicleStore.plate(), question: 'Ik heb een vraag over de beveiliging van mijn auto (beveiligingsklasse / alarm / volgsysteem).' });
    return `${UI.pageHeader({ crumbs: [[tt('sec.eyebrow')]], eyebrow: tt('sec.eyebrow'), title: tx('sec.title'), lead: tx('sec.lead') })}
      <section class="section section--first"><div class="container split split--top">
        <div>
          <p class="eyebrow">${icon('award').replace('<svg', '<svg style="width:14px;height:14px"')} Origineel</p>
          <h2 class="h2 mt-16">${tx('sec.oem.title')}</h2>
          <div class="prose mt-24"><p>${tx('sec.oem.text')}</p></div>
          <div class="detail-actions">
            ${oem ? `<a class="btn btn--primary" href="#/producten/${oem.slug}">${tx('sec.oem.btn')}</a>` : ''}
            <a class="btn btn--whatsapp" href="${attr(WhatsApp.url(wa))}" target="_blank" rel="noopener" data-action="whatsapp">${icon('whatsapp')} WhatsApp</a>
          </div>
        </div>
        <div>${S.photos.length ? UI.gallery(S.photos.map((p) => p.src), 'Beveiliging', 'alarm', S.photos.map((p) => p.alt))
          : `<div class="split-media" style="aspect-ratio:4/3">${Art.html('alarm', 1, 'Origineel alarmsysteem')}</div>`}</div>
      </div></section>
      ${classes.length ? `<section class="section section--soft" aria-labelledby="classes-title"><div class="container">
        <div class="section-intro"><p class="eyebrow">Klasse 1–5</p><h2 class="h2" id="classes-title" data-split>${tx('sec.classes.title')}</h2></div>
        <ol class="class-grid" data-stagger>${classes.map((c, i) => `<li class="class-card"><span class="class-num" aria-hidden="true">${i + 1}</span><h3>${esc(c.title)}${c.name ? `<span>${esc(c.name)}</span>` : ''}</h3><p>${esc(c.text)}</p></li>`).join('')}</ol>
      </div></section>` : ''}
      <section class="section" aria-label="Peilsystemen en verzekering"><div class="container sec-two">
        ${S.peil.visible && S.peil.text ? `<div class="sec-panel"><span class="ib-icon">${icon('signal')}</span><h2 class="h3">${esc(S.peil.title)}</h2><p>${esc(S.peil.text)}</p></div>` : ''}
        ${S.why ? `<div class="sec-panel"><span class="ib-icon">${icon('shield')}</span><h2 class="h3">${tx('sec.why.title')}</h2><p>${esc(S.why)}</p></div>` : ''}
      </div></section>
      ${S.marks.length ? `<section class="section section--soft section--sm" aria-labelledby="marks-title"><div class="container">
        <h2 class="h3" id="marks-title" style="margin-bottom:24px">${tx('sec.marks.title')}</h2>
        <div class="info-grid info-grid--3">${S.marks.map((m) => `<article class="info-block"><span class="ib-icon">${icon('award')}</span><h3 class="h4">${esc(m.name)}</h3><p>${esc(m.text)}</p></article>`).join('')}</div>
        ${tx('sec.note') ? `<p class="hint mt-24">${tx('sec.note')}</p>` : ''}
      </div></section>` : ''}
      <section class="section section--sm" aria-labelledby="sec-ask"><div class="container"><div class="review-cta">
        <div><h2 class="h3" id="sec-ask">${tx('sec.cta.title')}</h2><p>${tx('sec.cta.text')}</p></div>
        <div class="flex wrap gap-8"><a class="btn btn--dark" href="#/contact">${tx('sec.btn')}</a><a class="btn btn--whatsapp" href="${attr(WhatsApp.url(wa))}" target="_blank" rel="noopener" data-action="whatsapp">${icon('whatsapp')} WhatsApp</a></div>
      </div></div></section>
      ${ctaBand()}`;
  },
  mount(root) { Behaviours.mount(root); },
};

/* ---------- Video's ---------- */
const videoInfo = (v) => parseVideoUrl(v.url);
const videoThumb = (v, info) => v.thumb || (info && info.thumb) || '';
const visibleVideos = () => VIDEOS.filter((v) => v.visible && videoInfo(v)).sort((a, b) => Number(b.featured) - Number(a.featured));
Pages.videos = {
  id: 'videos', nav: 'videos',
  meta: () => ({ title: 'Video’s — CarTronic in beeld', description: Seo.clamp(`${tt('vid.lead')} Bekijk video’s van originele opties en uitleg van CarTronic.`) }),
  render(ctx) {
    const list = visibleVideos();
    const platforms = Object.keys(VIDEO_PLATFORMS).filter((p) => list.some((v) => videoInfo(v).platform === p));
    const fp = VIDEO_PLATFORMS[ctx.query.platform] ? ctx.query.platform : '';
    const follow = Content.videoSettings().follow ? uniq([COMPANY.facebook, ...(COMPANY.social || [])].filter(Boolean)) : [];
    const label = (u) => { try { const h = new URL(u).hostname.replace(/^www\./, ''); return ({ 'facebook.com': 'Facebook', 'instagram.com': 'Instagram', 'youtube.com': 'YouTube', 'tiktok.com': 'TikTok', 'linkedin.com': 'LinkedIn' })[h] || h; } catch (e) { return u; } };
    return `${UI.pageHeader({ crumbs: [[tt('vid.eyebrow')]], eyebrow: tt('vid.eyebrow'), title: tx('vid.title'), lead: tx('vid.lead') })}
      <section class="section section--first"><div class="container">
        ${platforms.length > 1 ? `<div class="chips video-filter" role="group" aria-label="Filter op platform" data-vf>
          <button class="chip" type="button" data-v="" aria-pressed="${!fp}">Alle video’s</button>${platforms.map((p) => `<button class="chip" type="button" data-v="${p}" aria-pressed="${fp === p}">${VIDEO_PLATFORMS[p]}</button>`).join('')}
        </div>` : ''}
        <p class="hint video-privacy">${icon('lock').replace('<svg', '<svg style="width:14px;height:14px;vertical-align:-2px"')} ${tx('vid.privacy')} <a class="text-link" href="#/privacy">Privacy</a></p>
        <h2 class="sr-only">Video’s</h2>
        <div class="video-grid" data-video-grid>${list.map((v) => {
          const info = videoInfo(v); const thumb = videoThumb(v, info);
          return `<article class="video-card${v.featured ? ' video-card--featured' : ''}" id="video-${attr(v.id)}" data-platform="${info.platform}">
            <div class="video-frame${info.short ? ' video-frame--tall' : ''}" data-frame>
              <button class="video-play" type="button" data-play="${attr(v.id)}" aria-label="Video afspelen: ${attr(v.title)} (laadt ${VIDEO_PLATFORMS[info.platform]})">
                ${thumb ? Media.html(thumb, '', { kind: 'camera' }) : '<span class="video-placeholder" aria-hidden="true"></span>'}
                <span class="video-play-icon" aria-hidden="true">${icon('play')}</span>
              </button>
            </div>
            <div class="video-body">
              <span class="video-tags"><span class="pill">${VIDEO_PLATFORMS[info.platform]}</span>${v.featured ? '<span class="pill pill--dark">Uitgelicht</span>' : ''}</span>
              <h3>${esc(v.title)}</h3>
              ${v.description ? `<p>${esc(v.description)}</p>` : ''}
              <a class="ink-link" href="${attr(v.url)}" target="_blank" rel="noopener">Bekijk op ${VIDEO_PLATFORMS[info.platform]}<span class="sr-only"> (opent in een nieuw venster)</span></a>
            </div>
          </article>`;
        }).join('')}</div>
        <div data-video-empty${list.length ? ' hidden' : ''}>${UI.empty({ icon: 'video', title: list.length ? 'Geen video’s voor dit platform' : 'Er staan nog geen video’s online', text: 'Kijk later nog eens of bekijk ons portfolio.', actions: '<a class="btn btn--dark btn--sm" href="#/portfolio">Naar het portfolio</a>' })}</div>
        ${follow.length ? `<div class="follow-row"><h2 class="h4">${tx('vid.follow')}</h2><div class="flex wrap gap-8">${follow.map((u) => `<a class="btn btn--light btn--sm" href="${attr(u)}" target="_blank" rel="noopener">${esc(label(u))}<span class="sr-only"> (opent in een nieuw venster)</span></a>`).join('')}</div></div>` : ''}
      </div></section>
      ${ctaBand()}`;
  },
  mount(root, ctx) {
    const grid = $('[data-video-grid]', root); const empty = $('[data-video-empty]', root);
    let platform = VIDEO_PLATFORMS[ctx.query.platform] ? ctx.query.platform : '';
    const apply = (animate = true) => {
      let shown = 0;
      $$('.video-card', grid).forEach((c) => { const ok = !platform || c.dataset.platform === platform; c.hidden = !ok; if (ok) shown++; });
      if (grid.children.length) empty.hidden = shown > 0;
      $$('[data-vf] .chip', root).forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.v === platform)));
      const q = {}; if (platform) q.platform = platform; if (ctx.query.v) q.v = ctx.query.v;
      Router.setQuery(q);
      if (animate) announce(`${shown} ${shown === 1 ? 'video' : 'video’s'}`);
    };
    root.addEventListener('click', (e) => {
      const chip = e.target.closest('[data-vf] .chip');
      if (chip) { platform = chip.dataset.v; apply(); return; }
      const play = e.target.closest('[data-play]');
      if (!play) return;
      // Only now is anything loaded from the platform.
      const v = VIDEOS.find((x) => x.id === play.dataset.play); const info = v && videoInfo(v);
      if (!info) return;
      const frame = play.closest('[data-frame]');
      frame.innerHTML = `<iframe src="${attr(info.embed)}" title="${attr(v.title)}" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe>`;
      frame.classList.add('is-playing');
      const f = $('iframe', frame); if (f) f.focus();
    });
    apply(false);
    if (ctx.query.v) { const c = document.getElementById(`video-${ctx.query.v}`); if (c) setTimeout(() => { c.scrollIntoView({ block: 'center' }); const b = $('[data-play]', c); if (b) b.focus({ preventScroll: true }); }, 60); }
  },
};
