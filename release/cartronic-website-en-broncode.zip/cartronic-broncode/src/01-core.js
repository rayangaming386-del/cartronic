/* =====================================================================
   CARTRONIC — APPLICATION SCRIPT
   ---------------------------------------------------------------------
   ARCHITECTURE
   UI layer ....... pages (render + mount), shared components, hash router
   Domain ......... catalog (retrofits, services, projects), vehicle matching,
                    pricing (integer cents), cart, checkout, orders
   Adapters ....... isolated so they can be replaced without touching the UI:
     Repo ............. persistence   today: localStorage
                                       production: REST API + database
     VehicleLookup .... kenteken      today: RDW Open Data (live, from the browser) + demo test plates
                                       production: proxy via own backend (caching, rate limiting,
                                       no logging of plates)
     Payments ......... payments      today: DemoPaymentAdapter (simulated, test mode only)
                                       production: server-side Mollie integration (see PRODUCTION_PAYMENT_FLOW)
     Auth ............. admin login   today: DemoAuth — NOT SECURE, credentials are visible in the UI
                                       production: server sessions (HttpOnly cookies), hashed passwords,
                                       CSRF protection, rate limiting, 2FA; every mutation authorised server-side
     Analytics ........ events        today: in-memory event layer, nothing leaves the browser
                                       production: consent-aware, privacy-friendly endpoint
   SEO (production)
     Every retrofit, model, product and project gets its own server-rendered, indexable URL, e.g.
     /mogelijkheden/volkswagen/golf-8/achteruitrijcamera. The hash routes here simulate that
     structure; filters must stay a progressive enhancement on top of crawlable pages.
   ===================================================================== */

/* ---------- Utilities ---------- */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const ESC_MAP = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const esc = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, (c) => ESC_MAP[c]);
const attr = esc;
const uid = (prefix = 'id') => `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
const slugify = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()
  .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80).replace(/-+$/, '');
const normText = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()
  .replace(/[^a-z0-9.+\s-]/g, ' ').replace(/[-.]/g, ' ').replace(/\s+/g, ' ').trim();
const clamp = (n, min, max) => Math.min(max, Math.max(min, n));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const debounce = (fn, ms = 200) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
const nowIso = () => new Date().toISOString();
const reducedMotion = () => { try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; } };
const isInt = (n) => Number.isInteger(n);
const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
const uniq = (arr) => Array.from(new Set(arr));
const byKey = (arr, key = 'id') => Object.assign(Object.create(null), Object.fromEntries(arr.map((x) => [x[key], x])));
const deepClone = (o) => JSON.parse(JSON.stringify(o));
/** JSON with sorted object keys, to compare data regardless of key order. */
const stableStringify = (v) => JSON.stringify(v, (k, x) => (x && typeof x === 'object' && !Array.isArray(x)
  ? Object.keys(x).sort().reduce((o, key) => { o[key] = x[key]; return o; }, {}) : x));

const DATE_FMT = new Intl.DateTimeFormat('nl-NL', { day: 'numeric', month: 'short', year: 'numeric' });
const DATETIME_FMT = new Intl.DateTimeFormat('nl-NL', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
const fmtDate = (iso) => { try { return DATE_FMT.format(new Date(iso)); } catch (e) { return ''; } };
const fmtDateTime = (iso) => { try { return DATETIME_FMT.format(new Date(iso)); } catch (e) { return ''; } };

/* ---------- Money: integer cents only ---------- */
const EUR = new Intl.NumberFormat('nl-NL', { style: 'currency', currency: 'EUR' });
const Money = {
  fmt(cents) { return EUR.format((Number(cents) || 0) / 100); },
  /** Parses user input ("249", "249,95", "1.249,95", "249.95") into integer cents, or NaN. */
  parse(input) {
    let s = String(input == null ? '' : input).trim().replace(/[€\s]/g, '');
    if (!s) return NaN;
    if (s.includes(',')) s = s.replace(/\./g, '').replace(',', '.');
    if (!/^\d{1,7}(\.\d{1,2})?$/.test(s)) return NaN;
    const [i, d = ''] = s.split('.');
    return parseInt(i, 10) * 100 + parseInt((d + '00').slice(0, 2), 10);
  },
  toInput(cents) { return Number.isFinite(cents) ? (cents / 100).toFixed(2).replace('.', ',') : ''; },
  /** Percentage of `part` relative to `whole`, rounded to a whole percent. */
  pct(part, whole) { return whole > 0 ? Math.round((part / whole) * 100) : 0; },
};

/* ---------- Storage (with in-memory fallback) ---------- */
const Storage = (() => {
  const PREFIX = 'ct.v1.';
  const memory = { local: {}, session: {} };
  function probe(name) {
    try { const s = window[name]; s.setItem('__ct', '1'); s.removeItem('__ct'); return s; } catch (e) { return null; }
  }
  const areas = { local: probe('localStorage'), session: probe('sessionStorage') };
  function get(key, fallback, area = 'local') {
    try {
      const s = areas[area];
      const raw = s ? s.getItem(PREFIX + key) : memory[area][key];
      return raw == null ? fallback : JSON.parse(raw);
    } catch (e) { return fallback; }
  }
  function set(key, value, area = 'local') {
    const raw = JSON.stringify(value);
    try {
      const s = areas[area];
      if (s) s.setItem(PREFIX + key, raw); else memory[area][key] = raw;
      return true;
    } catch (e) {
      memory[area][key] = raw;
      if (typeof Toast !== 'undefined') Toast.show('De opslag van deze browser is vol. Wijzigingen blijven bewaard tot u de pagina sluit.', { error: true });
      return false;
    }
  }
  function remove(key, area = 'local') {
    try { const s = areas[area]; if (s) s.removeItem(PREFIX + key); delete memory[area][key]; } catch (e) { /* ignore */ }
  }
  return { get, set, remove, PREFIX, available: !!areas.local };
})();

/* ---------- Event bus ---------- */
const Bus = (() => {
  const handlers = {};
  return {
    on(evt, fn) { (handlers[evt] = handlers[evt] || []).push(fn); return () => this.off(evt, fn); },
    off(evt, fn) { handlers[evt] = (handlers[evt] || []).filter((h) => h !== fn); },
    emit(evt, data) { (handlers[evt] || []).slice().forEach((h) => { try { h(data); } catch (e) { console.error(e); } }); },
  };
})();

/* ---------- Analytics-ready event layer (nothing is sent anywhere) ----------
   Supported events: vehicle_lookup_started, vehicle_lookup_success, vehicle_lookup_unsupported,
   vehicle_selected, retrofit_viewed, product_viewed, product_added_to_cart, product_saved,
   checkout_started, whatsapp_clicked (+ a few internal ones).
   Production: forward from here to a consent-aware endpoint. Never send plates or personal data. */
const Analytics = {
  events: [],
  BLOCKED_KEYS: ['kenteken', 'plate', 'email', 'phone', 'name', 'firstName', 'lastName'],
  track(name, props = {}) {
    const clean = {};
    Object.keys(props).forEach((k) => { if (!this.BLOCKED_KEYS.includes(k)) clean[k] = props[k]; });
    const evt = { name, props: clean, at: nowIso() };
    this.events.push(evt);
    if (this.events.length > 150) this.events.shift();
    try { window.dispatchEvent(new CustomEvent('ct:analytics', { detail: evt })); } catch (e) { /* ignore */ }
  },
};

/* ---------- Icons (inline SVG, stroke based) ---------- */
const ICON_PATHS = {
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  car: '<path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path d="M9 17h6"/><circle cx="17" cy="17" r="2"/>',
  cart: '<circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/>',
  phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/>',
  whatsapp: '<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/><path d="M9.2 8.6c.2-.4.6-.5.9-.3l.9 1.6c.1.3 0 .6-.2.8l-.5.5c.5 1 1.3 1.8 2.3 2.3l.5-.5c.2-.2.5-.3.8-.2l1.6.9c.3.2.4.6.2.9-.4.8-1.2 1.2-2.1 1-2.2-.6-4-2.4-4.6-4.6-.1-.9.3-1.7.2-2.4"/>',
  mail: '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
  pin: '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
  clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
  right: '<path d="m9 18 6-6-6-6"/>',
  left: '<path d="m15 18-6-6 6-6"/>',
  down: '<path d="m6 9 6 6 6-6"/>',
  arrow: '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
  arrowLeft: '<path d="M19 12H5"/><path d="m12 19-7-7 7-7"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
  plus: '<path d="M5 12h14"/><path d="M12 5v14"/>',
  minus: '<path d="M5 12h14"/>',
  bookmark: '<path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/>',
  settings2: '<path d="M20 7h-9"/><path d="M14 17H5"/><circle cx="17" cy="17" r="3"/><circle cx="7" cy="7" r="3"/>',
  sliders: '<path d="M21 4h-7M10 4H3M21 12h-9M8 12H3M21 20h-5M12 20H3M14 2v4M8 10v4M16 18v4"/>',
  info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>',
  alert: '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
  alertCircle: '<circle cx="12" cy="12" r="10"/><path d="M12 8v4"/><path d="M12 16h.01"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/>',
  camera: '<path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/>',
  phoneDevice: '<rect width="14" height="20" x="5" y="2" rx="2"/><path d="M12 18h.01"/>',
  monitor: '<rect width="20" height="14" x="2" y="3" rx="2"/><path d="M8 21h8"/><path d="M12 17v4"/>',
  chat: '<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/>',
  gauge: '<path d="m12 14 4-4"/><path d="M3.34 19a10 10 0 1 1 17.32 0"/>',
  radar: '<path d="M19.07 4.93A10 10 0 0 0 6.99 3.34"/><path d="M2.29 9.62A10 10 0 1 0 21.31 8.35"/><path d="M16.24 7.76A6 6 0 1 0 8.23 16.67"/><path d="M17.99 11.66A6 6 0 0 1 15.77 16.67"/><circle cx="12" cy="12" r="2"/><path d="m13.41 10.59 5.66-5.66"/>',
  light: '<path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/>',
  comfort: '<path d="M19 9V6a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v3"/><path d="M3 16a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-5a2 2 0 0 0-4 0v1.5a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5V11a2 2 0 0 0-4 0z"/><path d="M5 18v2"/><path d="M19 18v2"/>',
  tow: '<circle cx="17" cy="6" r="3"/><path d="M17 9v3a3 3 0 0 1-3 3H4"/><path d="M4 11v8"/>',
  wrench: '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>',
  cpu: '<rect width="16" height="16" x="4" y="4" rx="2"/><rect width="6" height="6" x="9" y="9" rx="1"/><path d="M15 2v2M15 20v2M2 15h2M2 9h2M20 15h2M20 9h2M9 2v2M9 20v2"/>',
  target: '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="4"/><path d="M22 12h-4M6 12H2M12 6V2M12 22v-4"/>',
  activity: '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
  refresh: '<path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"/><path d="M16 16h5v5"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
  trash: '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>',
  pencil: '<path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>',
  archive: '<rect width="20" height="5" x="2" y="3" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8"/><path d="M10 12h4"/>',
  eye: '<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>',
  eyeOff: '<path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.53 13.53 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/><path d="m2 2 20 20"/>',
  star: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
  box: '<path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M12 22V12"/>',
  tag: '<path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"/><circle cx="7.5" cy="7.5" r="1"/>',
  receipt: '<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M8 7h8M8 11h8M8 15h5"/>',
  dashboard: '<rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
  layers: '<path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/><path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/>',
  percent: '<path d="M19 5 5 19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/>',
  image: '<rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>',
  upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m17 8-5-5-5 5"/><path d="M12 3v12"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
  external: '<path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1"/>',
  calendar: '<rect width="18" height="18" x="3" y="4" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
  card: '<rect width="20" height="14" x="2" y="5" rx="2"/><path d="M2 10h20"/>',
  truck: '<path d="M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2"/><path d="M15 18H9"/><path d="M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14"/><circle cx="17" cy="18" r="2"/><circle cx="7" cy="18" r="2"/>',
  store: '<path d="M3 21h18"/><path d="M5 21V8l7-5 7 5v13"/><path d="M9 21v-6h6v6"/>',
  lock: '<rect width="18" height="11" x="3" y="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  history: '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>',
  nav: '<polygon points="3 11 22 2 13 21 11 13 3 11"/>',
  copy: '<rect width="14" height="14" x="8" y="8" rx="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
  mirror: '<path d="M3 10c0-3 2.5-5 6-5h9.5c1.6 0 2.7 1.5 2.3 3l-1.3 6.2c-.4 1.7-1.9 2.8-3.6 2.8H8c-2.8 0-5-2.2-5-5Z"/><path d="M8 17l-1 4"/>',
  wheel: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="2.5"/><path d="M3.5 10.5 9.6 12M14.4 12l6.1-1.5M12 14.5V21"/>',
  grid: '<rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/>',
  file: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/>',
  folder: '<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/>',
  euro: '<path d="M4 10h12"/><path d="M4 14h9"/><path d="M19 6a7.7 7.7 0 0 0-5.2-2A7.9 7.9 0 0 0 6 12c0 4.4 3.5 8 7.8 8 2 0 3.8-.8 5.2-2"/>',
};
function icon(name, cls = '') {
  const p = ICON_PATHS[name] || ICON_PATHS.info;
  return `<svg${cls ? ` class="${cls}"` : ''} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${p}</svg>`;
}

/* ---------- Logo (vector recreation of the CarTronic wordmark) ---------- */
function logoSvg({ light = false, title = 'CarTronic' } = {}) {
  const ink = light ? '#FFFFFF' : '#141414';
  return `<svg viewBox="0 0 216 46" role="img" aria-label="${esc(title)}"><title>${esc(title)}</title>
    <path d="M36 10.6C82 1.4 150 1.2 212 9.4 151 4.8 86 5.4 36 10.6Z" fill="${ink}"/>
    <path d="M2.5 33.2C2.5 21.6 17 14.6 39 14.6h27.5c8.6 0 12.6 4 12.6 9.6 0 10.2-14.4 18.4-35.6 18.4H15C7 42.6 2.5 39.4 2.5 33.2Z" fill="#B51625"/>
    <path d="M9 37.5c6-4.6 22-7.4 46-6.8" stroke="rgba(255,255,255,.18)" stroke-width="1" fill="none"/>
    <text x="12" y="37.4" font-family="'Times New Roman', Times, 'Liberation Serif', Georgia, serif" font-size="25" fill="#FFFFFF" letter-spacing=".4">CAR</text>
    <text x="80.5" y="37.6" font-family="'Times New Roman', Times, 'Liberation Serif', Georgia, serif" font-size="27.5" fill="${ink}" letter-spacing="1.1">TRONIC</text>
  </svg>`;
}

/* ---------- Route progress bar ---------- */
const RouteProgress = {
  start() { const el = $('#routeProgress'); if (!el) return; el.classList.remove('is-done'); void el.offsetWidth; el.classList.add('is-active'); },
  done() { const el = $('#routeProgress'); if (!el) return; el.classList.add('is-done'); setTimeout(() => el.classList.remove('is-active', 'is-done'), 450); },
};

/* ---------- Live region ---------- */
function announce(msg) {
  const el = $('#liveRegion'); if (!el) return;
  el.textContent = '';
  setTimeout(() => { el.textContent = msg; }, 40);
}

/* ---------- Toasts ---------- */
const Toast = {
  show(message, { action, error = false, duration = 4800 } = {}) {
    const region = $('#toastRegion'); if (!region) return;
    const el = document.createElement('div');
    el.className = `toast${error ? ' is-error' : ''}`;
    el.setAttribute('role', error ? 'alert' : 'status');
    el.innerHTML = `${icon(error ? 'alertCircle' : 'check', 't-icon')}<div>${esc(message)}</div>
      <div class="flex items-center gap-8">${action ? `<a class="t-action" href="${attr(action.href)}">${esc(action.label)}</a>` : ''}
      <button class="t-close" type="button" aria-label="Melding sluiten">${icon('x')}</button></div>`;
    region.appendChild(el);
    requestAnimationFrame(() => el.classList.add('is-in'));
    const close = () => { el.classList.remove('is-in'); setTimeout(() => el.remove(), 320); };
    el.querySelector('.t-close').addEventListener('click', close);
    el.querySelector('.t-action')?.addEventListener('click', close);
    if (duration) setTimeout(close, duration);
    while (region.children.length > 3) region.firstElementChild.remove();
  },
};

/* ---------- Overlays: modal, drawer, confirm (with focus management) ---------- */
const Overlay = (() => {
  const stack = [];
  const FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

  function lockScroll() { document.body.classList.add('is-locked'); }
  function unlockScroll() { if (!stack.length) document.body.classList.remove('is-locked'); }

  function open({ kind = 'modal', title = '', body = '', foot = '', size = '', className = '', onMount, onClose, labelledBy, side = 'right', initialFocus } = {}) {
    const root = $('#overlayRoot');
    const id = uid('ov');
    const backdrop = document.createElement('div');
    backdrop.className = 'overlay-backdrop';
    const panel = document.createElement('div');
    const titleId = `${id}_title`;
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-modal', 'true');
    panel.setAttribute('aria-labelledby', labelledBy || titleId);
    panel.tabIndex = -1;
    if (kind === 'drawer') {
      panel.className = `drawer${side === 'left' ? ' drawer--left' : ''} ${className}`;
      panel.innerHTML = `<div class="drawer-head"><h2 id="${titleId}">${title}</h2><button class="icon-btn" type="button" data-close aria-label="Sluiten">${icon('x')}</button></div>
        <div class="drawer-body">${body}</div>${foot ? `<div class="drawer-foot">${foot}</div>` : ''}`;
    } else if (kind === 'raw') {
      panel.className = className;
      panel.innerHTML = body;
    } else {
      panel.className = `modal ${size ? `modal--${size}` : ''} ${className}`;
      panel.innerHTML = `<div class="modal-head"><h2 id="${titleId}">${title}</h2><button class="icon-btn" type="button" data-close aria-label="Sluiten">${icon('x')}</button></div>
        <div class="modal-body">${body}</div>${foot ? `<div class="modal-foot">${foot}</div>` : ''}`;
    }
    root.appendChild(backdrop);
    root.appendChild(panel);
    const entry = { id, panel, backdrop, onClose, returnFocus: document.activeElement, closed: false };
    stack.push(entry);
    lockScroll();
    requestAnimationFrame(() => { backdrop.classList.add('is-open'); panel.classList.add('is-open'); });

    const close = (result) => closeEntry(entry, result);
    entry.close = close;
    backdrop.addEventListener('click', () => close());
    panel.addEventListener('click', (e) => { if (e.target.closest('[data-close]')) { e.preventDefault(); close(); } });
    panel.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') { e.stopPropagation(); close(); return; }
      if (e.key !== 'Tab') return;
      const f = $$(FOCUSABLE, panel).filter((el) => el.offsetParent !== null || el === document.activeElement);
      if (!f.length) { e.preventDefault(); return; }
      const first = f[0]; const last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    });
    if (onMount) onMount(panel, close);
    const focusFirst = () => {
      if (entry.closed || panel.contains(document.activeElement)) return;
      const target = initialFocus ? $(initialFocus, panel) : ($('[autofocus]', panel) || $$(FOCUSABLE, panel).find((el) => !el.hasAttribute('data-close')) || panel);
      try { target.focus({ preventScroll: true }); } catch (e) { /* ignore */ }
    };
    focusFirst(); // synchronous, so keystrokes typed right after opening are not lost
    setTimeout(focusFirst, 60);
    return { panel, close };
  }

  function closeEntry(entry, result) {
    if (entry.closed) return;
    entry.closed = true;
    const idx = stack.indexOf(entry);
    if (idx > -1) stack.splice(idx, 1);
    entry.backdrop.classList.remove('is-open');
    entry.panel.classList.remove('is-open');
    setTimeout(() => { entry.backdrop.remove(); entry.panel.remove(); }, 380);
    unlockScroll();
    try { entry.returnFocus && entry.returnFocus.focus({ preventScroll: true }); } catch (e) { /* ignore */ }
    if (entry.onClose) entry.onClose(result);
  }

  function closeAll() { stack.slice().forEach((e) => closeEntry(e)); }

  /** Promise-based confirmation dialog. */
  function confirm({ title = 'Weet u het zeker?', message = '', confirmLabel = 'Bevestigen', cancelLabel = 'Annuleren', danger = false } = {}) {
    return new Promise((resolve) => {
      let answered = false;
      open({
        size: 'sm', title: esc(title),
        body: `<p class="text-muted" style="font-size:14.5px;line-height:1.65">${message}</p>`,
        foot: `<button class="btn btn--light btn--sm" type="button" data-cancel>${esc(cancelLabel)}</button>
               <button class="btn ${danger ? 'btn--primary' : 'btn--dark'} btn--sm" type="button" data-ok>${esc(confirmLabel)}</button>`,
        initialFocus: '[data-cancel]',
        onMount(panel, close) {
          panel.querySelector('[data-ok]').addEventListener('click', () => { answered = true; close(true); });
          panel.querySelector('[data-cancel]').addEventListener('click', () => close(false));
        },
        onClose() { resolve(answered); },
      });
    });
  }

  return { open, closeAll, confirm, get count() { return stack.length; } };
})();

/* ---------- Router ----------
   Two URL styles for the same routes:
   - clean paths (/mogelijkheden/…) when the site runs on a web server: indexable by search engines.
     The server must answer every path with this page (Netlify: _redirects, elsewhere: 404.html).
   - hash routes (#/mogelijkheden/…) when the file is opened locally (file://).
   Templates always write "#/…" links; in path mode they are rewritten to clean paths. */
const Router = (() => {
  const routes = [];
  let current = null;
  let cleanup = null;
  let guard = null;
  const redirects = [];
  const metaContent = (name) => { const m = document.querySelector(`meta[name="${name}"]`); return m ? m.getAttribute('content') || '' : ''; };
  const BASE = (() => { const b = metaContent('ct-base') || '/'; return (`/${b.replace(/^\/+|\/+$/g, '')}/`).replace(/\/+/g, '/'); })();
  const inBase = () => (`${location.pathname}/`).startsWith(BASE);
  // Clean URLs on a web server. An address outside the base (a mistyped URL that the host answers with
  // 404.html) shows "page not found"; only the bare host root keeps the hash routes as a fallback.
  const pathMode = metaContent('ct-routing') === 'path' && /^https?:$/.test(location.protocol) && (inBase() || !/^\/(index\.html)?$/.test(location.pathname));
  const outside = () => pathMode && !inBase();
  const urlKey = () => (pathMode ? location.pathname + location.search : location.hash);
  let lastKey = urlKey();

  function add(pattern, page) {
    const keys = [];
    const re = pattern === '*' ? /(?!)/ : new RegExp('^' + pattern.replace(/\//g, '\\/').replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '\\/?$');
    routes.push({ pattern, re, keys, page });
  }
  const safeDecode = (s) => { try { return decodeURI(s); } catch (e) { return s; } };
  /** The current route as "/path?query" (independent of the URL style). */
  function rawRoute() {
    if (!pathMode) return location.hash.replace(/^#/, '');
    if (!inBase()) return location.pathname + location.search;
    let p = `/${location.pathname.slice(BASE.length)}`;
    if (/^\/(index|404)\.html$/.test(p)) p = '/';
    return p + location.search;
  }
  function parse(raw) {
    const r = raw == null ? rawRoute() : String(raw).replace(/^#/, '');
    const qi = r.indexOf('?');
    // Only the path is decoded here; URLSearchParams decodes the query itself (decoding twice would turn "%2541" into "A").
    const rawPath = safeDecode(qi < 0 ? r : r.slice(0, qi));
    const qs = qi < 0 ? '' : r.slice(qi + 1);
    const path = ('/' + rawPath.replace(/^\/+/, '')).replace(/\/+$/, '') || '/';
    const query = {};
    new URLSearchParams(qs).forEach((v, k) => { query[k] = v; });
    return { path, query };
  }
  function match(path) {
    for (const r of routes) {
      const m = path.match(r.re);
      if (m) {
        const params = {};
        try { r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); }); } catch (e) { return null; }
        return { route: r, params };
      }
    }
    return null;
  }
  const qsOf = (query = {}) => new URLSearchParams(Object.entries(query).filter(([, v]) => v !== '' && v != null)).toString();
  function buildHash(path, query = {}) { const qs = qsOf(query); return `#${path}${qs ? `?${qs}` : ''}`; }
  /** "#/x", "/x" or a full path under the base → "/x?…" */
  function toRoute(target) {
    // Browsers drop tabs and line breaks from addresses ("/\t/host" would become "//host"): remove them first.
    let t = String(target == null ? '/' : target).replace(/[\u0000-\u001F\u007F]/g, '');
    if (t.startsWith('#')) t = t.slice(1);
    else if (pathMode && BASE !== '/' && (`${t}/`).startsWith(BASE)) t = `/${t.slice(BASE.length)}`;
    return `/${t.replace(/^[/\\]+/, '')}`; // "//host" would leave the site
  }
  /** The URL to put in an href for a route, in the current URL style. */
  function href(path, query) {
    const route = query && typeof query === 'object' ? buildHash(path, query).slice(1) : toRoute(path);
    return pathMode ? BASE.slice(0, -1) + route : `#${route}`;
  }
  /** Absolute URL of a route on this site, for sharing. */
  function absUrl(path, query) {
    return pathMode ? location.origin + href(path, query) : `${location.href.split('#')[0]}${href(path, query)}`;
  }
  /* Unsaved changes: the guard returns a message while a form has changes that are not saved. */
  const onUnload = (e) => { if (guard && guard()) { e.preventDefault(); e.returnValue = ''; } };
  function setGuard(fn) {
    guard = fn || null;
    // Reloading, closing the tab or typing another address also asks (the browser's own question).
    if (guard) window.addEventListener('beforeunload', onUnload); else window.removeEventListener('beforeunload', onUnload);
  }
  async function passGuard() {
    if (!guard) return true;
    const msg = guard();
    if (!msg) return true;
    const ok = await Overlay.confirm({ title: 'Wijzigingen niet opgeslagen', message: esc(msg), confirmLabel: 'Pagina verlaten', cancelLabel: 'Blijven', danger: true });
    if (ok) setGuard(null);
    return ok;
  }
  /* History bookkeeping: every entry the app creates carries its position (ctIdx). When Back/Forward is
     pressed while a form has unsaved changes, the app can then return to the form entry without
     rewriting any history entry, and continue the traversal if the user decides to leave. */
  let idx = 0;
  let deciding = false; // the unsaved-changes question is open
  let landed = null; // called when a history step back to the form entry has arrived
  // Each entry also gets a key; its scroll position is kept under that key in this tab's session storage,
  // written at once while scrolling (history.state is only updated after scrolling stops).
  let curKey = '';
  const newKey = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  const ssY = (k) => { try { const v = k ? sessionStorage.getItem(`ct.y.${k}`) : null; return v == null || v === '' || !Number.isFinite(Number(v)) ? undefined : Number(v); } catch (e) { return undefined; } };
  const stamp = (i) => ({ ctIdx: i, ctKey: curKey });
  /* Scroll positions per history entry, kept by the app: Back/Forward return to where the visitor was and
     new pages start at the top. The browser's own restoration is off, because it would also restore a
     position after the app steps back to a form entry with unsaved changes. */
  const scrollAt = new Map();
  /** A new entry at position `from` replaces any Forward entries: their positions no longer apply. */
  const forget = (from) => [...scrollAt.keys()].forEach((k) => { if (k >= from) scrollAt.delete(k); });
  function pushUrl(url) {
    try { history.replaceState({ ...stamp(idx), ctY: window.scrollY }, ''); } catch (e) { /* ignore */ }
    scrollAt.set(idx, window.scrollY);
    idx += 1; forget(idx); curKey = newKey();
    history.pushState(stamp(idx), '', url); lastKey = urlKey();
  }
  function replaceUrl(url) { history.replaceState(stamp(idx), '', url); lastKey = urlKey(); }
  const keyUrl = (key) => key || location.pathname + location.search;
  /** The remembered scroll position of the current history entry, if any. */
  function rememberedY() {
    if (scrollAt.has(idx)) return scrollAt.get(idx);
    const st = history.state;
    const y = ssY(st && st.ctKey);
    if (y !== undefined) return y;
    return st && Number.isFinite(st.ctY) ? st.ctY : undefined;
  }
  /** Steps through history (back to the form entry) and waits until the step has arrived. */
  function stepTo(delta) {
    return new Promise((resolve) => {
      const t = setTimeout(() => { landed = null; resolve(); }, 600);
      landed = () => { clearTimeout(t); landed = null; resolve(); };
      history.go(delta);
    });
  }
  /** Asks about unsaved changes; `step` first returns to the form entry, so the address matches the page. */
  async function ask(step) {
    deciding = true;
    try {
      if (step) await stepTo(step);
      return await passGuard();
    } finally { deciding = false; }
  }
  function go(path, query) {
    if (deciding) return; // the unsaved-changes question is open: it decides first
    const url = pathMode ? href(path, query) : (query && typeof query === 'object' ? buildHash(path, query) : `#${toRoute(path)}`);
    const same = url === urlKey();
    // Unsaved changes are checked before anything changes, also when the open page is simply re-rendered.
    const asking = !!(guard && guard());
    if (asking) deciding = true;
    passGuard().then((ok) => {
      if (asking) deciding = false;
      if (!ok) return;
      if (!same) pushUrl(url);
      render({ force: same });
    }, (er) => { if (asking) deciding = false; console.error(er); });
  }
  /** True when an href points at the page that is currently open. */
  function isCurrent(target) {
    if (!target || !(target.startsWith('#/') || target.startsWith('/'))) return false;
    const a = parse(toRoute(target)); const b = parse();
    return a.path === b.path && qsOf(a.query) === qsOf(b.query);
  }
  /** Updates the query string without re-rendering the page (filters, shareable state). */
  function setQuery(query, { replace = true } = {}) {
    const { path } = parse();
    const url = pathMode ? href(path, query) : buildHash(path, query);
    if (url === urlKey()) return;
    if (replace) replaceUrl(url); else pushUrl(url);
  }
  function focusAnchor(id) {
    const target = id && document.getElementById(id);
    if (target) { if (!target.hasAttribute('tabindex')) target.setAttribute('tabindex', '-1'); target.focus({ preventScroll: true }); target.scrollIntoView(); }
  }
  const anchorId = (hash) => { try { return decodeURIComponent(hash.replace(/^#/, '')); } catch (e) { return ''; } };
  /** Back/Forward, typed addresses and hash changes (popstate in path mode, hashchange in hash mode). */
  async function onTraverse() {
    const key = urlKey();
    const st = history.state;
    const known = !!st && Number.isInteger(st.ctIdx);
    if (key === lastKey) { // nothing to render (this is also the step back to the form entry while asking)
      if (landed) landed(); else if (known && !deciding) { idx = st.ctIdx; curKey = st.ctKey || curKey; }
      return;
    }
    const to = known ? st.ctIdx : idx + 1; // an unknown entry is a typed address: a new entry
    const back = known && to !== idx;
    if (deciding) { // the question is open: undo this step, the answer decides
      if (back) history.go(idx - to);
      else if (!known) history.back();
      else history.replaceState(stamp(idx), '', keyUrl(lastKey));
      return;
    }
    if (!pathMode && !known && location.hash && !location.hash.startsWith('#/')) {
      // A typed in-page anchor (e.g. "#main") is not a route: keep the route address and focus the target.
      idx += 1; forget(idx); curKey = newKey(); history.replaceState(stamp(idx), '', keyUrl(lastKey));
      focusAnchor(anchorId(location.hash));
      return;
    }
    if (guard && guard()) {
      const target = pathMode ? key : location.hash;
      let ok;
      if (back) ok = await ask(idx - to); // return to the form entry; history stays as it was
      else if (!known) ok = await ask(-1); // a typed address: return to the form entry; it stays as a Forward entry
      else { history.replaceState(stamp(idx), '', keyUrl(lastKey)); ok = await ask(0); }
      if (!ok) return;
      if (back) { history.go(to - idx); return; } // continue the traversal; its event renders the page
      pushUrl(target); render(); return;
    }
    curKey = (known && st.ctKey) || newKey();
    if (!known) { history.replaceState(stamp(to), ''); forget(to); }
    idx = to; lastKey = key;
    render({ scrollY: known ? rememberedY() : undefined });
  }
  /** Path mode: an old "#/…" address becomes the clean one; other fragments are in-page anchors. */
  async function onPathHash() {
    const st = history.state;
    if (st && Number.isInteger(st.ctIdx)) { // Back/Forward between entries of the same page
      if (location.hash.length > 1 && !location.hash.startsWith('#/')) focusAnchor(anchorId(location.hash));
      return;
    }
    // A typed fragment: the browser made a new history entry.
    if (deciding) { history.back(); return; }
    if (location.hash.startsWith('#/')) {
      const target = href(location.hash.slice(1));
      if (guard && guard()) { if (await ask(-1)) { pushUrl(target); render(); } return; }
      idx += 1; forget(idx); curKey = newKey(); replaceUrl(target); render(); return;
    }
    idx += 1; forget(idx); curKey = newKey(); history.replaceState(stamp(idx), '');
    if (location.hash.length > 1) focusAnchor(anchorId(location.hash));
  }
  /** fn(path) → new path or null. Old URLs are replaced in history, so Back skips them. */
  function redirect(fn) { redirects.push(fn); }
  /** Rewrites "#/…" links to clean paths (path mode only). */
  const fixHtml = (html) => (pathMode ? html.replace(/(\s)href="#\//g, `$1href="${BASE}`) : html);
  function fixLink(a) { const h = a.getAttribute('href'); if (h && h.startsWith('#/')) a.setAttribute('href', href(h.slice(1))); }
  function watchLinks() {
    const scan = (n) => { if (n.nodeType !== 1) return; if (n.matches('a[href^="#/"]')) fixLink(n); n.querySelectorAll('a[href^="#/"]').forEach(fixLink); };
    scan(document.body);
    new MutationObserver((list) => list.forEach((m) => { if (m.type === 'attributes') { if (m.target.matches && m.target.matches('a[href^="#/"]')) fixLink(m.target); } else m.addedNodes.forEach(scan); }))
      .observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['href'] });
  }
  /** Links to pages of this site navigate inside the app, so the unsaved-changes check runs first.
      Runs after other click handlers (which may cancel it); new-tab clicks are left to the browser. */
  function onLinkClick(e) {
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    const a = e.target.closest && e.target.closest('a[href]');
    if (!a || (a.target && a.target !== '_self') || a.hasAttribute('download')) return;
    const raw = a.getAttribute('href');
    if (raw.startsWith('#/')) { e.preventDefault(); go(raw); return; }
    if (raw.startsWith('#')) { e.preventDefault(); focusAnchor(anchorId(raw)); return; } // in-page anchor: no history entry
    if (!pathMode) return;
    let u; try { u = new URL(a.href, location.href); } catch (er) { return; }
    if (u.origin !== location.origin || !(`${u.pathname}/`).startsWith(BASE) || /\.[a-z0-9]{2,5}$/i.test(u.pathname)) return;
    e.preventDefault();
    go(u.pathname + u.search);
  }
  /** scrollY: the position to return to (Back/Forward, reload); otherwise a new page starts at the top. */
  async function render({ force = false, scrollY } = {}) {
    const { path, query } = parse();
    const out = outside();
    if (!out) {
      for (const fn of redirects) {
        const to = fn(path);
        if (to && to !== path) { replaceUrl(pathMode ? href(to, query) : buildHash(to, query)); return render({ force, scrollY }); }
      }
    }
    const m = (!out && match(path)) || { route: routes.find((r) => r.pattern === '*'), params: {} };
    const page = m.route.page;
    const ctx = { path, query, params: m.params, url: urlKey() };
    RouteProgress.start();
    if (cleanup) { try { cleanup(); } catch (e) { console.error(e); } cleanup = null; }
    setGuard(null);
    Overlay.closeAll();
    Motion.cleanup();
    // Fresh root per render: listeners that pages attach in mount() never accumulate across navigations.
    const oldApp = $('#app');
    const app = oldApp.cloneNode(false);
    oldApp.replaceWith(app);
    let html = '';
    try {
      html = page.render(ctx);
    } catch (e) {
      console.error(e);
      html = Pages.error.render(ctx);
    }
    document.body.className = document.body.className.split(' ').filter((c) => !c.startsWith('page-') && c !== 'is-admin' && c !== 'has-mobile-bar').join(' ');
    document.body.classList.add(`page-${page.id || 'x'}`);
    if (page.admin) document.body.classList.add('is-admin');
    app.innerHTML = fixHtml(html);
    let meta = {};
    try { meta = typeof page.meta === 'function' ? page.meta(ctx) : (page.meta || {}); } catch (e) { console.error(e); }
    Seo.apply(meta, ctx);
    Layout.update(ctx, page);
    const prevPath = current ? current.path : null;
    current = ctx;
    if (prevPath !== path) { const mc = document.getElementById('miniCart'); if (mc) mc.classList.remove('is-open'); }
    const restore = scrollY !== undefined && !ctx.query.section;
    if (!ctx.query.section && !restore && (prevPath !== path || force)) window.scrollTo(0, 0);
    try { cleanup = page.mount ? page.mount(app, ctx) || null : null; } catch (e) { console.error(e); }
    if (ctx.query.section) {
      const target = document.getElementById(ctx.query.section);
      if (target) setTimeout(() => target.scrollIntoView({ behavior: reducedMotion() ? 'auto' : 'smooth', block: 'start' }), 60);
    }
    if (prevPath !== null && prevPath !== path) {
      const h1 = app.querySelector('h1');
      if (h1) { h1.setAttribute('tabindex', '-1'); h1.focus({ preventScroll: true }); }
    }
    Motion.page(app, { late: prevPath === path }); // same-page refresh: do not re-animate visible content
    if (restore) { // after mount: the page has its full height now
      window.scrollTo(0, scrollY);
      // Once more after the next frame: late layout (and Motion's ScrollTrigger refresh) may move the page.
      requestAnimationFrame(() => { if (Math.abs(window.scrollY - scrollY) > 2) window.scrollTo(0, scrollY); });
    }
    RouteProgress.done();
  }
  function start() {
    const st = history.state;
    idx = st && Number.isInteger(st.ctIdx) ? st.ctIdx : 0;
    curKey = (st && typeof st.ctKey === 'string' && st.ctKey) || newKey();
    const ys = ssY(curKey);
    const y0 = ys !== undefined ? ys : (st && Number.isFinite(st.ctY) ? st.ctY : undefined); // a reload or a return from another site
    try { history.scrollRestoration = 'manual'; } catch (e) { /* older browsers restore by themselves */ }
    if (pathMode) {
      // An old-style URL (/#/mogelijkheden) becomes the clean one.
      if (location.hash.startsWith('#/')) history.replaceState(stamp(idx), '', href(location.hash.slice(1)));
      else if (/\/(index|404)\.html$/.test(location.pathname)) history.replaceState(stamp(idx), '', BASE + location.search + location.hash);
      else history.replaceState({ ...(st || {}), ...stamp(idx) }, '');
      watchLinks();
      window.addEventListener('popstate', onTraverse);
      window.addEventListener('hashchange', onPathHash);
    } else {
      history.replaceState({ ...(st || {}), ...stamp(idx) }, '');
      window.addEventListener('hashchange', onTraverse);
    }
    window.addEventListener('click', onLinkClick);
    // The current entry also keeps its position in history.state (written shortly after scrolling stops), so
    // Back/Forward after a reload, or to an entry left by Back/Forward, return to the right place.
    let yTimer = 0;
    window.addEventListener('scroll', () => {
      if (deciding) return;
      scrollAt.set(idx, window.scrollY);
      try { sessionStorage.setItem(`ct.y.${curKey}`, String(window.scrollY)); } catch (e) { /* ignore */ }
      const at = idx; clearTimeout(yTimer);
      yTimer = setTimeout(() => {
        const s = history.state;
        if (deciding || at !== idx || !s || s.ctIdx !== at) return;
        try { history.replaceState({ ...s, ctY: window.scrollY }, ''); } catch (e) { /* ignore */ }
      }, 300);
    }, { passive: true });
    // Keep the position for a reload or a later return to this entry from another page.
    // (beforeunload too: Chromium keeps a history write made there across a reload, not one made in pagehide.)
    const keepY = () => { if (deciding) return; try { history.replaceState({ ...(history.state || {}), ctY: window.scrollY }, ''); } catch (e) { /* ignore */ } };
    window.addEventListener('pagehide', keepY);
    window.addEventListener('beforeunload', keepY);
    lastKey = urlKey();
    render({ scrollY: y0 });
  }
  /** The page and params that a path would render (used by Beheer → SEO and the sitemap). */
  function resolve(path) {
    const m = match(path) || { route: routes.find((r) => r.pattern === '*'), params: {} };
    return { page: m.route.page, params: m.params, found: m.route.pattern !== '*' };
  }
  return {
    add, redirect, start, go, setQuery, parse, buildHash, render, href, absUrl, isCurrent, toRoute, fixHtml, resolve,
    get current() { return current; },
    get pathMode() { return pathMode; },
    get base() { return BASE; },
    /** True while the open form reports unsaved changes. */
    hasUnsaved() { return !!(guard && guard()); },
    /** Asks about unsaved changes (if any) before the page is rebuilt; false when the user stays. */
    /** Runs a question (fn returns a promise) as an open question: Back or a typed address meanwhile is undone. */
    async whileAsking(fn) {
      if (deciding) return false;
      deciding = true;
      try { return await fn(); } finally { deciding = false; }
    },
    async confirmLeave() {
      if (deciding) return false;
      if (!(guard && guard())) return true;
      deciding = true; // Back or a typed address while this question is open is undone, as for the other questions
      try { return await passGuard(); } finally { deciding = false; }
    },
    setGuard,
  };
})();

/* ---------- SEO: title, description, canonical, robots, Open Graph and structured data ---------- */
const DAY_NAMES = {
  maandag: 'Monday', dinsdag: 'Tuesday', woensdag: 'Wednesday', donderdag: 'Thursday', vrijdag: 'Friday', zaterdag: 'Saturday', zondag: 'Sunday',
  ma: 'Monday', di: 'Tuesday', wo: 'Wednesday', do: 'Thursday', vr: 'Friday', za: 'Saturday', zo: 'Sunday',
  maa: 'Monday', din: 'Tuesday', woe: 'Wednesday', don: 'Thursday', vri: 'Friday', vrij: 'Friday', zat: 'Saturday', zon: 'Sunday',
};
const DAY_ORDER = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const Seo = {
  get defaultTitle() { return Content.seo().homeTitle; },
  get defaultDescription() { return Content.seo().description; },
  /** Absolute public URL of a route ("#/x" or "/x"), based on the website address in Beheer → SEO. */
  url(route = '/') {
    const r = Router.toRoute(route);
    const site = Content.seo().siteUrl;
    if (site) return `${site}${r === '/' ? '/' : r}`;
    return Router.pathMode ? location.origin + Router.href(r) : '';
  },
  /** The canonical form of the current page: no filters or tracking, except the meaningful catalog ones. */
  canonicalRoute(ctx) {
    if (!ctx) return '/';
    if (ctx.path !== '/mogelijkheden') return ctx.path;
    // Only valid filters, with the brand taken from the model: one address per selection, as in the sitemap.
    const q = ctx.query || {};
    const model = MODEL[q.model] ? q.model : '';
    const merk = model ? MODEL[model].brand : (BRAND[q.merk] ? q.merk : '');
    const cat = CATEGORY[q.cat] ? q.cat : '';
    return Router.buildHash(ctx.path, { merk, model, cat }).slice(1);
  },
  /** Automatic descriptions are cut at a word boundary, so search results show a complete sentence part. */
  clamp(text, max = 160) {
    const t = String(text || '').replace(/\s+/g, ' ').trim();
    if (t.length <= max) return t;
    const cut = t.slice(0, max - 1);
    const at = cut.lastIndexOf(' ');
    return `${(at > max * 0.6 ? cut.slice(0, at) : cut).replace(/[\s,;:.–-]+$/, '')}…`;
  },
  /** The final title, description and robots values for a page, after the overrides in Beheer → SEO. */
  resolve(meta = {}, path = '/') {
    const s = Content.seo();
    const ov = s.pages[path] || {};
    const isHome = path === '/';
    const base = ov.title || meta.title;
    const title = isHome ? (ov.title || s.homeTitle) : (base ? `${base}${s.suffix}` : s.homeTitle);
    const description = ov.description || this.clamp(meta.description) || s.description;
    const noindex = s.noindex || ov.noindex || !!meta.noindex;
    return { title, description, noindex };
  },
  tag(selector, create) {
    let el = document.head.querySelector(selector);
    if (!el) { el = create(); document.head.appendChild(el); }
    return el;
  },
  setMeta(attrName, key, value) {
    const el = this.tag(`meta[${attrName}="${key}"]`, () => { const m = document.createElement('meta'); m.setAttribute(attrName, key); return m; });
    if (value) el.setAttribute('content', value); else el.remove();
  },
  apply(meta = {}, ctx) {
    const path = ctx ? ctx.path : '/';
    const r = this.resolve(meta, path);
    const s = Content.seo();
    document.title = r.title;
    this.setMeta('name', 'description', r.description);
    this.setMeta('name', 'robots', r.noindex ? (s.noindex ? 'noindex, nofollow' : 'noindex, follow') : 'index, follow');
    const canonical = r.noindex ? '' : this.url(this.canonicalRoute(ctx));
    const link = this.tag('link[rel="canonical"]', () => { const l = document.createElement('link'); l.rel = 'canonical'; return l; });
    if (canonical) link.setAttribute('href', canonical); else link.remove();
    this.setMeta('property', 'og:title', path === '/' && !(s.pages['/'] || {}).title ? s.ogTitle : r.title);
    this.setMeta('property', 'og:description', path === '/' && !(s.pages['/'] || {}).description ? s.ogDescription : r.description);
    this.setMeta('property', 'og:url', canonical);
    $$('script[data-route-ld]').forEach((x) => x.remove());
    if (meta.jsonLd && !r.noindex) {
      const el = document.createElement('script');
      el.type = 'application/ld+json';
      el.dataset.routeLd = '1';
      el.textContent = JSON.stringify(meta.jsonLd).replace(/</g, '\\u003c');
      document.head.appendChild(el);
    }
    this.applyOrganization();
    document.documentElement.dataset.route = path;
  },
  /** The days of an opening-hours row ("Dinsdag – vrijdag", "Ma t/m vr, za", "Maandag en woensdag")
      in week order, or null when the text cannot be read with certainty. Remarks in brackets are ignored. */
  openingDays(text) {
    const s = String(text || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
      .replace(/\([^)]*\)/g, ' ')
      .replace(/\btot\s+en\s+met\b|\bt\s*\/\s*m\b|\bt\.\s*m\b\.?|\btm\b|\btot\b|[–—-]/g, ' ~ ')
      .replace(/\ben\b|[,/&+;]/g, ' , ')
      .replace(/\./g, ' ');
    const groups = s.split(',').map((g) => g.trim().split(/\s+/).filter(Boolean)).filter((g) => g.length);
    if (!groups.length) return null;
    const days = new Set();
    for (const g of groups) {
      const known = (w) => Object.prototype.hasOwnProperty.call(DAY_NAMES, w);
      if (g.length === 1 && known(g[0])) { days.add(DAY_NAMES[g[0]]); continue; }
      if (g.length !== 3 || g[1] !== '~' || !known(g[0]) || !known(g[2])) return null; // not "dag" or "dag – dag"
      const a = DAY_ORDER.indexOf(DAY_NAMES[g[0]]); const b = DAY_ORDER.indexOf(DAY_NAMES[g[2]]);
      for (let i = a, n = 0; n < 7; i = (i + 1) % 7, n += 1) { days.add(DAY_ORDER[i]); if (i === b) break; } // "za – ma" wraps round the week
    }
    return DAY_ORDER.filter((d) => days.has(d));
  },
  /** Opening hours rows ("Dinsdag – vrijdag", "09:30 – 17:00") → schema.org; rows that cannot be read are left out.
      Split hours ("09:00 – 12:00, 13:00 – 17:00") become one entry per period. */
  openingHours(rows) {
    const out = [];
    (rows || []).forEach(([days, time]) => {
      const list = this.openingDays(days);
      if (!list || !list.length) return;
      const parts = String(time || '').split(/,|\ben\b|&/i).map((x) => x.trim()).filter(Boolean);
      const periods = parts.map((p) => p.match(/^(\d{1,2})[:.](\d{2})\s*(?:[–—-]|tot)\s*(\d{1,2})[:.](\d{2})(?:\s*uur)?$/i));
      const okTime = (h, m) => Number(h) <= 24 && Number(m) <= 59 && !(Number(h) === 24 && Number(m) > 0);
      if (!periods.length || periods.some((t) => !t || !okTime(t[1], t[2]) || !okTime(t[3], t[4]))) return;
      const pad = (h, m) => `${String(h).padStart(2, '0')}:${m}`;
      periods.forEach((t) => out.push({ '@type': 'OpeningHoursSpecification', dayOfWeek: list, opens: pad(t[1], t[2]), closes: pad(t[3], t[4]) }));
    });
    return out;
  },
  organization() {
    const c = COMPANY;
    const s = Content.seo();
    const org = {
      '@context': 'https://schema.org', '@type': 'AutoRepair', name: c.name,
      description: 'Specialist in het achteraf inbouwen van originele fabrieksopties voor Volkswagen, Audi, SEAT en Škoda.',
      url: s.siteUrl ? `${s.siteUrl}/` : c.website, telephone: c.phoneHref.replace('tel:', ''), email: c.email,
      address: { '@type': 'PostalAddress', streetAddress: c.street, postalCode: c.postal, addressLocality: c.city, addressCountry: 'NL' },
    };
    const hours = this.openingHours(c.hours);
    if (hours.length) org.openingHoursSpecification = hours;
    const same = [c.facebook, ...(c.social || [])].filter(Boolean);
    if (same.length) org.sameAs = uniq(same);
    if (s.siteUrl) org.image = `${s.siteUrl}/og-image.jpg`;
    return org;
  },
  applyOrganization() {
    const el = this.tag('script#ctOrgLd', () => { const x = document.createElement('script'); x.id = 'ctOrgLd'; x.type = 'application/ld+json'; return x; });
    const json = JSON.stringify(this.organization(), null, 2).replace(/</g, '\\u003c');
    if (el.textContent !== json) el.textContent = json;
  },
};
