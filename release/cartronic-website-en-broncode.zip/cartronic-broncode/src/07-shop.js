/* =====================================================================
   WEBSHOP PAGES
   ===================================================================== */
const shopNotice = () => `<div class="shop-notice"><div class="container">${icon('info')}<span><strong>${tx('shop.notice.title')}</strong> ${tx('shop.notice.text')}</span></div></div>`;
/* The webshop can be switched off in Beheer → Weergave. Its pages then explain that, instead of selling.
   Order and payment result pages stay available for orders that already exist. */
function shopGate(page) {
  return {
    ...page,
    meta(ctx) { return Content.shopOn() ? (typeof page.meta === 'function' ? page.meta.call(page, ctx) : page.meta) : { title: 'Webshop', noindex: true }; },
    render(ctx) { return Content.shopOn() ? page.render.call(page, ctx) : Pages.shopClosed.render(ctx); },
    mount(root, ctx) { return Content.shopOn() && page.mount ? page.mount.call(page, root, ctx) : null; },
  };
}

function shopState(query) {
  return {
    cat: query.cat || '', merk: query.merk || '', model: query.model || '',
    min: query.min || '', max: query.max || '', stock: query.stock === '1', featured: query.featured === '1',
    sort: query.sort || 'aanbevolen',
  };
}
function shopFilter(products, s) {
  const min = s.min !== '' ? Money.parse(s.min) : NaN; const max = s.max !== '' ? Money.parse(s.max) : NaN;
  let list = products.filter((p) => {
    const c = p.compatibility || {};
    if (s.cat && p.category !== s.cat) return false;
    if (s.merk && (c.brands || []).length && !c.brands.includes(s.merk)) return false;
    if (s.model && !(c.models || []).includes(s.model)) return false;
    const price = Pricing.calc(p).price;
    if (Number.isFinite(min) && price < min) return false;
    if (Number.isFinite(max) && price > max) return false;
    if (s.stock && Stock.status(p).key === 'out') return false;
    if (s.featured && !p.featured) return false;
    return true;
  });
  const price = (p) => Pricing.calc(p).price;
  const sorters = {
    aanbevolen: (a, b) => (b.featured - a.featured) || ((Stock.status(a).key === 'out') - (Stock.status(b).key === 'out')) || a.name.localeCompare(b.name, 'nl'),
    'prijs-op': (a, b) => price(a) - price(b),
    'prijs-af': (a, b) => price(b) - price(a),
    nieuw: (a, b) => String(b.createdAt).localeCompare(String(a.createdAt)),
  };
  list = list.slice().sort(sorters[s.sort] || sorters.aanbevolen);
  return list;
}

Pages.shop = {
  id: 'shop', nav: 'webshop',
  meta() {
    const pub = Repo.products().filter(isPublicProduct);
    // Demo products and prices must not end up in search engines.
    return { title: 'Webshop — onderdelen en modules', description: 'Onderdelen, modules en retrofit-sets voor Volkswagen, Audi, SEAT en Škoda.', noindex: !pub.length || pub.every((p) => p.isDemo) };
  },
  render(ctx) {
    const s = shopState(ctx.query);
    const all = Repo.products().filter(isPublicProduct);
    const v = VehicleStore.get();
    const forCar = v ? all.filter((p) => UI.productFit(p, v) === 'model') : [];
    return `${UI.pageHeader({ crumbs: [[tt('shop.eyebrow')]], eyebrow: tt('shop.eyebrow'), title: tx('shop.title'), lead: tx('shop.lead') })}
      ${shopNotice()}
      <section class="section section--sm" style="padding-top:56px"><div class="container shop-layout">
        <div data-filters-home><aside class="filters" aria-label="Filters" data-filters>${this.filtersHtml(s, all)}</aside></div>
        <div>
          ${v && forCar.length ? `<div class="shop-section">
            <div class="shop-section-head"><div><p class="eyebrow">${icon('car').replace('<svg', '<svg style="width:15px;height:15px"')} Uw auto</p><h2 class="mt-8">Producten voor uw ${esc(VehicleStore.short(v))}</h2><p>Volgens de productinformatie bedoeld voor uw model. CarTronic controleert de definitieve compatibiliteit.</p></div></div>
            <div class="shop-grid" data-stagger>${forCar.slice(0, 3).map((p) => UI.productCard(p, { vehicle: v })).join('')}</div>
          </div>` : ''}
          <div class="shop-section">
            <div class="results-head">
              <p class="results-count" data-count aria-live="polite"></p>
              <div class="results-tools">
                <button class="btn btn--light btn--sm filters-toggle" type="button" data-action="open-filters">${icon('sliders')} Filters</button>
                <label class="sr-only" for="shop-sort">Sorteren</label>
                <select class="select select--sm" id="shop-sort" data-sort>
                  ${[['aanbevolen', 'Aanbevolen'], ['prijs-op', 'Prijs: laag naar hoog'], ['prijs-af', 'Prijs: hoog naar laag'], ['nieuw', 'Nieuwste']].map(([k, l]) => `<option value="${k}"${s.sort === k ? ' selected' : ''}>${l}</option>`).join('')}
                </select>
              </div>
            </div>
            <h2 class="sr-only">Alle producten</h2>
            <div class="shop-grid" data-results></div>
          </div>
          ${(() => { const r = Content.section('recent') ? Recent.list().filter((e) => e.type === 'product') : []; return r.length ? `<div class="shop-section"><div class="shop-section-head"><h2>Recent bekeken</h2></div><div class="mini-list">${r.slice(0, 4).map((e) => UI.miniItem(e)).join('')}</div></div>` : ''; })()}
        </div>
      </div></section>`;
  },
  filtersHtml(s, all) {
    const cats = Repo.shopCategories().filter((c) => all.some((p) => p.category === c.id));
    const brands = BRANDS.filter((b) => all.some((p) => (p.compatibility.brands || []).includes(b.id)));
    const models = MODELS.filter((m) => all.some((p) => (p.compatibility.models || []).includes(m.id)));
    const anyFeatured = all.some((p) => p.featured);
    const count = (fn) => all.filter(fn).length;
    return `<div class="filters-head">${icon('sliders')} Verfijn uw selectie</div>
      ${cats.length > 1 ? `<div class="field"><label for="s-cat">Categorie</label><select class="select" id="s-cat" data-f="cat"><option value="">Alle categorieën</option>${cats.map((c) => `<option value="${c.id}"${s.cat === c.id ? ' selected' : ''}>${esc(c.name)} (${count((p) => p.category === c.id)})</option>`).join('')}</select></div>` : ''}
      ${brands.length > 1 ? `<div class="field"><label for="s-merk">Merk</label><select class="select" id="s-merk" data-f="merk"><option value="">Alle merken</option>${brands.map((b) => `<option value="${b.id}"${s.merk === b.id ? ' selected' : ''}>${b.name}</option>`).join('')}</select></div>` : ''}
      ${models.length ? `<div class="field"><label for="s-model">Model</label><select class="select" id="s-model" data-f="model"><option value="">Alle modellen</option>${models.map((m) => `<option value="${m.id}"${s.model === m.id ? ' selected' : ''}>${esc(modelLabel(m.id))}</option>`).join('')}</select></div>` : ''}
      <div class="field"><span class="label" id="s-price-l">Prijs (€)</span><div class="price-range" role="group" aria-labelledby="s-price-l">
        <input class="input input--sm" data-f="min" inputmode="decimal" placeholder="Min" aria-label="Minimumprijs in euro" value="${attr(s.min)}"><span>–</span>
        <input class="input input--sm" data-f="max" inputmode="decimal" placeholder="Max" aria-label="Maximumprijs in euro" value="${attr(s.max)}"></div></div>
      <div class="field"><span class="label">Beschikbaarheid</span><div class="check-list">
        <label class="check"><input type="checkbox" data-f="stock"${s.stock ? ' checked' : ''}><span class="box">${icon('check')}</span>Alleen op voorraad</label>
        ${anyFeatured ? `<label class="check"><input type="checkbox" data-f="featured"${s.featured ? ' checked' : ''}><span class="box">${icon('check')}</span>Alleen uitgelicht</label>` : ''}
      </div></div>
      <button class="filter-reset" type="button" data-action="reset-filters">Filters wissen</button>
      <p class="filter-note">Producten worden zonder inbouw geleverd, tenzij anders vermeld. Wilt u een optie laten inbouwen? <a class="text-link" href="#/mogelijkheden">Bekijk de mogelijkheden</a>.</p>`;
  },
  mount(root, ctx) {
    let s = shopState(ctx.query);
    const all = Repo.products().filter(isPublicProduct);
    const grid = $('[data-results]', root); const countEl = $('[data-count]', root);
    const filtersEl = $('[data-filters]', root);
    const update = (animate = true) => {
      const list = shopFilter(all, s);
      countEl.innerHTML = `<strong>${list.length}</strong> ${list.length === 1 ? 'product' : 'producten'}`;
      grid.innerHTML = list.length ? list.map((p) => UI.productCard(p)).join('')
        : UI.empty({ icon: 'box', title: all.length ? 'Geen producten gevonden' : 'Er zijn momenteel geen producten', text: all.length ? 'Pas uw filters aan om meer producten te zien.' : 'Bekijk in de tussentijd de mogelijkheden voor uw auto.', actions: all.length ? '<button class="btn btn--dark btn--sm" type="button" data-action="reset-filters">Filters wissen</button>' : '<a class="btn btn--dark btn--sm" href="#/mogelijkheden">Mogelijkheden</a>' });
      if (animate) Motion.swap(grid);
      const n = [s.cat, s.merk, s.model, s.min, s.max, s.stock, s.featured].filter(Boolean).length;
      const t = $('.filters-toggle', root); if (t) t.innerHTML = `${icon('sliders')} Filters${n ? ` (${n})` : ''}`;
    };
    const sync = () => Router.setQuery({ cat: s.cat, merk: s.merk, model: s.model, min: s.min, max: s.max, stock: s.stock ? '1' : '', featured: s.featured ? '1' : '', sort: s.sort !== 'aanbevolen' ? s.sort : '' });
    const onChange = (e) => {
      const f = e.target.dataset.f; if (!f) return;
      if (f === 'stock' || f === 'featured') s[f] = e.target.checked;
      else if (f === 'min' || f === 'max') {
        const raw = e.target.value.trim();
        const ok = raw === '' || Number.isFinite(Money.parse(raw));
        e.target.setAttribute('aria-invalid', String(!ok));
        if (!ok) return;
        s[f] = raw;
      } else s[f] = e.target.value;
      sync(); update();
    };
    filtersEl.addEventListener('change', onChange);
    filtersEl.addEventListener('input', debounce((e) => { if (['min', 'max'].includes(e.target.dataset.f)) onChange(e); }, 350));
    $('[data-sort]', root).addEventListener('change', (e) => { s.sort = e.target.value; sync(); update(); });
    root.addEventListener('click', (e) => {
      if (e.target.closest('[data-action="reset-filters"]')) {
        s = shopState({});
        filtersEl.innerHTML = this.filtersHtml(s, all);
        $('[data-sort]', root).value = 'aanbevolen';
        sync(); update();
      }
      if (e.target.closest('[data-action="open-filters"]')) openFiltersDrawer(filtersEl, $('[data-filters-home]', root));
    });
    update(false);
  },
};

/* ---------- Product detail ---------- */
Pages.product = {
  id: 'product', nav: 'webshop',
  meta(ctx) {
    const p = Repo.productBySlug(ctx.params.slug);
    if (!isPublicProduct(p)) return { title: 'Product niet gevonden', noindex: true };
    const pr = Pricing.calc(p);
    // Structured data only for genuine (non-demo) products with real values. No ratings/reviews.
    const jsonLd = !p.isDemo ? {
      '@context': 'https://schema.org', '@type': 'Product', name: p.name, sku: p.sku, description: p.shortDescription,
      brand: p.brand && BRAND[p.brand] ? { '@type': 'Brand', name: BRAND[p.brand].name } : undefined,
      offers: { '@type': 'Offer', priceCurrency: 'EUR', price: (pr.price / 100).toFixed(2), availability: Stock.status(p).key === 'out' ? 'https://schema.org/OutOfStock' : 'https://schema.org/InStock' },
    } : null;
    return { title: p.name, description: p.shortDescription, jsonLd, noindex: !!p.isDemo };
  },
  render(ctx) {
    const p = Repo.productBySlug(ctx.params.slug);
    if (!isPublicProduct(p)) return Pages.notFound.render(ctx, { title: 'Dit product is niet (meer) beschikbaar.', text: 'Bekijk de andere producten in de webshop.' });
    Recent.add('product', p.id);
    Analytics.track('product_viewed', { id: p.id });
    const v = VehicleStore.get();
    const pr = Pricing.calc(p);
    const st = Stock.status(p);
    const cat = Repo.shopCategory(p.category);
    const max = Stock.max(p);
    const inCart = Cart.qtyOf(p.id);
    const fit = UI.productFit(p, v);
    const c = p.compatibility || {};
    const saved = Saved.has('products', p.id);
    let compatHtml;
    if (v) {
      const badge = fit === 'model' ? '<span class="status status--ok">Vermeld voor uw model</span>' : (fit === 'brand' ? '<span class="status status--check">Controle vereist</span>' : '<span class="status status--neutral">Niet vermeld voor uw model</span>');
      compatHtml = `<div class="cp-head"><div class="who">Uw auto: ${esc(VehicleStore.name(v))}<small>${esc(VehicleStore.meta(v))}</small></div>${badge}</div>`;
    } else {
      compatHtml = `<div class="cp-head"><div class="who">Compatibiliteit<small>Volgens de productinformatie</small></div><button class="btn btn--dark btn--xs" type="button" data-action="open-vehicle">${icon('car')} Kies uw auto</button></div>`;
    }
    compatHtml += `<div class="cp-body">${c.note ? `${esc(c.note)} ` : ''}<div class="cp-models">${(c.models || []).length ? c.models.map((m) => `<span class="pill">${esc(modelLabel(m))}</span>`).join('') : (c.brands || []).map((b) => `<span class="pill">${BRAND[b].name}</span>`).join('')}</div>
      <p class="mt-16 text-muted">Geschiktheid is niet gegarandeerd: die hangt af van uitvoering en aanwezige systemen. CarTronic controleert dit graag vooraf.</p></div>`;
    const related = Repo.products().filter((x) => isPublicProduct(x) && x.id !== p.id && (x.category === p.category || (x.compatibility.models || []).some((m) => (c.models || []).includes(m)))).slice(0, 3);
    const promoEnd = pr.onSale && p.endDate ? `Actie geldig t/m ${fmtDate(`${p.endDate}T12:00:00`)}` : '';
    return `<div class="detail-top"><div class="container">${UI.crumbs([['Home', '#/'], ['Webshop', '#/webshop'], ...(cat ? [[cat.name, `#/webshop?cat=${cat.id}`]] : []), [p.name]], { light: true })}</div></div>
      <div class="container pdp">
        <div class="pdp-gallery">${UI.gallery(p.images, p.name, productArtKind(p))}</div>
        <div class="pdp-info">
          <div class="flex wrap gap-8 items-center"><p class="eyebrow">${esc(cat ? cat.name : 'Webshop')}</p>${p.isDemo ? `<span class="demo-flag">${icon('info')} Demoproduct</span>` : ''}</div>
          <h1>${esc(p.name)}</h1>
          <p class="pdp-sku">Artikelnummer ${esc(p.sku)}</p>
          <p class="pdp-short">${esc(p.shortDescription)}</p>
          <div class="pdp-buy">
            ${Pricing.html(p, { size: 'lg' })}
            <p class="price-note">${Repo.settings().vat.pricesIncludeVat ? 'Inclusief btw' : 'Exclusief btw'}${promoEnd ? ` · ${promoEnd}` : ''}</p>
            <div class="mt-16">${Stock.html(p)}${inCart ? ` <span class="text-small text-muted">· ${inCart} in uw winkelmand</span>` : ''}</div>
            <div class="buy-row">
              ${st.key !== 'out' ? UI.qty({ id: `pdp-${p.id}`, value: 1, max: Math.max(1, max - inCart), label: `Aantal ${p.name}` }) : ''}
              <button class="btn btn--primary" type="button" data-action="add-to-cart" data-id="${p.id}" data-qty-from="[data-qty='pdp-${p.id}'] input"${st.key === 'out' || max - inCart <= 0 ? ' disabled' : ''}>${icon('cart')} ${st.key === 'out' ? 'Uitverkocht' : (max - inCart <= 0 ? 'Maximum in winkelmand' : 'In winkelmand')}</button>
              <button class="btn btn--light" type="button" data-action="toggle-save" data-type="products" data-id="${p.id}" aria-pressed="${saved}">${icon('bookmark')} <span data-save-label>${saved ? 'Bewaard' : 'Bewaar'}</span></button>
            </div>
            <div class="buy-meta">
              <span>${icon(p.installationIncluded ? 'wrench' : 'box')} ${p.installationIncluded ? 'Inclusief inbouw' : 'Inbouw niet inbegrepen'}</span>
              <span>${icon('lock')} Betaling in testmodus</span>
              <span>${icon('truck')} ${esc(Repo.settings().shipping.filter((m) => m.enabled).map((m) => m.label).join(' of ') || 'Levering in overleg')}</span>
            </div>
          </div>
          <div class="detail-block"><h2>Compatibiliteit</h2><div class="compat-panel">${compatHtml}</div></div>
          <div class="detail-block"><h2>Omschrijving</h2><div class="prose">${String(p.description || '').split(/\n{2,}/).map((para) => `<p>${esc(para)}</p>`).join('')}</div></div>
          <div class="detail-block"><h2>Specificaties</h2><dl class="spec-list">
            <dt>Categorie</dt><dd>${esc(cat ? cat.name : '—')}</dd>
            <dt>Merk</dt><dd>${esc(p.brand && BRAND[p.brand] ? BRAND[p.brand].name : ((c.brands || []).map((b) => BRAND[b].name).join(', ') || '—'))}</dd>
            ${p.model && MODEL[p.model] ? `<dt>Model</dt><dd>${esc(modelLabel(p.model))}</dd>` : ''}
            <dt>Artikelnummer</dt><dd>${esc(p.sku)}</dd>
            <dt>Soort</dt><dd>${esc(PRODUCT_TYPES[p.type] || 'Product')}</dd>
          </dl></div>
          <div class="detail-block">${UI.notice('Wilt u dit laten inbouwen? Bekijk de <a class="text-link" href="#/mogelijkheden">mogelijkheden voor uw auto</a> of <a class="text-link" href="#/contact">vraag het ons</a>.', { ic: 'wrench' })}</div>
        </div>
      </div>
      ${related.length ? `<section class="section section--soft section--sm"><div class="container"><div class="section-head" style="margin-bottom:28px"><h2 class="h3">Gerelateerde producten</h2><a class="link" href="#/webshop">Alle producten ${icon('arrow')}</a></div><div class="shop-grid" data-stagger>${related.map((x) => UI.productCard(x)).join('')}</div></div></section>` : ''}`;
  },
  mount(root) { Behaviours.mount(root); },
};

/* ---------- Cart page ---------- */
Pages.cart = {
  id: 'cart', nav: 'webshop',
  meta: { title: 'Winkelmand', noindex: true },
  render() {
    return `${UI.pageHeader({ crumbs: [['Webshop', '#/webshop'], ['Winkelmand']], eyebrow: 'Webshop', title: 'Uw winkelmand', compact: true })}
      ${shopNotice()}
      <div class="container" data-cart-root></div>`;
  },
  mount(root) {
    const host = $('[data-cart-root]', root);
    const draw = (notices = []) => {
      const lines = Cart.lines();
      const t = computeTotals(lines, 0);
      if (!lines.length) {
        const sugg = Saved.products().length ? Saved.products() : Repo.products().filter((p) => isPublicProduct(p) && p.featured);
        host.innerHTML = `<div style="padding:48px 0 96px">${notices.length ? `<div class="notice-stack" style="margin-bottom:20px">${notices.map((n) => UI.notice(esc(n), { type: 'warn', ic: 'alert' })).join('')}</div>` : ''}
          ${UI.empty({ icon: 'cart', title: 'Uw winkelmand is leeg', text: 'Voeg producten toe vanuit de webshop. Wilt u een optie laten inbouwen? Bekijk dan de mogelijkheden voor uw auto.', actions: '<a class="btn btn--dark btn--sm" href="#/webshop">Naar de webshop</a><a class="btn btn--light btn--sm" href="#/mogelijkheden">Mogelijkheden</a>' })}
          ${sugg.length ? `<div class="mt-48"><h2 class="h3" style="margin-bottom:24px">${Saved.products().length ? 'Uw bewaarde producten' : 'Uitgelicht'}</h2><div class="shop-grid">${sugg.slice(0, 3).map((p) => UI.productCard(p)).join('')}</div></div>` : ''}</div>`;
        return;
      }
      host.innerHTML = `<div class="cart-page">
        <div>
          ${notices.length ? `<div class="notice-stack" style="margin-bottom:20px">${notices.map((n) => UI.notice(esc(n), { type: 'warn', ic: 'alert' })).join('')}</div>` : ''}
          <div class="table-wrap cart-table"><table class="table">
            <thead><tr><th scope="col">Product</th><th scope="col" class="num">Prijs per stuk</th><th scope="col">Aantal</th><th scope="col" class="num">Totaal</th></tr></thead>
            <tbody>${lines.map((l) => `<tr>
              <td class="ct-cell-product"><div class="ct-product"><div class="cl-media">${Media.html(l.product.images[0], l.product.name, { kind: productArtKind(l.product) })}</div>
                <div><div class="ct-name"><a href="#/webshop/${l.product.slug}">${esc(l.product.name)}</a></div><div class="ct-sub">${esc(l.product.sku)} · ${Stock.html(l.product)}</div>
                <button class="cl-remove mt-8" type="button" data-remove="${l.product.id}">Verwijderen</button></div></div></td>
              <td class="num ct-cell-unit">${l.pricing.onSale ? `<div class="text-muted" style="text-decoration:line-through;font-size:12.5px">${Money.fmt(l.unitRegular)}</div>` : ''}${Money.fmt(l.unitPrice)}${l.pricing.onSale ? `<div style="color:var(--red);font-size:11.5px;font-weight:700">−${l.pricing.pct}%</div>` : ''}</td>
              <td>${UI.qty({ id: l.product.id, value: l.qty, max: Stock.max(l.product), size: 'sm', label: `Aantal ${l.product.name}` })}</td>
              <td class="num" style="font-weight:700">${l.pricing.onSale ? `<div class="text-muted" style="text-decoration:line-through;font-size:12.5px;font-weight:500">${Money.fmt(l.lineRegular)}</div>` : ''}${Money.fmt(l.lineTotal)}</td>
            </tr>`).join('')}</tbody></table></div>
          <p class="mt-24"><a class="link link--ink" href="#/webshop">${icon('arrowLeft')} Verder winkelen</a></p>
        </div>
        <aside class="summary-card" aria-label="Overzicht">
          <h2>Overzicht</h2>
          ${CartUI.totalsHtml(t)}
          <div class="sc-actions"><a class="btn btn--primary btn--block" href="#/afrekenen">Afrekenen</a><a class="btn btn--light btn--block" href="#/webshop">Verder winkelen</a></div>
          <p class="sc-foot">Prijzen zijn ${Repo.settings().vat.pricesIncludeVat ? 'inclusief' : 'exclusief'} btw. Verzendkosten worden bij het afrekenen berekend (testconfiguratie). Inbouw is niet inbegrepen, tenzij vermeld.</p>
        </aside></div>`;
      Behaviours.mount(host);
    };
    const { notices } = Cart.validate();
    draw(notices);
    host.addEventListener('change', (e) => {
      const q = e.target.closest('[data-qty]'); if (!q) return;
      const r = Cart.setQty(q.dataset.qty, e.target.value);
      draw(r.limited ? ['Het aantal is beperkt tot de beschikbare voorraad.'] : []);
    });
    host.addEventListener('click', (e) => {
      const rm = e.target.closest('[data-remove]');
      if (rm) { Cart.remove(rm.dataset.remove); draw(); announce('Product verwijderd'); }
    });
  },
};

/* ---------- Checkout ---------- */
Pages.checkout = {
  id: 'checkout', nav: 'webshop', mobileBar: false,
  meta: { title: 'Afrekenen', noindex: true },
  render() {
    return `<div class="detail-top" style="border-bottom:1px solid var(--line);padding-bottom:22px"><div class="container flex justify-between items-center wrap gap-16">
        ${UI.crumbs([['Home', '#/'], ['Winkelmand', '#/winkelmand'], ['Afrekenen']], { light: true })}
        <ol class="checkout-steps" aria-label="Stappen"><li class="is-active"><span class="n">1</span>Gegevens</li><li><span class="n">2</span>Betalen</li><li><span class="n">3</span>Bevestiging</li></ol>
      </div></div>
      ${shopNotice()}
      <div class="container" data-checkout-root></div>`;
  },
  mount(root) {
    const host = $('[data-checkout-root]', root);
    const settings = Repo.settings();
    const methods = settings.shipping.filter((m) => m.enabled);
    const draft = Storage.get('checkoutForm', {}, 'session');
    const form = {
      firstName: '', lastName: '', email: '', phone: '', street: '', houseNumber: '', postal: '', city: '', note: '',
      delivery: (methods[0] || {}).id || '', ...draft,
    };
    if (!methods.find((m) => m.id === form.delivery)) form.delivery = (methods[0] || {}).id || '';
    let errors = {}; let notices = Cart.validate().notices; let busy = false;
    Analytics.track('checkout_started', { items: Cart.count() });
    const field = (k, label, opts = {}) => `<div class="field${opts.span ? ' span-2' : ''}"><label for="co-${k}">${label}${opts.optional ? ' <span class="opt">(optioneel)</span>' : ''}</label>
      <input class="input" id="co-${k}" name="${k}" data-k="${k}" type="${opts.type || 'text'}" autocomplete="${opts.ac || 'off'}"${opts.mode ? ` inputmode="${opts.mode}"` : ''} value="${attr(form[k])}"${errors[k] ? ' aria-invalid="true"' : ''} aria-describedby="co-${k}-e">
      <span class="field-error" id="co-${k}-e">${errors[k] || ''}</span></div>`;
    const draw = () => {
      const lines = Cart.lines();
      if (!lines.length) {
        host.innerHTML = `<div style="padding:56px 0 96px">${UI.empty({ icon: 'cart', title: 'Er is niets om af te rekenen', text: notices.length ? notices.map(esc).join(' ') : 'Uw winkelmand is leeg.', actions: '<a class="btn btn--dark btn--sm" href="#/webshop">Naar de webshop</a>' })}</div>`;
        return;
      }
      const method = methods.find((m) => m.id === form.delivery) || null;
      const t = computeTotals(lines, method ? method.price : 0);
      const v = VehicleStore.get();
      host.innerHTML = `<form class="checkout" data-co-form novalidate>
        <div>
          <h1 class="h3" style="margin-bottom:28px">Afrekenen</h1>
          ${notices.length ? `<div class="notice-stack" style="margin-bottom:24px">${notices.map((n) => UI.notice(esc(n), { type: 'warn', ic: 'alert' })).join('')}</div>` : ''}
          ${Object.keys(errors).length ? `<div class="error-summary" role="alert" tabindex="-1" data-err-summary style="margin-bottom:24px"><strong>Controleer de volgende velden:</strong><ul>${Object.entries(errors).map(([k, m]) => `<li><a href="#co-${k}" data-focus="co-${k}">${esc(m)}</a></li>`).join('')}</ul></div>` : ''}
          <div class="form-section"><h2>Contactgegevens</h2><div class="form-grid">
            ${field('firstName', 'Voornaam', { ac: 'given-name' })}${field('lastName', 'Achternaam', { ac: 'family-name' })}
            ${field('email', 'E-mailadres', { type: 'email', ac: 'email', mode: 'email' })}${field('phone', 'Telefoonnummer', { type: 'tel', ac: 'tel', mode: 'tel' })}
          </div></div>
          <div class="form-section"><h2>Levering</h2>
            ${methods.length ? `<div class="option-cards" role="radiogroup" aria-label="Leveringsmethode">${methods.map((m) => `<label class="option-card">
              <input type="radio" name="delivery" value="${m.id}"${form.delivery === m.id ? ' checked' : ''} data-k="delivery"><span class="oc-radio" aria-hidden="true"></span>
              <span><span class="oc-title">${esc(m.label)}</span><span class="oc-sub" style="display:block">${esc(m.description || '')}</span></span>
              <span class="oc-price">${m.price ? Money.fmt(m.price) : 'Gratis'}</span></label>`).join('')}</div>` : UI.notice('Er zijn geen leveringsmethoden ingesteld.', { type: 'danger', ic: 'alert' })}
            <span class="field-error" id="co-delivery-e">${errors.delivery || ''}</span>
            ${method && method.requiresAddress ? `<div class="form-grid mt-24">
              ${field('street', 'Straat', { ac: 'address-line1', span: false })}${field('houseNumber', 'Huisnummer', { ac: 'off' })}
              ${field('postal', 'Postcode', { ac: 'postal-code' })}${field('city', 'Plaats', { ac: 'address-level2' })}
            </div>` : ''}
          </div>
          <div class="form-section"><h2>Opmerking</h2>
            <div class="field"><label for="co-note">Opmerking bij uw bestelling <span class="opt">(optioneel)</span></label><textarea class="textarea" id="co-note" data-k="note" style="min-height:96px">${esc(form.note)}</textarea></div>
            ${v ? `<p class="hint mt-8">Uw auto (${esc(VehicleStore.name(v))}${v.year ? `, ${v.year}` : ''}) wordt bij de bestelling vermeld, zodat CarTronic de compatibiliteit kan controleren.</p>` : ''}
          </div>
          <div class="form-section"><h2>Betalen</h2>
            <div class="pay-box">${icon('card')}<div><div class="pb-title">Online betalen <span class="pill pill--warn">Testmodus</span></div>
              <p class="pb-text">In deze demo wordt de betaling gesimuleerd; er wordt geen geld afgeschreven. In productie wordt u doorgestuurd naar de beveiligde betaalpagina van Mollie, en bepaalt de server het te betalen bedrag.</p></div></div>
          </div>
          <div class="mt-32 flex wrap gap-12 items-center">
            <button class="btn btn--primary" type="submit" data-submit style="min-width:260px">${icon('lock')} Bestelling plaatsen en betalen</button>
            <a class="link link--ink" href="#/winkelmand">${icon('arrowLeft')} Terug naar winkelmand</a>
          </div>
        </div>
        <aside class="summary-card" aria-label="Uw bestelling">
          <h2>Uw bestelling</h2>
          <div class="summary-lines">${lines.map((l) => `<div class="summary-line"><div class="sl-media">${Media.html(l.product.images[0], l.product.name, { kind: productArtKind(l.product) })}<span class="sl-qty">${l.qty}</span></div>
            <div class="sl-name">${esc(l.product.name)}</div><div class="sl-price">${l.pricing.onSale ? `<small>${Money.fmt(l.lineRegular)}</small>` : ''}${Money.fmt(l.lineTotal)}</div></div>`).join('')}</div>
          ${CartUI.totalsHtml(t, { shippingLabel: method ? method.label : 'Verzending', shippingKnown: !!method })}
          <p class="sc-foot">De bedragen worden bij het plaatsen opnieuw gecontroleerd. In productie berekent de server het definitieve totaal.</p>
        </aside>
      </form>`;
      const summary = $('[data-err-summary]', host);
      if (summary) summary.focus();
    };
    draw();
    const save = () => { const { note, ...rest } = form; Storage.set('checkoutForm', { ...rest, note }, 'session'); };
    host.addEventListener('input', (e) => {
      const k = e.target.dataset.k;
      if (!k || k === 'delivery') return;
      form[k] = e.target.value; save();
      if (errors[k]) { // clear the error as soon as the field is corrected
        const method = methods.find((m) => m.id === form.delivery);
        if (!validateCheckout(form, method)[k]) {
          delete errors[k];
          e.target.removeAttribute('aria-invalid');
          const el = document.getElementById(`co-${k}-e`); if (el) el.textContent = '';
          const li = host.querySelector(`[data-focus="co-${k}"]`); if (li) li.closest('li').remove();
        }
      }
    });
    host.addEventListener('change', (e) => {
      if (e.target.dataset.k === 'delivery') { form.delivery = e.target.value; save(); draw(); $(`input[value="${form.delivery}"]`, host)?.focus(); }
    });
    host.addEventListener('click', (e) => {
      const f = e.target.closest('[data-focus]'); if (f) { e.preventDefault(); document.getElementById(f.dataset.focus)?.focus(); }
    });
    host.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (busy) return; // double-click protection
      const method = methods.find((m) => m.id === form.delivery);
      errors = validateCheckout(form, method);
      if (Object.keys(errors).length) { draw(); return; }
      busy = true;
      const btn = $('[data-submit]', host);
      btn.classList.add('is-loading'); btn.disabled = true; btn.setAttribute('aria-busy', 'true');
      announce('Bestelling wordt aangemaakt');
      const res = await CheckoutService.placeOrder(form);
      busy = false;
      if (!res.ok) {
        if (res.code === 'cart_changed') { notices = res.notices; errors = {}; Toast.show('Uw winkelmand is bijgewerkt. Controleer het overzicht.', { error: true }); }
        else if (res.code === 'invalid') errors = res.errors || {};
        else notices = ['Uw winkelmand is leeg.'];
        draw();
        return;
      }
      Router.go(res.checkoutUrl.replace(/^#/, ''));
    });
  },
};

/* ---------- Simulated payment page (NOT Mollie) ---------- */
Pages.payment = {
  id: 'payment', nav: 'webshop', mobileBar: false,
  meta: { title: 'Testbetaling', noindex: true },
  render(ctx) {
    const o = Repo.order(ctx.params.id);
    if (!o) return Pages.notFound.render(ctx, { title: 'Deze betaling bestaat niet.' });
    const pay = (o.payments || []).find((p) => p.id === o.paymentId);
    if (!pay || pay.status !== 'open') {
      return `<div class="container"><div class="pay-sim">${UI.notice(`De betaling voor bestelling ${esc(o.orderNumber)} is al verwerkt.`, { ic: 'info', actions: `<a class="btn btn--dark btn--sm" href="#/bestelling/${o.id}">Bekijk de status</a>` })}</div></div>`;
    }
    const opts = [
      ['paid', 'Betaling geslaagd', 'Simuleert een succesvolle betaling', 'var(--ok)'],
      ['pending', 'Betaling in behandeling', 'De betaling is gestart maar nog niet bevestigd', 'var(--info)'],
      ['failed', 'Betaling mislukt', 'Bijvoorbeeld door de bank geweigerd', 'var(--red)'],
      ['canceled', 'Betaling annuleren', 'De klant breekt de betaling af', 'var(--muted-2)'],
    ];
    return `<div class="container"><div class="pay-sim">
      <div class="ps-card">
        <div class="ps-head on-dark"><div><div class="lbl">Te betalen</div><div class="amount">${Money.fmt(o.total)}</div><div class="text-small" style="color:var(--dark-muted);margin-top:4px">Bestelling ${esc(o.orderNumber)}</div></div>
          <span class="demo-flag">${icon('lock')} Testmodus</span></div>
        <div class="ps-body">
          <h1 class="h4">Demo-betaalomgeving</h1>
          <p class="text-muted text-small mt-8" style="line-height:1.65">Dit is een gesimuleerde betaalpagina. Er wordt geen geld overgemaakt en er worden geen betaalgegevens gevraagd. In productie verloopt deze stap via Mollie Checkout; de status wordt daarna door de server via een webhook bevestigd.</p>
          <div class="ps-options" data-ps>${opts.map(([k, t, d, c]) => `<button class="ps-option" type="button" data-outcome="${k}"><span class="dot" style="background:${c}"></span><span><strong>${t}</strong><small>${d}</small></span>${icon('right')}</button>`).join('')}</div>
          <div class="mt-24 flex justify-between items-center wrap gap-12"><span class="text-small text-muted">Betaal-ID: <span class="code">${esc(o.paymentId)}</span></span><a class="text-link text-small" href="#/afrekenen">Terug naar afrekenen</a></div>
        </div>
      </div></div></div>`;
  },
  mount(root, ctx) {
    const box = $('[data-ps]', root); if (!box) return;
    box.addEventListener('click', async (e) => {
      const b = e.target.closest('[data-outcome]'); if (!b) return;
      $$('[data-outcome]', box).forEach((x) => { x.disabled = true; x.style.opacity = x === b ? '1' : '.45'; });
      b.querySelector('svg:last-child').outerHTML = '<span class="loading-dot" style="width:22px;height:22px;background:none" aria-hidden="true"></span>';
      announce('Betaling wordt verwerkt');
      await Payments.simulate(ctx.params.id, b.dataset.outcome);
      Router.go(`/bestelling/${ctx.params.id}`);
    });
  },
};

/* ---------- Order result ---------- */
Pages.orderResult = {
  id: 'order', nav: 'webshop',
  meta: { title: 'Uw bestelling', noindex: true },
  render(ctx) {
    const o = Repo.order(ctx.params.id);
    if (!o) return Pages.notFound.render(ctx, { title: 'Deze bestelling bestaat niet.' });
    const ps = o.paymentStatus;
    let kind; let eyebrow; let title; let text; let actions;
    if (ps === 'paid') {
      kind = 'ok'; eyebrow = 'Betaling geslaagd'; title = 'Bedankt voor uw bestelling.';
      text = `Bestelling ${esc(o.orderNumber)} is betaald. Dit is een demobestelling: er wordt geen e-mail verstuurd en niets geleverd.`;
      actions = '<a class="btn btn--primary" href="#/webshop">Verder winkelen</a><a class="btn btn--light" href="#/">Naar de homepage</a>';
    } else if (ps === 'pending') {
      kind = 'pending'; eyebrow = 'Betaling wordt verwerkt'; title = 'We wachten op de bevestiging.';
      text = 'Uw betaling is gestart maar nog niet bevestigd. Dat kan enkele minuten duren. Zodra de status bekend is, ziet u die hier.';
      actions = '<button class="btn btn--dark" type="button" data-refresh>Status vernieuwen</button>';
    } else if (ps === 'open') {
      kind = 'pending'; eyebrow = 'Betaling nog niet afgerond'; title = 'Uw bestelling wacht op betaling.';
      text = `Bestelling ${esc(o.orderNumber)} is aangemaakt, maar nog niet betaald.`;
      actions = `<a class="btn btn--primary" href="#/betaling/${o.id}">Ga verder met betalen</a><a class="btn btn--light" href="#/winkelmand">Terug naar winkelmand</a>`;
    } else if (ps === 'failed') {
      kind = 'fail'; eyebrow = 'Betaling mislukt'; title = 'De betaling is niet gelukt.';
      text = 'Er is niets afgeschreven. U kunt het opnieuw proberen; uw winkelmand is bewaard.';
      actions = '<button class="btn btn--primary" type="button" data-retry>Opnieuw betalen</button><a class="btn btn--light" href="#/winkelmand">Terug naar winkelmand</a>';
    } else {
      kind = 'cancel'; eyebrow = 'Betaling geannuleerd'; title = 'U heeft de betaling geannuleerd.';
      text = 'Er is niets afgeschreven. Uw winkelmand is bewaard, zodat u later verder kunt.';
      actions = '<button class="btn btn--primary" type="button" data-retry>Opnieuw betalen</button><a class="btn btn--light" href="#/winkelmand">Terug naar winkelmand</a>';
    }
    const ic = { ok: 'check', pending: 'clock', fail: 'x', cancel: 'arrowLeft' }[kind];
    return `<div class="container"><div class="result">
      <div class="result-head">
        <div class="result-icon result-icon--${kind}" data-result-icon>${icon(ic)}</div>
        <p class="eyebrow">${kind === 'pending' && ps === 'pending' ? '<span class="pulse-dot" aria-hidden="true"></span> ' : ''}${eyebrow}</p>
        <h1>${title}</h1>
        <p>${text}</p>
        <div class="result-actions" data-result-actions>${actions}</div>
      </div>
      ${ps === 'pending' ? `<div class="mt-32">${UI.notice('<strong>Testmodus.</strong> Simuleer hoe de betaalprovider de status later bevestigt (webhook).', { ic: 'info', actions: '<button class="btn btn--dark btn--xs" type="button" data-sim="paid">Webhook: geslaagd</button><button class="btn btn--light btn--xs" type="button" data-sim="failed">Webhook: mislukt</button>' })}</div>` : ''}
      <div class="result-card">
        <div class="rc-head"><div><div class="label">Bestelling ${esc(o.orderNumber)}</div><div class="text-small text-muted">${fmtDateTime(o.createdAt)}</div></div>${orderBadge(o.orderStatus)}</div>
        <div class="rc-body">
          <div class="summary-lines">${o.items.map((l) => `<div class="summary-line"><div class="sl-media">${Media.html(l.image, l.name, { kind: 'box' })}<span class="sl-qty">${l.qty}</span></div><div class="sl-name">${esc(l.name)}<div class="text-small text-muted" style="font-weight:500">${Money.fmt(l.unitPrice)} per stuk${l.discountLabel ? ` · ${esc(l.discountLabel)}` : ''}</div></div><div class="sl-price">${Money.fmt(l.lineTotal)}</div></div>`).join('')}</div>
          ${CartUI.totalsHtml({ subtotalRegular: o.subtotalRegular, discountTotal: o.discountTotal, subtotal: o.subtotal, shipping: o.shipping, total: o.total, vat: o.vat }, { shippingLabel: o.delivery.label, shippingKnown: true })}
          <hr style="margin:20px 0">
          <dl class="kv"><dt>Naam</dt><dd>${esc(`${o.customer.firstName} ${o.customer.lastName}`)}</dd><dt>E-mail</dt><dd>${esc(o.customer.email)}</dd><dt>Levering</dt><dd>${esc(o.delivery.label)}</dd><dt>Betaal-ID</dt><dd><span class="code">${esc(o.paymentId || '—')}</span></dd></dl>
        </div>
      </div>
    </div></div>`;
  },
  mount(root, ctx) {
    root.addEventListener('click', async (e) => {
      if (e.target.closest('[data-refresh]')) {
        const b = e.target.closest('[data-refresh]'); b.classList.add('is-loading');
        await sleep(500);
        const o = Repo.order(ctx.params.id);
        await OrderService.onPaymentWebhook(o.paymentId);
        Router.render({ force: false });
        Toast.show('Status bijgewerkt.');
      }
      const sim = e.target.closest('[data-sim]');
      if (sim) { sim.classList.add('is-loading'); await Payments.simulate(ctx.params.id, sim.dataset.sim); Router.render(); }
      const retry = e.target.closest('[data-retry]');
      if (retry) {
        retry.classList.add('is-loading');
        const r = await CheckoutService.retryPayment(ctx.params.id);
        if (r.ok) Router.go(r.checkoutUrl.replace(/^#/, ''));
        else { retry.classList.remove('is-loading'); Toast.show(r.message, { error: true }); }
      }
    });
    const o = Repo.order(ctx.params.id);
    if (o && o.paymentStatus === 'paid') Analytics.track('order_paid_viewed', { order: o.orderNumber });
  },
};

/* ---------- Webshop switched off ---------- */
Pages.shopClosed = {
  id: 'shop-closed', nav: 'webshop',
  meta: { title: 'Webshop', noindex: true },
  render() {
    return `${UI.pageHeader({ crumbs: [['Webshop']], eyebrow: tt('shop.eyebrow'), title: tx('shop.closed.title'), lead: tx('shop.closed.text'), compact: true })}
      <section class="section section--sm"><div class="container"><div class="flex wrap gap-12">
        <a class="btn btn--primary" href="#/contact">Neem contact op</a><a class="btn btn--light" href="#/mogelijkheden">Bekijk de mogelijkheden</a>
      </div></div></section>`;
  },
};
