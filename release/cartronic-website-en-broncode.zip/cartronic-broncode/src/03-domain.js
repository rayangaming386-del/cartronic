/* =====================================================================
   DOMAIN
   ===================================================================== */

/* ---------- Repo: persistence adapter ----------
   Production: replace the bodies with API calls (GET /api/products, PUT /api/products/:id, …)
   and keep the method signatures. Every mutation must then be authorised server-side. */
const Repo = (() => {
  const cache = {};
  const read = (key, fallback) => {
    if (!(key in cache)) cache[key] = Storage.get(key, fallback);
    return cache[key];
  };
  const SHOP_KEYS = ['products', 'shopCategories', 'projects', 'settings'];
  let ver = 0; // changes whenever stored data may have changed
  let dirtyMemo = null;
  let pubFp; // fingerprint of this page's published webshop data (null: none)
  /* Unpublished webshop changes are found by comparing the data with its state when it was last loaded
     (the publication, or the demo data when nothing is published): saving without changes, or changing
     something back, is no change. Kept as a short fingerprint, not as a second copy of the data. */
  function fingerprint(sh, noStock = false) {
    const clean = Content.cleanShop(sh);
    if (!clean) return 'x';
    clean.products = clean.products.map((p) => { const q = { ...p }; delete q.createdAt; delete q.updatedAt; if (noStock) delete q.stock; return q; });
    const str = stableStringify(clean);
    let h1 = 0xdeadbeef; let h2 = 0x41c6ce57;
    for (let i = 0; i < str.length; i++) { const ch = str.charCodeAt(i); h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677); }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return `${str.length}:${(h2 >>> 0).toString(36)}${(h1 >>> 0).toString(36)}`;
  }
  /* Stock set by hand in Beheer is an edit like any other; stock changed by orders is not. The values set in
     Beheer are remembered (per product) until the data is loaded from a publication again. */
  const stockEdits = () => { const e = Storage.get('shopStockEdits', {}); return e && typeof e === 'object' ? e : {}; };
  /** True when every stock value set in Beheer is also the stock in `products` (nothing unpublished). */
  const stockEditsIn = (products) => Object.entries(stockEdits()).every(([id, v]) => { const q = products.find((x) => String(x.id) === id); return !q || q.stock === v; });
  /** Data that differs from `pub` only in stock that came from orders, not from Beheer. */
  const orderStockOnly = (snap, pub) => !!pub && fingerprint(snap, true) === fingerprint(pub, true) && stockEditsIn(pub.products);
  const write = (key, value) => {
    if (SHOP_KEYS.includes(key) && Content.stale && document.body.classList.contains('is-admin')) {
      // An outdated tab must not overwrite the webshop data of a newer version: stop here, nothing is saved.
      Toast.show(RELOAD_FIRST, { error: true });
      const er = new Error('Opslaan gestopt: deze pagina toont een verouderde versie.'); er.ctStale = true; throw er;
    }
    if (key === 'products' && Array.isArray(value) && document.body.classList.contains('is-admin')) {
      const prev = new Map(read('products', []).map((p) => [String(p.id), p.stock]));
      const ed = stockEdits(); let n = 0;
      value.forEach((p) => { const k = String(p.id); if (prev.has(k) && prev.get(k) !== p.stock) { ed[k] = p.stock; n += 1; } });
      if (n) Storage.set('shopStockEdits', ed);
    }
    ver += 1;
    cache[key] = value; Storage.set(key, value);
    // Webshop changes made in Beheer stay unpublished until the next "Publiceren".
    // (A save that leaves the data equal to its base, e.g. without changes or changed back, is no change.)
    if (SHOP_KEYS.includes(key) && document.body.classList.contains('is-admin')) { Storage.set('shopDirty', true); if (!Repo.shopDirty()) Storage.set('shopDirty', false); }
  };
  const SCHEMA = 1;
  return {
    /** True when this browser holds unpublished webshop changes from an older publication. */
    shopParked: false,
    init() {
      const v = Storage.get('schema', 0);
      if (!Storage.get('seeded', false) || v !== SCHEMA) this.reset({ silent: true });
      else if (!Content.stale && Storage.get('pubStamp', '') !== Content.pubStamp) {
        // A new publication: visitors get it straight away; an editor's unpublished changes are kept until they
        // choose. Data that already equals the publication is left as it is (nothing to load, nothing lost).
        // An outdated page (Content.stale) never replaces the data of a newer version.
        const pub = Content.publishedShop();
        const fp = fingerprint(this.shopSnapshot());
        const base = Storage.get('shopBase', null);
        // Edits made in Beheer since the data was last loaded (data stored by an older version: trust the flag).
        const local = Storage.get('shopDirty', false) === true && (typeof base !== 'string' || fp !== base);
        if (pub && fp === fingerprint(pub)) { // already exactly this publication (e.g. the editor's own, just deployed)
          Storage.set('pubStamp', Content.pubStamp); Storage.set('shopDirty', false); Storage.remove('shopStockEdits'); this.markShopBase(pub);
        } else if (Content.isEditor() && !pub) {
          Storage.set('pubStamp', Content.pubStamp); // a page without webshop data (the unpublished file): the editor's data stays
        } else if (Content.isEditor() && local && !orderStockOnly(this.shopSnapshot(), pub)) {
          // (Only stock from orders differs, e.g. a test order: the publication's data simply applies.)
          this.shopParked = true; // unpublished edits and a different publication: the editor chooses
        } else this.loadPublishedShop({ silent: true });
      }
      window.addEventListener('storage', (e) => {
        if (!e.key || !e.key.startsWith(Storage.PREFIX)) return;
        this.invalidate();
        // A decision about this publication taken in another tab ("Mijn concept behouden" or loading it).
        if (this.shopParked && Storage.get('pubStamp', '') === Content.pubStamp) this.shopParked = false;
        Bus.emit('data:changed', { external: true });
      });
    },
    invalidate() { ver += 1; Object.keys(cache).forEach((k) => delete cache[k]); Search.invalidate(); },
    /** Remembers `sh` (default: the current webshop data) as the state without unpublished changes. */
    markShopBase(sh = this.shopSnapshot()) {
      if (sh) { Storage.set('shopBase', fingerprint(sh)); Storage.set('shopBaseNoStock', fingerprint(sh, true)); } else { Storage.remove('shopBase'); Storage.remove('shopBaseNoStock'); }
      ver += 1;
    },
    /** Seeds all webshop data: from the published version, or from the built-in demo data (source 'defaults').
        keepOrders: leave the orders and the order counter as they are. */
    reset({ silent = false, source = 'published', keepOrders = false } = {}) {
      const pub = source === 'defaults' ? null : Content.publishedShop();
      const seq = keepOrders ? (this.settings().orderSeq || 0) : 0;
      const products = pub ? pub.products : seedProducts();
      write('products', products);
      write('shopCategories', pub ? pub.shopCategories : deepClone(DEFAULT_SHOP_CATEGORIES));
      if (!keepOrders) write('orders', seedOrders(products));
      write('settings', { ...(pub ? pub.settings : deepClone(DEFAULT_SETTINGS)), orderSeq: seq });
      write('projects', pub ? pub.projects : deepClone(DEFAULT_PROJECTS));
      Storage.set('seeded', true);
      Storage.set('schema', SCHEMA);
      Storage.set('pubStamp', Content.pubStamp);
      Storage.set('shopDirty', source === 'defaults' && !!Content.publishedShop());
      Storage.remove('shopStockEdits');
      // The demo data replacing a publication is an unpublished change; otherwise this is the clean state.
      this.markShopBase(source === 'defaults' && Content.publishedShop() ? Content.publishedShop() : this.shopSnapshot());
      this.shopParked = false;
      Search.invalidate();
      if (!silent) Bus.emit('data:changed', {});
    },
    /** Replaces products, categories, projects and settings with the published version; orders stay. */
    loadPublishedShop({ silent = false } = {}) {
      const pub = Content.publishedShop();
      const seq = this.settings().orderSeq || 0;
      write('products', pub ? pub.products : seedProducts());
      write('shopCategories', pub ? pub.shopCategories : deepClone(DEFAULT_SHOP_CATEGORIES));
      write('projects', pub ? pub.projects : deepClone(DEFAULT_PROJECTS));
      write('settings', { ...(pub ? pub.settings : deepClone(DEFAULT_SETTINGS)), orderSeq: seq });
      Storage.set('pubStamp', Content.pubStamp);
      Storage.set('shopDirty', false);
      Storage.remove('shopStockEdits');
      this.markShopBase();
      this.shopParked = false;
      Search.invalidate();
      if (!silent) Bus.emit('data:changed', {});
    },
    /** The webshop data that a publication carries (no orders, no order counter). */
    shopSnapshot() {
      const s = { ...this.settings() }; delete s.orderSeq;
      return { products: this.products(), shopCategories: this.shopCategories(), projects: this.projects(), settings: s };
    },
    /** Unpublished webshop changes: the data differs from the publication of this page (or, when it carries
        none, from the state remembered when the data was loaded). */
    shopDirty() {
      if (Storage.get('shopDirty', false) !== true) return false;
      if (pubFp === undefined) { const pub = Content.publishedShop(); pubFp = pub ? fingerprint(pub) : null; }
      const base = pubFp || Storage.get('shopBase', null);
      if (typeof base !== 'string') return true; // stored by an older version: trust the flag
      if (!dirtyMemo || dirtyMemo.ver !== ver || dirtyMemo.base !== base) {
        const snap = this.shopSnapshot();
        // A difference only in stock from orders (not set in Beheer) is no unpublished change.
        const ordersOnly = pubFp ? orderStockOnly(snap, Content.publishedShop())
          : (fingerprint(snap, true) === Storage.get('shopBaseNoStock', null) && !Object.keys(stockEdits()).length);
        dirtyMemo = { ver, base, value: fingerprint(snap) !== base && !ordersOnly };
      }
      return dirtyMemo.value;
    },
    // Products
    products() { return read('products', []); },
    product(id) { return this.products().find((p) => p.id === id) || null; },
    productBySlug(slug) { return this.products().find((p) => p.slug === slug) || null; },
    saveProduct(product) {
      const list = this.products().slice();
      const p = { ...product, updatedAt: nowIso() };
      const i = list.findIndex((x) => x.id === p.id);
      if (i > -1) list[i] = p; else { p.createdAt = p.createdAt || nowIso(); list.push(p); }
      write('products', list);
      Search.invalidate();
      Bus.emit('products:changed', p);
      return p;
    },
    deleteProduct(id) {
      write('products', this.products().filter((p) => p.id !== id));
      Search.invalidate();
      Bus.emit('products:changed', { id });
    },
    replaceProducts(list) { write('products', list); Search.invalidate(); Bus.emit('products:changed', {}); },
    // Shop categories
    shopCategories() { return read('shopCategories', []).slice().sort((a, b) => a.order - b.order); },
    shopCategory(id) { return this.shopCategories().find((c) => c.id === id) || null; },
    saveShopCategories(list) { write('shopCategories', list); Search.invalidate(); Bus.emit('categories:changed'); },
    // Orders
    orders() { return read('orders', []); },
    order(id) { return this.orders().find((o) => o.id === id) || null; },
    saveOrder(order) {
      const list = this.orders().slice();
      const o = { ...order, updatedAt: nowIso() };
      const i = list.findIndex((x) => x.id === o.id);
      if (i > -1) list[i] = o; else list.push(o);
      write('orders', list);
      Bus.emit('orders:changed', o);
      return o;
    },
    /** Removes the orders matching pred (used by "Alles wissen" for orders placed in this browser). */
    removeOrders(pred) {
      const list = this.orders();
      const keep = list.filter((o) => !pred(o));
      if (keep.length !== list.length) { write('orders', keep); Bus.emit('orders:changed', null); }
      return list.length - keep.length;
    },
    // Settings
    settings() { return { ...deepClone(DEFAULT_SETTINGS), ...read('settings', {}) }; },
    saveSettings(s) { write('settings', s); Bus.emit('settings:changed', s); },
    nextOrderNumber() {
      const s = this.settings();
      s.orderSeq = (s.orderSeq || 0) + 1;
      this.saveSettings(s);
      return `CT-${new Date().getFullYear()}-${String(s.orderSeq).padStart(5, '0')}`;
    },
    // Projects
    projects() { return read('projects', []); },
    project(slug) { return this.projects().find((p) => p.slug === slug) || null; },
    saveProjects(list) { write('projects', list); Search.invalidate(); Bus.emit('projects:changed'); },
  };
})();

const isPublicProduct = (p) => !!p && p.active && !p.archived;

/* ---------- Pricing (integer cents) ---------- */
const Pricing = {
  promoState(p, at = Date.now()) {
    if (!p || !p.discountType || p.discountType === 'none') return 'none';
    const start = p.startDate ? Date.parse(`${p.startDate}T00:00:00`) : null;
    const end = p.endDate ? Date.parse(`${p.endDate}T23:59:59`) : null;
    if (start && at < start) return 'scheduled';
    if (end && at > end) return 'expired';
    return 'active';
  },
  calc(p, at = Date.now()) {
    const regular = p.regularPrice;
    let price = regular;
    if (this.promoState(p, at) === 'active') {
      if (p.discountType === 'sale' && isInt(p.salePrice) && p.salePrice > 0 && p.salePrice < regular) price = p.salePrice;
      if (p.discountType === 'percent' && isInt(p.discountValue) && p.discountValue > 0 && p.discountValue < 100) price = regular - Math.round((regular * p.discountValue) / 100);
      if (p.discountType === 'fixed' && isInt(p.discountValue) && p.discountValue > 0 && p.discountValue < regular) price = regular - p.discountValue;
    }
    const discount = regular - price;
    return { regular, price, discount, pct: Money.pct(discount, regular), onSale: discount > 0 };
  },
  describe(p) {
    switch (p.discountType) {
      case 'sale': return `Actieprijs ${Money.fmt(p.salePrice)}`;
      case 'percent': return `${p.discountValue}% korting`;
      case 'fixed': return `${Money.fmt(p.discountValue)} korting`;
      default: return 'Geen korting';
    }
  },
  html(p, { size = '' } = {}) {
    const c = this.calc(p);
    return `<div class="price${c.onSale ? ' is-sale' : ''}${size ? ` price--${size}` : ''}">
      <span class="now">${Money.fmt(c.price)}</span>
      ${c.onSale ? `<span class="was"><span class="sr-only">Normale prijs </span>${Money.fmt(c.regular)}</span><span class="off">${c.pct}% korting</span>` : ''}
    </div>`;
  },
};

/* ---------- Stock ---------- */
const Stock = {
  threshold() { return Repo.settings().lowStockThreshold; },
  max(p) { return p.trackStock ? Math.max(0, p.stock | 0) : 99; },
  status(p) {
    if (!p.trackStock) return { key: 'na', label: 'Levertijd op aanvraag' };
    if ((p.stock | 0) <= 0) return { key: 'out', label: 'Uitverkocht' };
    if (p.stock <= this.threshold()) return { key: 'low', label: `Nog ${p.stock} op voorraad` };
    return { key: 'in', label: 'Op voorraad' };
  },
  html(p) { const s = this.status(p); return `<span class="stock stock--${s.key}">${esc(s.label)}</span>`; },
};

/* ---------- Compatibility (retrofit catalog vs. vehicle) ---------- */
const Compat = {
  STATUS: {
    ok: { label: 'Beschikbaar voor dit model', cls: 'ok', rank: 0 },
    variant: { label: 'Uitvoering afhankelijk', cls: 'variant', rank: 1 },
    check: { label: 'Controle vereist', cls: 'check', rank: 2 },
    contact: { label: 'Neem contact op', cls: 'contact', rank: 3 },
  },
  brandsOf(item) { return item.scope === 'brand' ? (item.brands || [item.brand]) : [item.brand]; },
  status(item, v) {
    if (!v || !v.brandId) return null;
    if (item.scope === 'brand') {
      if (!this.brandsOf(item).includes(v.brandId)) return null;
      return { key: 'check', reason: item.variantNote || 'Mogelijk voor meerdere modellen; CarTronic controleert de uitvoering van uw auto.' };
    }
    if (!v.modelId || !item.models.includes(v.modelId)) return null;
    const years = (item.yearsByModel && item.yearsByModel[v.modelId]) || item.years;
    if (years) {
      const [a, b] = years;
      if (!v.year) return { key: 'check', reason: `Online vermeld voor bouwjaar ${a}–${b}. Uw bouwjaar is nog niet bekend.` };
      if (v.year < a || v.year > b) return { key: 'contact', reason: `Online vermeld voor bouwjaar ${a}–${b}. Voor bouwjaar ${v.year} bekijken we de mogelijkheden graag persoonlijk.` };
    }
    if (item.body && v.body && !normText(v.body).includes(item.body)) {
      return { key: 'contact', reason: `${item.variantNote || ''} Uw auto is geregistreerd als ${String(v.body).toLowerCase()}.`.trim() };
    }
    if (item.variantNote) return { key: 'variant', reason: item.variantNote };
    return { key: 'ok', reason: 'Deze optie staat in de CarTronic-catalogus voor uw model.' };
  },
  badge(st) {
    if (!st) return '';
    const s = this.STATUS[st.key];
    return `<span class="status status--${s.cls}">${esc(s.label)}</span>`;
  },
  forVehicle(v) {
    if (!v) return [];
    return RETROFITS.map((item) => ({ item, st: this.status(item, v) }))
      .filter((x) => x.st)
      .sort((a, b) => (this.STATUS[a.st.key].rank - this.STATUS[b.st.key].rank)
        || (CATEGORIES.findIndex((c) => c.id === a.item.cat) - CATEGORIES.findIndex((c) => c.id === b.item.cat)));
  },
  countForModel(modelId) { return RETROFITS.filter((r) => r.models.includes(modelId)).length; },
  get disclaimer() { return tt('compat.disclaimer'); },
};
const retrofitImage = (r) => (r.image ? imgRef(r.image) : `art:${r.art}:0`);
const retrofitModelsText = (r) => (r.scope === 'brand'
  ? (r.brands || [r.brand]).map((b) => BRAND[b].name).join(', ')
  : r.models.map((m) => MODEL[m].name).join(', '));

/* ---------- Kenteken (Dutch registration plates) ---------- */
const Plate = {
  // All Dutch side codes (sidecodes 1–14), as letter/digit patterns of the compact plate.
  SIDECODES: [
    [/^[A-Z]{2}\d{2}\d{2}$/, [2, 2, 2]], [/^\d{2}\d{2}[A-Z]{2}$/, [2, 2, 2]], [/^\d{2}[A-Z]{2}\d{2}$/, [2, 2, 2]],
    [/^[A-Z]{2}\d{2}[A-Z]{2}$/, [2, 2, 2]], [/^[A-Z]{2}[A-Z]{2}\d{2}$/, [2, 2, 2]], [/^\d{2}[A-Z]{2}[A-Z]{2}$/, [2, 2, 2]],
    [/^\d{2}[A-Z]{3}\d$/, [2, 3, 1]], [/^\d[A-Z]{3}\d{2}$/, [1, 3, 2]], [/^[A-Z]{2}\d{3}[A-Z]$/, [2, 3, 1]],
    [/^[A-Z]\d{3}[A-Z]{2}$/, [1, 3, 2]], [/^[A-Z]{3}\d{2}[A-Z]$/, [3, 2, 1]], [/^[A-Z]\d{2}[A-Z]{3}$/, [1, 2, 3]],
    [/^\d[A-Z]{2}\d{3}$/, [1, 2, 3]], [/^\d{3}[A-Z]{2}\d$/, [3, 2, 1]],
  ],
  compact(input) { return String(input || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); },
  format(input) {
    const c = this.compact(input);
    if (c.length !== 6) return null;
    const hit = this.SIDECODES.find(([re]) => re.test(c));
    if (!hit) return null;
    const out = []; let i = 0;
    hit[1].forEach((n) => { out.push(c.slice(i, i + n)); i += n; });
    return out.join('-');
  },
  isValid(input) { return !!this.format(input); },
};

/* Demo/test plates — clearly labelled in the UI, never mixed with real RDW results. */
const DEMO_VEHICLES = {
  TEST01: { merk: 'VOLKSWAGEN', handelsbenaming: 'GOLF', datum_eerste_toelating: '20190315', voertuigsoort: 'Personenauto', inrichting: 'hatchback', type: 'AU', _hint: 'Volkswagen Golf 7 · 2019' },
  TEST02: { merk: 'AUDI', handelsbenaming: 'A3 SPORTBACK', datum_eerste_toelating: '20180620', voertuigsoort: 'Personenauto', inrichting: 'hatchback', type: '8V', _hint: 'Audi A3 8V · 2018' },
  TEST03: { merk: 'SEAT', handelsbenaming: 'IBIZA', datum_eerste_toelating: '20210302', voertuigsoort: 'Personenauto', inrichting: 'hatchback', type: 'KJ', _hint: 'SEAT Ibiza · 2021' },
  TEST04: { merk: 'SKODA', handelsbenaming: 'KODIAQ', datum_eerste_toelating: '20180911', voertuigsoort: 'Personenauto', inrichting: 'stationwagen', type: 'NS', _hint: 'Škoda Kodiaq · 2018' },
  TEST12: { merk: 'AUDI', handelsbenaming: 'A4 AVANT', datum_eerste_toelating: '20190404', voertuigsoort: 'Personenauto', inrichting: 'stationwagen', type: '8W', _hint: 'Audi A4 Avant · 2019' },
  TEST06: { merk: 'VOLKSWAGEN', handelsbenaming: 'GOLF VARIANT', datum_eerste_toelating: '20200601', voertuigsoort: 'Personenauto', inrichting: 'stationwagen', type: '', _hint: 'Golf 2020 — generatie kiezen' },
  TEST11: { merk: 'VOLKSWAGEN', handelsbenaming: 'GOLF', datum_eerste_toelating: '20100215', voertuigsoort: 'Personenauto', inrichting: 'hatchback', type: '1K', _hint: 'Golf 2010 — generatie niet online' },
  TEST07: { merk: 'VOLKSWAGEN', handelsbenaming: 'PHAETON', datum_eerste_toelating: '20120410', voertuigsoort: 'Personenauto', inrichting: 'sedan', type: '3D', _hint: 'Model niet in catalogus' },
  TEST05: { merk: 'BMW', handelsbenaming: '3ER REIHE', datum_eerste_toelating: '20200115', voertuigsoort: 'Personenauto', inrichting: 'sedan', type: '', _hint: 'Merk niet ondersteund' },
  TEST08: null, // not found
  TEST09: 'unavailable', // simulates RDW downtime
};
const DEMO_PLATE_LIST = [['TEST01'], ['TEST02'], ['TEST03'], ['TEST04'], ['TEST12'], ['TEST06'], ['TEST11'], ['TEST07'], ['TEST05'], ['TEST08', 'Niet gevonden'], ['TEST09', 'RDW niet bereikbaar']];

const DemoVehicleAdapter = {
  id: 'demo',
  handles(compact) { return Object.prototype.hasOwnProperty.call(DEMO_VEHICLES, compact); },
  async lookup(compact) {
    await sleep(700);
    const v = DEMO_VEHICLES[compact];
    if (v === 'unavailable') return { status: 'unavailable' };
    if (!v) return { status: 'not_found' };
    return { status: 'ok', source: 'demo', raw: { ...v, kenteken: compact } };
  },
};

/* RDW Open Data — "Gekentekende voertuigen" (Socrata API, CORS enabled, no key required).
   Production: call this through an own backend endpoint (GET /api/vehicle?plate=…) for caching,
   rate limiting and to keep plate look-ups out of third-party logs where possible. */
const RdwAdapter = {
  id: 'rdw',
  endpoint: 'https://opendata.rdw.nl/resource/m9d7-ebf2.json',
  async lookup(compact) {
    const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const timer = setTimeout(() => ctrl && ctrl.abort(), 8000);
    try {
      const res = await fetch(`${this.endpoint}?kenteken=${encodeURIComponent(compact)}`, {
        signal: ctrl ? ctrl.signal : undefined, headers: { Accept: 'application/json' }, credentials: 'omit', referrerPolicy: 'no-referrer',
      });
      if (!res.ok) return { status: 'unavailable' };
      const rows = await res.json();
      if (!Array.isArray(rows)) return { status: 'unavailable' };
      if (!rows.length) return { status: 'not_found' };
      const r = rows[0];
      return {
        status: 'ok', source: 'rdw',
        raw: {
          kenteken: r.kenteken, merk: r.merk, handelsbenaming: r.handelsbenaming,
          datum_eerste_toelating: r.datum_eerste_toelating, voertuigsoort: r.voertuigsoort,
          inrichting: r.inrichting, type: r.type || '',
        },
      };
    } catch (e) {
      return { status: 'unavailable' };
    } finally { clearTimeout(timer); }
  },
};

const VehicleMatcher = {
  SUPPORTED_KINDS: ['personenauto', 'bedrijfsauto'],
  brandFor(merk) {
    const m = String(merk || '').toUpperCase().trim();
    return BRANDS.find((b) => b.rdw.some((r) => m === r || m.startsWith(`${r} `))) || null;
  },
  cleanName(name, brand) {
    let n = String(name || '').toUpperCase();
    [brand ? brand.name.toUpperCase() : '', ...(brand ? brand.rdw : [])].forEach((p) => { if (p && n.startsWith(`${p} `)) n = n.slice(p.length + 1); });
    return n.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Z0-9]/g, '');
  },
  match(raw) {
    const year = parseInt(String(raw.datum_eerste_toelating || '').slice(0, 4), 10) || null;
    const kind = String(raw.voertuigsoort || '').toLowerCase();
    const base = {
      year, rdwBrand: raw.merk || '', rdwName: raw.handelsbenaming || '', body: raw.inrichting || '',
      firstAdmission: raw.datum_eerste_toelating || '',
    };
    if (kind && !this.SUPPORTED_KINDS.includes(kind)) return { ...base, status: 'unsupported_kind', kind: raw.voertuigsoort };
    const brand = this.brandFor(raw.merk);
    if (!brand) return { ...base, status: 'unsupported_brand' };
    const name = this.cleanName(raw.handelsbenaming, brand);
    const candidates = MODELS.filter((m) => m.brand === brand.id
      && m.match.some((t) => name.startsWith(t) && !(year && m.matchTo && m.matchTo[t] && year > m.matchTo[t]))
      && !(m.exclude || []).some((x) => name.startsWith(x)));
    if (!candidates.length) return { ...base, status: 'unknown_model', brandId: brand.id };
    const inYear = year ? candidates.filter((m) => year >= m.from && year <= (m.to || 9999)) : candidates;
    const type = String(raw.type || '').toUpperCase();
    if (type) {
      const byType = inYear.filter((m) => (m.types || []).some((t) => type.startsWith(t)));
      if (byType.length === 1) return { ...base, status: 'matched', brandId: brand.id, modelId: byType[0].id, confidence: 'type' };
    }
    if (inYear.length === 1) {
      // A known type code that contradicts the year-based generation is flagged, never silently trusted.
      const known = inYear[0].types || [];
      const conflict = !!type && known.length > 0 && !known.some((t) => type.startsWith(t));
      return { ...base, status: 'matched', brandId: brand.id, modelId: inYear[0].id, confidence: conflict ? 'unverified' : 'year' };
    }
    if (inYear.length > 1) return { ...base, status: 'ambiguous', brandId: brand.id, options: inYear.map((m) => m.id) };
    return { ...base, status: 'generation_unknown', brandId: brand.id, options: candidates.map((m) => m.id), baseName: candidates[0].base };
  },
};

const VehicleLookup = {
  /** Returns a normalised result object; never throws. */
  async lookup(input) {
    const plate = Plate.format(input);
    if (!plate) return { status: 'invalid' };
    const compact = Plate.compact(input);
    const mode = Repo.settings().vehicleLookupMode;
    const useDemo = DemoVehicleAdapter.handles(compact) || mode === 'demo';
    Analytics.track('vehicle_lookup_started', { source: useDemo ? 'demo' : 'rdw' });
    const res = useDemo ? await DemoVehicleAdapter.lookup(compact) : await RdwAdapter.lookup(compact);
    if (res.status !== 'ok') {
      Analytics.track(res.status === 'not_found' ? 'vehicle_lookup_not_found' : 'vehicle_lookup_unavailable', { source: useDemo ? 'demo' : 'rdw' });
      return { ...res, plate, source: useDemo ? 'demo' : 'rdw' };
    }
    const m = VehicleMatcher.match(res.raw);
    if (m.status === 'matched') Analytics.track('vehicle_lookup_success', { brand: m.brandId, model: m.modelId, source: res.source });
    else Analytics.track('vehicle_lookup_unsupported', { reason: m.status, source: res.source });
    return { ...m, plate, source: res.source };
  },
};

/* ---------- Vehicle context ("Uw auto") ----------
   The vehicle (brand/model/year) is kept in localStorage for convenience.
   The kenteken is kept in sessionStorage only and expires after 24 hours. */
const VehicleStore = {
  PLATE_TTL: 24 * 3600 * 1000,
  get() {
    const v = Storage.get('vehicle', null);
    if (!v || !BRAND[v.brandId] || (v.modelId && !MODEL[v.modelId])) return null;
    return v;
  },
  set(v, { plate = null } = {}) {
    const clean = {
      brandId: v.brandId, modelId: v.modelId || null, year: v.year || null, body: v.body || '',
      source: v.source || 'manual', confidence: v.confidence || 'manual', rdwName: v.rdwName || '', setAt: nowIso(),
    };
    Storage.set('vehicle', clean);
    if (plate) Storage.set('plate', { value: plate, at: Date.now() }, 'session');
    else Storage.remove('plate', 'session');
    Analytics.track('vehicle_selected', { brand: clean.brandId, model: clean.modelId, source: clean.source });
    Bus.emit('vehicle:changed', clean);
    return clean;
  },
  clear() {
    Storage.remove('vehicle'); Storage.remove('plate', 'session');
    Bus.emit('vehicle:changed', null);
  },
  plate() {
    const p = Storage.get('plate', null, 'session');
    if (!p) return null;
    if (Date.now() - p.at > this.PLATE_TTL) { Storage.remove('plate', 'session'); return null; }
    return p.value;
  },
  forgetPlate() { Storage.remove('plate', 'session'); Bus.emit('vehicle:changed', this.get()); },
  name(v = this.get()) { if (!v) return ''; return v.modelId ? modelLabel(v.modelId) : BRAND[v.brandId].name; },
  short(v = this.get()) { if (!v) return ''; return v.modelId ? MODEL[v.modelId].name : BRAND[v.brandId].name; },
  meta(v = this.get()) {
    if (!v) return '';
    const parts = [];
    if (v.year) parts.push(String(v.year));
    else if (v.modelId) parts.push(modelYears(MODEL[v.modelId]));
    if (v.body) parts.push(v.body.charAt(0).toUpperCase() + v.body.slice(1).toLowerCase());
    return parts.join(' · ');
  },
  sourceLabel(v = this.get()) {
    if (!v) return '';
    return { rdw: 'Bron: RDW Open Data', demo: 'Demo-gegevens', manual: 'Handmatig gekozen' }[v.source] || '';
  },
};

/* ---------- Saved items & recently viewed ---------- */
const Saved = {
  all() { return Storage.get('saved', { retrofits: [], products: [] }); },
  has(type, id) { return (this.all()[type] || []).includes(id); },
  toggle(type, id) {
    const s = this.all();
    const list = s[type] || [];
    const on = !list.includes(id);
    s[type] = on ? [id, ...list] : list.filter((x) => x !== id);
    Storage.set('saved', s);
    if (on) Analytics.track(type === 'products' ? 'product_saved' : 'retrofit_saved', { id });
    Bus.emit('saved:changed', s);
    return on;
  },
  remove(type, id) { const s = this.all(); s[type] = (s[type] || []).filter((x) => x !== id); Storage.set('saved', s); Bus.emit('saved:changed', s); },
  retrofits() { return this.all().retrofits.map((s) => RETROFIT[s]).filter(Boolean); },
  products() { return Content.shopOn() ? this.all().products.map((id) => Repo.product(id)).filter(isPublicProduct) : []; },
  count() { return this.retrofits().length + this.products().length; },
};
const Recent = {
  add(type, id) {
    const list = Storage.get('recent', []).filter((r) => !(r.type === type && r.id === id));
    list.unshift({ type, id, at: Date.now() });
    Storage.set('recent', list.slice(0, 12));
  },
  list(exclude) {
    return Storage.get('recent', []).filter((r) => !(exclude && r.type === exclude.type && r.id === exclude.id)).map((r) => {
      if (r.type === 'retrofit') { const it = RETROFIT[r.id]; return it ? { type: r.type, item: it } : null; }
      if (r.type === 'product') { const p = Content.shopOn() ? Repo.product(r.id) : null; return isPublicProduct(p) ? { type: r.type, item: p } : null; }
      return null;
    }).filter(Boolean);
  },
  clear() { Storage.remove('recent'); },
};

/* ---------- Cart ---------- */
const Cart = {
  get() { return Storage.get('cart', { items: [] }); },
  save(cart) { Storage.set('cart', { items: cart.items, updatedAt: nowIso() }); Bus.emit('cart:changed'); },
  count() { return this.get().items.reduce((s, i) => s + i.qty, 0); },
  qtyOf(productId) { const it = this.get().items.find((i) => i.productId === productId); return it ? it.qty : 0; },
  add(productId, qty = 1) {
    const p = Repo.product(productId);
    if (!isPublicProduct(p)) return { ok: false, message: 'Dit product is niet beschikbaar.' };
    const max = Stock.max(p);
    if (max <= 0) return { ok: false, message: `“${p.name}” is uitverkocht.` };
    const cart = this.get();
    const it = cart.items.find((i) => i.productId === productId);
    const current = it ? it.qty : 0;
    const want = current + Math.max(1, qty | 0);
    const next = Math.min(want, max);
    if (next === current) return { ok: false, message: `U heeft al het maximaal beschikbare aantal (${max}) in uw winkelmand.` };
    const price = Pricing.calc(p).price;
    if (it) { it.qty = next; it.priceSeen = price; } else cart.items.push({ productId, qty: next, priceSeen: price, addedAt: nowIso() });
    this.save(cart);
    Analytics.track('product_added_to_cart', { id: productId, qty: next - current });
    return { ok: true, limited: next < want, added: next - current, qty: next, max };
  },
  setQty(productId, qty) {
    const p = Repo.product(productId);
    const cart = this.get();
    const it = cart.items.find((i) => i.productId === productId);
    if (!it || !p) return { ok: false };
    const max = Stock.max(p);
    const next = clamp(parseInt(qty, 10) || 1, 1, Math.max(1, max));
    it.qty = next;
    this.save(cart);
    return { ok: true, qty: next, limited: next < (parseInt(qty, 10) || 1) };
  },
  remove(productId) { const cart = this.get(); cart.items = cart.items.filter((i) => i.productId !== productId); this.save(cart); },
  clear() { this.save({ items: [] }); },
  /** Re-validates the cart against current product data, corrects it and returns notices. */
  validate() {
    const cart = this.get();
    const notices = [];
    let changed = false;
    const items = [];
    cart.items.forEach((it) => {
      const p = Repo.product(it.productId);
      if (!p || p.archived) { notices.push('Een product in uw winkelmand is niet meer beschikbaar en is verwijderd.'); changed = true; return; }
      if (!p.active) { notices.push(`“${p.name}” is momenteel niet beschikbaar en is uit uw winkelmand verwijderd.`); changed = true; return; }
      const max = Stock.max(p);
      if (max <= 0) { notices.push(`“${p.name}” is uitverkocht en is uit uw winkelmand verwijderd.`); changed = true; return; }
      const qty = clamp(parseInt(it.qty, 10) || 1, 1, max);
      if (qty !== it.qty) { notices.push(`Van “${p.name}” zijn nog ${max} stuks beschikbaar. Het aantal is aangepast.`); changed = true; }
      const price = Pricing.calc(p).price;
      if (it.priceSeen != null && it.priceSeen !== price) {
        notices.push(`De prijs van “${p.name}” is gewijzigd van ${Money.fmt(it.priceSeen)} naar ${Money.fmt(price)}.`);
        changed = true;
      }
      items.push({ productId: p.id, qty, priceSeen: price, addedAt: it.addedAt });
    });
    if (changed) this.save({ items });
    return { notices, changed };
  },
  lines() {
    return this.get().items.map((it) => {
      const p = Repo.product(it.productId);
      if (!isPublicProduct(p)) return null;
      const pr = Pricing.calc(p);
      return { product: p, qty: it.qty, unitRegular: pr.regular, unitPrice: pr.price, lineRegular: pr.regular * it.qty, lineTotal: pr.price * it.qty, pricing: pr };
    }).filter(Boolean);
  },
};
function computeTotals(lines, shipping = 0) {
  const settings = Repo.settings();
  const subtotalRegular = lines.reduce((s, l) => s + l.lineRegular, 0);
  const subtotal = lines.reduce((s, l) => s + l.lineTotal, 0);
  const total = subtotal + shipping;
  const rate = settings.vat.rate;
  return {
    subtotalRegular, discountTotal: subtotalRegular - subtotal, subtotal, shipping, total,
    vat: { rate, amount: settings.vat.pricesIncludeVat ? Math.round((total * rate) / (100 + rate)) : 0, included: settings.vat.pricesIncludeVat },
  };
}

/* ---------- Orders ---------- */
const ORDER_STATUS = {
  WACHT_OP_BETALING: { label: 'Wacht op betaling', cls: 'check' },
  BETAALD: { label: 'Betaald', cls: 'ok' },
  BETALING_MISLUKT: { label: 'Betaling mislukt', cls: 'contact' },
  GEANNULEERD: { label: 'Geannuleerd', cls: 'neutral' },
  IN_BEHANDELING: { label: 'In behandeling', cls: 'variant' },
  AFGEROND: { label: 'Afgerond', cls: 'ok' },
};
const ORDER_TRANSITIONS = {
  WACHT_OP_BETALING: ['GEANNULEERD'],
  BETAALD: ['IN_BEHANDELING', 'AFGEROND', 'GEANNULEERD'],
  IN_BEHANDELING: ['AFGEROND', 'GEANNULEERD'],
  BETALING_MISLUKT: ['GEANNULEERD'],
  GEANNULEERD: [],
  AFGEROND: [],
};
const PAYMENT_STATUS = { open: 'Open', pending: 'In verwerking', paid: 'Betaald', failed: 'Mislukt', canceled: 'Geannuleerd', expired: 'Verlopen' };
const orderBadge = (status) => { const s = ORDER_STATUS[status] || { label: status, cls: 'neutral' }; return `<span class="status status--${s.cls}">${esc(s.label)}</span>`; };

const OrderService = {
  /* Simulated webhook handler. Production: POST /api/webhooks/mollie with only a payment id.
     The server re-fetches the payment from Mollie (never trusts the request body), then
     updates the order idempotently. */
  async onPaymentWebhook(paymentId) {
    const payment = await Payments.getPayment(paymentId);
    const order = Repo.orders().find((o) => (o.payments || []).some((p) => p.id === paymentId));
    if (!order || !payment) return null;
    if (order.paymentId !== paymentId) return order; // stale payment for this order
    if (order.paymentStatus === payment.status) return order; // idempotent
    const o = deepClone(order);
    o.paymentStatus = payment.status;
    const map = { paid: 'BETAALD', failed: 'BETALING_MISLUKT', canceled: 'GEANNULEERD', expired: 'GEANNULEERD', open: 'WACHT_OP_BETALING', pending: 'WACHT_OP_BETALING' };
    const next = map[payment.status];
    const locked = ['BETAALD', 'IN_BEHANDELING', 'AFGEROND'].includes(o.orderStatus);
    if (!locked && next && next !== o.orderStatus) {
      o.orderStatus = next;
      o.history.push({ at: nowIso(), status: next, note: `Betaalstatus: ${PAYMENT_STATUS[payment.status]}` });
    } else if (payment.status === 'pending') {
      o.history.push({ at: nowIso(), status: o.orderStatus, note: 'Betaling wordt verwerkt' });
    }
    if (payment.status === 'paid' && !o.stockApplied) {
      o.items.forEach((line) => {
        const p = Repo.product(line.productId);
        if (p && p.trackStock) {
          if (p.stock < line.qty) o.history.push({ at: nowIso(), status: o.orderStatus, note: `Voorraadconflict: ${line.name} (${p.stock} op voorraad, ${line.qty} besteld)` });
          Repo.saveProduct({ ...p, stock: Math.max(0, p.stock - line.qty) });
        }
      });
      o.stockApplied = true;
      const key = Storage.get('checkoutKey', null, 'session');
      if (key && key.key === o.idempotencyKey) { Cart.clear(); Storage.remove('checkoutKey', 'session'); }
    }
    return Repo.saveOrder(o);
  },
  setStatus(orderId, status, note = '') {
    const o = deepClone(Repo.order(orderId));
    if (!o) return { ok: false, message: 'Bestelling niet gevonden.' };
    if (!(ORDER_TRANSITIONS[o.orderStatus] || []).includes(status)) return { ok: false, message: 'Deze statuswijziging is niet toegestaan.' };
    o.orderStatus = status;
    o.history.push({ at: nowIso(), status, note: note || `Status gewijzigd naar ${ORDER_STATUS[status].label}` });
    Repo.saveOrder(o);
    return { ok: true };
  },
};

/* ---------- Checkout (SIMULATED SERVER) ----------
   PRODUCTION_PAYMENT_FLOW (server-side, Mollie test mode first):
    1. Browser sends POST /api/checkout { items: [{productId, qty}], customer, delivery } + Idempotency-Key.
    2. Server loads the products from the database and validates active state, stock and quantities.
    3. Server calculates prices, discounts, shipping and VAT itself (client prices are never trusted).
    4. Server creates the order with immutable snapshots, status WACHT_OP_BETALING.
    5. Server creates a Mollie payment (amount from the order, redirectUrl + webhookUrl, metadata.orderId).
    6. Server returns the Mollie checkout URL; the browser redirects the customer to Mollie.
    7. Customer returns to /bestelling/:id — the page shows the status the SERVER reports.
    8. Mollie calls the webhook; the server fetches the payment from Mollie and updates the order.
    9. Only the webhook (server) marks an order as BETAALD. Live mode is switched on manually. */
function validateCheckout(form, method) {
  const e = {};
  if (!form.firstName || form.firstName.trim().length < 1) e.firstName = 'Vul uw voornaam in.';
  if (!form.lastName || form.lastName.trim().length < 1) e.lastName = 'Vul uw achternaam in.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email || '')) e.email = 'Vul een geldig e-mailadres in.';
  if (!/^(\+|0)[0-9\s-]{8,15}$/.test((form.phone || '').trim())) e.phone = 'Vul een geldig telefoonnummer in.';
  if (!method) e.delivery = 'Kies een leveringsmethode.';
  if (method && method.requiresAddress) {
    if (!form.street || !form.street.trim()) e.street = 'Vul uw straat in.';
    if (!form.houseNumber || !/^\d+\s?[a-zA-Z0-9-]{0,6}$/.test(form.houseNumber.trim())) e.houseNumber = 'Vul een geldig huisnummer in.';
    if (!/^\d{4}\s?[A-Za-z]{2}$/.test((form.postal || '').trim())) e.postal = 'Vul een geldige postcode in (1234 AB).';
    if (!form.city || !form.city.trim()) e.city = 'Vul uw woonplaats in.';
  }
  return e;
}
const CheckoutService = {
  key() {
    const fp = Cart.get().items.map((i) => `${i.productId}x${i.qty}`).sort().join('|');
    let k = Storage.get('checkoutKey', null, 'session');
    if (!k || k.fp !== fp) { k = { fp, key: uid('idem') }; Storage.set('checkoutKey', k, 'session'); }
    return k.key;
  },
  async placeOrder(form) {
    await sleep(650);
    const { notices } = Cart.validate();
    if (notices.length) return { ok: false, code: 'cart_changed', notices };
    const lines = Cart.lines();
    if (!lines.length) return { ok: false, code: 'empty' };
    const settings = Repo.settings();
    const method = settings.shipping.find((m) => m.id === form.delivery && m.enabled);
    const errors = validateCheckout(form, method);
    if (Object.keys(errors).length) return { ok: false, code: 'invalid', errors };
    const idem = this.key();
    const totals = computeTotals(lines, method.price);
    const items = lines.map((l) => ({
      productId: l.product.id, sku: l.product.sku, name: l.product.name,
      image: (l.product.images[0] || '').length < 4096 ? l.product.images[0] : `art:${(l.product.images.find((i) => i.startsWith('art:')) || 'art:box').split(':')[1] || 'box'}:0`,
      qty: l.qty, unitRegular: l.unitRegular, unitPrice: l.unitPrice,
      discountType: l.pricing.onSale ? l.product.discountType : 'none',
      discountLabel: l.pricing.onSale ? `−${l.pricing.pct}%` : '',
      lineRegular: l.lineRegular, lineTotal: l.lineTotal,
    }));
    const customer = {
      firstName: form.firstName.trim(), lastName: form.lastName.trim(), email: form.email.trim(), phone: form.phone.trim(),
      address: method.requiresAddress ? { street: form.street.trim(), houseNumber: form.houseNumber.trim(), postal: form.postal.trim().toUpperCase(), city: form.city.trim() } : null,
    };
    const v = VehicleStore.get();
    const existing = Repo.orders().find((o) => o.idempotencyKey === idem && o.orderStatus === 'WACHT_OP_BETALING');
    let order;
    if (existing) {
      order = { ...deepClone(existing), customer, delivery: { method: method.id, label: method.label, price: method.price }, items, ...totals, shipping: method.price, note: form.note || '' };
      order.history.push({ at: nowIso(), status: order.orderStatus, note: 'Dezelfde bestelling opnieuw bevestigd (dubbele bestelling voorkomen)' });
    } else {
      order = {
        id: uid('ord'), orderNumber: Repo.nextOrderNumber(), idempotencyKey: idem, isDemo: true, placedHere: true,
        customer, delivery: { method: method.id, label: method.label, price: method.price },
        vehicle: v ? { label: VehicleStore.name(v), year: v.year || null } : null,
        note: (form.note || '').trim(), items, ...totals, currency: 'EUR',
        paymentStatus: 'open', orderStatus: 'WACHT_OP_BETALING', paymentId: null, payments: [],
        history: [{ at: nowIso(), status: 'WACHT_OP_BETALING', note: 'Bestelling aangemaakt' }],
        stockApplied: false, createdAt: nowIso(),
      };
    }
    Repo.saveOrder(order);
    const open = (order.payments || []).find((p) => p.id === order.paymentId && p.status === 'open');
    const payment = open || await Payments.createPayment(order.id);
    return { ok: true, order: Repo.order(order.id), checkoutUrl: payment.checkoutUrl };
  },
  async retryPayment(orderId) {
    const order = Repo.order(orderId);
    if (!order) return { ok: false, message: 'Bestelling niet gevonden.' };
    if (!['BETALING_MISLUKT', 'GEANNULEERD', 'WACHT_OP_BETALING'].includes(order.orderStatus)) return { ok: false, message: 'Deze bestelling kan niet opnieuw worden betaald.' };
    for (const line of order.items) {
      const p = Repo.product(line.productId);
      if (!isPublicProduct(p) || Stock.max(p) < line.qty) return { ok: false, code: 'stock', message: `“${line.name}” is niet meer in de gevraagde hoeveelheid beschikbaar.` };
    }
    const payment = await Payments.createPayment(orderId);
    return { ok: true, checkoutUrl: payment.checkoutUrl };
  },
};

/* ---------- Payments: demo adapter (Mollie-ready interface) ----------
   This is NOT Mollie and processes no money. The production adapter calls the own backend,
   which talks to Mollie with the secret API key (never in the browser). */
const DemoPaymentAdapter = {
  id: 'demo', testMode: true, label: 'Demo-betaalomgeving (testmodus)',
  async createPayment(orderId) {
    await sleep(350);
    const o = deepClone(Repo.order(orderId));
    const id = `tr_test_${Math.random().toString(36).slice(2, 12)}`;
    const p = { id, status: 'open', amount: o.total, createdAt: nowIso(), updatedAt: nowIso(), checkoutUrl: `#/betaling/${o.id}` };
    o.payments = (o.payments || []).concat(p);
    o.paymentId = id;
    o.paymentStatus = 'open';
    if (o.orderStatus !== 'WACHT_OP_BETALING') {
      o.orderStatus = 'WACHT_OP_BETALING';
      o.history.push({ at: nowIso(), status: 'WACHT_OP_BETALING', note: 'Nieuwe betaalpoging gestart' });
    }
    Repo.saveOrder(o);
    return p;
  },
  async getPayment(paymentId) {
    for (const o of Repo.orders()) {
      const p = (o.payments || []).find((x) => x.id === paymentId);
      if (p) return { id: p.id, status: p.status, amount: p.amount };
    }
    return null;
  },
  /* Demo only: the tester chooses the outcome on the simulated payment page.
     That mimics the provider changing the status and then calling our webhook. */
  async simulate(orderId, status) {
    await sleep(500);
    const o = deepClone(Repo.order(orderId));
    const p = (o.payments || []).find((x) => x.id === o.paymentId);
    if (!p) return null;
    p.status = status; p.updatedAt = nowIso();
    Repo.saveOrder(o);
    return OrderService.onPaymentWebhook(p.id);
  },
};
const Payments = DemoPaymentAdapter;

/* ---------- Admin auth: DEMO ONLY ----------
   NOT SECURE: credentials are shown in the UI and checked in the browser.
   Production: server-side authentication (HttpOnly session cookie, hashed passwords,
   CSRF protection, rate limiting, 2FA) and server-side authorisation of every mutation. */
const DemoAuth = {
  USER: 'demo', PASS: 'cartronic-demo',
  session() { return Storage.get('adminSession', null, 'session'); },
  isAuthed() { return !!this.session(); },
  login(user, pass) {
    if (user.trim() === this.USER && pass === this.PASS) { Storage.set('adminSession', { user: this.USER, at: nowIso() }, 'session'); return true; }
    return false;
  },
  logout() { Storage.remove('adminSession', 'session'); },
};

/* ---------- Search ---------- */
const Search = {
  index: null,
  TYPE_LABEL: { CATEGORIE: 'Categorie', DIENST: 'Dienst', RETROFIT: 'Retrofit', MODEL: 'Model', PRODUCT: 'Product', PROJECT: 'Project', KENNIS: 'Kennis', PAGINA: 'Pagina' },
  TYPE_ORDER: ['CATEGORIE', 'DIENST', 'RETROFIT', 'MODEL', 'PRODUCT', 'PROJECT', 'KENNIS', 'PAGINA'],
  TYPE_BOOST: { CATEGORIE: 6, DIENST: 5, RETROFIT: 0, MODEL: 4, PRODUCT: 0, PROJECT: -2, KENNIS: -3, PAGINA: 2 },
  invalidate() { this.index = null; },
  build() {
    const docs = [];
    RETROFITS.forEach((r) => docs.push({
      type: 'RETROFIT', id: r.slug, title: r.title, sub: `${CATEGORY[r.cat].name} · ${retrofitModelsText(r)}`, href: `#/mogelijkheden/${r.slug}`,
      text: [r.name, r.short, (r.keywords || []).join(' '), r.models.map(modelLabel).join(' '), Compat.brandsOf(r).map((b) => BRAND[b].name).join(' ')].join(' '),
      catText: normText(CATEGORY[r.cat].name), catIdx: CATEGORIES.findIndex((c) => c.id === r.cat), models: r.models, brands: Compat.brandsOf(r), wide: r.scope === 'brand',
    }));
    SERVICES.forEach((s) => docs.push({ type: 'DIENST', id: s.slug, title: s.title, sub: s.short, href: `#/diensten/${s.slug}`, text: [s.short, s.keywords.join(' ')].join(' ') }));
    [
      ['beoordelingen', 'Beoordelingen', 'Ervaringen van klanten', '#/beoordelingen', 'beoordelingen reviews ervaringen klantenvertellen score klanten'],
      ['productinformatie', 'Productinformatie', 'Onderdelen, garantie, prijzen en compatibiliteit', '#/productinformatie', 'productinformatie garantie onderdelen origineel oem prijzen aanbiedingen compatibiliteit'],
      ['privacy', 'Privacy', 'Wat deze website in uw browser bewaart', '#/privacy', 'privacy gegevens kenteken opslag wissen cookies'],
      ['contact', 'Contact', `${COMPANY.street}, ${COMPANY.city} · ${COMPANY.phoneDisplay}`, '#/contact', 'contact adres telefoon whatsapp email openingstijden route afspraak'],
    ].forEach(([id, title, sub, href, text]) => docs.push({ type: 'PAGINA', id, title, sub, href, text }));
    ARTICLES.forEach((a) => docs.push({ type: 'KENNIS', id: a.slug, title: a.title, sub: a.short, href: `#/kennis/${a.slug}`, text: [a.tag, a.short, (a.keywords || []).join(' ')].join(' ') }));
    CATEGORIES.forEach((c) => docs.push({ type: 'CATEGORIE', id: c.id, title: c.name, sub: c.text, href: `#/mogelijkheden?cat=${c.id}`, text: c.text }));
    MODELS.forEach((m) => {
      const n = Compat.countForModel(m.id);
      docs.push({ type: 'MODEL', id: m.id, title: modelLabel(m.id), sub: `${modelYears(m)} · ${plural(n, 'mogelijkheid', 'mogelijkheden')}`, href: `#/mogelijkheden?merk=${m.brand}&model=${m.id}`, text: `${BRAND[m.brand].name} ${m.base}` });
    });
    Repo.projects().filter((p) => p.active).forEach((p) => docs.push({ type: 'PROJECT', id: p.slug, title: p.title, sub: p.vehicle, href: `#/projecten/${p.slug}`, text: [p.vehicle, p.short, p.tag].join(' '), models: p.models || [], brands: p.brands || [], wide: !(p.models || []).length }));
    (Content.shopOn() ? Repo.products().filter(isPublicProduct) : []).forEach((p) => docs.push({
      type: 'PRODUCT', id: p.id, title: p.name, sub: `${Money.fmt(Pricing.calc(p).price)} · ${(Repo.shopCategory(p.category) || {}).name || 'Webshop'}`, href: `#/webshop/${p.slug}`,
      text: [p.shortDescription, (Repo.shopCategory(p.category) || {}).name, p.sku, (p.compatibility.models || []).map(modelLabel).join(' ')].join(' '),
      models: p.compatibility.models || [], brands: p.compatibility.brands || [], wide: !(p.compatibility.models || []).length,
    }));
    docs.forEach((d) => { d.nTitle = normText(d.title); d.nText = normText(`${d.title} ${d.text}`); d.words = d.nText.split(' '); d.tWords = d.nTitle.split(' '); });
    // Per result type: its words and full text, to tell meaningful query words from filler.
    this.vocab = {};
    docs.forEach((d) => {
      const v = (this.vocab[d.type] = this.vocab[d.type] || { words: new Set(), text: '' });
      d.words.forEach((w) => v.words.add(w));
      if (d.catText) d.catText.split(' ').forEach((w) => v.words.add(w));
      v.text += ` ${d.nText}`;
    });
    this.index = docs;
  },
  /* Synonym phrases for a query. A multi-word query only expands through multi-word terms
     ("cruise control", "360 camera"); single words are expanded per word in score(). */
  expand(nq, { phrase = false } = {}) {
    const phrases = [];
    SYNONYMS.forEach((group) => {
      const g = group.map(normText);
      const hit = g.some((t) => nq === t || (nq.length >= 3 && t.startsWith(nq))
        || ((!phrase || t.includes(' ')) && (` ${nq} `).includes(` ${t} `)));
      if (hit) g.forEach((t) => { if (t !== nq) phrases.push(t); });
    });
    return uniq(phrases);
  },
  /* Finds brand/model mentions ("golf 7 camera", "a4 b9 carplay", "t6 camera") and returns
     the rest of the query, so the remaining words are matched against the option itself. */
  parseVehicle(nq) {
    const ALIAS = { enyak: 'enyaq' }; // CarTronic's own spelling on its product pages
    const BODY = new Set(['avant', 'sportback', 'limousine', 'sedan', 'variant', 'combi', 'kombi', 'coupe', 'cabrio', 'cabriolet', 'allspace', 'hatchback', 'sline', 'rline']);
    const words = nq.split(' ').map((w) => ALIAS[w] || w);
    const set = new Set(words);
    for (let i = 0; i < words.length - 1; i++) set.add(words[i] + words[i + 1]);
    const used = new Set();
    let brand = null;
    BRANDS.forEach((b) => [b.id, normText(b.name), ...(b.id === 'volkswagen' ? ['vw'] : [])].forEach((t) => { if (set.has(t)) { brand = b.id; used.add(t); } }));
    const hits = [];
    MODELS.forEach((m) => {
      if (brand && m.brand !== brand) return;
      const baseW = normText(m.base).split(' ');
      const baseC = baseW.join('');
      const codes = normText(m.name).split(' ').filter((w) => !baseW.includes(w));
      const codeHit = codes.filter((c) => set.has(c) || set.has(baseC + c));
      // Sport variants count as the model ("rs6", "sq8", "s3").
      const varHit = (m.match || []).map((t) => t.toLowerCase()).filter((t) => /\d/.test(t) && !baseW.includes(t) && set.has(t));
      const baseHit = baseW.every((w) => set.has(w)) || set.has(baseC) || codes.some((c) => set.has(baseC + c)) || varHit.length > 0;
      // A distinctive generation code on its own also counts ("t6", "b8", "8v").
      if (!baseHit && !codeHit.some((c) => c.length > 1 && /\d/.test(c) && /[a-z]/.test(c))) return;
      hits.push({ m, baseW, baseC, codes, codeHit, baseHit, varHit });
    });
    if (!hits.length) return { brand, models: null, rest: words.filter((w) => !used.has(w)).join(' ') };
    let pick = hits.filter((h) => h.codeHit.length);
    if (!pick.length) pick = hits;
    // A year narrows the generation ("golf 2018 camera" → Golf 7).
    const yw = words.find((w) => /^(19|20)\d\d$/.test(w));
    if (yw) {
      used.add(yw);
      const inYear = pick.filter((h) => +yw >= h.m.from && +yw <= (h.m.to || 9999));
      if (inYear.length) pick = inYear;
    }
    const longest = Math.max(...pick.map((h) => (h.baseHit ? h.baseW.length : 0)));
    pick = pick.filter((h) => (h.baseHit ? h.baseW.length : 0) === longest);
    pick.forEach((h) => { if (h.baseHit) { h.baseW.forEach((w) => used.add(w)); used.add(h.baseC); h.varHit.forEach((t) => used.add(t)); } h.codeHit.forEach((c) => { used.add(c); used.add(h.baseC + c); }); });
    // Body styles ("avant", "sportback") describe the car, not the option.
    BODY.forEach((w) => used.add(w));
    const rest = words.filter((w, i) => !used.has(w) && !(i < words.length - 1 && used.has(w + words[i + 1])) && !(i > 0 && used.has(words[i - 1] + w))).join(' ');
    return { brand: brand || pick[0].m.brand, models: pick.map((h) => h.m.id), rest };
  },
  /* Text relevance of one document. Multi-word queries need every word to match (directly, via a
     synonym or via the category name), unless the whole phrase matched. Words that occur nowhere in
     the index ("inbouwen", "gti", a year) are ignored. Returns { score, viaCat }. */
  score(d, nq, ctx) {
    let score = 0;
    if (d.nTitle === nq) score += 100;
    if (d.nTitle.startsWith(nq)) score += 40;
    if (d.nTitle.includes(nq)) score += 30; else if ((` ${d.nText}`).includes(` ${nq}`)) score += 16;
    let syn = 0;
    ctx.phraseSyn.forEach((ph) => { syn = Math.max(syn, d.nTitle.includes(ph) ? 14 : (d.nText.includes(ph) ? 9 : 0)); });
    score += syn;
    const { tokens, tokenSyn } = ctx.forType(d.type);
    let viaCat = false;
    const every = tokens.length > 0 && tokens.every((t, i) => {
      if (d.words.some((w) => w.startsWith(t)) || tokenSyn[i].some((ph) => d.nText.includes(ph))) return true;
      if (d.catText && d.catText.split(' ').some((w) => w.startsWith(t))) { viaCat = true; return true; }
      return false;
    });
    if (every) {
      score += viaCat ? 8 : (tokens.length > 1 ? 22 : 12);
      // Words found in the title count more than words found only in the description
      // ("spiegels inklapbaar": the mirror options before a blind-spot system with LEDs in the mirrors).
      score += 5 * tokens.filter((t) => d.tWords.some((w) => w.startsWith(t))).length;
    } else if (tokens.length > 1 && score < 30 && !syn) score = 0;
    return { score, viaCat: every && viaCat && score < 30 };
  },
  /* Query words that mean something for a result type; the rest ("inbouwen", "gti", a year) is
     ignored for that type instead of excluding every result. */
  context(nq) {
    const all = nq.split(' ').filter((t) => t.length > 1);
    const syn = new Map(all.map((t) => [t, this.expand(t)]));
    const cache = {};
    return {
      all,
      phraseSyn: this.expand(nq, { phrase: all.length > 1 }),
      forType: (type) => {
        if (!cache[type]) {
          const v = this.vocab[type] || { words: new Set(), text: '' };
          const words = [...v.words];
          const isKnown = (t) => words.some((w) => w.startsWith(t)) || syn.get(t).some((ph) => v.text.includes(ph));
          // Dutch adjective forms: "inklapbaar" also finds "inklapbare", "afneembaar" "afneembare".
          const stem = (t) => (/baar$/.test(t) ? t.slice(0, -2) : t);
          const known = [];
          all.forEach((t) => {
            if (isKnown(t)) known.push(t);
            else if (stem(t) !== t && words.some((w) => w.startsWith(stem(t)))) { known.push(stem(t)); if (!syn.has(stem(t))) syn.set(stem(t), []); }
          });
          cache[type] = { tokens: known, tokenSyn: known.map((t) => syn.get(t)) };
        }
        return cache[type];
      },
    };
  },
  query(q, { limit = 8, types = null, perType = 3 } = {}) {
    if (!this.index) this.build();
    const nq = normText(q);
    if (nq.length < 2) return [];
    const pv = this.parseVehicle(nq);
    const scoped = !!(pv.models || pv.brand);
    let rq = scoped ? pv.rest : nq;
    if (rq && !rq.split(' ').some((t) => t.length > 1)) rq = ''; // "golf 7.5", "t6.1": only a facelift suffix left
    const sc = this.context(rq);
    const modelSet = pv.models ? new Set(pv.models) : null;
    const v = VehicleStore.get();
    const out = [];
    this.index.forEach((d) => {
      if (types && !types.includes(d.type)) return;
      let score = 0; let viaCat = false;
      const run = (txt) => { const r = this.score(d, txt, sc); viaCat = r.viaCat; return r.score; };
      if (!scoped) score = run(nq);
      else if (d.type === 'MODEL') {
        if (modelSet) { if (!modelSet.has(d.id)) return; score = 60 + (rq ? 0 : 40); } else { if (rq || MODEL[d.id].brand !== pv.brand) return; score = 40; }
      } else if (d.models) {
        const inModel = modelSet ? d.models.some((m) => modelSet.has(m)) : false;
        const inBrand = !(d.brands || []).length || d.brands.includes(pv.brand);
        if (modelSet && !inModel && !(d.wide && inBrand)) return;
        if (!modelSet && !inBrand) return;
        score = rq ? run(rq) : 20;
        if (!score) return;
        score += inModel ? 30 : (modelSet ? -10 : 10);
      } else {
        if (!rq) return;
        score = run(rq);
        if (d.type === 'KENNIS' && score > 0) score = Math.max(1, score - 15); // vehicle queries: the options first
      }
      if (score <= 0) return;
      if (v && d.models && d.models.includes(v.modelId)) score += 15;
      out.push({ ...d, viaCat, score: score + (this.TYPE_BOOST[d.type] || 0) });
    });
    // Options that only match through their category name give way when others match directly.
    const direct = out.some((o) => o.type === 'RETROFIT' && !o.viaCat);
    if (direct) for (let i = out.length - 1; i >= 0; i--) if (out[i].viaCat) out.splice(i, 1);
    out.sort((a, b) => b.score - a.score || ((a.catIdx ?? 99) - (b.catIdx ?? 99)) || a.title.localeCompare(b.title, 'nl'));
    if (!perType) return out.slice(0, limit);
    const counts = {};
    return out.filter((r) => { counts[r.type] = (counts[r.type] || 0) + 1; return counts[r.type] <= perType; }).slice(0, limit);
  },
  highlight(title, q) {
    const t = esc(title);
    const needle = String(q || '').trim();
    if (needle.length < 2) return t;
    const i = title.toLowerCase().indexOf(needle.toLowerCase());
    if (i < 0) return t;
    return `${esc(title.slice(0, i))}<mark>${esc(title.slice(i, i + needle.length))}</mark>${esc(title.slice(i + needle.length))}`;
  },
};
