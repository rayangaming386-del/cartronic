/* =====================================================================
   ADMIN — CATALOG CONTENT (opties, categorieën & merken, diensten, kennis, beoordelingen, meer werk)
   Built-in options are never changed in place: Beheer stores only the fields that differ, so
   "Standaard herstellen" always works. New options, services and articles are stored in full.
   ===================================================================== */

/* ---------- Options (retrofit catalog) ---------- */
/* "nieuw" is the address of the form for a new item (…/nieuw), so it cannot be used as a slug. */
const RESERVED_SLUG = 'Het webadres “nieuw” is gereserveerd voor het formulier “nieuw”. Kies een ander.';
const RETROFIT_FIELDS = ['title', 'name', 'cat', 'brand', 'models', 'scope', 'brands', 'years', 'short', 'variantNote', 'specs', 'warranty', 'price', 'offer', 'keywords', 'image', 'imageNote'];
/** Compares option field values, treating "", null, [] and a missing value as the same. */
const fieldValue = (k, v) => {
  if (v == null || v === '' || (Array.isArray(v) && !v.length)) return null;
  if (k === 'scope' && v === 'model') return null;
  return v;
};
const sortedList = (v) => (Array.isArray(v) ? v.slice().sort() : v);
/** a = the form value, b = the built-in value of option `orig`. Model and brand lists compare as sets. */
function sameField(k, a, b, orig) {
  if (k === 'models') return stableStringify(fieldValue(k, sortedList(a))) === stableStringify(fieldValue(k, sortedList(b)));
  if (k === 'brands') {
    const eff = orig.scope === 'brand' ? (orig.brands || [orig.brand]).filter(Boolean) : [];
    return stableStringify(fieldValue(k, sortedList(a))) === stableStringify(fieldValue(k, sortedList(eff)));
  }
  return stableStringify(fieldValue(k, a)) === stableStringify(fieldValue(k, b));
}
function retrofitBundle() {
  const b = Content.working();
  const rb = b.retrofits && typeof b.retrofits === 'object' && !Array.isArray(b.retrofits) ? b.retrofits : {};
  return { hide: new Set(Array.isArray(rb.hide) ? rb.hide : []), edit: rb.edit && typeof rb.edit === 'object' ? rb.edit : {}, add: Array.isArray(rb.add) ? rb.add : [] };
}
/** Every option as Beheer sees it: built-in (possibly edited or hidden) and added ones. */
function adminRetrofits() {
  const rb = retrofitBundle();
  const out = Content.P.retrofits.map((orig) => {
    const item = RETROFIT[orig.slug] || Object.assign(deepClone(orig), Content.cleanRetrofitFields(rb.edit[orig.slug] || {}));
    return { item, hidden: rb.hide.has(orig.slug), edited: !!rb.edit[orig.slug], added: false };
  });
  rb.add.forEach((a) => {
    const item = (a && RETROFIT[a.slug]) || Content.buildAdded(a);
    if (item) out.push({ item, hidden: rb.hide.has(item.slug), edited: false, added: true });
  });
  return out;
}
function allOptionSlugs() {
  const rb = retrofitBundle();
  return new Set([...Content.P.retrofits.map((r) => r.slug), ...rb.add.map((a) => a && a.slug).filter(Boolean), ...Object.keys(Content.P.aliases)]);
}
const optionModelsText = (r) => (r.scope === 'brand' ? (r.brands || [r.brand]).filter((b) => BRAND[b]).map((b) => BRAND[b].name).join(', ') : r.models.filter((m) => MODEL[m]).map((m) => MODEL[m].name).join(', '));

Pages.adminOptions = adminPage({
  key: 'opties', title: 'Opties',
  actions: () => `<a class="btn btn--primary btn--sm" href="#/admin/opties/nieuw">${icon('plus')}<span class="hide-sm">Nieuwe optie</span></a>`,
  render(ctx) {
    const q = ctx.query;
    return `<div class="toolbar">
        <div class="input-icon">${icon('search')}<input class="input input--sm" type="search" data-oq placeholder="Zoek op titel, model of zoekwoord" aria-label="Zoek opties" value="${attr(q.q || '')}"></div>
        <select class="select select--sm" data-ob style="width:auto" aria-label="Merk"><option value="">Alle merken</option>${BRANDS.map((b) => `<option value="${b.id}"${q.merk === b.id ? ' selected' : ''}>${esc(b.name)}</option>`).join('')}</select>
        <select class="select select--sm" data-om style="width:auto" aria-label="Model"><option value="">Alle modellen</option>${MODELS.filter((m) => !q.merk || m.brand === q.merk).map((m) => `<option value="${m.id}"${q.model === m.id ? ' selected' : ''}>${esc(modelLabel(m.id))}</option>`).join('')}</select>
        <select class="select select--sm" data-oc style="width:auto" aria-label="Categorie"><option value="">Alle categorieën</option>${CATEGORIES.map((c) => `<option value="${c.id}"${q.cat === c.id ? ' selected' : ''}>${esc(c.name)}</option>`).join('')}</select>
        <select class="select select--sm" data-os style="width:auto" aria-label="Status">${[['', 'Alle statussen'], ['zichtbaar', 'Zichtbaar'], ['verborgen', 'Verborgen'], ['gewijzigd', 'Gewijzigd'], ['nieuw', 'Nieuw toegevoegd'], ['prijs', 'Met prijs of aanbieding']].map(([k, l]) => `<option value="${k}"${(q.status || '') === k ? ' selected' : ''}>${l}</option>`).join('')}</select>
      </div>
      <div data-osum class="flex wrap gap-8"></div>
      <section class="panel"><div class="panel-body panel-body--flush" data-olist></div></section>
      <p class="hint">Verborgen opties staan niet meer op de website en niet in de zoekresultaten. Bij gewijzigde opties kunt u altijd terug naar de standaardtekst.</p>`;
  },
  mount(root, ctx) {
    const st = { q: ctx.query.q || '', merk: ctx.query.merk || '', model: ctx.query.model || '', cat: ctx.query.cat || '', status: ctx.query.status || '', page: Math.max(0, (parseInt(ctx.query.p, 10) || 1) - 1) };
    const PER = 30;
    const list = $('[data-olist]', root);
    const draw = () => {
      const all = adminRetrofits();
      $('[data-osum]', root).innerHTML = `<span class="pill">${all.length} opties</span><span class="pill pill--ok">${all.filter((x) => !x.hidden).length} zichtbaar</span>${all.some((x) => x.hidden) ? `<span class="pill">${all.filter((x) => x.hidden).length} verborgen</span>` : ''}${all.some((x) => x.edited) ? `<span class="pill pill--info">${all.filter((x) => x.edited).length} gewijzigd</span>` : ''}${all.some((x) => x.added) ? `<span class="pill pill--dark">${all.filter((x) => x.added).length} nieuw</span>` : ''}`;
      const term = normText(st.q);
      const items = all.filter(({ item: r, hidden, edited, added }) => {
        if (st.merk && !(r.scope === 'brand' ? (r.brands || [r.brand]) : [r.brand]).includes(st.merk)) return false;
        if (st.model && !r.models.includes(st.model)) return false;
        if (st.cat && r.cat !== st.cat) return false;
        if (st.status === 'zichtbaar' && hidden) return false;
        if (st.status === 'verborgen' && !hidden) return false;
        if (st.status === 'gewijzigd' && !edited) return false;
        if (st.status === 'nieuw' && !added) return false;
        if (st.status === 'prijs' && !(r.price || r.offer)) return false;
        if (term && !normText(`${r.title} ${r.slug} ${r.name} ${optionModelsText(r)} ${(r.keywords || []).join(' ')}`).includes(term)) return false;
        return true;
      });
      const pages = Math.max(1, Math.ceil(items.length / PER));
      st.page = Math.min(st.page, pages - 1);
      if (!items.length) { list.innerHTML = `<div class="panel-body">${UI.empty({ icon: 'search', title: 'Geen opties gevonden', text: 'Pas de filters aan of voeg een nieuwe optie toe.', actions: '<a class="btn btn--primary btn--sm" href="#/admin/opties/nieuw">Nieuwe optie</a>' })}</div>`; return; }
      list.innerHTML = `<div class="table-wrap rtable"><table class="table admin-table"><thead><tr><th>Optie</th><th>Categorie</th><th>Modellen</th><th>Status</th><th class="num"><span class="sr-only">Acties</span></th></tr></thead><tbody>
        ${items.slice(st.page * PER, st.page * PER + PER).map(({ item: r, hidden, edited, added }) => `<tr class="${hidden ? 'is-archived' : ''}">
          <td class="cell-main" data-label="Optie"><div class="prod"><div class="thumb">${Media.html(retrofitImage(r), '', { kind: r.art })}</div><div><a class="p-name text-link" href="#/admin/opties/${attr(r.slug)}">${esc(r.title)}</a><div class="p-sub">${esc(r.slug)}</div></div></div></td>
          <td data-label="Categorie">${esc((CATEGORY[r.cat] || {}).name || '—')}</td>
          <td data-label="Modellen" class="text-small">${esc(optionModelsText(r))}${r.years ? ` <span class="text-muted">· ${r.years[0]}–${r.years[1]}</span>` : ''}</td>
          <td data-label="Status">${hidden ? '<span class="pill">Verborgen</span>' : '<span class="pill pill--ok">Zichtbaar</span>'} ${edited ? '<span class="pill pill--info">Gewijzigd</span>' : ''}${added ? '<span class="pill pill--dark">Nieuw</span>' : ''}${r.price || r.offer ? ' <span class="pill pill--outline">Prijs</span>' : ''}</td>
          <td class="num cell-actions"><div class="row-actions">
            <a class="icon-btn icon-btn--sm" href="#/admin/opties/${attr(r.slug)}" title="Bewerken" aria-label="Bewerken: ${attr(r.title)}">${icon('pencil')}</a>
            ${hidden ? '' : `<a class="icon-btn icon-btn--sm" href="#/mogelijkheden/${attr(r.slug)}" target="_blank" rel="noopener" title="Bekijk op de website" aria-label="Bekijk op de website: ${attr(r.title)}">${icon('external')}</a>`}
            <a class="icon-btn icon-btn--sm" href="#/admin/opties/nieuw?van=${attr(r.slug)}" title="Dupliceren" aria-label="Dupliceren: ${attr(r.title)}">${icon('copy')}</a>
            <button class="icon-btn icon-btn--sm" type="button" data-otoggle="${attr(r.slug)}" title="${hidden ? 'Weer tonen' : 'Verbergen'}" aria-label="${hidden ? 'Weer tonen' : 'Verbergen'}: ${attr(r.title)}">${icon(hidden ? 'eye' : 'eyeOff')}</button>
          </div></td></tr>`).join('')}
        </tbody></table></div>
        ${pages > 1 ? `<div class="pager"><button class="btn btn--light btn--sm" type="button" data-pg="-1"${st.page ? '' : ' disabled'}>${icon('left')} Vorige</button><span class="text-small text-muted">Pagina ${st.page + 1} van ${pages} · ${items.length} opties</span><button class="btn btn--light btn--sm" type="button" data-pg="1"${st.page < pages - 1 ? '' : ' disabled'}>Volgende ${icon('right')}</button></div>` : ''}`;
    };
    const sync = () => Router.setQuery({ q: st.q, merk: st.merk, model: st.model, cat: st.cat, status: st.status, p: st.page ? st.page + 1 : '' });
    const on = (sel, key, evt = 'change') => $(sel, root).addEventListener(evt, (e) => {
      st[key] = e.target.value.trim(); st.page = 0;
      if (key === 'merk') {
        st.model = '';
        $('[data-om]', root).innerHTML = `<option value="">Alle modellen</option>${MODELS.filter((m) => !st.merk || m.brand === st.merk).map((m) => `<option value="${m.id}">${esc(modelLabel(m.id))}</option>`).join('')}`;
      }
      sync(); draw();
    });
    on('[data-ob]', 'merk'); on('[data-om]', 'model'); on('[data-oc]', 'cat'); on('[data-os]', 'status');
    $('[data-oq]', root).addEventListener('input', debounce((e) => { st.q = e.target.value.trim(); st.page = 0; sync(); draw(); }, 200));
    list.addEventListener('click', (e) => {
      const pg = e.target.closest('[data-pg]');
      if (pg) { st.page += Number(pg.dataset.pg); sync(); draw(); list.scrollIntoView({ block: 'start' }); return; }
      const t = e.target.closest('[data-otoggle]');
      if (!t) return;
      const slug = t.dataset.otoggle;
      const hiddenNow = retrofitBundle().hide.has(slug);
      if (saveContent((d) => {
        d.retrofits = d.retrofits && typeof d.retrofits === 'object' ? d.retrofits : {};
        const hide = new Set(Array.isArray(d.retrofits.hide) ? d.retrofits.hide : []);
        if (hiddenNow) hide.delete(slug); else hide.add(slug);
        d.retrofits.hide = [...hide];
      }, hiddenNow ? 'De optie staat weer op de website.' : 'De optie is verborgen.')) draw();
    });
    draw();
  },
});

Pages.adminOptionForm = adminPage({
  key: 'opties', title: 'Optie',
  heading: (ctx) => (ctx.params.slug ? 'Optie bewerken' : 'Nieuwe optie'),
  find(ctx) {
    const list = adminRetrofits();
    if (ctx.params.slug) return list.find((x) => x.item.slug === ctx.params.slug) || null;
    const src = ctx.query.van ? list.find((x) => x.item.slug === ctx.query.van) : null;
    const base = src ? deepClone(src.item) : { slug: '', title: '', name: '', cat: CATEGORIES[0].id, brand: BRANDS[0].id, models: [], short: '', variantNote: '', specs: [], keywords: [], image: '' };
    base.slug = ''; delete base.aliases; delete base.feature;
    if (src) { base.title = `${base.title} (kopie)`; }
    return { item: base, hidden: false, edited: false, added: true, isNew: true };
  },
  render(ctx) {
    const entry = this.find(ctx);
    if (!entry) return UI.empty({ icon: 'layers', title: 'Optie niet gevonden', actions: '<a class="btn btn--dark btn--sm" href="#/admin/opties">Alle opties</a>' });
    const r = entry.item;
    const isNew = !!entry.isNew;
    const scope = r.scope === 'brand' ? 'brand' : 'model';
    const brands = r.scope === 'brand' ? (r.brands || [r.brand]).filter(Boolean) : [];
    const path = `/mogelijkheden/${r.slug}`;
    const seo = (!isNew && Content.seo().pages[path]) || {};
    const orig = !isNew && !entry.added ? Content.PR[r.slug] : null;
    return `<p><a class="link link--ink" href="#/admin/opties">${icon('arrowLeft')} Alle opties</a></p>
      <form data-opt-form novalidate data-new="${isNew}" data-slug="${attr(r.slug)}"><div class="form-layout">
        <div class="form-col">
          <section class="panel"><div class="panel-head"><div><h2>Inhoud</h2><p>Wat bezoekers op de optiepagina en in de catalogus zien</p></div>${entry.edited ? `<button class="btn btn--ghost btn--sm" type="button" data-opt-revert>${icon('refresh')} Standaard herstellen</button>` : ''}</div><div class="panel-body"><div class="form-grid">
            ${saField({ name: 'title', label: 'Titel', value: r.title, max: 200, hint: 'Bijvoorbeeld “Volkswagen Golf 8 – App Connect”.' })}
            ${saField({ name: 'name', label: 'Korte naam', value: r.name, max: 120, half: true, hint: 'Voor kruimelpad en lijsten, bijvoorbeeld “App Connect”.' })}
            ${isNew ? saField({ name: 'slug', label: 'Webadres (slug)', value: '', max: 120, half: true, placeholder: 'wordt gemaakt van de titel', hint: '/mogelijkheden/<strong>…</strong> — kan later niet worden gewijzigd.' }) : `<div class="field"><span class="label">Webadres</span><p class="text-small" style="word-break:break-all;padding-top:6px">${esc(path)}</p></div>`}
            ${saField({ name: 'short', label: 'Omschrijving', value: r.short, multi: true, rows: 4, max: 1200, hint: 'Staat bovenaan de optiepagina en wordt gebruikt voor Google.' })}
            ${saField({ name: 'variantNote', label: 'Afhankelijk van uitvoering', value: r.variantNote || '', multi: true, rows: 3, max: 1200, opt: true, hint: 'Laat leeg als de optie zonder voorbehoud bij het model past.' })}
            ${saField({ name: 'specs', label: 'Specificaties', value: (r.specs || []).map(([k, v]) => `${k}: ${v}`).join('\n'), multi: true, rows: 4, opt: true, hint: 'Eén per regel: <code class="code">Naam: waarde</code>. Model, categorie, garantie en prijs worden automatisch toegevoegd.' })}
            ${saField({ name: 'keywords', label: 'Zoekwoorden', value: (r.keywords || []).join(', '), opt: true, hint: 'Gescheiden door komma’s; helpt de zoekfunctie.' })}
          </div></div></section>
          <section class="panel"><div class="panel-head"><div><h2>Geldig voor</h2><p>Bepaalt bij welke auto’s de optie verschijnt</p></div></div><div class="panel-body"><div class="form-grid">
            <div class="field span-2"><span class="label">Soort</span><div class="radio-row">
              <label class="radio-tile"><input type="radio" name="scope" value="model"${scope === 'model' ? ' checked' : ''}><span>Specifieke modellen</span></label>
              <label class="radio-tile"><input type="radio" name="scope" value="brand"${scope === 'brand' ? ' checked' : ''}><span>Meerdere modellen van een merk</span></label>
            </div></div>
            <div class="field" data-scope-model><label for="op-brand">Merk</label><select class="select" id="op-brand" name="brand">${BRANDS.map((b) => `<option value="${b.id}"${r.brand === b.id ? ' selected' : ''}>${esc(b.name)}</option>`).join('')}</select></div>
            <div class="field span-2" data-scope-model><span class="label">Modellen</span><div class="model-checks" data-model-checks>${BRANDS.map((b) => `<div class="mc-brand" data-mb="${b.id}">${esc(b.name)}</div>${MODELS.filter((m) => m.brand === b.id).map((m) => `<label class="check" data-mb="${b.id}"><input type="checkbox" name="models" value="${m.id}"${r.models.includes(m.id) ? ' checked' : ''}><span class="box">${icon('check')}</span>${esc(m.name)} <span class="text-muted text-small">${modelYears(m)}</span></label>`).join('')}`).join('')}</div><span class="field-error" data-err="models"></span></div>
            <div class="field span-2" data-scope-brand><span class="label">Merken</span><div class="flex wrap gap-16">${BRANDS.map((b) => `<label class="check"><input type="checkbox" name="brands" value="${b.id}"${brands.includes(b.id) ? ' checked' : ''}><span class="box">${icon('check')}</span>${esc(b.name)}</label>`).join('')}</div><span class="hint">De optie krijgt de status “Controle vereist” bij elke auto van deze merken.</span><span class="field-error" data-err="brands"></span></div>
            ${saField({ name: 'yearFrom', label: 'Bouwjaar vanaf', value: r.years ? r.years[0] : '', type: 'number', half: true, opt: true, attrs: ' min="1950" max="2100" inputmode="numeric"' })}
            ${saField({ name: 'yearTo', label: 'Bouwjaar tot en met', value: r.years ? r.years[1] : '', type: 'number', half: true, opt: true, attrs: ' min="1950" max="2100" inputmode="numeric"' })}
            ${r.yearsByModel ? '<p class="hint span-2">Deze optie heeft bouwjaren per model. Als u hier bouwjaren invult, gelden die voor alle modellen.</p>' : ''}
            ${r.body && (isNew || entry.added) ? `<div class="span-2" data-scope-model>${saSwitch('keepBody', `Alleen voor carrosserie: ${r.body}`, true, 'Uit = de optie geldt voor elke carrosserie van de gekozen modellen.')}</div>` : ''}
            ${r.body && !isNew && !entry.added ? `<p class="hint span-2">Deze optie geldt alleen voor carrosserie: ${esc(r.body)}.</p>` : ''}
          </div></div></section>
          <section class="panel"><div class="panel-head"><div><h2>Garantie en prijs</h2><p>Vul alleen prijzen en aanbiedingen in die CarTronic zelf publiceert</p></div></div><div class="panel-body"><div class="form-grid">
            ${saField({ name: 'warranty', label: 'Garantie', value: r.warranty || '', max: 60, half: true, opt: true, placeholder: '3 jaar' })}
            ${saField({ name: 'price', label: 'Prijs', value: r.price || '', max: 120, half: true, opt: true, placeholder: '€ 1.099 excl. btw', hint: 'Leeg = “Op aanvraag”.' })}
            ${saField({ name: 'offer', label: 'Aanbieding', value: r.offer || '', max: 200, opt: true, placeholder: 'Vanaf € 199 inclusief montage' })}
          </div></div></section>
        </div>
        <div class="form-col">
          <section class="panel"><div class="panel-head"><div><h2>Publicatie</h2></div></div><div class="panel-body" style="display:grid;gap:16px">
            ${saSwitch('visible', 'Zichtbaar op de website', !entry.hidden)}
            <div class="field"><label for="op-cat">Categorie</label><select class="select" id="op-cat" name="cat">${CATEGORIES.map((c) => `<option value="${c.id}"${r.cat === c.id ? ' selected' : ''}>${esc(c.name)}</option>`).join('')}</select></div>
            ${!isNew && !entry.hidden ? `<a class="btn btn--light btn--sm" href="#${attr(path)}" target="_blank" rel="noopener">${icon('external')} Bekijk op de website</a>` : ''}
            ${orig && entry.edited ? '<p class="hint">Deze optie is aangepast ten opzichte van de standaardcatalogus.</p>' : ''}
          </div></section>
          <section class="panel"><div class="panel-head"><div><h2>Foto</h2></div></div><div class="panel-body"><div class="form-grid">
            ${imagePicker('image', r.image || '', { label: 'Foto', kind: r.art || (CATEGORY[r.cat] || {}).art || 'camera', hint: 'Zonder foto toont de website een passende illustratie.' })}
            ${saField({ name: 'imageNote', label: 'Bijschrift bij de foto', value: r.imageNote || '', max: 200, opt: true, hint: 'Bijvoorbeeld “Foto: vergelijkbaar model”.' })}
          </div></div></section>
          <section class="panel"><div class="panel-head"><div><h2>Google</h2><p>Leeg = automatisch uit titel en omschrijving</p></div></div><div class="panel-body"><div class="form-grid">
            ${saField({ name: 'seoTitle', label: 'Titel in Google', value: seo.title || '', max: 120, opt: true })}
            ${saField({ name: 'seoDescription', label: 'Omschrijving in Google', value: seo.description || '', multi: true, rows: 3, max: 300, opt: true })}
            ${saSwitch('seoNoindex', 'Niet laten indexeren', !!seo.noindex)}
          </div></div></section>
          <section class="panel"><div class="panel-head"><div><h2>Voorbeeld</h2></div></div><div class="panel-body"><div data-opt-preview class="opt-preview" inert></div></div></section>
          ${entry.added && !isNew ? `<section class="panel"><div class="panel-body"><button class="btn btn--ghost btn--sm" type="button" data-opt-delete style="color:var(--red)">${icon('trash')} Optie verwijderen</button><p class="hint mt-8">Alleen opties die u zelf heeft toegevoegd, kunt u verwijderen. Standaardopties kunt u verbergen.</p></div></section>` : ''}
        </div>
      </div>${saveBar(isNew ? 'Optie toevoegen' : 'Opslaan')}</form>`;
  },
  mount(root, ctx) {
    const f = $('[data-opt-form]', root); if (!f) return null;
    const isNew = f.dataset.new === 'true';
    const entry = this.find(ctx);
    const st = trackDirty(f);
    mountPickers(f);
    const scopeSync = () => {
      const scope = (f.querySelector('[name="scope"]:checked') || {}).value || 'model';
      $$('[data-scope-model]', f).forEach((el) => { el.hidden = scope !== 'model'; });
      $$('[data-scope-brand]', f).forEach((el) => { el.hidden = scope !== 'brand'; });
      const b = f.elements.brand.value;
      $$('[data-mb]', f).forEach((el) => { el.hidden = el.dataset.mb !== b; });
    };
    f.addEventListener('change', (e) => {
      if (e.target.name === 'brand') $$('input[name="models"]', f).forEach((c) => { if (MODEL[c.value].brand !== f.elements.brand.value) c.checked = false; });
      if (e.target.name === 'scope' || e.target.name === 'brand') scopeSync();
    });
    scopeSync();
    if (isNew) f.elements.title.addEventListener('input', () => { if (!f.elements.slug.dataset.touched) f.elements.slug.value = slugify(f.elements.title.value); });
    if (isNew) f.elements.slug.addEventListener('input', () => { f.elements.slug.dataset.touched = '1'; });
    const read = () => {
      const v = (k) => f.elements[k].value.trim();
      const scope = (f.querySelector('[name="scope"]:checked') || {}).value || 'model';
      const brandsSel = $$('input[name="brands"]:checked', f).map((x) => x.value);
      const yf = v('yearFrom'); const yt = v('yearTo');
      const specs = lines(f.elements.specs.value).map((l) => { const i = l.indexOf(':'); return i > 0 ? [l.slice(0, i).trim(), l.slice(i + 1).trim()] : [l, '']; });
      return {
        title: v('title'), name: v('name'), cat: f.elements.cat.value, scope,
        brand: scope === 'brand' ? (brandsSel.length === 1 ? brandsSel[0] : null) : f.elements.brand.value,
        brands: scope === 'brand' ? brandsSel : [],
        models: scope === 'brand' ? [] : $$('input[name="models"]:checked', f).map((x) => x.value).filter((m) => MODEL[m] && MODEL[m].brand === f.elements.brand.value),
        years: yf || yt ? [Number(yf), Number(yt)] : null,
        short: v('short'), variantNote: v('variantNote'), specs, warranty: v('warranty'), price: v('price'), offer: v('offer'),
        keywords: csv(f.elements.keywords.value), image: f.elements.image.value.trim(), imageNote: v('imageNote'),
      };
    };
    const validate = (r) => {
      const e = {};
      if (!r.title) e.title = 'Vul een titel in.';
      if (!r.name) e.name = 'Vul een korte naam in.';
      if (!r.short) e.short = 'Vul een omschrijving in.';
      if (r.scope === 'model' && !r.models.length) e.models = 'Kies ten minste één model.';
      if (r.scope === 'brand' && !r.brands.length) e.brands = 'Kies ten minste één merk.';
      if (r.years) {
        const [a, b] = r.years;
        if (!Number.isInteger(a) || !Number.isInteger(b) || a < 1950 || b > 2100) e.yearFrom = 'Vul beide bouwjaren in (bijv. 2015 en 2020), of laat beide leeg.';
        else if (a > b) e.yearTo = 'Het eindjaar ligt vóór het beginjaar.';
      }
      if (r.specs.some(([k, val]) => !k || !val)) e.specs = 'Schrijf elke specificatie als “Naam: waarde”.';
      else if (r.specs.length > 20) e.specs = 'Gebruik maximaal 20 specificaties.';
      else if (r.specs.some(([k, val]) => k.length > 60 || val.length > 300)) e.specs = 'Per specificatie maximaal 60 tekens voor de naam en 300 voor de waarde.';
      const kw = listLimit(r.keywords, 40, 60, 'zoekwoorden'); if (kw) e.keywords = kw;
      if (r.image && !Content.isImageRef(r.image)) e.image = 'De foto is ongeldig.';
      if (isNew) {
        const slug = f.elements.slug.value.trim() || slugify(r.title);
        if (!Content.isSlug(slug)) e.slug = 'Gebruik kleine letters, cijfers en koppeltekens.';
        else if (slug === 'nieuw') e.slug = RESERVED_SLUG;
        else if (allOptionSlugs().has(slug)) e.slug = 'Dit webadres bestaat al. Kies een ander.';
      }
      return e;
    };
    const preview = () => {
      const r = read();
      const card = { ...(entry.item || {}), ...r, slug: entry.item.slug || 'voorbeeld', art: (entry.item && entry.item.art) || (CATEGORY[r.cat] || {}).art || 'camera', aliases: [] };
      const ok = Content.retrofitOk({ ...card, slug: card.slug || 'voorbeeld' });
      // A static copy of the catalog card: links and buttons become plain text.
      $('[data-opt-preview]', f).innerHTML = ok ? UI.retrofitCard(card, { vehicle: null, status: false })
        .replace(/<a\b[^>]*>/g, '<span class="link-like">').replace(/<\/a>/g, '</span>').replace(/<button\b[\s\S]*?<\/button>/g, '')
        : '<p class="hint">Vul titel, categorie en modellen in voor een voorbeeld.</p>';
    };
    f.addEventListener('input', debounce(preview, 150)); f.addEventListener('change', preview); preview();
    const seoOf = () => ({ title: f.elements.seoTitle.value.trim(), description: f.elements.seoDescription.value.trim(), noindex: f.elements.seoNoindex.checked });
    f.addEventListener('submit', (e) => {
      e.preventDefault();
      const r = read();
      if (!showErrors(f, validate(r))) return;
      const slug = isNew ? (f.elements.slug.value.trim() || slugify(r.title)) : f.dataset.slug;
      const visible = f.elements.visible.checked;
      const seo = seoOf();
      const orig = Content.PR[slug];
      let fields;
      if (orig) {
        fields = {};
        RETROFIT_FIELDS.forEach((k) => { if (!sameField(k, r[k], orig[k], orig)) fields[k] = r[k]; });
        const merged = Object.assign(deepClone(orig), Content.cleanRetrofitFields(fields));
        if (merged.scope !== 'brand') delete merged.brands;
        if (!Content.retrofitOk(merged)) { Toast.show('Deze combinatie van merk, modellen en categorie is ongeldig.', { error: true }); return; }
      } else {
        fields = { slug, ...r };
        const src = entry.item || {};
        if (fields.scope !== 'brand') {
          if (!r.years && src.yearsByModel) {
            const y = Object.entries(src.yearsByModel).filter(([m]) => r.models.includes(m));
            if (y.length) fields.yearsByModel = Object.fromEntries(y);
          }
          if (src.body && f.elements.keepBody && f.elements.keepBody.checked) fields.body = src.body; // shown as a switch
        }
        if (fields.scope === 'model') delete fields.scope;
        if (!Content.buildAdded(fields)) { Toast.show('Deze optie is onvolledig. Controleer titel, categorie en modellen.', { error: true }); return; }
      }
      const ok = saveContent((d) => {
        d.retrofits = d.retrofits && typeof d.retrofits === 'object' && !Array.isArray(d.retrofits) ? d.retrofits : {};
        const rb = d.retrofits;
        rb.edit = rb.edit && typeof rb.edit === 'object' ? { ...rb.edit } : {};
        rb.add = Array.isArray(rb.add) ? rb.add.slice() : [];
        const hide = new Set(Array.isArray(rb.hide) ? rb.hide : []);
        if (orig) { if (Object.keys(fields).length) rb.edit[slug] = fields; else delete rb.edit[slug]; }
        else { const i = rb.add.findIndex((a) => a && a.slug === slug); if (i > -1) rb.add[i] = fields; else rb.add.push(fields); }
        if (visible) hide.delete(slug); else hide.add(slug);
        rb.hide = [...hide];
        d.seo = d.seo && typeof d.seo === 'object' ? d.seo : {};
        d.seo.pages = { ...(d.seo.pages || {}) };
        const path = `/mogelijkheden/${slug}`;
        if (seo.title || seo.description || seo.noindex) d.seo.pages[path] = seo; else delete d.seo.pages[path];
      }, isNew ? 'Optie toegevoegd.' : 'Optie opgeslagen.');
      if (!ok) return;
      st.set(false);
      Router.go(isNew ? `/admin/opties/${slug}` : '/admin/opties');
    });
    const revert = $('[data-opt-revert]', f);
    if (revert) revert.addEventListener('click', async () => {
      if (!(await Overlay.confirm({ title: 'Standaard herstellen?', message: 'Alle aanpassingen aan deze optie worden ongedaan gemaakt. Zichtbaarheid en Google-instellingen blijven zoals ze zijn.', confirmLabel: 'Herstellen' }))) return;
      const slug = f.dataset.slug;
      if (saveContent((d) => { if (d.retrofits && d.retrofits.edit) { d.retrofits.edit = { ...d.retrofits.edit }; delete d.retrofits.edit[slug]; } }, 'De standaardinhoud is hersteld.')) { st.set(false); Router.render({ force: true }); }
    });
    const del = $('[data-opt-delete]', f);
    if (del) del.addEventListener('click', async () => {
      if (!(await Overlay.confirm({ title: 'Optie verwijderen?', message: `“${esc(entry.item.title)}” wordt definitief verwijderd.`, confirmLabel: 'Verwijderen', danger: true }))) return;
      const slug = f.dataset.slug;
      if (saveContent((d) => {
        const rb = d.retrofits || {};
        rb.add = (Array.isArray(rb.add) ? rb.add : []).filter((a) => !a || a.slug !== slug);
        rb.hide = (Array.isArray(rb.hide) ? rb.hide : []).filter((s) => s !== slug);
        d.retrofits = rb;
        if (d.seo && d.seo.pages) { d.seo.pages = { ...d.seo.pages }; delete d.seo.pages[`/mogelijkheden/${slug}`]; }
      }, 'Optie verwijderd.')) { st.set(false); Router.go('/admin/opties'); }
    });
    return () => Router.setGuard(null);
  },
});

/* ---------- Categorieën & merken ---------- */
Pages.adminCatalog = adminPage({
  key: 'catalogus', title: 'Categorieën & merken',
  render() {
    return `<form data-catalog novalidate>
      ${UI.notice('Deze teksten verschijnen op de homepage (categoriekaarten), in de filters van de catalogus en in het blok “Technische informatie” op elke optiepagina van de categorie.', { ic: 'info' })}
      ${CATEGORIES.map((c) => {
        const copy = CATEGORY_COPY[c.id] || {};
        return `<details class="panel cat-panel"><summary class="panel-head"><div><h2>${icon(c.icon).replace('<svg', '<svg style="width:16px;height:16px;vertical-align:-3px;margin-right:6px"')}${esc(c.name)}</h2><p>${esc(c.tagline)}</p></div><span class="pill">${RETROFITS.filter((r) => r.cat === c.id).length} opties</span></summary>
          <div class="panel-body"><div class="form-grid">
            ${saField({ id: `${c.id}-name`, name: `${c.id}:name`, label: 'Naam', value: c.name, max: 80, half: true })}
            ${saField({ id: `${c.id}-tagline`, name: `${c.id}:tagline`, label: 'Slogan (homepage)', value: c.tagline, max: 120, half: true })}
            ${saField({ id: `${c.id}-text`, name: `${c.id}:text`, label: 'Korte omschrijving', value: c.text, max: 300 })}
            ${saField({ id: `${c.id}-install`, name: `${c.id}:install`, label: '“Wat wordt ingebouwd?”', value: copy.install || '', multi: true, rows: 3, max: 1500 })}
            ${saField({ id: `${c.id}-program`, name: `${c.id}:program`, label: '“Wat wordt geprogrammeerd?”', value: copy.program || '', multi: true, rows: 3, max: 1500, opt: true, placeholder: tt('retro.program'), hint: 'Leeg = de algemene tekst (Beheer → Teksten → Mogelijkheden).' })}
            ${saField({ id: `${c.id}-calibrate`, name: `${c.id}:calibrate`, label: '“Kalibratie nodig?”', value: copy.calibrate || '', multi: true, rows: 3, max: 1500, opt: true, hint: 'Alleen ingevuld verschijnt dit blok op de optiepagina’s.' })}
            ${saField({ id: `${c.id}-benefits`, name: `${c.id}:benefits`, label: 'Voordelen', value: (copy.benefits || []).join('\n'), multi: true, rows: 3, hint: 'Eén voordeel per regel (maximaal 8).' })}
          </div></div></details>`;
      }).join('')}
      <section class="panel"><div class="panel-head"><div><h2>Merken</h2><p>Introductie op de merkpagina’s en in het merkenoverzicht</p></div></div><div class="panel-body"><div class="form-grid">
        ${BRANDS.map((b) => saField({ id: `brand-${b.id}`, name: `brand:${b.id}`, label: b.name, value: b.intro, multi: true, rows: 2, max: 600 })).join('')}
      </div></div></section>
      ${saveBar()}
    </form>`;
  },
  mount(root) {
    const f = $('[data-catalog]', root);
    const st = trackDirty(f);
    const v = (k) => (f.elements[k] ? f.elements[k].value.trim() : '');
    const CAT_FIELDS = ['name', 'tagline', 'text', 'install', 'program', 'calibrate'];
    const values = () => {
      const out = {};
      CATEGORIES.forEach((c) => {
        CAT_FIELDS.forEach((k) => { out[`${c.id}:${k}`] = v(`${c.id}:${k}`); });
        out[`${c.id}:benefits`] = lines(f.elements[`${c.id}:benefits`].value);
      });
      BRANDS.forEach((b) => { out[`brand:${b.id}`] = v(`brand:${b.id}`); });
      return out;
    };
    let shown = values();
    const defaultOf = (id, k) => {
      const pc = Content.P.categoryCopy[id] || {};
      if (['name', 'tagline', 'text'].includes(k)) return Content.P.categories[id][k];
      return k === 'benefits' ? (pc.benefits || []) : (pc[k] || '');
    };
    f.addEventListener('submit', (e) => {
      e.preventDefault();
      const errs = {};
      CATEGORIES.forEach((c) => {
        ['name', 'tagline', 'text'].forEach((k) => { if (!v(`${c.id}:${k}`)) errs[`${c.id}:${k}`] = 'Dit veld is verplicht.'; });
        if (!v(`${c.id}:install`)) errs[`${c.id}:install`] = 'Dit veld is verplicht.';
        const benefits = lines(f.elements[`${c.id}:benefits`].value);
        if (!benefits.length) errs[`${c.id}:benefits`] = 'Vul ten minste één voordeel in.';
        else { const lim = listLimit(benefits, 8, 200, 'voordelen'); if (lim) errs[`${c.id}:benefits`] = lim; }
      });
      if (!showErrors(f, errs)) return;
      const next = values();
      const changed = changedKeys(shown, next);
      if (saveContent((d) => {
        // Only the fields changed in this form; a value equal to the built-in text is not stored.
        const cats = { ...(isObj(d.categories) ? d.categories : {}) };
        const brands = { ...(isObj(d.brands) ? d.brands : {}) };
        changed.forEach((key) => {
          const val = next[key];
          if (key.startsWith('brand:')) {
            const id = key.slice(6);
            if (val && val !== Content.P.brands[id].intro) brands[id] = { intro: val }; else delete brands[id];
            return;
          }
          const [id, k] = key.split(':');
          const o = { ...(isObj(cats[id]) ? cats[id] : {}) };
          if (stableStringify(val) === stableStringify(defaultOf(id, k))) delete o[k]; else o[k] = val;
          if (Object.keys(o).length) cats[id] = o; else delete cats[id];
        });
        d.categories = cats; d.brands = brands;
      }, 'Categorieën en merken opgeslagen.')) { st.set(false); shown = next; }
    });
    return () => Router.setGuard(null);
  },
});

/* ---------- Ordered lists (services, articles): shared list page ---------- */
const SERVICE_ICONS = ['cpu', 'settings2', 'target', 'activity', 'box', 'radar', 'wrench', 'shield', 'camera', 'monitor', 'gauge', 'light', 'comfort', 'tow', 'refresh', 'sliders', 'car', 'phoneDevice', 'file', 'info'];
const iconSelect = (name, value) => `<div class="field"><label for="sa-${name}">Pictogram</label><div class="flex gap-12 items-center"><span class="icon-circle icon-circle--sm" data-icon-preview>${icon(value)}</span><select class="select" id="sa-${name}" name="${name}">${SERVICE_ICONS.map((k) => `<option value="${k}"${k === value ? ' selected' : ''}>${k}</option>`).join('')}</select></div></div>`;
function orderedListPage({ key, title, newLabel, items, base, rowHtml, store, minItems = 0, note = '' }) {
  return adminPage({
    key, title,
    actions: () => `<a class="btn btn--primary btn--sm" href="#/admin/${base}/nieuw">${icon('plus')}<span class="hide-sm">${esc(newLabel)}</span></a>`,
    render() {
      const list = items();
      return `${note ? UI.notice(note, { ic: 'info' }) : ''}<section class="panel"><div class="panel-body panel-body--flush"><div class="table-wrap rtable"><table class="table admin-table"><tbody>
        ${list.map((x, i) => `<tr><td class="cell-main" data-label="${esc(title)}">${rowHtml(x, i)}</td>
          <td class="num cell-actions"><div class="row-actions">
            <button class="icon-btn icon-btn--sm" type="button" data-move="${i}" data-dir="-1"${i ? '' : ' disabled'} aria-label="Omhoog" title="Omhoog">${icon('left').replace('<svg', '<svg style="transform:rotate(90deg)"')}</button>
            <button class="icon-btn icon-btn--sm" type="button" data-move="${i}" data-dir="1"${i < list.length - 1 ? '' : ' disabled'} aria-label="Omlaag" title="Omlaag">${icon('right').replace('<svg', '<svg style="transform:rotate(90deg)"')}</button>
            <a class="icon-btn icon-btn--sm" href="#/admin/${base}/${attr(x.slug)}" aria-label="Bewerken: ${attr(x.title)}" title="Bewerken">${icon('pencil')}</a>
            <button class="icon-btn icon-btn--sm" type="button" data-del="${i}"${list.length <= minItems ? ' disabled' : ''} aria-label="Verwijderen: ${attr(x.title)}" title="Verwijderen">${icon('trash')}</button>
          </div></td></tr>`).join('')}
      </tbody></table></div>${list.length ? '' : `<div class="panel-body">${UI.empty({ icon: 'file', title: 'Nog niets toegevoegd' })}</div>`}</div></section>`;
    },
    mount(root) {
      root.addEventListener('click', async (e) => {
        const mv = e.target.closest('[data-move]');
        if (mv) {
          const i = Number(mv.dataset.move); const j = i + Number(mv.dataset.dir);
          const list = deepClone(items()); if (j < 0 || j >= list.length) return;
          [list[i], list[j]] = [list[j], list[i]];
          if (store(list, 'Volgorde opgeslagen.')) Router.render();
          return;
        }
        const del = e.target.closest('[data-del]');
        if (del) {
          const list = deepClone(items()); const x = list[Number(del.dataset.del)];
          if (!x || list.length <= minItems) return;
          if (!(await Overlay.confirm({ title: 'Verwijderen?', message: `“${esc(x.title)}” wordt van de website verwijderd.`, confirmLabel: 'Verwijderen', danger: true }))) return;
          if (store(list.filter((y) => y.slug !== x.slug), 'Verwijderd.')) Router.render();
        }
      });
    },
  });
}
/** SEO override fields for a detail page, and saving them into a draft. */
const seoFields = (path) => {
  const s = (path && Content.seo().pages[path]) || {};
  return `${saField({ name: 'seoTitle', label: 'Titel in Google', value: s.title || '', max: 120, opt: true })}
    ${saField({ name: 'seoDescription', label: 'Omschrijving in Google', value: s.description || '', multi: true, rows: 3, max: 300, opt: true })}
    ${saSwitch('seoNoindex', 'Niet laten indexeren', !!s.noindex)}`;
};
function putSeo(d, path, f, oldPath) {
  d.seo = d.seo && typeof d.seo === 'object' ? d.seo : {};
  d.seo.pages = { ...(d.seo.pages || {}) };
  if (oldPath && oldPath !== path) delete d.seo.pages[oldPath];
  const e = { title: f.elements.seoTitle.value.trim(), description: f.elements.seoDescription.value.trim(), noindex: f.elements.seoNoindex.checked };
  if (e.title || e.description || e.noindex) d.seo.pages[path] = e; else delete d.seo.pages[path];
}

/* ---------- Diensten ---------- */
const storeServices = (list, msg) => saveContent((d) => { d.services = list; }, msg);
Pages.adminServices = orderedListPage({
  key: 'diensten', title: 'Diensten', newLabel: 'Nieuwe dienst', base: 'diensten', minItems: 1,
  note: 'De eerste drie diensten staan op de homepage. Alle diensten staan op de pagina Expertise en hebben een eigen pagina.',
  items: () => SERVICES,
  store: storeServices,
  rowHtml: (s, i) => `<div class="prod"><span class="icon-circle icon-circle--sm">${icon(s.icon)}</span><div><a class="p-name text-link" href="#/admin/diensten/${attr(s.slug)}">${esc(s.title)}</a><div class="p-sub">/diensten/${esc(s.slug)}${i < 3 ? ' · op de homepage' : ''}</div></div></div>`,
});
Pages.adminServiceForm = adminPage({
  key: 'diensten', title: 'Dienst',
  heading: (ctx) => (ctx.params.slug ? 'Dienst bewerken' : 'Nieuwe dienst'),
  render(ctx) {
    const isNew = !ctx.params.slug;
    const s = isNew ? { slug: '', title: '', icon: 'wrench', card: '', cardText: '', points: [], short: '', body: [], cta: ['Meer informatie', ''], keywords: [], cats: [], image: '', topic: '' } : SERVICE[ctx.params.slug];
    if (!s) return UI.empty({ icon: 'wrench', title: 'Dienst niet gevonden', actions: '<a class="btn btn--dark btn--sm" href="#/admin/diensten">Alle diensten</a>' });
    const path = isNew ? '' : `/diensten/${s.slug}`;
    return `<p><a class="link link--ink" href="#/admin/diensten">${icon('arrowLeft')} Alle diensten</a></p>
      <form data-svc-form novalidate data-new="${isNew}" data-slug="${attr(s.slug)}"><div class="form-layout">
        <div class="form-col">
          <section class="panel"><div class="panel-head"><div><h2>Dienstpagina</h2></div>${isNew ? '' : `<a class="btn btn--light btn--sm" href="#${attr(path)}" target="_blank" rel="noopener">${icon('external')} Bekijk</a>`}</div><div class="panel-body"><div class="form-grid">
            ${saField({ name: 'title', label: 'Titel', value: s.title, max: 160 })}
            ${isNew ? saField({ name: 'slug', label: 'Webadres (slug)', value: '', max: 120, placeholder: 'wordt gemaakt van de titel', hint: '/diensten/<strong>…</strong> — kan later niet worden gewijzigd.' }) : ''}
            ${saField({ name: 'short', label: 'Korte omschrijving', value: s.short, multi: true, rows: 2, max: 400, hint: 'Onder de titel en in Google.' })}
            ${saField({ name: 'body', label: 'Tekst', value: s.body.join('\n\n'), multi: true, rows: 7, max: 8000, hint: 'Lege regel = nieuwe alinea.' })}
            ${saField({ name: 'keywords', label: 'Zoekwoorden', value: s.keywords.join(', '), opt: true })}
          </div></div></section>
          <section class="panel"><div class="panel-head"><div><h2>Kaart op home en Expertise</h2></div></div><div class="panel-body"><div class="form-grid">
            ${saField({ name: 'card', label: 'Titel op de kaart', value: s.card, max: 80, half: true })}
            ${iconSelect('icon', s.icon)}
            ${saField({ name: 'cardText', label: 'Tekst op de kaart', value: s.cardText, multi: true, rows: 3, max: 600 })}
            ${saField({ name: 'points', label: 'Opsomming', value: s.points.join('\n'), multi: true, rows: 3, hint: 'Eén punt per regel, maximaal 6.' })}
            ${saField({ name: 'ctaLabel', label: 'Linktekst', value: s.cta[0], max: 80, half: true })}
            ${saField({ name: 'ctaHref', label: 'Link naar', value: s.cta[1] ? s.cta[1].replace(/^#/, '') : '', max: 300, half: true, placeholder: isNew ? '/diensten/…' : path, hint: 'Leeg = de eigen dienstpagina.' })}
          </div></div></section>
        </div>
        <div class="form-col">
          <section class="panel"><div class="panel-head"><div><h2>Koppelingen</h2></div></div><div class="panel-body" style="display:grid;gap:16px">
            <div class="field"><label for="sv-topic">Onderwerp in het contactformulier</label><select class="select" id="sv-topic" name="topic"><option value="">Geen</option>${ENQUIRY_TOPICS.map((t) => `<option value="${t.id}"${(s.topic || SERVICE_TOPIC[s.slug]) === t.id ? ' selected' : ''}>${esc(t.label)}</option>`).join('')}</select></div>
            <div class="field"><span class="label">Gerelateerde categorieën</span><div style="display:grid;gap:8px">${CATEGORIES.map((c) => `<label class="check"><input type="checkbox" name="cats" value="${c.id}"${s.cats.includes(c.id) ? ' checked' : ''}><span class="box">${icon('check')}</span>${esc(c.name)}</label>`).join('')}</div></div>
          </div></section>
          <section class="panel"><div class="panel-head"><div><h2>Foto</h2></div></div><div class="panel-body"><div class="form-grid">${imagePicker('image', s.image || '', { label: 'Foto', kind: 'assist', hint: 'Zonder foto toont de pagina een illustratie.' })}</div></div></section>
          <section class="panel"><div class="panel-head"><div><h2>Google</h2><p>Leeg = automatisch</p></div></div><div class="panel-body"><div class="form-grid">${seoFields(path)}</div></div></section>
        </div>
      </div>${saveBar(isNew ? 'Dienst toevoegen' : 'Opslaan')}</form>`;
  },
  mount(root) {
    const f = $('[data-svc-form]', root); if (!f) return null;
    const isNew = f.dataset.new === 'true';
    const st = trackDirty(f);
    mountPickers(f);
    f.elements.icon.addEventListener('change', () => { $('[data-icon-preview]', f).innerHTML = icon(f.elements.icon.value); });
    if (isNew) {
      f.elements.title.addEventListener('input', () => { if (!f.elements.slug.dataset.touched) f.elements.slug.value = slugify(f.elements.title.value); });
      f.elements.slug.addEventListener('input', () => { f.elements.slug.dataset.touched = '1'; });
    }
    f.addEventListener('submit', (e) => {
      e.preventDefault();
      const v = (k) => f.elements[k].value.trim();
      const slug = isNew ? (v('slug') || slugify(v('title'))) : f.dataset.slug;
      const errs = {};
      if (!v('title')) errs.title = 'Vul een titel in.';
      if (isNew && !Content.isSlug(slug)) errs.slug = 'Gebruik kleine letters, cijfers en koppeltekens.';
      else if (isNew && slug === 'nieuw') errs.slug = RESERVED_SLUG;
      else if (isNew && SERVICES.some((x) => x.slug === slug)) errs.slug = 'Dit webadres bestaat al. Kies een ander.';
      if (!v('short')) errs.short = 'Vul een korte omschrijving in.';
      const body = String(f.elements.body.value).split(/\n\s*\n/).map((p) => p.replace(/\s*\n\s*/g, ' ').trim()).filter(Boolean);
      if (!body.length) errs.body = 'Vul een tekst in.';
      if (!errs.body) { const lim = listLimit(body, 20, 3000, 'alinea’s'); if (lim) errs.body = lim; }
      const points = lines(f.elements.points.value);
      const pl = listLimit(points, 6, 160, 'punten'); if (pl) errs.points = pl;
      const kw = listLimit(csv(f.elements.keywords.value), 30, 60, 'zoekwoorden'); if (kw) errs.keywords = kw;
      const href = v('ctaHref') ? Content.safeHref(v('ctaHref')) : `#/diensten/${slug}`;
      if (!href) errs.ctaHref = 'Gebruik een pagina van deze site (bijv. /contact) of een webadres met https://.';
      if (!showErrors(f, errs)) return;
      const next = {
        slug, title: v('title'), icon: f.elements.icon.value, card: v('card') || v('title'), cardText: v('cardText') || v('short'), points,
        short: v('short'), body, cta: [v('ctaLabel') || 'Meer informatie', href], keywords: csv(f.elements.keywords.value),
        cats: $$('input[name="cats"]:checked', f).map((x) => x.value), image: f.elements.image.value.trim(), topic: f.elements.topic.value,
      };
      if (!next.image) delete next.image;
      const list = deepClone(SERVICES);
      const i = list.findIndex((x) => x.slug === slug);
      if (i > -1) list[i] = next; else list.push(next);
      if (!saveContent((d) => { d.services = list; putSeo(d, `/diensten/${slug}`, f); }, isNew ? 'Dienst toegevoegd.' : 'Dienst opgeslagen.')) return;
      st.set(false);
      Router.go('/admin/diensten');
    });
    return () => Router.setGuard(null);
  },
});

/* ---------- Berichten & kennis ---------- */
const storeArticles = (list, msg) => saveContent((d) => { d.articles = list; }, msg);
Pages.adminArticles = orderedListPage({
  key: 'kennis', title: 'Berichten & kennis', newLabel: 'Nieuw bericht', base: 'kennis',
  items: () => ARTICLES,
  store: storeArticles,
  rowHtml: (a) => `<div class="prod"><span class="icon-circle icon-circle--sm">${icon(a.icon)}</span><div><a class="p-name text-link" href="#/admin/kennis/${attr(a.slug)}">${esc(a.title)}</a><div class="p-sub">${esc(a.tag)} · /kennis/${esc(a.slug)}</div></div></div>`,
});
Pages.adminArticleForm = adminPage({
  key: 'kennis', title: 'Bericht',
  heading: (ctx) => (ctx.params.slug ? 'Bericht bewerken' : 'Nieuw bericht'),
  render(ctx) {
    const isNew = !ctx.params.slug;
    const a = isNew ? { slug: '', tag: '', icon: 'info', title: '', keywords: [], short: '', body: [], links: [] } : ARTICLE[ctx.params.slug];
    if (!a) return UI.empty({ icon: 'file', title: 'Bericht niet gevonden', actions: '<a class="btn btn--dark btn--sm" href="#/admin/kennis">Alle berichten</a>' });
    const path = isNew ? '' : `/kennis/${a.slug}`;
    return `<p><a class="link link--ink" href="#/admin/kennis">${icon('arrowLeft')} Alle berichten</a></p>
      <form data-art-form novalidate data-new="${isNew}" data-slug="${attr(a.slug)}"><div class="form-layout">
        <div class="form-col"><section class="panel"><div class="panel-head"><div><h2>Bericht</h2></div>${isNew ? '' : `<a class="btn btn--light btn--sm" href="#${attr(path)}" target="_blank" rel="noopener">${icon('external')} Bekijk</a>`}</div><div class="panel-body"><div class="form-grid">
          ${saField({ name: 'title', label: 'Titel', value: a.title, max: 160 })}
          ${isNew ? saField({ name: 'slug', label: 'Webadres (slug)', value: '', max: 120, placeholder: 'wordt gemaakt van de titel', hint: '/kennis/<strong>…</strong> — kan later niet worden gewijzigd.' }) : ''}
          ${saField({ name: 'tag', label: 'Label', value: a.tag, max: 40, half: true, placeholder: 'Techniek' })}
          ${iconSelect('icon', a.icon)}
          ${saField({ name: 'short', label: 'Samenvatting', value: a.short, multi: true, rows: 2, max: 400, hint: 'Op de overzichtspagina, onder de titel en in Google.' })}
          ${saField({ name: 'body', label: 'Tekst', value: richSource(a.body), multi: true, rows: 14, max: 20000, hint: '<code class="code">## Kop</code> voor een tussenkop, <code class="code">- </code> voor een opsomming, lege regel = nieuwe alinea, <code class="code">**tekst**</code> = vet, <code class="code">[linktekst](/contact)</code> = link.' })}
          ${saField({ name: 'links', label: 'Links onder het bericht', value: linksText((a.links || []).map(([l, h]) => [l, h.replace(/^#/, '')])), multi: true, rows: 3, opt: true, hint: 'Eén per regel (maximaal 6): <code class="code">Linktekst | /pagina</code> of <code class="code">Linktekst | https://…</code>' })}
          ${saField({ name: 'keywords', label: 'Zoekwoorden', value: a.keywords.join(', '), opt: true })}
        </div></div></section></div>
        <div class="form-col"><section class="panel"><div class="panel-head"><div><h2>Google</h2><p>Leeg = automatisch</p></div></div><div class="panel-body"><div class="form-grid">${seoFields(path)}</div></div></section></div>
      </div>${saveBar(isNew ? 'Bericht toevoegen' : 'Opslaan')}</form>`;
  },
  mount(root) {
    const f = $('[data-art-form]', root); if (!f) return null;
    const isNew = f.dataset.new === 'true';
    const st = trackDirty(f);
    if (isNew) {
      f.elements.title.addEventListener('input', () => { if (!f.elements.slug.dataset.touched) f.elements.slug.value = slugify(f.elements.title.value); });
      f.elements.slug.addEventListener('input', () => { f.elements.slug.dataset.touched = '1'; });
    }
    f.addEventListener('submit', (e) => {
      e.preventDefault();
      const v = (k) => f.elements[k].value.trim();
      const slug = isNew ? (v('slug') || slugify(v('title'))) : f.dataset.slug;
      const errs = {};
      if (!v('title')) errs.title = 'Vul een titel in.';
      if (isNew && !Content.isSlug(slug)) errs.slug = 'Gebruik kleine letters, cijfers en koppeltekens.';
      else if (isNew && slug === 'nieuw') errs.slug = RESERVED_SLUG;
      else if (isNew && ARTICLES.some((x) => x.slug === slug)) errs.slug = 'Dit webadres bestaat al. Kies een ander.';
      if (!v('short')) errs.short = 'Vul een samenvatting in.';
      const body = parseRich(f.elements.body.value);
      if (!body.length) errs.body = 'Vul een tekst in.';
      else if (body.length > 80) errs.body = 'Gebruik maximaal 80 alinea’s, kopjes en opsommingen.';
      else if (body.some(([k, c]) => (k === 'ul' ? c.length > 40 || c.some((li) => li.length > 600) : c.length > 3000))) errs.body = 'Maximaal 3.000 tekens per alinea en 40 punten van elk 600 tekens per opsomming.';
      const links = parseLinks(f.elements.links.value);
      if (!links) errs.links = 'Schrijf elke link als “Linktekst | /pagina” of “Linktekst | https://…”.';
      else if (links.length > 6) errs.links = 'Gebruik maximaal 6 links.';
      else if (linkLabelError(links)) errs.links = linkLabelError(links);
      const kw = listLimit(csv(f.elements.keywords.value), 30, 60, 'zoekwoorden'); if (kw) errs.keywords = kw;
      if (!showErrors(f, errs)) return;
      const next = { slug, tag: v('tag') || 'Kennis', icon: f.elements.icon.value, title: v('title'), keywords: csv(f.elements.keywords.value), short: v('short'), body, links };
      const list = deepClone(ARTICLES);
      const i = list.findIndex((x) => x.slug === slug);
      if (i > -1) list[i] = next; else list.push(next);
      if (!saveContent((d) => { d.articles = list; putSeo(d, `/kennis/${slug}`, f); }, isNew ? 'Bericht toegevoegd.' : 'Bericht opgeslagen.')) return;
      st.set(false);
      Router.go('/admin/kennis');
    });
    return () => Router.setGuard(null);
  },
});

/* ---------- Beoordelingen ---------- */
const reviewRow = (r = {}) => `<div class="row-edit row-edit--card">
  <div class="form-grid">
    <label class="field"><span class="label">Titel</span><input class="input input--sm" data-r="title" value="${attr(r.title || '')}" maxlength="120"></label>
    <label class="field"><span class="label">Score</span><select class="select select--sm" data-r="score">${[10, 9, 8, 7, 6, 5, 4, 3, 2, 1].map((n) => `<option${Number(r.score || 10) === n ? ' selected' : ''}>${n}</option>`).join('')}</select></label>
    <label class="field"><span class="label">Naam</span><input class="input input--sm" data-r="name" value="${attr(r.name || '')}" maxlength="60"></label>
    <label class="field"><span class="label">Plaats</span><input class="input input--sm" data-r="place" value="${attr(r.place || '')}" maxlength="60"></label>
    <label class="field"><span class="label">Datum</span><input class="input input--sm" type="date" data-r="date" value="${attr(r.date || '')}"></label>
    <label class="field span-2"><span class="label">Citaat (letterlijk)</span><textarea class="textarea textarea--sm" data-r="text" rows="3">${esc(r.text || '')}</textarea></label>
  </div>
  <div class="row-edit-actions"><button class="icon-btn icon-btn--sm" type="button" data-row-up aria-label="Omhoog">${icon('left').replace('<svg', '<svg style="transform:rotate(90deg)"')}</button><button class="icon-btn icon-btn--sm" type="button" data-row-down aria-label="Omlaag">${icon('right').replace('<svg', '<svg style="transform:rotate(90deg)"')}</button><button class="icon-btn icon-btn--sm" type="button" data-row-del aria-label="Verwijderen">${icon('trash')}</button></div>
</div>`;
Pages.adminReviews = adminPage({
  key: 'beoordelingen', title: 'Beoordelingen',
  render() {
    const r = REVIEWS;
    return `<form data-reviews novalidate>
      ${UI.notice('<strong>Alleen echte beoordelingen.</strong> Neem score, aantal en citaten letterlijk over van de bron (bijvoorbeeld Klantenvertellen) en pas ze aan wanneer die veranderen.', { type: 'warn', ic: 'alert' })}
      <section class="panel"><div class="panel-head"><div><h2>Score</h2></div></div><div class="panel-body"><div class="form-grid">
        ${saField({ name: 'score', label: 'Gemiddelde score', value: r.score, max: 4, half: true, placeholder: '9,4' })}
        ${saField({ name: 'scale', label: 'Schaal', value: r.scale, type: 'number', half: true, attrs: ' min="5" max="10"' })}
        ${saField({ name: 'count', label: 'Aantal beoordelingen', value: r.count, type: 'number', half: true, attrs: ' min="0"' })}
        ${saField({ name: 'source', label: 'Bron', value: r.source, max: 60, half: true })}
        ${saField({ name: 'url', label: 'Link naar alle beoordelingen', value: r.url, type: 'url' })}
        ${saField({ name: 'writeUrl', label: 'Link om een beoordeling te schrijven', value: r.writeUrl, type: 'url' })}
      </div></div></section>
      <section class="panel"><div class="panel-head"><div><h2>Citaten</h2><p>De eerste twee staan op de homepage</p></div><button class="btn btn--light btn--sm" type="button" data-rv-add>${icon('plus')} Citaat toevoegen</button></div>
        <div class="panel-body"><div class="rows-editor" data-rv-rows>${r.items.map(reviewRow).join('')}</div></div></section>
      ${saveBar()}
    </form>`;
  },
  mount(root) {
    const f = $('[data-reviews]', root);
    const st = trackDirty(f);
    const rows = $('[data-rv-rows]', f);
    bindRowEditor(rows, reviewRow, () => st.set(true));
    $('[data-rv-add]', f).addEventListener('click', () => { rows.insertAdjacentHTML('beforeend', reviewRow({ score: 10 })); st.set(true); $$('.row-edit', rows).pop().querySelector('input').focus(); });
    const v = (k) => f.elements[k].value.trim();
    const itemsOf = () => $$('.row-edit', rows).map((row) => { const g = (k) => $(`[data-r="${k}"]`, row).value.trim(); return { title: g('title'), name: g('name'), place: g('place'), date: g('date'), score: Number(g('score')), text: g('text') }; });
    const values = () => ({ score: v('score').replace('.', ','), scale: Number(v('scale')), count: Number(v('count')), source: v('source'), url: v('url'), writeUrl: v('writeUrl'), items: itemsOf() });
    let shown = values();
    f.addEventListener('submit', (e) => {
      e.preventDefault();
      const errs = {};
      if (!/^\d{1,2}([.,]\d)?$/.test(v('score'))) errs.score = 'Vul een score in, bijvoorbeeld 9,4.';
      const scale = Number(v('scale')); const count = Number(v('count'));
      if (!Number.isInteger(scale) || scale < 5 || scale > 10) errs.scale = 'Kies een schaal van 5 tot 10.';
      else if (Number(v('score').replace(',', '.')) > scale) errs.score = 'De score is hoger dan de schaal.';
      if (!Number.isInteger(count) || count < 0 || count >= 1000000) errs.count = 'Vul een geldig aantal in.';
      if (!v('source')) errs.source = 'Vul de bron in.';
      ['url', 'writeUrl'].forEach((k) => { if (!Content.httpsUrl(v(k))) errs[k] = 'Gebruik een webadres dat met https:// begint.'; });
      const items = itemsOf();
      if (items.some((it) => !it.name || !it.text)) { Toast.show('Vul bij elk citaat ten minste de naam en het citaat in.', { error: true }); return; }
      if (items.length > 40) { Toast.show('Gebruik maximaal 40 citaten.', { error: true }); return; }
      if (items.some((it) => it.text.length > 1500)) { Toast.show('Een citaat mag maximaal 1.500 tekens hebben.', { error: true }); return; }
      if (!showErrors(f, errs)) return;
      const next = values();
      const changed = changedKeys(shown, next);
      if (saveContent((d) => {
        const rv = { ...(isObj(d.reviews) ? d.reviews : {}) };
        changed.forEach((k) => { rv[k] = next[k]; });
        d.reviews = rv;
      }, 'Beoordelingen opgeslagen.')) { st.set(false); shown = next; }
    });
    return () => Router.setGuard(null);
  },
});

/* ---------- Meer van ons werk ---------- */
const workRow = (m = {}) => `<div class="row-edit row-edit--card">
  <div class="form-grid">
    <label class="field span-2"><span class="label">Titel</span><input class="input input--sm" data-w="title" value="${attr(m.title || '')}" maxlength="120"></label>
    <label class="field span-2"><span class="label">Tekst</span><textarea class="textarea textarea--sm" data-w="text" rows="2">${esc(m.text || '')}</textarea></label>
    <label class="field span-2"><span class="label">Links</span><textarea class="textarea textarea--sm" data-w="links" rows="2">${esc(linksText(m.links))}</textarea><span class="hint">Eén per regel (maximaal 4): <code class="code">Linktekst | https://…</code></span></label>
  </div>
  <div class="row-edit-actions"><button class="icon-btn icon-btn--sm" type="button" data-row-up aria-label="Omhoog">${icon('left').replace('<svg', '<svg style="transform:rotate(90deg)"')}</button><button class="icon-btn icon-btn--sm" type="button" data-row-down aria-label="Omlaag">${icon('right').replace('<svg', '<svg style="transform:rotate(90deg)"')}</button><button class="icon-btn icon-btn--sm" type="button" data-row-del aria-label="Verwijderen">${icon('trash')}</button></div>
</div>`;
Pages.adminMoreWork = adminPage({
  key: 'meer-werk', title: 'Meer van ons werk',
  render() {
    return `<form data-work novalidate>
      ${UI.notice('Deze kaarten staan op de pagina Projecten onder “Meer van ons werk”, met links naar bijvoorbeeld foto’s of video’s op Facebook. Zonder kaarten verdwijnt het blok.', { ic: 'info' })}
      <section class="panel"><div class="panel-head"><div><h2>Kaarten</h2></div><button class="btn btn--light btn--sm" type="button" data-w-add>${icon('plus')} Kaart toevoegen</button></div>
        <div class="panel-body"><div class="rows-editor" data-w-rows>${MORE_WORK.map(workRow).join('')}</div></div></section>
      ${saveBar()}
    </form>`;
  },
  mount(root) {
    const f = $('[data-work]', root);
    const st = trackDirty(f);
    const rows = $('[data-w-rows]', f);
    bindRowEditor(rows, workRow, () => st.set(true));
    $('[data-w-add]', f).addEventListener('click', () => { rows.insertAdjacentHTML('beforeend', workRow()); st.set(true); $$('.row-edit', rows).pop().querySelector('input').focus(); });
    const raw = () => $$('.row-edit', rows).map((row) => ['title', 'text', 'links'].map((k) => $(`[data-w="${k}"]`, row).value.trim()));
    let shown = raw();
    const listNow = () => stableStringify(MORE_WORK); // kept up to date when another tab saves
    let base = listNow();
    f.addEventListener('submit', (e) => {
      e.preventDefault();
      let bad = '';
      const items = $$('.row-edit', rows).map((row) => {
        const g = (k) => $(`[data-w="${k}"]`, row).value.trim();
        const links = parseLinks(g('links'));
        if (!g('title')) bad = 'Elke kaart heeft een titel nodig.';
        if (g('text').length > 800) bad = 'De tekst van een kaart mag maximaal 800 tekens hebben.';
        if (!links) bad = 'Schrijf elke link als “Linktekst | https://…”.';
        else if (links.length > 4) bad = 'Gebruik maximaal 4 links per kaart.';
        else if (linkLabelError(links)) bad = linkLabelError(links);
        return { title: g('title'), text: g('text'), links: links || [] };
      });
      if (items.length > 24) bad = 'Gebruik maximaal 24 kaarten.';
      if (bad) { Toast.show(bad, { error: true }); return; }
      const next = raw();
      // The cards are one list: saved when it changed in this form. If another tab saved the list meanwhile,
      // saving here would undo that, so it is refused with a message.
      const changedHere = stableStringify(next) !== stableStringify(shown);
      if (changedHere && listNow() !== base) { Toast.show('Deze kaarten zijn intussen in een ander tabblad gewijzigd. Laad de pagina opnieuw en voer uw wijziging opnieuw in.', { error: true }); return; }
      if (saveContent((d) => { if (changedHere) d.moreWork = items; }, 'Opgeslagen.')) { st.set(false); shown = next; base = listNow(); }
    });
    return () => Router.setGuard(null);
  },
});
