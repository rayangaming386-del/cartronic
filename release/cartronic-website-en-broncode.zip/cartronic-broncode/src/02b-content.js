/* =====================================================================
   CONTENT — everything Beheer can change without touching code
   ---------------------------------------------------------------------
   Layers, applied on top of the defaults in DATA:
     published ... the bundle embedded in this page (script#ctContent), written by "Publiceren";
     draft ....... an editor's working copy in this browser (localStorage). Visitors never see it.
   Every value is validated on the way in and falls back to its default when it is missing or
   invalid, so a damaged bundle can never break the site. Production: the same bundle becomes a
   CMS/API document; the shapes below stay the same.
   ===================================================================== */

/* ---------- Editable texts ----------
   [key, label, default, options]. The default is plain text: Enter = new line, **tekst** = bold,
   [label](adres) = link. `html` keeps the original markup when a default needs more than that.
   `vars` lists placeholders such as {bron}; `optional` texts may be left empty to hide them;
   `control` texts sit inside a button or link, so link syntax there only keeps the link text. */
const TEXT_GROUPS = [
  ['home', 'Home', [
    ['home.hero.eyebrow', 'Hero — bovenregel', 'De specialist in originele VAG-opties'],
    ['home.hero.line1', 'Hero — titel, regel 1', 'Origineel.'],
    ['home.hero.line2', 'Hero — titel, regel 2', 'Tot in detail.'],
    ['home.hero.lead', 'Hero — introductie', 'De fabrieksopties die uw auto nog mist. Vakkundig ingebouwd, geprogrammeerd en afgestemd op uw Volkswagen, Audi, SEAT of Škoda.', { multi: true }],
    ['home.hero.cta1', 'Hero — eerste knop', 'Bekijk opties voor uw auto', { control: true }],
    ['home.hero.cta2', 'Hero — tweede knop', 'Bekijk ons werk', { control: true }],
    ['home.hero.check1', 'Hero — vinkje 1', 'Originele OEM-onderdelen'],
    ['home.hero.check2', 'Hero — vinkje 2', 'Diagnose op dealerniveau'],
    ['home.hero.caption', 'Hero — bijschrift bij de foto', 'Audi MMI\nOriginele integratie', { multi: true }],
    ['home.brands.tagline', 'Merkenbalk — tekst', 'Vier merken.\nEén specialisme.', { multi: true }],
    ['home.finder.eyebrow', 'Voertuigzoeker — bovenregel', 'Uw auto, uw mogelijkheden'],
    ['home.finder.title', 'Voertuigzoeker — titel', 'Welke opties passen bij uw auto?'],
    ['home.cats.eyebrow', 'Categorieën — bovenregel', 'Af fabriek. Achteraf ingebouwd.'],
    ['home.cats.title', 'Categorieën — titel', 'Meer uit uw auto.\nMet originele opties.', { multi: true }],
    ['home.cats.lead', 'Categorieën — introductie', 'Van een achteruitrijcamera tot een digitale cockpit. Ontdek de upgrade die bij uw auto past.', { multi: true }],
    ['home.cats.link', 'Categorieën — linktekst op elke kaart', 'Ontdek de mogelijkheden', { control: true }],
    ['home.svc.eyebrow', 'Diensten — bovenregel', 'Expertise & diensten'],
    ['home.svc.title', 'Diensten — titel', 'Van retrofit\ntot reparatie.', { multi: true }],
    ['home.svc.lead', 'Diensten — introductie', 'Naast het inbouwen van originele opties programmeert CarTronic modules, kalibreert rijhulpsystemen en lost elektronische storingen op.', { multi: true }],
    ['home.svc.link', 'Diensten — link onder de kaarten', 'Bekijk alle diensten en specialismen', { control: true }],
    ['home.proj.eyebrow', 'Projecten — bovenregel', 'Uit de werkplaats'],
    ['home.proj.title', 'Projecten — titel', 'Techniek die u terugziet.'],
    ['home.proj.link', 'Projecten — link', 'Bekijk alle projecten', { control: true }],
    ['home.shop.eyebrow', 'Webshop — bovenregel', 'Webshop'],
    ['home.shop.title', 'Webshop — titel', 'Origineel, direct te bestellen.'],
    ['home.shop.link', 'Webshop — link', 'Naar de webshop', { control: true }],
    ['home.shop.hint', 'Webshop — opmerking onder de producten', 'Testomgeving: producten en prijzen in de webshop zijn demonstratiegegevens.', { optional: true }],
  ]],
  ['werkwijze', 'Werkwijze & techniek', [
    ['tech.caption', 'Bijschrift bij de foto', 'De werkplaats · Uitlijnen & kalibreren'],
    ['tech.eyebrow', 'Bovenregel', 'Techniek achter het resultaat'],
    ['tech.title', 'Titel', 'Inbouwen is één ding.\nIntegreren is ons vak.', { multi: true }],
    ['tech.text', 'Introductie', 'Een originele optie werkt samen met de rest van uw auto. Daarvoor zijn de juiste onderdelen, programmering en afstelling nodig.', { multi: true }],
    ['tech.step1.title', 'Stap 1 — titel', 'Originele onderdelen'],
    ['tech.step1.text', 'Stap 1 — tekst', 'OEM-componenten, afgestemd op uw model en uitvoering.', { multi: true }],
    ['tech.step2.title', 'Stap 2 — titel', 'Montage volgens fabrieksnormen'],
    ['tech.step2.text', 'Stap 2 — tekst', 'Vakkundige inbouw in onze werkplaats in Rijswijk.', { multi: true }],
    ['tech.step3.title', 'Stap 3 — titel', 'Coderen & programmeren'],
    ['tech.step3.text', 'Stap 3 — tekst', 'Via de online verbinding met de fabriek wordt de optie geprogrammeerd en correct aangemeld in de auto.', { multi: true }],
    ['tech.step4.title', 'Stap 4 — titel', 'Kalibratie waar nodig'],
    ['tech.step4.text', 'Stap 4 — tekst', 'Rijhulpsystemen zoals adaptieve cruisecontrol, Lane Assist en Night Vision worden uitgelijnd en gekalibreerd.', { multi: true }],
    ['tech.step5.title', 'Stap 5 — titel', 'Werkt zoals af fabriek'],
    ['tech.step5.text', 'Stap 5 — tekst', 'Bediend via de originele schermen, knoppen en menu’s.', { multi: true }],
    ['tech.link', 'Link naar de expertisepagina', 'Meer over onze werkwijze', { control: true }],
  ]],
  ['algemeen', 'Algemeen, header & footer', [
    ['cta.title', 'Afsluitende balk — titel', 'Wat mist er nog aan uw auto?'],
    ['cta.text', 'Afsluitende balk — tekst', 'Vertel ons uw merk, model en gewenste optie. Wij denken met u mee.', { multi: true }],
    ['cta.btn1', 'Afsluitende balk — knop', 'Bespreek uw mogelijkheden', { control: true }],
    ['cta.btn2', 'Afsluitende balk — belknop', 'Bel CarTronic', { control: true }],
    ['mn.sub', 'Mobiel menu — ondertitel', 'Originele opties voor uw Volkswagen, Audi, SEAT en Škoda.'],
    ['footer.tagline', 'Footer — slogan', 'Originele fabrieksopties.\nSpecialistische inbouw.\nVolkswagen · Audi · SEAT · Škoda.', { multi: true }],
    ['footer.legal', 'Footer — merkenvermelding', 'Volkswagen, Audi, SEAT en Škoda zijn merken van hun respectievelijke eigenaren.'],
    ['footer.proto', 'Footer — vermelding rechtsonder', 'Interactief prototype', { optional: true }],
    ['wa.generic', 'WhatsApp — standaardbericht', 'Ik heb een vraag over de mogelijkheden voor mijn auto.', { multi: true }],
    ['compat.disclaimer', 'Uitleg bij compatibiliteit', 'Compatibiliteit is afhankelijk van bouwjaar, uitvoering en aanwezige systemen. Een kenteken toont niet alle fabrieksopties. CarTronic controleert de definitieve compatibiliteit.', { multi: true }],
    ['nf.title', 'Pagina niet gevonden — titel', 'Deze pagina bestaat niet (meer).'],
    ['nf.text', 'Pagina niet gevonden — tekst', 'Controleer het adres of ga verder via de mogelijkheden of de homepage.', { multi: true }],
  ]],
  ['mogelijkheden', 'Mogelijkheden & opties', [
    ['catalog.eyebrow', 'Catalogus — bovenregel', 'De CarTronic-catalogus'],
    ['catalog.title', 'Catalogus — titel', 'Wat past bij uw auto?'],
    ['catalog.lead', 'Catalogus — introductie', 'Selecteer uw merk en model. Bekijk de opties, technische informatie en voorwaarden voor uw uitvoering.', { multi: true }],
    ['catalog.filterNote', 'Catalogus — opmerking onder de filters', 'De mogelijkheden hangen af van bouwjaar, uitvoering en aanwezige opties. CarTronic controleert de definitieve compatibiliteit.', { multi: true }],
    ['retro.program', 'Optiepagina — “Wat wordt geprogrammeerd?” (standaard)', 'Na de montage wordt de optie via de online verbinding met de fabriek geprogrammeerd en correct aangemeld in de auto.', { multi: true }],
    ['retro.variantDefault', 'Optiepagina — “Afhankelijk van uitvoering?” (standaard)', 'Ja. Of deze optie mogelijk is, hangt af van bouwjaar, uitvoering en de systemen die al in uw auto aanwezig zijn.', { multi: true }],
    ['retro.priceNote', 'Optiepagina — opmerking bij een prijs', 'Prijs zoals vermeld door CarTronic. De definitieve prijs voor uw uitvoering bevestigen we bij uw aanvraag.', { multi: true }],
  ]],
  ['merken', 'Merken', [
    ['brands.eyebrow', 'Overzicht — bovenregel', 'Merken'],
    ['brands.title', 'Overzicht — titel', 'Volkswagen, Audi, SEAT en Škoda.'],
    ['brands.lead', 'Overzicht — introductie', 'Vier merken uit de Volkswagen-groep, met gedeelde techniek en fabriekssystemen. Daarin is CarTronic gespecialiseerd.', { multi: true }],
    ['brands.notice', 'Overzicht — melding onderaan', 'Staat uw model of generatie er niet bij? De online catalogus is een selectie. [Vraag naar de mogelijkheden](#/contact) — CarTronic bouwt opties in op vrijwel elk model van deze vier merken.', { multi: true }],
    ['brand.models.title', 'Merkpagina — titel modellen', 'Kies uw model'],
    ['brand.models.text', 'Merkpagina — tekst modellen', 'Per model en generatie ziet u welke opties in de online catalogus staan.'],
    ['brand.cta.title', 'Merkpagina — afsluitende titel', 'Ander {merk}-model?', { vars: ['merk'] }],
    ['brand.cta.text', 'Merkpagina — afsluitende tekst', 'De online catalogus is een selectie. Stuur uw kenteken en de gewenste optie — CarTronic controleert wat er mogelijk is.', { multi: true }],
  ]],
  ['projecten', 'Projecten', [
    ['projects.eyebrow', 'Bovenregel', 'Portfolio'],
    ['projects.title', 'Titel', 'Uit de werkplaats.'],
    ['projects.lead', 'Introductie', 'Originele upgrades en specialistische werkzaamheden, gefotografeerd in de CarTronic-werkplaats.', { multi: true }],
    ['projects.more.eyebrow', 'Meer werk — bovenregel', 'Meer van ons werk'],
    ['projects.more.title', 'Meer werk — titel', 'Ook deze auto’s kregen een upgrade.'],
    ['projects.note', 'Opmerking onderaan', 'Projecten blijven als referentie beschikbaar. Ze zijn geen overzicht van actuele levertijden of voorraad. Vraag naar de mogelijkheden voor uw auto.', { multi: true }],
  ]],
  ['expertise', 'Expertise', [
    ['exp.eyebrow', 'Bovenregel', 'Expertise & diensten'],
    ['exp.title', 'Titel', 'Van retrofit\ntot reparatie.', { multi: true }],
    ['exp.lead', 'Introductie', 'Originele fabrieksopties inbouwen, programmeren en kalibreren — en elektronische storingen oplossen. Voor Volkswagen, Audi, SEAT en Škoda.', { multi: true }],
    ['exp.tools.eyebrow', 'Uitrusting — bovenregel', 'Uitrusting'],
    ['exp.tools.title', 'Uitrusting — titel', 'Gereedschap\nop dealerniveau.', { multi: true }],
    ['exp.t1.title', 'Uitrusting 1 — titel', 'Diagnose op dealerniveau'],
    ['exp.t1.text', 'Uitrusting 1 — tekst', 'Voor storingszoeken en het controleren van de aanwezige systemen in uw auto.', { multi: true }],
    ['exp.t2.title', 'Uitrusting 2 — titel', 'Online verbinding met de fabriek'],
    ['exp.t2.text', 'Uitrusting 2 — tekst', 'Net als grote Volkswagen- en Audi-dealers hebben we toegang tot de online database van de fabriek.', { multi: true }],
    ['exp.t3.title', 'Uitrusting 3 — titel', 'Uitlijn- en kalibratieset'],
    ['exp.t3.text', 'Uitrusting 3 — tekst', 'Voor het afstellen van adaptieve cruisecontrol, Lane Assist en Night Vision — apparatuur die verder vooral bij grote dealers staat.', { multi: true }],
    ['exp.t4.title', 'Uitrusting 4 — titel', 'Originele OEM-onderdelen'],
    ['exp.t4.text', 'Uitrusting 4 — tekst', 'Gemonteerd volgens de fabrieksnormen en passend bij de systemen in uw auto.', { multi: true }],
    ['exp.dealer.eyebrow', 'Dealers — bovenregel', 'Voor dealers'],
    ['exp.dealer.title', 'Dealers — titel', 'Partner van de werkplaats.'],
    ['exp.dealer.text', 'Dealers — tekst', 'Een groot deel van onze klanten bestaat uit Audi-, Volkswagen-, SEAT- en Škoda-dealers. Voor retrofits, programmeerwerk en kalibratie die u liever uitbesteedt.', { multi: true }],
    ['exp.dealer.btn', 'Dealers — knop', 'Neem contact op', { control: true }],
  ]],
  ['over', 'Over CarTronic', [
    ['about.eyebrow', 'Bovenregel', 'Over CarTronic'],
    ['about.title', 'Titel', 'Vier merken.\nEén specialisme.', { multi: true, html: 'Vier merken.<br class="br-sm"> Eén specialisme.' }],
    ['about.lead', 'Introductie', 'Originele fabrieksopties achteraf inbouwen vraagt om kennis van de auto, de elektronica en de fabriekssystemen.', { multi: true }],
    ['about.intro.eyebrow', 'Verhaal — bovenregel', 'VAG-specialist in Rijswijk'],
    ['about.intro.title', 'Verhaal — titel', 'Van onderdeel\ntot onderdeel van uw auto.', { multi: true }],
    ['about.p1', 'Verhaal — alinea 1', 'CarTronic richt zich op Volkswagen, Audi, SEAT en Škoda. Onze werkplaats is ingericht voor het achteraf monteren van originele fabrieksopties, met diagnoseapparatuur op dealerniveau.', { multi: true }],
    ['about.p2', 'Verhaal — alinea 2', 'We werken voor particuliere klanten en dealers. De online verbinding met de fabriek maakt het mogelijk om geïnstalleerde opties te programmeren en correct aan te melden in de auto.', { multi: true }],
    ['about.p3', 'Verhaal — alinea 3', 'Voor het afstellen van adaptieve cruisecontrol, Lane Assist en Night Vision beschikken we over een complete uitlijn- en kalibratieset.', { multi: true, optional: true }],
    ['about.btn', 'Verhaal — knop', 'Bekijk onze expertise', { control: true }],
    ['about.f1.title', 'Kenmerk 1 — titel', 'Originele onderdelen'],
    ['about.f1.text', 'Kenmerk 1 — tekst', 'OEM-componenten en inbouw volgens de fabrieksnormen.', { multi: true }],
    ['about.f2.title', 'Kenmerk 2 — titel', 'Werkplaats voor 10 auto’s'],
    ['about.f2.text', 'Kenmerk 2 — tekst', 'Een ruime werkplaats met gespecialiseerde diagnoseapparatuur.', { multi: true }],
    ['about.f3.title', 'Kenmerk 3 — titel', 'Uitleg na de inbouw'],
    ['about.f3.text', 'Kenmerk 3 — tekst', 'Bij veel werkzaamheden kunt u wachten. Na afloop lichten we de werking van het systeem toe.', { multi: true }],
    ['about.note', 'Opmerking onderaan', 'Ruim 14 jaar ervaring met modellen uit de VAG-groep.\nKennis van de techniek én van de originele mogelijkheden.', { multi: true }],
  ]],
  ['contact', 'Contact', [
    ['contact.eyebrow', 'Bovenregel', 'Contact & aanvragen'],
    ['contact.title', 'Titel', 'Uw auto. Onze expertise.'],
    ['contact.lead', 'Introductie', 'Een optie laten inbouwen of een elektronische storing bespreken? Geef ons uw model en vraag door.', { multi: true }],
    ['contact.info.eyebrow', 'Gegevens — bovenregel', 'CarTronic · Rijswijk'],
    ['contact.info.title', 'Gegevens — titel', 'We horen graag van u.'],
    ['contact.info.lead', 'Gegevens — tekst', 'Vermeld bij een aanvraag uw merk, model, bouwjaar en bij voorkeur het kenteken. Zo kunnen we de juiste mogelijkheden voor uw auto bekijken.', { multi: true }],
    ['contact.waLabel', 'Gegevens — label bij WhatsApp', 'WhatsApp op ons vaste nummer'],
    ['contact.form.title', 'Formulier — titel', 'Stel uw vraag'],
    ['contact.form.sub', 'Formulier — ondertitel', 'Vul in wat u weet. Uw aanvraag opent daarna in WhatsApp of uw e-mailprogramma.', { multi: true }],
    ['contact.form.hint', 'Formulier — uitleg onderaan', 'Dit formulier verstuurt zelf geen gegevens: uw aanvraag opent in WhatsApp of uw e-mailprogramma, zodat u alles nog kunt controleren. Uw invoer wordt tijdelijk bewaard in deze browsersessie.', { multi: true }],
    ['topic.inbouw', 'Onderwerp: inbouw', 'Optie laten inbouwen'],
    ['topic.programmeren', 'Onderwerp: programmeren', 'Programmeren of software-update'],
    ['topic.kalibratie', 'Onderwerp: kalibratie', 'Kalibratie of reparatie rijhulpsystemen'],
    ['topic.storing', 'Onderwerp: storing', 'Storing, diagnose of module'],
    ['topic.optielijst', 'Onderwerp: optielijst', 'Optielijst van mijn auto (€ 10,00)'],
    ['topic.webshop', 'Onderwerp: webshop', 'Vraag over de webshop'],
    ['topic.anders', 'Onderwerp: overig', 'Iets anders'],
  ]],
  ['beoordelingen', 'Beoordelingen', [
    ['rev.eyebrow', 'Blok — bovenregel', 'Ervaringen van klanten'],
    ['rev.title', 'Blok — titel', 'Vakwerk wordt\ngewaardeerd.', { multi: true }],
    ['rev.more', 'Blok — link naar alle ervaringen', 'Lees meer ervaringen', { control: true }],
    ['reviews.eyebrow', 'Pagina — bovenregel', 'Beoordelingen'],
    ['reviews.title', 'Pagina — titel', 'Ervaringen van klanten.'],
    ['reviews.lead', 'Pagina — introductie', 'Klanten beoordelen CarTronic op {bron}. Hieronder ziet u de gemiddelde score en een selectie van hun ervaringen.', { multi: true, vars: ['bron'] }],
    ['reviews.write.title', 'Pagina — oproep, titel', 'Ook bij CarTronic geweest?'],
    ['reviews.write.text', 'Pagina — oproep, tekst', 'Deel uw ervaring op {bron}. Zo helpt u andere autobezitters bij hun keuze.', { multi: true, vars: ['bron'] }],
    ['reviews.write.btn', 'Pagina — oproep, knop', 'Schrijf een beoordeling', { control: true }],
    ['reviews.note', 'Pagina — bronvermelding', 'Score, aantal beoordelingen en citaten zoals gepubliceerd op {bron}. De citaten zijn letterlijk overgenomen; “…” markeert een inkorting.', { multi: true, vars: ['bron'] }],
  ]],
  ['kennis', 'Berichten & kennis', [
    ['kb.eyebrow', 'Bovenregel', 'Berichten & kennis'],
    ['kb.title', 'Titel', 'Weten hoe het werkt.'],
    ['kb.lead', 'Introductie', 'Korte uitleg over originele opties, programmeren en kalibreren — en over wat er voor uw auto mogelijk is.', { multi: true }],
    ['kb.aside.title', 'Bericht — kader, titel', 'Vraag het CarTronic'],
    ['kb.aside.text', 'Bericht — kader, tekst', 'Twijfelt u wat er voor uw auto mogelijk is? Stuur uw kenteken en uw vraag.', { multi: true }],
    ['kb.aside.btn', 'Bericht — kader, knop', 'Stel uw vraag', { control: true }],
  ]],
  ['productinfo', 'Productinformatie', [
    ['pi.eyebrow', 'Bovenregel', 'Productinformatie'],
    ['pi.title', 'Titel', 'Origineel, en goed om te weten.'],
    ['pi.lead', 'Introductie', 'Hoe CarTronic werkt met onderdelen, garantie en prijzen — en hoe u ziet of een optie bij uw auto past.', { multi: true }],
    ['pi.b1.title', 'Blok 1 — titel', 'Originele onderdelen'],
    ['pi.b1.text', 'Blok 1 — tekst', 'CarTronic werkt uitsluitend met originele OEM-onderdelen. Ze worden ingebouwd volgens de fabrieksnormen en passen bij de systemen in uw auto.', { multi: true }],
    ['pi.b2.title', 'Blok 2 — titel', 'Garantie'],
    ['pi.b2.text', 'Blok 2 — tekst', 'Bij de meeste opties in de catalogus staat de garantie vermeld, vaak 3 jaar. Staat er bij een optie geen garantie, vraag er dan naar bij uw aanvraag.', { multi: true }],
    ['pi.b3.title', 'Blok 3 — titel', 'Prijzen en aanbiedingen'],
    ['pi.b3.text', 'Blok 3 — tekst', 'De prijs hangt af van model, bouwjaar en uitvoering. Waar CarTronic een prijs of aanbieding publiceert, ziet u die bij de optie. Anders is de prijs op aanvraag.', { multi: true }],
    ['pi.b4.title', 'Blok 4 — titel', 'Geprogrammeerd en aangemeld'],
    ['pi.b4.text', 'Blok 4 — tekst', 'Een ingebouwde optie wordt via de online verbinding met de fabriek geprogrammeerd en correct aangemeld in de auto. Daarna werkt ze via de originele schermen, knoppen en menu’s.', { multi: true }],
    ['pi.fit.eyebrow', 'Compatibiliteit — bovenregel', 'Compatibiliteit'],
    ['pi.fit.title', 'Compatibiliteit — titel', 'Past het op\nmijn auto?', { multi: true }],
    ['pi.fit.lead', 'Compatibiliteit — tekst', 'Kies uw auto via het kenteken of merk en model. Bij elke optie ziet u dan een van deze statussen. CarTronic controleert de uitvoering van uw auto altijd vooraf.', { multi: true }],
    ['pi.st.ok', 'Status “Beschikbaar voor dit model”', 'De optie staat in de catalogus voor uw model en bouwjaar.', { multi: true }],
    ['pi.st.variant', 'Status “Uitvoering afhankelijk”', 'Mogelijk voor uw model; welke uitvoering nodig is, hangt af van de uitrusting van uw auto.', { multi: true }],
    ['pi.st.check', 'Status “Controle vereist”', 'Mogelijk voor uw merk of model, maar CarTronic controleert eerst uw uitvoering of bouwjaar.', { multi: true }],
    ['pi.st.contact', 'Status “Neem contact op”', 'Online staat een ander bouwjaar of een andere carrosserie vermeld. CarTronic bekijkt de mogelijkheden graag persoonlijk.', { multi: true }],
    ['pi.opt.eyebrow', 'Optielijst — bovenregel', 'Service'],
    ['pi.opt.title', 'Optielijst — titel', 'Welke opties heeft\nuw auto al?', { multi: true }],
    ['pi.opt.p1', 'Optielijst — alinea 1', 'CarTronic levert een optielijst van uw Audi, Volkswagen, SEAT of Škoda: een overzicht van de fabrieksopties op basis van het chassisnummer, als PDF of Word-bestand. Volgens CarTronic is dit mogelijk voor bouwjaren 1990 tot en met 2025.', { multi: true }],
    ['pi.opt.p2', 'Optielijst — alinea 2', '**Prijs: € 10,00.** Vraag de optielijst aan via WhatsApp, e-mail of het contactformulier en vermeld uw chassisnummer (VIN).', { multi: true }],
    ['pi.opt.link', 'Optielijst — link', 'Vraag een optielijst aan', { control: true }],
    ['pi.shop.title', 'Webshop — titel', 'Over de webshop.'],
    ['pi.shop.text', 'Webshop — tekst', 'De webshop in deze omgeving is een demonstratie: producten, prijzen, voorraad en betalingen zijn testgegevens en er wordt niets echt afgerekend. Een retrofit (inbouw in uw auto) bestelt u niet online; die vraagt u aan via de optie in de catalogus.', { multi: true }],
  ]],
  ['webshop', 'Webshop', [
    ['shop.eyebrow', 'Bovenregel', 'Webshop'],
    ['shop.title', 'Titel', 'Onderdelen en modules.'],
    ['shop.lead', 'Introductie', 'Originele onderdelen, modules en retrofit-sets. Let op: een product bestellen is iets anders dan een optie laten inbouwen — inbouw is alleen inbegrepen als dat bij het product staat.', { multi: true }],
    ['shop.notice.title', 'Testmelding — titel', 'Testomgeving.'],
    ['shop.notice.text', 'Testmelding — tekst', 'Producten en prijzen in deze webshop zijn demonstratiegegevens; betalingen worden gesimuleerd.', { multi: true }],
    ['shop.closed.title', 'Webshop uitgeschakeld — titel', 'De webshop is op dit moment niet beschikbaar.'],
    ['shop.closed.text', 'Webshop uitgeschakeld — tekst', 'Onderdelen en modules bestelt u op dit moment rechtstreeks bij CarTronic. Neem contact op, dan bekijken we wat er voor uw auto mogelijk is.', { multi: true }],
  ]],
  ['overig', 'Privacy & Mijn auto', [
    ['priv.eyebrow', 'Privacy — bovenregel', 'Privacy'],
    ['priv.title', 'Privacy — titel', 'Wat deze website bewaart.'],
    ['priv.lead', 'Privacy — introductie', 'Zonder account en zonder trackers. Wat u kiest en bewaart, blijft in uw eigen browser.', { multi: true }],
    ['priv.body', 'Privacy — tekst', '## In uw browser\nDeze website bewaart een aantal gegevens alleen in uw eigen browser (lokale opslag). Ze worden niet naar CarTronic of anderen verstuurd:\n- uw gekozen auto (merk, model, bouwjaar en uitvoering);\n- bewaarde opties en producten en recent bekeken pagina’s;\n- de inhoud van uw winkelmand;\n- demobestellingen die u in de testwebshop plaatst, met de naam, het e-mailadres, het telefoonnummer en het adres die u bij het afrekenen invult;\n- een kenteken, alleen in deze browsersessie en maximaal 24 uur;\n- concepten van het contact- en bestelformulier, alleen in deze browsersessie.\n## Kenteken opzoeken\nZoekt u uw auto op kenteken, dan vraagt de website de voertuiggegevens op bij RDW Open Data, de openbare database van de Rijksdienst voor het Wegverkeer. Daarvoor wordt alleen het kenteken verstuurd.\n## Contact via WhatsApp of e-mail\nHet contactformulier verstuurt zelf niets. Uw aanvraag opent in WhatsApp of in uw e-mailprogramma, zodat u alles kunt controleren voordat u het verstuurt.\n## Statistieken\nDeze versie van de website gebruikt geen trackingcookies en verstuurt geen statistieken.\n## Alles wissen\nU kunt alle gegevens die deze website in uw browser bewaart in één keer verwijderen.', { rich: true, html: "<h2>In uw browser</h2>\n          <p>Deze website bewaart een aantal gegevens alleen in uw eigen browser (lokale opslag). Ze worden niet naar CarTronic of anderen verstuurd:</p>\n          <ul>\n            <li>uw gekozen auto (merk, model, bouwjaar en uitvoering);</li>\n            <li>bewaarde opties en producten en recent bekeken pagina’s;</li>\n            <li>de inhoud van uw winkelmand;</li>\n            <li>demobestellingen die u in de testwebshop plaatst, met de naam, het e-mailadres, het telefoonnummer en het adres die u bij het afrekenen invult;</li>\n            <li>een kenteken, alleen in deze browsersessie en maximaal 24 uur;</li>\n            <li>concepten van het contact- en bestelformulier, alleen in deze browsersessie.</li>\n          </ul>\n          <h2>Kenteken opzoeken</h2>\n          <p>Zoekt u uw auto op kenteken, dan vraagt de website de voertuiggegevens op bij RDW Open Data, de openbare database van de Rijksdienst voor het Wegverkeer. Daarvoor wordt alleen het kenteken verstuurd.</p>\n          <h2>Contact via WhatsApp of e-mail</h2>\n          <p>Het contactformulier verstuurt zelf niets. Uw aanvraag opent in WhatsApp of in uw e-mailprogramma, zodat u alles kunt controleren voordat u het verstuurt.</p>\n          <h2>Statistieken</h2>\n          <p>Deze versie van de website gebruikt geen trackingcookies en verstuurt geen statistieken.</p>\n          <h2>Alles wissen</h2>\n          <p>U kunt alle gegevens die deze website in uw browser bewaart in één keer verwijderen.</p>" }],
    ['priv.aside.title', 'Privacy — kader, titel', 'Vragen?'],
    ['garage.eyebrow', 'Mijn auto — bovenregel', 'Mijn auto'],
    ['garage.title', 'Mijn auto — titel', 'Uw auto en bewaarde opties.'],
    ['garage.lead', 'Mijn auto — introductie', 'Alles wat u heeft gekozen, bewaard en bekeken. Zonder account — alleen opgeslagen in deze browser.', { multi: true }],
  ]],
];
const TEXT = Object.create(null);
TEXT_GROUPS.forEach(([gid, , rows]) => rows.forEach(([key, label, def, opts = {}]) => { TEXT[key] = { key, group: gid, label, def, ...opts }; }));

/* ---------- Text formatting ---------- */
const SAFE_HREF = /^(#\/(?![/\\])|\/(?![/\\])|https:\/\/|http:\/\/|mailto:|tel:)/i;
/* Browsers drop tabs and line breaks inside an address, so "/<tab>/host" would lead off-site: refused. */
const CONTROL_CHARS = /[\u0000-\u001F\u007F]/;
/** Plain text → safe HTML: escapes, then **bold**, [label](address) and line breaks.
    noLinks: for texts inside a button or link (a link cannot contain another link). */
function fmtText(s, noLinks = false) {
  return esc(s)
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\[([^\]\n]+)\]\(([^)\s]+)\)/g, (m, label, url) => {
      const raw = url.replace(/&amp;/g, '&');
      if (noLinks || !SAFE_HREF.test(raw) || CONTROL_CHARS.test(raw)) return label;
      const href = raw.startsWith('/') ? `#${raw}` : raw;
      const ext = /^https?:/i.test(href);
      return `<a class="text-link" href="${attr(href)}"${ext ? ' target="_blank" rel="noopener"' : ''}>${label}</a>`;
    })
    .replace(/\r?\n/g, '<br>');
}
/** Markup-free version of a text (for attributes, titles and search). */
function plainText(s) {
  return String(s == null ? '' : s).replace(/\*\*(.+?)\*\*/g, '$1').replace(/\[([^\]\n]+)\]\(([^)\s]+)\)/g, '$1').replace(/\s*\r?\n\s*/g, ' ').trim();
}
/* Rich text: "## Kop", "- opsommingsteken", lege regel = nieuwe alinea. */
function parseRich(src) {
  const blocks = [];
  let para = []; let list = null;
  const flushPara = () => { if (para.length) { blocks.push(['p', para.join(' ')]); para = []; } };
  const flushList = () => { if (list) { blocks.push(['ul', list]); list = null; } };
  String(src || '').split(/\r?\n/).forEach((line) => {
    const t = line.trim();
    if (!t) { flushPara(); flushList(); return; }
    if (t.startsWith('## ')) { flushPara(); flushList(); blocks.push(['h', t.slice(3).trim()]); return; }
    if (/^[-*] /.test(t)) { flushPara(); (list = list || []).push(t.slice(2).trim()); return; }
    flushList(); para.push(t);
  });
  flushPara(); flushList();
  return blocks.filter(([k, c]) => (k === 'ul' ? c.length : String(c).trim()));
}
function richSource(blocks) {
  return (blocks || []).map(([k, c]) => (k === 'h' ? `## ${c}` : k === 'ul' ? c.map((li) => `- ${li}`).join('\n') : c)).join('\n\n');
}
// Paragraphs and list items take **bold** and [links](/pagina) too; headings are plain text.
const richBlockHtml = ([t, c]) => (t === 'h' ? `<h2>${esc(c)}</h2>` : t === 'ul' ? `<ul>${c.map((li) => `<li>${fmtText(li)}</li>`).join('')}</ul>` : `<p>${fmtText(c)}</p>`);

/* ---------- Content store ---------- */
const Content = (() => {
  const str = (v, max = 4000) => (typeof v === 'string' ? v.slice(0, max) : '');
  const strList = (v, max = 60, len = 600) => (Array.isArray(v) ? v.filter((x) => typeof x === 'string' && x.trim()).slice(0, max).map((x) => x.trim().slice(0, len)) : []);
  const isSlug = (s) => typeof s === 'string' && /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(s) && s.length <= 120;
  const isImageRef = (s) => typeof s === 'string' && (/^[a-z0-9_]+$/i.test(s) || /^(img:[a-z0-9_]+|https:\/\/[^\s"'<>]+|data:image\/(png|jpeg|webp);base64,[a-z0-9+/=]+)$/i.test(s));
  const safeHref = (s) => {
    if (typeof s !== 'string') return '';
    const v = s.trim();
    if (!SAFE_HREF.test(v) || CONTROL_CHARS.test(v)) return '';
    return v.startsWith('/') ? `#${v}` : v;
  };
  const httpsUrl = (s) => (typeof s === 'string' && /^https:\/\/[^\s"'<>]+$/i.test(s.trim()) ? s.trim() : '');
  const plainObj = (o) => !!o && typeof o === 'object' && !Array.isArray(o);
  /** The website address as "https://host" or "https://host/sub/map" (lower-case host, no slash at the end),
      or '' when it cannot be used: no ?, # or login, and a sub-path of plain letters, digits, - and _ only
      (it also becomes a folder name in the published zip). */
  function siteAddress(v) {
    if (typeof v !== 'string' || !v.trim() || /[\s"'<>\\]/.test(v.trim())) return '';
    let u;
    try { u = new URL(v.trim()); } catch (e) { return ''; }
    if (!/^https?:$/.test(u.protocol) || !u.hostname || u.username || u.password || u.search || u.hash || /[?#]/.test(v)) return '';
    const path = u.pathname.replace(/\/+$/, '');
    // Folder names only (no file names such as index.html), and not "admin", which is the address of Beheer.
    if (path && (!/^(\/[A-Za-z0-9_-]+)+$/.test(path) || /(^|\/)admin(\/|$)/i.test(path))) return '';
    return `${u.origin}${path}`;
  }
  const ownKey = (o, k) => !!o && Object.prototype.hasOwnProperty.call(o, k);
  /** An image of a product or project: a known illustration or embedded photo, a web address or an
      uploaded photo. (Only called after start-up: ART_SHAPES is defined further on.) */
  function isMediaRef(s) {
    if (typeof s !== 'string' || s.length > 3000000) return false;
    let m = s.match(/^art:([a-z]{1,30}):[0-9]$/i);
    if (m) return ownKey(ART_SHAPES, m[1]);
    m = s.match(/^img:([a-z0-9_]{1,60})$/i);
    if (m) return ownKey(window.CT_IMAGES, m[1]);
    return /^https?:\/\/[^\s"'<>]+$/i.test(s) || /^data:image\/(png|jpeg|webp);base64,[a-z0-9+/=]+$/i.test(s);
  }
  /* Webshop limits, shared by the forms in Beheer and the cleaning of published data, so whatever
     a form accepts is published unchanged. */
  const LIMITS = {
    productName: 160, productShort: 600, productDescription: 12000, productNote: 600, productImages: 12,
    projectTitle: 160, projectVehicle: 120, projectTag: 60, projectShort: 400, projectBody: 6000, projectImages: 12,
    shipLabel: 80, shipDescription: 200,
  };

  /* Defaults, captured before anything is applied. */
  const P = {
    company: deepClone(COMPANY),
    brands: Object.fromEntries(BRANDS.map((b) => [b.id, { intro: b.intro }])),
    categories: Object.fromEntries(CATEGORIES.map((c) => [c.id, { name: c.name, tagline: c.tagline, text: c.text }])),
    categoryCopy: deepClone(CATEGORY_COPY),
    services: deepClone(SERVICES),
    serviceTopic: { ...SERVICE_TOPIC },
    articles: deepClone(ARTICLES),
    reviews: deepClone(REVIEWS),
    moreWork: deepClone(MORE_WORK),
    retrofits: deepClone(RETROFITS),
    aliases: { ...RETROFIT_ALIAS },
  };
  P.company.facebook = FACEBOOK_URL;
  P.company.social = [];
  P.company.kvk = '';
  P.company.whatsappDisplay = '';
  P.company.vat = '';
  const PR = byKey(P.retrofits, 'slug');

  const OPTIONAL_COMPANY = ['facebook', 'kvk', 'vat', 'whatsappDisplay'];
  const URL_COMPANY = ['mapsUrl', 'website', 'facebook'];
  const COMPANY_FIELDS = ['name', 'street', 'postal', 'city', 'phoneDisplay', 'phoneHref', 'whatsapp', 'whatsappDisplay', 'email', 'mapsUrl', 'website', 'facebook', 'kvk', 'vat'];
  const DISPLAY_DEFAULTS = {
    sections: { 'home.brands': true, 'home.finder': true, 'home.categories': true, 'home.services': true, 'home.tech': true, 'home.projects': true, 'home.reviews': true, 'home.shop': true, cta: true, recent: true },
    shop: true,
    footerAdmin: true,
    announcement: { on: false, text: '', linkLabel: '', link: '', tone: 'dark' },
  };
  const SEO_DEFAULTS = {
    siteUrl: 'https://www.cartronic.nl', suffix: ' | CarTronic',
    homeTitle: 'CarTronic — Originele fabrieksopties voor Volkswagen, Audi, SEAT en Škoda',
    description: 'CarTronic in Rijswijk bouwt originele fabrieksopties achteraf in voor Volkswagen, Audi, SEAT en Škoda: vakkundig gemonteerd, geprogrammeerd en afgestemd.',
    ogTitle: 'CarTronic — Origineel. Tot in detail.',
    ogDescription: 'Originele fabrieksopties voor Volkswagen, Audi, SEAT en Škoda. Vakkundig ingebouwd, geprogrammeerd en afgestemd op uw auto.',
    noindex: false, google: '', bing: '', pages: {},
  };

  /* ---------- Cleaning: every section of a bundle is validated independently ---------- */
  function cleanCompany(c) {
    if (!plainObj(c)) return {};
    const out = {};
    COMPANY_FIELDS.forEach((k) => {
      if (typeof c[k] !== 'string') return;
      if (c[k].trim()) out[k] = c[k].trim().slice(0, URL_COMPANY.includes(k) ? 2000 : 300); // route links can be long
      else if (OPTIONAL_COMPANY.includes(k)) out[k] = ''; // optional fields may be cleared
    });
    if (out.phoneHref && !/^tel:\+?[0-9]{6,16}$/.test(out.phoneHref)) delete out.phoneHref;
    if (out.whatsapp && !/^[0-9]{8,15}$/.test(out.whatsapp)) delete out.whatsapp;
    if (out.email && !/^[^\s@<>"]+@[^\s@<>"]+\.[^\s@<>"]{2,}$/.test(out.email)) delete out.email;
    ['mapsUrl', 'website', 'facebook'].forEach((k) => { if (out[k] && !httpsUrl(out[k])) delete out[k]; });
    if (Array.isArray(c.hours)) {
      const rows = c.hours.filter((r) => Array.isArray(r) && typeof r[0] === 'string' && typeof r[1] === 'string' && r[0].trim()).slice(0, 10).map((r) => [r[0].trim().slice(0, 60), r[1].trim().slice(0, 60)]);
      if (rows.length) out.hours = rows;
    }
    if (Array.isArray(c.social)) out.social = c.social.map(httpsUrl).filter(Boolean).slice(0, 8);
    return out;
  }
  function cleanService(s) {
    if (!plainObj(s) || !isSlug(s.slug) || s.slug === 'nieuw' || !str(s.title).trim()) return null;
    const title = str(s.title, 160).trim();
    const short = str(s.short, 400).trim() || title;
    const body = strList(s.body, 20, 3000);
    return {
      slug: s.slug, title, icon: ICON_PATHS[s.icon] ? s.icon : 'wrench',
      card: str(s.card, 80).trim() || title, cardText: str(s.cardText, 600).trim() || short,
      points: strList(s.points, 6, 160), short, body: body.length ? body : [short],
      cta: [str(Array.isArray(s.cta) ? s.cta[0] : '', 80).trim() || 'Meer informatie', safeHref(Array.isArray(s.cta) ? s.cta[1] : '') || `#/diensten/${s.slug}`],
      keywords: strList(s.keywords, 30, 60), cats: strList(s.cats, 10, 40).filter((c) => CATEGORY[c]),
      ...(isImageRef(s.image) ? { image: s.image } : {}),
      ...(typeof s.topic === 'string' && (s.topic === '' || ENQUIRY_TOPIC[s.topic]) ? { topic: s.topic } : {}),
    };
  }
  function cleanArticle(a) {
    if (!plainObj(a) || !isSlug(a.slug) || a.slug === 'nieuw' || !str(a.title).trim()) return null;
    const body = (Array.isArray(a.body) ? a.body : []).filter((b) => Array.isArray(b) && (
      (['p', 'h'].includes(b[0]) && typeof b[1] === 'string' && b[1].trim()) || (b[0] === 'ul' && strList(b[1]).length)))
      .slice(0, 80).map((b) => (b[0] === 'ul' ? ['ul', strList(b[1], 40, 600)] : [b[0], b[1].trim().slice(0, 3000)]));
    const short = str(a.short, 400).trim();
    return {
      slug: a.slug, tag: str(a.tag, 40).trim() || 'Kennis', icon: ICON_PATHS[a.icon] ? a.icon : 'info', title: str(a.title, 160).trim(),
      keywords: strList(a.keywords, 30, 60), short: short || str(a.title, 160).trim(), body: body.length ? body : [['p', short || a.title]],
      links: (Array.isArray(a.links) ? a.links : []).filter((l) => Array.isArray(l) && str(l[0]).trim() && safeHref(l[1])).slice(0, 6).map((l) => [l[0].trim().slice(0, 80), safeHref(l[1])]),
    };
  }
  function cleanReviews(r) {
    if (!plainObj(r)) return null;
    const out = {};
    if (/^\d{1,2}([.,]\d)?$/.test(str(r.score).trim())) out.score = r.score.trim().replace('.', ',');
    if (Number.isInteger(r.scale) && r.scale >= 5 && r.scale <= 10) out.scale = r.scale;
    if (Number.isInteger(r.count) && r.count >= 0 && r.count < 1e6) out.count = r.count;
    if (str(r.source).trim()) out.source = r.source.trim().slice(0, 60);
    if (httpsUrl(r.url)) out.url = httpsUrl(r.url);
    if (httpsUrl(r.writeUrl)) out.writeUrl = httpsUrl(r.writeUrl);
    if (Array.isArray(r.items)) {
      out.items = r.items.filter((it) => plainObj(it) && str(it.text).trim() && str(it.name).trim()).slice(0, 40).map((it) => ({
        title: str(it.title, 120).trim(), name: str(it.name, 60).trim(), place: str(it.place, 60).trim(),
        date: /^\d{4}-\d{2}-\d{2}$/.test(str(it.date)) ? it.date : '', score: Number.isFinite(Number(it.score)) ? clamp(Math.round(Number(it.score)), 1, 10) : 10,
        text: str(it.text, 1500).trim(),
      }));
    }
    return out;
  }
  function cleanMoreWork(list) {
    if (!Array.isArray(list)) return null;
    return list.filter((m) => plainObj(m) && str(m.title).trim()).slice(0, 24).map((m) => ({
      title: str(m.title, 120).trim(), text: str(m.text, 800).trim(),
      links: (Array.isArray(m.links) ? m.links : []).filter((l) => Array.isArray(l) && str(l[0]).trim() && safeHref(l[1])).slice(0, 4).map((l) => [l[0].trim().slice(0, 80), safeHref(l[1])]),
    }));
  }
  const RETROFIT_TEXT = ['title', 'name', 'short', 'variantNote', 'warranty', 'price', 'offer', 'imageNote'];
  /** Validates option fields from a bundle (edits or new options). Unknown fields are dropped. */
  function cleanRetrofitFields(e) {
    const out = {};
    if (!plainObj(e)) return out;
    RETROFIT_TEXT.forEach((k) => { if (typeof e[k] === 'string') out[k] = e[k].trim().slice(0, k === 'short' || k === 'variantNote' ? 1200 : 200); });
    if (typeof e.cat === 'string' && CATEGORY[e.cat]) out.cat = e.cat;
    if (e.brand === null || (typeof e.brand === 'string' && BRAND[e.brand])) out.brand = e.brand;
    if (Array.isArray(e.models)) out.models = uniq(e.models.filter((m) => typeof m === 'string' && MODEL[m]));
    if (e.scope === 'brand' || e.scope === 'model') out.scope = e.scope;
    if (Array.isArray(e.brands)) out.brands = uniq(e.brands.filter((b) => typeof b === 'string' && BRAND[b]));
    if (e.years === null) out.years = null;
    else if (Array.isArray(e.years) && e.years.length === 2 && e.years.every((y) => Number.isInteger(y) && y >= 1950 && y <= 2100) && e.years[0] <= e.years[1]) out.years = [e.years[0], e.years[1]];
    if (Array.isArray(e.specs)) out.specs = e.specs.filter((r) => Array.isArray(r) && str(r[0]).trim() && str(r[1]).trim()).slice(0, 20).map((r) => [r[0].trim().slice(0, 60), r[1].trim().slice(0, 300)]);
    if (Array.isArray(e.keywords)) out.keywords = strList(e.keywords, 40, 60);
    if (e.image === '' || isImageRef(e.image)) out.image = e.image;
    if (typeof e.feature === 'string' && (e.feature === '' || FEATURES[e.feature])) out.feature = e.feature;
    if (typeof e.art === 'string' && /^[a-zA-Z]+$/.test(e.art)) out.art = e.art;
    if (plainObj(e.yearsByModel)) {
      const y = Object.entries(e.yearsByModel).filter(([m, v]) => MODEL[m] && Array.isArray(v) && v.length === 2
        && v.every((n) => Number.isInteger(n) && n >= 1950 && n <= 2100) && v[0] <= v[1]);
      if (y.length) out.yearsByModel = Object.fromEntries(y.map(([m, v]) => [m, [v[0], v[1]]]));
    }
    if (typeof e.body === 'string' && /^[a-z]{1,30}$/.test(e.body)) out.body = e.body;
    return out;
  }
  /** A new option from Beheer as a complete catalog entry, or null when it is incomplete. */
  function buildAdded(a) {
    if (!plainObj(a) || !isSlug(a.slug) || a.slug === 'nieuw' || PR[a.slug]) return null;
    const item = { slug: a.slug, models: [], keywords: [], ...cleanRetrofitFields(a), added: true };
    if (item.scope === 'brand') { item.models = []; if (!item.brands || !item.brands.length) return null; item.brand = item.brands.length === 1 ? item.brands[0] : null; }
    else { delete item.scope; delete item.brands; }
    if (!item.feature) delete item.feature;
    if (!str(item.name).trim()) item.name = item.title;
    if (!retrofitOk(item)) return null;
    normalizeRetrofit(item);
    return item;
  }
  /** Checks that an option can be rendered everywhere (brand, models and category exist). */
  function retrofitOk(r) {
    if (!r || !isSlug(r.slug) || !CATEGORY[r.cat] || !str(r.title).trim() || !str(r.name).trim() || !Array.isArray(r.models)) return false;
    if (r.scope === 'brand') {
      if (r.brand && !BRAND[r.brand]) return false;
      const brands = r.brands || (r.brand ? [r.brand] : []);
      return brands.length > 0 && brands.every((b) => BRAND[b]);
    }
    return !!BRAND[r.brand] && r.models.length > 0 && r.models.every((m) => MODEL[m] && MODEL[m].brand === r.brand);
  }

  /* Webshop data (products, categories, projects, settings) travels with a publication too. */
  const PRODUCT_BASE = {
    sku: '', shortDescription: '', description: '', category: '', brand: '', model: '', stock: 0,
    discountType: 'none', salePrice: null, discountValue: null, startDate: '', endDate: '',
    trackStock: true, active: true, featured: false, archived: false, isDemo: false, type: 'PHYSICAL_PRODUCT', installationIncluded: false,
  };
  function cleanSettings(s) {
    const d = deepClone(DEFAULT_SETTINGS);
    delete d.orderSeq;
    if (!plainObj(s)) return d;
    if (Array.isArray(s.shipping)) {
      const ship = s.shipping.filter((m) => plainObj(m) && typeof m.id === 'string' && str(m.label).trim() && Number.isInteger(m.price) && m.price >= 0)
        .map((m) => ({ id: m.id, label: m.label.slice(0, LIMITS.shipLabel), description: str(m.description, LIMITS.shipDescription), price: m.price, enabled: m.enabled !== false, requiresAddress: m.requiresAddress === true }));
      if (ship.some((m) => m.enabled)) d.shipping = ship;
    }
    if (plainObj(s.vat)) {
      if (Number.isInteger(s.vat.rate) && s.vat.rate >= 0 && s.vat.rate <= 50) d.vat.rate = s.vat.rate;
      if (typeof s.vat.showBreakdown === 'boolean') d.vat.showBreakdown = s.vat.showBreakdown;
    }
    if (Number.isInteger(s.lowStockThreshold) && s.lowStockThreshold >= 0 && s.lowStockThreshold <= 999) d.lowStockThreshold = s.lowStockThreshold;
    if (['live', 'demo'].includes(s.vehicleLookupMode)) d.vehicleLookupMode = s.vehicleLookupMode;
    return d;
  }
  const bool = (v, d) => (typeof v === 'boolean' ? v : d);
  const intOr = (v, d, min = 0) => (Number.isInteger(v) && v >= min ? v : d);
  const isDay = (v) => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v);
  /** A product exactly in the shape the shop pages use; unknown fields are dropped. */
  function cleanProduct(p) {
    const c = plainObj(p.compatibility) ? p.compatibility : {};
    return {
      ...PRODUCT_BASE, id: p.id, slug: p.slug, name: p.name.trim().slice(0, LIMITS.productName),
      sku: str(p.sku, 40), shortDescription: str(p.shortDescription, LIMITS.productShort), description: str(p.description, LIMITS.productDescription),
      category: str(p.category, 80), brand: BRAND[p.brand] ? p.brand : '', model: MODEL[p.model] ? p.model : '',
      regularPrice: p.regularPrice,
      discountType: ['none', 'sale', 'percent', 'fixed'].includes(p.discountType) ? p.discountType : 'none',
      salePrice: intOr(p.salePrice, null, 1), discountValue: intOr(p.discountValue, null, 1),
      startDate: isDay(p.startDate) ? p.startDate : '', endDate: isDay(p.endDate) ? p.endDate : '',
      trackStock: bool(p.trackStock, true), stock: intOr(p.stock, 0),
      active: bool(p.active, true), featured: bool(p.featured, false), archived: bool(p.archived, false), isDemo: bool(p.isDemo, false),
      type: PRODUCT_TYPES[p.type] ? p.type : 'PHYSICAL_PRODUCT', installationIncluded: bool(p.installationIncluded, false),
      images: (Array.isArray(p.images) ? p.images : []).filter(isMediaRef).slice(0, LIMITS.productImages),
      compatibility: { brands: strList(c.brands, 8, 40).filter((b) => BRAND[b]), models: strList(c.models, 80, 40).filter((m) => MODEL[m]), note: str(c.note, LIMITS.productNote) },
      createdAt: str(p.createdAt, 40) || null, updatedAt: str(p.updatedAt, 40) || null,
    };
  }
  /** A portfolio project in the shape the project pages use. */
  function cleanProject(p) {
    return {
      id: p.id, slug: p.slug, title: p.title.trim().slice(0, LIMITS.projectTitle), vehicle: str(p.vehicle, LIMITS.projectVehicle), tag: str(p.tag, LIMITS.projectTag),
      short: str(p.short, LIMITS.projectShort), body: str(p.body, LIMITS.projectBody), type: str(p.type, 60), active: p.active !== false,
      image: isMediaRef(p.image) ? p.image : '', before: isMediaRef(p.before) ? p.before : '', after: isMediaRef(p.after) ? p.after : '',
      brands: strList(p.brands, 8, 40).filter((b) => BRAND[b]), models: strList(p.models, 40, 40).filter((m) => MODEL[m]),
      related: strList(p.related, 10, 120), services: strList(p.services, 10, 120),
      ...(Array.isArray(p.gallery) ? { gallery: p.gallery.filter(isMediaRef).slice(0, LIMITS.projectImages) } : {}),
    };
  }
  function cleanShop(sh) {
    if (!plainObj(sh) || !Array.isArray(sh.products) || !Array.isArray(sh.shopCategories)) return null;
    const cats = sh.shopCategories.filter((c) => plainObj(c) && typeof c.id === 'string' && str(c.name).trim())
      .map((c, i) => ({ id: c.id, name: c.name.slice(0, 60), slug: isSlug(c.slug) ? c.slug : slugify(c.name), order: Number.isFinite(c.order) ? c.order : i + 1 }));
    const products = sh.products.filter((p) => plainObj(p) && typeof p.id === 'string' && isSlug(p.slug) && str(p.name).trim() && Number.isInteger(p.regularPrice) && p.regularPrice > 0)
      .map(cleanProduct);
    const projects = Array.isArray(sh.projects) ? sh.projects.filter((p) => plainObj(p) && typeof p.id === 'string' && isSlug(p.slug) && str(p.title).trim())
      .map(cleanProject) : deepClone(DEFAULT_PROJECTS);
    return { products, shopCategories: cats, projects, settings: cleanSettings(sh.settings) };
  }

  /* ---------- Bundles ---------- */
  function readPublished() {
    try {
      const el = document.getElementById('ctContent');
      const data = el ? JSON.parse(el.textContent || '{}') : {};
      return plainObj(data) ? data : {};
    } catch (e) { console.error('Gepubliceerde inhoud kon niet worden gelezen', e); return {}; }
  }
  const published = readPublished();
  const pubStamp = typeof published.stamp === 'string' ? published.stamp : '';
  /* The newest publication opened in this browser (stamps are ISO times; '' = the unpublished starting file).
     A page with an older publication, or a tab that is open while another tab opens a different one, is
     outdated: it keeps its own view, and saving and publishing stop until the editor works on in the newest
     version (or explicitly chooses this one, see adoptVersion). Written before the draft is read below, so
     other tabs hear about it before anything else. */
  const newest = Storage.get('newestStamp', null);
  // Only for an editor: a visitor always gets the publication of the page they open (also after a rollback).
  let stale = Storage.get('editor', false) === true && typeof newest === 'string' && newest > pubStamp;
  if (!stale) Storage.set('newestStamp', pubStamp);
  // Cleaned on first use (Repo.init), when every part of the page script is ready.
  let pubShop; let pubShopRead = false;
  function readPubShop() {
    if (!pubShopRead) { pubShopRead = true; try { pubShop = cleanShop(published.shop); } catch (e) { pubShop = null; console.error(e); } }
    return pubShop;
  }
  /** The content of a bundle, normalised so that saving a screen without changes never counts as a change:
      empty containers, values equal to the defaults and lists equal to the built-in lists are left out. */
  function contentOf(b) {
    const o = { ...(plainObj(b) ? b : {}) };
    ['stamp', 'base', 'baseFp', 'updatedAt', 'shop', 'v'].forEach((k) => delete o[k]);
    const same = (a, c) => stableStringify(a) === stableStringify(c);
    const isEmpty = (v) => (Array.isArray(v) ? !v.length : plainObj(v) && !Object.keys(v).length);
    const prune = (obj, defaults) => {
      const r = { ...obj };
      Object.keys(r).forEach((k) => {
        if (defaults && k in defaults && plainObj(defaults[k]) && plainObj(r[k])) r[k] = prune(r[k], defaults[k]);
        if (isEmpty(r[k]) || (defaults && k in defaults && same(r[k], defaults[k]))) delete r[k];
      });
      return r;
    };
    try {
      ['texts', 'company', 'categories', 'brands'].forEach((k) => { if (isEmpty(o[k])) delete o[k]; });
      if (plainObj(o.retrofits)) {
        // Hidden options are a set: the order in which they were hidden is no change.
        const r = { ...o.retrofits };
        if (Array.isArray(r.hide)) r.hide = uniq(r.hide.filter((x) => typeof x === 'string')).sort();
        o.retrofits = prune(r);
      }
      if (plainObj(o.seo)) o.seo = prune(o.seo, SEO_DEFAULTS);
      if (plainObj(o.display)) o.display = prune(o.display, DISPLAY_DEFAULTS);
      const services = (list) => list.map(cleanService).filter(Boolean).map((s) => ({ ...s, topic: 'topic' in s ? s.topic : (P.serviceTopic[s.slug] || '') }));
      if (Array.isArray(o.services) && same(services(o.services), services(P.services))) delete o.services;
      if (Array.isArray(o.articles) && same(o.articles.map(cleanArticle).filter(Boolean), P.articles.map(cleanArticle))) delete o.articles;
      if (plainObj(o.reviews) && same({ ...P.reviews, ...cleanReviews(o.reviews) }, P.reviews)) delete o.reviews;
      if (Array.isArray(o.moreWork) && same(cleanMoreWork(o.moreWork), cleanMoreWork(P.moreWork))) delete o.moreWork;
      // Empty means "nothing changed" for these; an empty list of articles or portfolio cards is a real choice.
      ['texts', 'company', 'categories', 'brands', 'retrofits', 'seo', 'display', 'reviews', 'services'].forEach((k) => { if (isEmpty(o[k])) delete o[k]; });
    } catch (e) { console.error(e); }
    return o;
  }
  const isEditor = () => Storage.get('editor', false) === true;
  let draft = null;
  /* A draft based on an older publication is parked: it is only used once the editor chooses so. */
  let parked = false;
  /** Reads the editor's draft from storage (also when another tab changed it). */
  /** Short fingerprint of a bundle's content (what contentOf keeps). */
  function contentFp(b) {
    const str = stableStringify(contentOf(b));
    let h1 = 0xdeadbeef; let h2 = 0x41c6ce57;
    for (let i = 0; i < str.length; i++) { const ch = str.charCodeAt(i); h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677); }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return `${str.length}:${(h2 >>> 0).toString(36)}${(h1 >>> 0).toString(36)}`;
  }
  function syncDraft() {
    const s = isEditor() ? Storage.get('siteDraft', null) : null;
    draft = plainObj(s) ? s : null;
    parked = false;
    // On the unpublished starting file ('' = no publication) a draft is simply the editor's work: never parked.
    if (draft && (draft.base || '') !== pubStamp && !(pubStamp === '' && !stale)) {
      // Equal to this publication: nothing to decide. It now counts as based on this publication (kept, not
      // deleted), so after a later rollback it is not silently taken for unpublished changes.
      if (stableStringify(contentOf(draft)) === stableStringify(contentOf(published))) {
        if (!stale && isEditor()) { draft.base = pubStamp; draft.baseFp = contentFp(published); Storage.set('siteDraft', draft); }
        draft = null;
      } else if (typeof draft.baseFp === 'string' && draft.baseFp === contentFp(draft)) {
        // No edits since the publication it was based on (e.g. after a rollback, or a save without changes):
        // nothing of the editor's to keep, so this publication simply applies.
        if (!stale && isEditor()) Storage.remove('siteDraft');
        draft = null;
      } else parked = true;
    }
  }
  syncDraft();
  const active = () => (draft && !parked ? draft : published);

  /* ---------- Apply: defaults first, then the active bundle ---------- */
  let texts = {};
  let display = deepClone(DISPLAY_DEFAULTS);
  let seo = deepClone(SEO_DEFAULTS);
  const issues = [];
  function section(name, fn) { try { fn(); } catch (e) { issues.push(name); console.error(`Inhoud "${name}" overgeslagen`, e); } }
  function resetMap(map, entries) { Object.keys(map).forEach((k) => delete map[k]); entries.forEach(([k, v]) => { map[k] = v; }); }

  function apply({ initial = false, external = false } = {}) {
    const b = active();
    issues.length = 0;
    section('texts', () => {
      texts = {};
      if (plainObj(b.texts)) Object.keys(b.texts).forEach((k) => { if (TEXT[k] && typeof b.texts[k] === 'string') texts[k] = b.texts[k].slice(0, 12000); });
    });
    section('company', () => {
      Object.keys(COMPANY).forEach((k) => delete COMPANY[k]);
      Object.assign(COMPANY, deepClone(P.company), cleanCompany(b.company));
    });
    section('brands', () => BRANDS.forEach((br) => {
      const o = plainObj(b.brands) ? b.brands[br.id] : null;
      br.intro = (o && str(o.intro, 600).trim()) || P.brands[br.id].intro;
    }));
    section('categories', () => {
      CATEGORIES.forEach((c) => {
        const o = (plainObj(b.categories) && plainObj(b.categories[c.id])) ? b.categories[c.id] : {};
        ['name', 'tagline', 'text'].forEach((k) => { c[k] = str(o[k], 300).trim() || P.categories[c.id][k]; });
        const copy = deepClone(P.categoryCopy[c.id] || {});
        // An empty programme or calibration text is a deliberate choice: the general text is used, or the block disappears.
        ['install', 'program', 'calibrate'].forEach((k) => {
          if (typeof o[k] !== 'string') return;
          const t = o[k].trim().slice(0, 1500);
          if (t || k !== 'install') copy[k] = t;
        });
        const ben = strList(o.benefits, 8, 200);
        if (ben.length) copy.benefits = ben;
        CATEGORY_COPY[c.id] = copy;
      });
      PROJECT_TYPES.forEach((t) => { if (CATEGORY[t.id]) t.name = CATEGORY[t.id].name; });
    });
    section('topics', () => ENQUIRY_TOPICS.forEach((t) => { if (TEXT[`topic.${t.id}`]) t.label = plainText(rawText(`topic.${t.id}`)); }));
    section('services', () => {
      const list = Array.isArray(b.services) ? b.services.map(cleanService).filter(Boolean) : [];
      const seen = new Set();
      const final = (list.length ? list : deepClone(P.services)).filter((s) => !seen.has(s.slug) && seen.add(s.slug));
      SERVICES.length = 0; SERVICES.push(...final);
      resetMap(SERVICE, SERVICES.map((s) => [s.slug, s]));
      // An explicit empty topic means "no topic"; a missing one falls back to the built-in topic.
      resetMap(SERVICE_TOPIC, SERVICES.map((s) => [s.slug, 'topic' in s ? s.topic : P.serviceTopic[s.slug]]).filter(([, t]) => t));
    });
    section('articles', () => {
      const list = Array.isArray(b.articles) ? b.articles.map(cleanArticle).filter(Boolean) : null;
      const seen = new Set();
      const final = (list || deepClone(P.articles)).filter((a) => !seen.has(a.slug) && seen.add(a.slug));
      ARTICLES.length = 0; ARTICLES.push(...final);
      resetMap(ARTICLE, ARTICLES.map((a) => [a.slug, a]));
    });
    section('reviews', () => {
      Object.keys(REVIEWS).forEach((k) => delete REVIEWS[k]);
      Object.assign(REVIEWS, deepClone(P.reviews), cleanReviews(b.reviews) || {});
    });
    section('moreWork', () => { const list = cleanMoreWork(b.moreWork); MORE_WORK.length = 0; MORE_WORK.push(...(list || deepClone(P.moreWork))); });
    section('retrofits', () => {
      const rb = plainObj(b.retrofits) ? b.retrofits : {};
      const hide = new Set(strList(rb.hide, 2000, 120));
      const edits = plainObj(rb.edit) ? rb.edit : {};
      const list = []; const seen = new Set();
      P.retrofits.forEach((orig) => {
        if (hide.has(orig.slug)) return;
        let item = deepClone(orig);
        if (plainObj(edits[orig.slug])) {
          const fields = cleanRetrofitFields(edits[orig.slug]);
          const next = Object.assign(deepClone(orig), fields);
          if (next.scope !== 'brand') delete next.brands;
          if ('years' in fields) delete next.yearsByModel;
          if (retrofitOk(next)) item = next;
        }
        list.push(item); seen.add(item.slug);
      });
      (Array.isArray(rb.add) ? rb.add : []).forEach((a) => {
        if (!plainObj(a) || seen.has(a.slug) || hide.has(a.slug)) return;
        const item = buildAdded(a);
        if (item) { list.push(item); seen.add(item.slug); }
      });
      RETROFITS.length = 0; RETROFITS.push(...list);
      resetMap(RETROFIT, RETROFITS.map((r) => [r.slug, r]));
      resetMap(RETROFIT_ALIAS, Object.entries(P.aliases).filter(([a, s]) => RETROFIT[s] && !RETROFIT[a]));
    });
    section('display', () => {
      const d = plainObj(b.display) ? b.display : {};
      display = deepClone(DISPLAY_DEFAULTS);
      if (plainObj(d.sections)) Object.keys(display.sections).forEach((k) => { if (typeof d.sections[k] === 'boolean') display.sections[k] = d.sections[k]; });
      ['shop', 'footerAdmin'].forEach((k) => { if (typeof d[k] === 'boolean') display[k] = d[k]; });
      if (plainObj(d.announcement)) {
        const a = d.announcement;
        display.announcement = {
          on: a.on === true, text: str(a.text, 300).trim(), linkLabel: str(a.linkLabel, 60).trim(), link: safeHref(a.link),
          tone: ['dark', 'red', 'light'].includes(a.tone) ? a.tone : 'dark',
        };
        if (!display.announcement.text) display.announcement.on = false;
      }
    });
    section('seo', () => {
      const s = plainObj(b.seo) ? b.seo : {};
      seo = deepClone(SEO_DEFAULTS);
      if (typeof s.siteUrl === 'string') seo.siteUrl = siteAddress(s.siteUrl);
      if (typeof s.suffix === 'string') seo.suffix = s.suffix.slice(0, 60);
      ['homeTitle', 'description', 'ogTitle', 'ogDescription'].forEach((k) => { if (str(s[k]).trim()) seo[k] = s[k].trim().slice(0, 400); });
      seo.noindex = s.noindex === true;
      if (/^[A-Za-z0-9_-]{8,120}$/.test(str(s.google).trim())) seo.google = s.google.trim();
      if (/^[A-Za-z0-9_-]{8,120}$/.test(str(s.bing).trim())) seo.bing = s.bing.trim();
      if (plainObj(s.pages)) {
        Object.keys(s.pages).slice(0, 3000).forEach((path) => {
          const o = s.pages[path];
          if (!/^\/[^\s?#]*$/.test(path) || !plainObj(o)) return;
          const e = { title: str(o.title, 200).trim(), description: str(o.description, 400).trim(), noindex: o.noindex === true };
          if (e.title || e.description || e.noindex) seo.pages[path] = e;
        });
      }
    });
    if (!initial) {
      Search.invalidate();
      Bus.emit('content:changed', { external });
    }
  }

  function rawText(key) {
    const d = TEXT[key]; if (!d) return '';
    const ov = texts[key];
    if (typeof ov === 'string' && (ov.trim() || (d.optional && ov === ''))) return ov;
    return d.def;
  }

  /* ---------- Draft editing ---------- */
  const emptyBundle = () => ({ v: 1 });
  function working() { return deepClone(active()); }
  /** Changes the editor's working copy: fn receives a mutable copy of the active bundle.
      Returns false (and changes nothing) while a draft from an older publication awaits a decision. */
  function update(fn) {
    if (stale) return false;
    syncDraft(); // another tab may have saved meanwhile: build on the latest stored draft
    if (parked) { apply(); return false; }
    const d = working();
    fn(d);
    d.v = 1; d.base = pubStamp; d.baseFp = contentFp(published); d.updatedAt = nowIso();
    delete d.stamp; delete d.shop;
    draft = d; parked = false;
    Storage.set('editor', true);
    Storage.set('siteDraft', d);
    apply();
    return true;
  }
  function discardDraft() { draft = null; parked = false; Storage.remove('siteDraft'); apply(); }
  function resumeParked() { syncDraft(); if (!draft) { apply(); return; } draft.base = pubStamp; draft.baseFp = contentFp(published); parked = false; Storage.set('siteDraft', draft); apply(); }
  // A draft saved in another tab: use it here too, so open screens and the site show the latest version.
  window.addEventListener('storage', (e) => {
    if (e.key === `${Storage.PREFIX}newestStamp`) {
      const v = Storage.get('newestStamp', null);
      if (!stale && isEditor() && typeof v === 'string' && v !== pubStamp) { stale = true; Bus.emit('content:stale'); }
      return;
    }
    if (e.key === `${Storage.PREFIX}editor`) recheckVersion();
    if (e.key !== null && e.key !== `${Storage.PREFIX}siteDraft` && e.key !== `${Storage.PREFIX}editor`) return;
    if (stale) return; // an outdated tab keeps showing what it has until it is reloaded
    syncDraft(); apply({ external: true });
  });
  /** A page opened by a visitor becomes an editor's page at login: another version may have been opened since. */
  function recheckVersion() {
    const v = Storage.get('newestStamp', null);
    if (!stale && isEditor() && typeof v === 'string' && v !== pubStamp) { stale = true; Bus.emit('content:stale'); }
  }
  function hasDraftChanges() { return !!draft && !parked && stableStringify(contentOf(draft)) !== stableStringify(contentOf(published)); }

  /** Per-section summary of what the draft changes compared with the published version. */
  function changes() {
    if (!draft || parked) return [];
    const a = contentOf(draft); const p = contentOf(published);
    const LABELS = { texts: 'Teksten', company: 'Bedrijfsgegevens', brands: 'Merken', categories: 'Categorieën', services: 'Diensten', articles: 'Berichten & kennis', reviews: 'Beoordelingen', moreWork: 'Meer van ons werk', retrofits: 'Opties (catalogus)', display: 'Weergave', seo: 'SEO' };
    return Object.keys(LABELS).filter((k) => stableStringify(a[k] === undefined ? null : a[k]) !== stableStringify(p[k] === undefined ? null : p[k])).map((k) => LABELS[k]);
  }

  apply({ initial: true });

  return {
    TEXT, P, PR, DISPLAY_DEFAULTS, SEO_DEFAULTS, COMPANY_FIELDS, buildAdded,
    apply, update, working, discardDraft, resumeParked, hasDraftChanges, changes, rawText, retrofitOk, cleanRetrofitFields, isSlug, isImageRef, isMediaRef, safeHref, httpsUrl,
    LIMITS, cleanProduct, siteAddress,
    get issues() { return issues.slice(); },
    get published() { return published; },
    get pubStamp() { return pubStamp; },
    get parked() { return parked; },
    /** True when another tab opened a different publication: this tab must be reloaded before saving. */
    get stale() { return stale; },
    /** The publication stamp a parked draft is based on. */
    get draftBase() { return draft ? draft.base || '' : ''; },
    /** Makes this page's publication the current one in this browser (other open tabs become outdated). */
    adoptVersion() { Storage.set('newestStamp', pubStamp); }, // takes effect after the reload that follows
    recheckVersion,
    get draft() { return draft; },
    isEditor,
    texts() { return texts; },
    display() { return display; },
    seo() { return seo; },
    section(key) { return display.sections[key] !== false; },
    shopOn() { return display.shop !== false; },
    emptyBundle,
    /** Published webshop data (validated), or null when nothing was published. */
    publishedShop() { const sh = readPubShop(); return sh ? deepClone(sh) : null; },
    cleanShop,
  };
})();

/** Editable text as safe HTML (see TEXT_GROUPS). vars fill {placeholders}; they are escaped. */
function tx(key, vars) {
  const d = TEXT[key]; if (!d) return '';
  const ov = Content.texts()[key];
  const custom = typeof ov === 'string' && (ov.trim() || (d.optional && ov === ''));
  let out;
  if (d.rich) out = custom ? parseRich(ov).map(richBlockHtml).join('') : (d.html != null ? d.html : parseRich(d.def).map(richBlockHtml).join(''));
  else out = custom ? fmtText(ov, !!d.control) : (d.html != null ? d.html : fmtText(d.def, !!d.control));
  return vars ? out.replace(/\{(\w+)\}/g, (m, k) => (k in vars ? esc(vars[k]) : m)) : out;
}
/** Editable text without markup (for attributes and plain-text contexts). Not escaped. */
function tt(key, vars) {
  const out = plainText(Content.rawText(key));
  return vars ? out.replace(/\{(\w+)\}/g, (m, k) => (k in vars ? String(vars[k]) : m)) : out;
}
/** Image reference of a catalog item: a key of the embedded photos, or a full reference. */
const imgRef = (key) => (!key ? '' : (key.includes(':') ? key : `img:${key}`));
