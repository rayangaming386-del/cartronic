/* =====================================================================
   ILLUSTRATIONS & MEDIA
   Items without real photography get a technical line illustration that is clearly
   labelled "Illustratie" — it never pretends to be a CarTronic product photo.
   ===================================================================== */
const ART_SHAPES = {
  camera: '<rect x="22" y="40" width="76" height="46" rx="8"/><circle cx="60" cy="63" r="16"/><circle cx="60" cy="63" r="8.5"/><circle cx="60" cy="63" r="2.6" class="f"/><path d="M36 40v-7h48v7"/><path d="M98 54h9M98 72h9"/><path d="M60 86v8c0 6 4 10 10 10h28"/><circle cx="86" cy="50" r="2" class="f a"/>',
  sensor: '<circle cx="60" cy="86" r="12"/><circle cx="60" cy="86" r="5"/><path d="M38 64A31 31 0 0 1 82 64"/><path d="M29.6 55.6A43 43 0 0 1 90.4 55.6" class="a"/><path d="M21.1 47.1A55 55 0 0 1 98.9 47.1"/><path d="M60 98v14"/>',
  connect: '<rect x="12" y="28" width="66" height="44" rx="5"/><path d="M45 72v10M32 84h26"/><rect x="22" y="38" width="11" height="11" rx="2.5"/><rect x="38" y="38" width="11" height="11" rx="2.5" class="a"/><rect x="54" y="38" width="11" height="11" rx="2.5"/><path d="M22 60h30"/><rect x="72" y="42" width="34" height="58" rx="6" class="bg"/><path d="M84 92h10"/><path d="M80 52h18M80 60h12"/>',
  cockpit: '<path d="M8 46c0-7 5-12 12-12h80c7 0 12 5 12 12v28c0 9-7 16-16 16H24c-9 0-16-7-16-16Z"/><circle cx="36" cy="62" r="16"/><circle cx="84" cy="62" r="16"/><path d="M36 62l10-7" class="a"/><path d="M84 62l-6-11"/><path d="M54 52h12M54 60h12M54 68h12"/><path d="M26 82h20M74 82h20"/>',
  assist: '<rect x="12" y="40" width="34" height="58" rx="11"/><path d="M18 56h22M18 84h22"/><path d="M58 50a18 18 0 0 1 0 28"/><path d="M68 42a30 30 0 0 1 0 44" class="a"/><path d="M78 34a42 42 0 0 1 0 60"/><rect x="92" y="14" width="18" height="30" rx="5"/>',
  gauge: '<path d="M18 86a42 42 0 1 1 84 0"/><path d="M60 86l22-24" class="a"/><circle cx="60" cy="86" r="5"/><path d="M28 70l6 3M38 52l5 5M60 44v7M82 52l-5 5M92 70l-6 3"/><path d="M40 102h40"/>',
  mirror: '<path d="M16 52c0-15 12-25 29-25h45c9 0 15 8 13 16l-6 27c-2 9-10 15-19 15H38c-12 0-22-10-22-23Z"/><path d="M26 53c0-9 8-15 18-15h40c5 0 8 4 7 9l-4 18c-1 5-6 8-11 8H40c-8 0-14-6-14-14Z" class="a"/><path d="M38 85l-6 18h22l4-15"/><path d="M98 96a20 20 0 0 1-16 9"/><path d="M87 100l-5 5 6 3"/>',
  mirrorInterior: '<rect x="14" y="38" width="92" height="40" rx="14"/><rect x="22" y="45" width="76" height="26" rx="9" class="a"/><path d="M60 38V20M50 20h20"/><circle cx="98" cy="84" r="3" class="f"/>',
  tailgate: '<path d="M8 88V72c0-4 2-6 6-7l18-3 14-17c2-2 4-3 7-3h32c3 0 5 1 7 3l11 13"/><circle cx="30" cy="90" r="8"/><circle cx="84" cy="90" r="8"/><path d="M38 90h38M8 90h14M92 90h12V74"/><path d="M103 58l13-24" class="a"/><path d="M110 74a18 18 0 0 0 4-18"/><path d="M111 61l3-5 4 4"/>',
  light: '<path d="M10 38h32c15 0 26 10 26 22s-11 22-26 22H10Z"/><path d="M20 50h22M20 60h26M20 70h22" class="a"/><path d="M80 44l30-9M80 56l32-3M80 68l32 4M80 80l30 10"/>',
  towbar: '<circle cx="80" cy="34" r="10"/><path d="M80 44v8c0 11-9 20-20 20H30"/><path d="M18 60v24h12V60Z"/><path d="M64 84h24v14H64Z" class="a"/><path d="M70 98v8M82 98v8"/><path d="M76 84v-6"/>',
  alarm: '<path d="M60 12l38 14v28c0 27-17 43-38 52-21-9-38-25-38-52V26Z"/><rect x="45" y="52" width="30" height="24" rx="3" class="a"/><path d="M50 52v-7a10 10 0 0 1 20 0v7"/><circle cx="60" cy="64" r="2.6" class="f"/>',
  nav: '<path d="M12 34l30-11 36 11 30-11v64l-30 11-36-11-30 11Z"/><path d="M42 23v64M78 34v64"/><path d="M60 76s15-13 15-26a15 15 0 0 0-30 0c0 13 15 26 15 26Z" class="bg a"/><circle cx="60" cy="50" r="5"/>',
  usb: '<rect x="44" y="12" width="32" height="26" rx="3"/><path d="M52 20h5M63 20h5"/><rect x="36" y="38" width="48" height="44" rx="7"/><path d="M60 82v26"/><path d="M60 72V48M60 48l-4 5M60 48l4 5M60 64l-9-6v-4M60 60l9-6v-4" class="a"/>',
  module: '<rect x="16" y="30" width="88" height="58" rx="5"/><rect x="26" y="42" width="36" height="34" rx="2" class="a"/><path d="M72 46h22M72 54h22M72 62h16"/><path d="M30 88v12M42 88v12M54 88v12M66 88v12M78 88v12M90 88v12"/>',
  wheel: '<circle cx="60" cy="60" r="44"/><circle cx="60" cy="60" r="34"/><circle cx="60" cy="62" r="12" class="a"/><path d="M26 56l22 4M94 56l-22 4M60 74v20"/><rect x="34" y="62" width="8" height="5" rx="1.5"/><rect x="78" y="62" width="8" height="5" rx="1.5"/>',
  sensorRain: '<path d="M10 92L28 28h64l18 64Z"/><rect x="50" y="28" width="20" height="12" rx="2" class="a"/><path d="M36 60c0 3 2 5 4 5s4-2 4-5-4-8-4-8-4 5-4 8ZM74 70c0 3 2 5 4 5s4-2 4-5-4-8-4-8-4 5-4 8ZM56 80c0 3 2 5 4 5s4-2 4-5-4-8-4-8-4 5-4 8Z"/>',
  key: '<rect x="38" y="34" width="40" height="66" rx="15"/><circle cx="58" cy="54" r="6"/><circle cx="58" cy="74" r="6" class="a"/><path d="M51 89h14"/><path d="M58 34v-8"/><circle cx="58" cy="18" r="8"/><path d="M88 52a12 12 0 0 1 0 18M96 44a24 24 0 0 1 0 34" class="a"/>',
  garage: '<path d="M10 52 60 22l50 30"/><path d="M20 46v56h80V46"/><path d="M32 102V60h56v42"/><path d="M32 70h56M32 80h56M32 90h56" class="a"/>',
  socket: '<rect x="22" y="22" width="76" height="76" rx="16"/><circle cx="60" cy="60" r="25" class="a"/><circle cx="50" cy="60" r="4" class="f"/><circle cx="70" cy="60" r="4" class="f"/><path d="M60 35v7M60 78v7"/>',
  box: '<path d="M100 40 60 20 20 40v42l40 20 40-20Z"/><path d="M20 40l40 20 40-20M60 60v42" /><path d="M40 30l40 20" class="a"/>',
};
const Art = {
  svg(kind = 'box', variant = 0) {
    // Own keys only: a reference such as "art:constructor:0" must fall back, not reach Object.prototype.
    const shape = Object.prototype.hasOwnProperty.call(ART_SHAPES, kind) ? ART_SHAPES[kind] : ART_SHAPES.box;
    const v = Number(variant) || 0;
    const dark = v === 1;
    const bg = dark ? '#1C2025' : (v === 2 ? '#EDF0F3' : '#F3F5F7');
    const grid = dark ? 'rgba(255,255,255,.05)' : 'rgba(17,20,26,.055)';
    const ink = dark ? '#E7E9EC' : '#20252C';
    const accent = dark ? '#E7737E' : '#B51625';
    const label = dark ? 'rgba(255,255,255,.42)' : 'rgba(17,20,26,.42)';
    let g = '';
    for (let x = 20; x < 400; x += 20) g += `M${x} 0V300`;
    for (let y = 20; y < 300; y += 20) g += `M0 ${y}H400`;
    const scale = v === 1 ? 1.55 : 1.3;
    const tx = 200 - 60 * scale + (v === 2 ? -40 : 0);
    const ty = 146 - 60 * scale;
    const extra = v === 2
      ? `<path d="M${tx - 6} ${ty + 128 * scale}H${tx + 126 * scale}M${tx - 6} ${ty + 124 * scale}v8M${tx + 126 * scale} ${ty + 124 * scale}v8" stroke="${accent}" stroke-width="1.2" fill="none"/>
         <path d="M300 92h56M300 112h44M300 132h50M300 152h34" stroke="${ink}" stroke-opacity=".28" stroke-width="2" stroke-linecap="round"/>`
      : `<circle cx="200" cy="146" r="${v === 1 ? 128 : 118}" fill="${dark ? '#262B31' : '#FFFFFF'}" fill-opacity="${dark ? '.55' : '.7'}"/>`;
    return `<svg viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
      <rect width="400" height="300" fill="${bg}"/><path d="${g}" stroke="${grid}" stroke-width="1"/>
      ${extra}
      <g transform="translate(${tx} ${ty}) scale(${scale})" fill="none" stroke="${ink}" stroke-width="${(2.1 / scale).toFixed(2)}" stroke-linecap="round" stroke-linejoin="round" class="art-g">
        ${shape.replace(/class="([^"]*)"/g, (m, c) => {
          const cls = c.split(' ');
          let a = '';
          if (cls.includes('a')) a += ` stroke="${accent}"`;
          if (cls.includes('f')) a += ` fill="${cls.includes('a') ? accent : ink}"`;
          else if (cls.includes('bg')) a += ` fill="${bg}"`;
          return a;
        })}
      </g>
      <text x="16" y="286" font-family="Helvetica Neue, Helvetica, Arial, sans-serif" font-size="9" font-weight="700" letter-spacing="1.6" fill="${label}">ILLUSTRATIE</text>
    </svg>`;
  },
  html(kind, variant, alt) {
    return `<div class="art" role="img" aria-label="Illustratie${alt ? `: ${esc(alt)}` : ''}">${this.svg(kind, variant)}</div>`;
  },
};

/* Media references:  "img:<key>" embedded photo │ "art:<kind>:<variant>" illustration │ https://… / data:image URL */
const Media = {
  src(ref) {
    if (!ref || typeof ref !== 'string') return null;
    if (ref.startsWith('img:')) {
      const imgs = window.CT_IMAGES || {}; const k = ref.slice(4);
      return Object.prototype.hasOwnProperty.call(imgs, k) && typeof imgs[k] === 'string' ? imgs[k] : null;
    }
    if (/^(https?:|data:image\/)/i.test(ref)) return ref;
    return null;
  },
  isPhoto(ref) { return typeof ref === 'string' && !!ref && !ref.startsWith('art:') && !!this.src(ref); },
  html(ref, alt = '', { kind = 'box', eager = false, cls = '', sizes = '' } = {}) {
    if (typeof ref !== 'string') ref = '';
    if (!ref || ref.startsWith('art:')) {
      const [, k, v] = String(ref || `art:${kind}:0`).split(':');
      return Art.html(k || kind, v || 0, alt);
    }
    const src = this.src(ref);
    if (!src) return Art.html(kind, 0, alt);
    return `<img src="${attr(src)}" alt="${attr(alt)}"${eager ? ' fetchpriority="high"' : ' loading="lazy"'} decoding="async" data-fallback="${attr(kind)}"${cls ? ` class="${cls}"` : ''}${sizes ? ` sizes="${sizes}"` : ''}>`;
  },
  /** Replaces broken images with an illustration so the UI never shows a broken image icon. */
  installFallback() {
    document.addEventListener('error', (e) => {
      const img = e.target;
      if (!(img instanceof HTMLImageElement) || !img.dataset.fallback || img.dataset.failed) return;
      img.dataset.failed = '1';
      const wrap = document.createElement('div');
      wrap.innerHTML = Art.html(img.dataset.fallback, 0, img.alt);
      img.replaceWith(wrap.firstElementChild);
    }, true);
  },
};
const productArtKind = (p) => {
  const a = (p.images || []).find((i) => i.startsWith('art:'));
  return a ? a.split(':')[1] : 'box';
};
