// Builds the single-file prototype: inlines CSS, JS and the embedded photography.
import fs from 'fs';
import path from 'path';
const here = path.dirname(new URL(import.meta.url).pathname);
const src = (f) => fs.readFileSync(path.join(here, 'src', f), 'utf8');
const out = process.argv[2] || path.join(here, 'index.html');
const css = ['10-base.css', '20-layout.css', '30-components.css', '40-shop.css', '50-admin.css'].map(src).join('\n');
const js = ['01-core.js', '02-data.js', '02b-content.js', '03-domain.js', '04-art.js', '05-ui.js', '06-pages.js', '07-shop.js', '08-admin.js', '08b-site.js', '08c-catalog.js', '09-motion.js', '10-init.js'].map(src).join('\n');
const imgDir = path.join(here, 'img');
const images = {};
for (const f of fs.readdirSync(imgDir).filter((f) => f.endsWith('.webp')).sort()) {
  images[f.replace(/\.webp$/, '')] = `data:image/webp;base64,${fs.readFileSync(path.join(imgDir, f)).toString('base64')}`;
}
const imgJs = `window.CT_IMAGES = {\n${Object.entries(images).map(([k, v]) => `  ${JSON.stringify(k)}: ${JSON.stringify(v)}`).join(',\n')}\n};`;
const template = src('index.template.html');
// The template travels inside the page (base64) so Beheer → Publiceren can rebuild this exact file
// with new content, without a server or build step.
// Inline scripts must never contain these sequences, or the HTML parser ends the script early.
for (const [name, code] of [['application script', js], ['image script', imgJs]]) {
  if (/<\/script|<!--/i.test(code)) throw new Error(`The ${name} contains "</script" or "<!--"; split the string.`);
}
const parts = {
  CSS: css, JS: `(function () {\n'use strict';\n${js}\n})();`, IMAGES: imgJs, CONTENT: '{}',
  TEMPLATE: Buffer.from(template, 'utf8').toString('base64'),
};
// One pass over the template, so inserted code is never searched for placeholders itself.
const html = template.replace(/\/\*__(CSS|JS|IMAGES|CONTENT|TEMPLATE)__\*\//g, (m, k) => parts[k]);
fs.writeFileSync(out, html);
console.log(`wrote ${out} (${(Buffer.byteLength(html) / 1024).toFixed(0)} KB), images: ${Object.keys(images).join(', ')}`);
