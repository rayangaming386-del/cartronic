// Emits the merged RETROFITS literal from out/merged.json and splices it into src/02-data.js.
// Usage: node tools/catalog/emit.mjs <dataJs> [overrides.json]
import fs from 'node:fs';
import path from 'node:path';

const [dataPath, overridesPath] = process.argv.slice(2);
const here = path.dirname(new URL(import.meta.url).pathname);
const merged = JSON.parse(fs.readFileSync(path.join(here, 'out', 'merged.json'), 'utf8'));
const overrides = overridesPath ? JSON.parse(fs.readFileSync(overridesPath, 'utf8')) : {};

const BRAND_ORDER = ['volkswagen', 'audi', 'seat', 'skoda'];
const BRAND_LABEL = { volkswagen: 'Volkswagen', audi: 'Audi', seat: 'SEAT', skoda: 'Škoda' };
const MODEL_ORDER = [
  'golf-7', 'golf-sportsvan', 'golf-8', 'polo-aw', 't-roc', 'tiguan-ad', 'sharan', 'passat-b8', 'id-3', 'id-4', 'up', 'caddy-sa', 'transporter-t6', 'crafter-sy',
  'a1-8x', 'a1-gb', 'a3-8v', 'a3-8y', 'a4-b9', 'a5-f5', 'a6-c8', 'a7-c8', 'q2-ga', 'q3-f3', 'q4-etron', 'q5-fy', 'q7-4m', 'q8',
  'ibiza-kj', 'arona', 'leon-5f', 'ateca', 'tarraco', 'mii',
  'octavia-5e', 'fabia-6v', 'kamiq', 'karoq', 'kodiaq', 'enyaq', 'superb-3v', 'citigo', 'yeti',
];
const FEATURE_ORDER = [
  'achteruitrijcamera', 'achteruitrijcamera-achterdeuren', 'achteruitrijcamera-achterklep', 'area-view', 'top-view',
  'parkeerhulp-achter', 'parkeerhulp-voor-achter', 'parkeerhulp-voor-upgrade',
  'app-connect', 'smartphone-interface', 'discover-media', 'discover-pro', 'mmi-plus', 'active-info-display', 'virtual-cockpit',
  'dodehoek', 'lane-assist', 'verkeersbordherkenning', 'wegrijassistent', 'cruise-control', 'cruise-control-stuur', 'cruise-control-hendel',
  'inklapbare-spiegels', 'dimmende-binnenspiegel', 'achterklep', 'keyless', 'homelink', '230v', 'rijprofielen', 'stuurwiel', 'licht-regensensor',
  'led-koplampen', 'xenon', 'led-achterlichten', 'led-achterlichten-donker', 'led-dynamisch', 'instapverlichting',
  'trekhaak-afneembaar', 'trekhaak-zwenkbaar', 'alarm', 'discover-carplay',
];
const idx = (arr, v) => { const i = arr.indexOf(v); if (i < 0) throw new Error(`unknown order key ${v}`); return i; };
const sortKey = (r) => (r.scope === 'brand'
  ? [9, 0, 0, idx(FEATURE_ORDER, r.feature)]
  : [idx(BRAND_ORDER, r.brand), idx(MODEL_ORDER, r.models[0]), r.variant ? 1 : 0, idx(FEATURE_ORDER, r.feature)]);
// Curated entries keep their approved order (the unfiltered catalog opens exactly as before);
// the additions follow, grouped by brand → model → feature.
const curated = merged.filter((r) => !r.fromArchive);
const added = merged.filter((r) => r.fromArchive);
added.sort((a, b) => { const ka = sortKey(a); const kb = sortKey(b); for (let i = 0; i < ka.length; i++) if (ka[i] !== kb[i]) return ka[i] - kb[i]; return 0; });
merged.length = 0; merged.push(...curated, ...added);

const q = (s) => `'${String(s).replace(/\\/g, '\\\\').replace(/'/g, "\\'")}'`;
const lit = (v) => {
  if (v === null) return 'null';
  if (Array.isArray(v)) return `[${v.map(lit).join(', ')}]`;
  if (typeof v === 'object') return `{ ${Object.entries(v).map(([k, x]) => `${/^[a-z]\w*$/i.test(k) ? k : q(k)}: ${lit(x)}`).join(', ')} }`;
  if (typeof v === 'number' || typeof v === 'boolean') return String(v);
  return q(v);
};
const FIELD_ORDER = ['slug', 'feature', 'brand', 'brands', 'models', 'scope', 'variant', 'years', 'yearsByModel', 'body', 'cat', 'title', 'name', 'art', 'image', 'imageNote',
  'short', 'variantNote', 'specs', 'keywords', 'project', 'warranty', 'price', 'offer', 'aliases', 'source'];
const DROP = new Set(['fromArchive', 'fromSite', 'archiveId', 'archivePrice']);

let lastGroup = '';
const lines = [];
merged.forEach((r0) => {
  const r = { ...r0, ...(overrides[r0.slug] || {}) };
  Object.keys(r).forEach((k) => { if (r[k] === undefined || (r[k] === null && k !== 'brand')) delete r[k]; });
  const extra = Object.keys(r).filter((k) => !FIELD_ORDER.includes(k) && !DROP.has(k));
  if (extra.length) throw new Error(`unexpected fields ${extra} on ${r.slug}`);
  const group = `${r0.fromArchive ? 'Aanvulling uit de volledige catalogus – ' : ''}${r.scope === 'brand' ? 'Meerdere merken/modellen' : BRAND_LABEL[r.brand]}`;
  if (group !== lastGroup) { lines.push(`  // ---- ${group}`); lastGroup = group; }
  const body = FIELD_ORDER.filter((k) => k in r).map((k) => `${k}: ${lit(r[k])}`);
  lines.push(`  { ${body.join(', ')} },`);
});

const block = `const RETROFITS = [\n${lines.join('\n')}\n];`;
const src = fs.readFileSync(dataPath, 'utf8');
const start = src.indexOf('const RETROFITS = [');
const end = src.indexOf('\n];', start) + 3;
fs.writeFileSync(dataPath, src.slice(0, start) + block + src.slice(end));
console.log(`wrote ${merged.length} entries (${block.length} chars)`);
