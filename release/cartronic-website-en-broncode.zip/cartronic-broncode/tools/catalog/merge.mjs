// One-off reconciliation of the supplied archive catalog (cartronic-replica/assets/js/products.js)
// with the curated RETROFITS of the approved site. Writes:
//   tools/catalog/out/retrofits.js   – the merged RETROFITS literal (spliced into src/02-data.js)
//   tools/catalog/out/report.json    – counts, reconciliations, aliases, skipped records
// Usage: node tools/catalog/merge.mjs <archiveProductsJs> <dataJs>
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { ENRICH, EXTRA_ENTRIES, SITE_ENTRIES } from './enrich.mjs';

const [archivePath, dataPath] = process.argv.slice(2);
const here = path.dirname(new URL(import.meta.url).pathname);
const outDir = path.join(here, 'out');
fs.mkdirSync(outDir, { recursive: true });

/* ---------- load inputs ---------- */
const archiveCtx = { window: {} };
vm.runInNewContext(fs.readFileSync(archivePath, 'utf8'), archiveCtx);
const ARCHIVE = archiveCtx.window.PRODUCTS;

const dataSrc = fs.readFileSync(dataPath, 'utf8');
const start = dataSrc.indexOf('const RETROFITS = [');
const end = dataSrc.indexOf('\n];', start) + 3;
if (start < 0 || end < 3) throw new Error('RETROFITS block not found');
const curCtx = { SRC_OLD: 'https://www.cartronic.nl/producten/', SRC_NEW: 'https://new.cartronic.nl/producten/' };
vm.runInNewContext(`${dataSrc.slice(start, end).replace('const RETROFITS', 'globalThis.RETROFITS')}`, curCtx);
const CURRENT = curCtx.RETROFITS;

/* ---------- mapping tables ---------- */
// archive "model" → [modelId, variant, slugPrefix]
const MODEL_MAP = {
  'Volkswagen|Golf 7': ['golf-7', null, 'volkswagen-golf-7'],
  'Volkswagen|Golf 7 Sportsvan': ['golf-sportsvan', null, 'volkswagen-golf-7-sportsvan'],
  'Volkswagen|Golf 8': ['golf-8', null, 'volkswagen-golf-8'],
  'Volkswagen|Polo AW': ['polo-aw', null, 'volkswagen-polo-aw'],
  'Volkswagen|T-Roc': ['t-roc', null, 'volkswagen-t-roc'],
  'Volkswagen|Passat B8': ['passat-b8', null, 'volkswagen-passat-b8'],
  'Volkswagen|Up!': ['up', null, 'volkswagen-up'],
  'Volkswagen|Transporter T6': ['transporter-t6', null, 'volkswagen-transporter-t6'],
  'Volkswagen|Caddy SA': ['caddy-sa', null, 'volkswagen-caddy-sa'],
  'Volkswagen|Crafter SY': ['crafter-sy', null, 'volkswagen-crafter-sy'],
  'Audi|A1 8X': ['a1-8x', null, 'audi-a1-8x'],
  'Audi|A1 GB': ['a1-gb', null, 'audi-a1-gb'],
  'Audi|A3 8V': ['a3-8v', null, 'audi-a3-8v'],
  'Audi|A4 B9/8W': ['a4-b9', null, 'audi-a4-b9'],
  'Audi|A4 B9/8W Avant': ['a4-b9', 'avant', 'audi-a4-b9-avant'],
  'Audi|A4 B9/8W Limousine': ['a4-b9', 'limousine', 'audi-a4-b9-limousine'],
  'Audi|A5 F5': ['a5-f5', null, 'audi-a5-f5'],
  'Audi|Q2 GA': ['q2-ga', null, 'audi-q2-ga'],
  'Audi|Q3 F3': ['q3-f3', null, 'audi-q3-f3'],
  'Audi|Q5 FY': ['q5-fy', null, 'audi-q5-fy'],
  'Audi|Q7 4M': ['q7-4m', null, 'audi-q7-4m'],
  'Seat|Arona': ['arona', null, 'seat-arona'],
  'Seat|Ateca': ['ateca', null, 'seat-ateca'],
  'Seat|Ibiza KJ': ['ibiza-kj', null, 'seat-ibiza-kj'],
  'Seat|Leon 5F': ['leon-5f', null, 'seat-leon-5f'],
  'Seat|Mii': ['mii', null, 'seat-mii'],
  'Skoda|Citigo': ['citigo', null, 'skoda-citigo'],
  'Skoda|Fabia 6V0': ['fabia-6v', null, 'skoda-fabia-6v'],
  'Skoda|Karoq': ['karoq', null, 'skoda-karoq'],
  'Skoda|Kodiaq': ['kodiaq', null, 'skoda-kodiaq'],
  'Skoda|SuperB 3V': ['superb-3v', null, 'skoda-superb-3v'],
  'Skoda|Yeti': ['yeti', null, 'skoda-yeti'],
  'Skoda|Yeti II': ['yeti', 'ii', 'skoda-yeti'],
};
const ARCHIVE_PREFIX = { 'Audi|A4 B9/8W': 'audi-a4-b9-8w', 'Audi|A4 B9/8W Avant': 'audi-a4-b9-8w-avant', 'Audi|A4 B9/8W Limousine': 'audi-a4-b9-8w-limousine', 'Skoda|Fabia 6V0': 'skoda-fabia-6v0', 'Skoda|Yeti II': 'skoda-yeti-ii' };
const BRAND_ID = { Volkswagen: 'volkswagen', Audi: 'audi', Seat: 'seat', Skoda: 'skoda' };

// archive "feature" → feature key (see FEATURES in src/02-data.js)
const FEATURE_MAP = {
  '230 Volt Aansluiting': '230v',
  Achteruitrijcamera: 'achteruitrijcamera',
  'Achteruitrijcamera (achterdeuren)': 'achteruitrijcamera-achterdeuren',
  'Achteruitrijcamera (achterklep)': 'achteruitrijcamera-achterklep',
  'Active Info Display': 'active-info-display',
  'Active Lane Assist': 'lane-assist',
  'Afneembare Trekhaak': 'trekhaak-afneembaar',
  'App Connect': 'app-connect',
  'Area View 360 Camera': 'area-view',
  'Comfortsleutel Keyless Entry': 'keyless',
  'Cruise Control': 'cruise-control',
  'Cruise Control op Stuur': 'cruise-control-stuur',
  'Cruise Control via Hendel': 'cruise-control-hendel',
  'Dimmende Binnenspiegel': 'dimmende-binnenspiegel',
  'Discover Media': 'discover-media',
  'Discover PRO': 'discover-pro',
  'Dode Hoek Assistent': 'dodehoek',
  'Elektrische Achterklep': 'achterklep',
  'Garagedeuropener Homelink': 'homelink',
  'Inklapbare Spiegels': 'inklapbare-spiegels',
  'Instapverlichting “Audi Ringen”': 'instapverlichting',
  'LED Achterlichten': 'led-achterlichten',
  'LED Achterlichten Donker': 'led-achterlichten-donker',
  'LED Dynamische Achterlichten': 'led-dynamisch',
  'LED Koplampen': 'led-koplampen',
  'Licht en Regensensor': 'licht-regensensor',
  'MMI Plus Navigatiesysteem': 'mmi-plus',
  'Multifunctioneel Stuurwiel': 'stuurwiel',
  'Parkeerhulp Achterzijde': 'parkeerhulp-achter',
  'Parkeerhulp Voor- en Achterzijde': 'parkeerhulp-voor-achter',
  'Parkeerhulp Voorzijde Upgrade': 'parkeerhulp-voor-upgrade',
  Rijprofielen: 'rijprofielen',
  'Smartphone Interface': 'smartphone-interface',
  'Top View 360 Graden Camera': 'top-view',
  Verkeersbordherkenning: 'verkeersbordherkenning',
  'Virtual Cockpit': 'virtual-cockpit',
  Wegrijassistent: 'wegrijassistent',
  'Xenon Koplampen': 'xenon',
  'Zwenkbare/Wegklapbare Trekhaak': 'trekhaak-zwenkbaar',
};

// current slug suffix → feature key (for the curated entries)
const SUFFIX_FEATURE = {
  'active-info-display': 'active-info-display', 'app-connect': 'app-connect', 'parkeerhulp-voor-en-achterzijde': 'parkeerhulp-voor-achter',
  'zwenkbare-wegklapbare-trekhaak': 'trekhaak-zwenkbaar', 'inklapbare-spiegels': 'inklapbare-spiegels', achteruitrijcamera: 'achteruitrijcamera',
  'elektrische-achterklep': 'achterklep', 'dode-hoek-assistent': 'dodehoek', 'discover-pro': 'discover-pro',
  'multifunctioneel-stuurwiel': 'stuurwiel', 'virtual-cockpit': 'virtual-cockpit', verkeersbordherkenning: 'verkeersbordherkenning',
  'cruise-control': 'cruise-control', 'mmi-plus-navigatiesysteem': 'mmi-plus', 'licht-en-regensensor': 'licht-regensensor',
  'led-dynamische-achterlichten': 'led-dynamisch', 'parkeerhulp-voorzijde-upgrade': 'parkeerhulp-voor-upgrade',
  'dimmende-binnenspiegel': 'dimmende-binnenspiegel', 'afneembare-trekhaak': 'trekhaak-afneembaar', 'parkeerhulp-achterzijde': 'parkeerhulp-achter',
  'smartphone-interface-carplay': 'smartphone-interface', 'alarm-scm': 'alarm',
};
const featureOfCurrent = (r) => {
  const hit = Object.keys(SUFFIX_FEATURE).sort((a, b) => b.length - a.length).find((s) => r.slug.endsWith(s));
  if (!hit) throw new Error(`no feature for ${r.slug}`);
  return SUFFIX_FEATURE[hit];
};
const variantOfCurrent = (r) => {
  if (r.body === 'stationwagen') return 'avant';
  if (r.models[0] === 'yeti' && r.years) return 'ii';
  return null;
};
const keyOf = (scope, model, variant, feature) => `${scope}|${model}|${variant || ''}|${feature}`;

/* ---------- curated entries ---------- */
const merged = [];
const byKey = new Map();
CURRENT.forEach((r) => {
  const feature = featureOfCurrent(r);
  const variant = variantOfCurrent(r);
  const entry = { ...r, feature };
  const key = r.scope === 'brand' ? keyOf('brand', (r.brands || [r.brand]).join('+'), null, feature) : keyOf('model', r.models[0], variant, feature);
  if (byKey.has(key)) throw new Error(`duplicate curated key ${key}`);
  byKey.set(key, entry);
  merged.push(entry);
});

/* ---------- archive entries ---------- */
const report = {
  archiveCount: ARCHIVE.length, currentCount: CURRENT.length,
  reconciled: [], added: [], skipped: [], aliases: [], prices: [], warrantyExceptions: [],
};
// Records whose "model" was parsed from an offer title ("Aanbieding N – …").
const OFFER = {
  'aanbieding-1-volkswagen-golf-7-active-info-display': { key: keyOf('model', 'golf-7', null, 'active-info-display') },
  'aanbieding-2-audi-smartphone-interface-carplay': { key: keyOf('brand', 'audi', null, 'smartphone-interface') },
  // On cartronic.nl the "Aanbieding 3" offer lives on the T-Roc App Connect page.
  'aanbieding-3-volkswagen-app-connect': { key: keyOf('model', 't-roc', null, 'app-connect') },
  // "Aanbieding 4" becomes its own multi-model entry (see EXTRA_ENTRIES in enrich.mjs).
  'aanbieding-4-volkswagen-discover-navigatie-met-carplay': { extra: 'volkswagen-discover-navigatie-met-carplay' },
};

ARCHIVE.forEach((a) => {
  const offer = OFFER[a.slug];
  if (offer && offer.skip) { report.skipped.push({ id: a.id, slug: a.slug, title: a.title, price: a.price, reason: offer.skip }); return; }
  if (offer && offer.extra) {
    const e = EXTRA_ENTRIES.find((x) => x.slug === offer.extra);
    merged.push({ ...e }); report.added.push({ id: a.id, slug: e.slug, title: a.title, note: 'offer → multi-model entry' });
    report.aliases.push([a.slug, e.slug]);
    return;
  }
  let key; let mm; let feature;
  if (offer) key = offer.key;
  else {
    mm = MODEL_MAP[`${a.brand}|${a.model}`];
    feature = FEATURE_MAP[a.feature];
    if (!mm || !feature) { report.skipped.push({ id: a.id, slug: a.slug, title: a.title, reason: `onbekend model/feature (${a.model} / ${a.feature})` }); return; }
    key = keyOf('model', mm[0], mm[1], feature);
  }
  const archivePrice = a.price && a.price !== 'Prijs op aanvraag' ? a.price : null;
  const existing = byKey.get(key);
  if (existing) {
    // Curated entry wins; only fill fields that are missing. Archive text is generic → not copied.
    if (existing.slug !== a.slug) { existing.aliases = [...(existing.aliases || []), a.slug]; report.aliases.push([a.slug, existing.slug]); }
    if (a.warranty) existing.warranty = existing.warranty || a.warranty;
    if (archivePrice) { existing.archivePrice = archivePrice; report.prices.push({ slug: existing.slug, price: archivePrice, from: a.title }); }
    existing.archiveId = [...(existing.archiveId || []), a.id];
    report.reconciled.push({ id: a.id, archiveSlug: a.slug, slug: existing.slug, curated: !existing.fromArchive });
    return;
  }
  const brand = BRAND_ID[a.brand];
  const archivePrefix = ARCHIVE_PREFIX[`${a.brand}|${a.model}`] || mm[2];
  if (!a.slug.startsWith(`${archivePrefix}-`)) throw new Error(`prefix mismatch ${a.slug} vs ${archivePrefix}`);
  const suffix = a.slug.slice(archivePrefix.length + 1);
  const slug = `${mm[2]}-${suffix}`;
  const entry = { slug, feature, brand, models: [mm[0]], fromArchive: true, archiveId: [a.id] };
  if (mm[1]) entry.variant = mm[1];
  if (slug !== a.slug) { entry.aliases = [a.slug]; report.aliases.push([a.slug, slug]); }
  if (a.warranty) entry.warranty = a.warranty;
  if (archivePrice) { entry.archivePrice = archivePrice; report.prices.push({ slug, price: archivePrice, from: a.title }); }
  if (a.warranty && a.warranty !== '3 jaar') report.warrantyExceptions.push({ slug, warranty: a.warranty });
  byKey.set(key, entry);
  merged.push(entry);
  report.added.push({ id: a.id, slug, title: a.title });
});

/* ---------- extra options found on cartronic.nl (not in the archive) ---------- */
report.siteAdded = [];
SITE_ENTRIES.forEach((e) => {
  const key = keyOf('model', e.models[0], e.variant || null, e.feature);
  if (byKey.has(key)) throw new Error(`SITE_ENTRIES duplicate of existing option: ${e.slug} (${key})`);
  const entry = { ...e, fromArchive: true, fromSite: true };
  if (entry.image === null) delete entry.image;
  byKey.set(key, entry); merged.push(entry); report.siteAdded.push(e.slug);
});

/* ---------- entry-level enrichment (cartronic.nl) ---------- */
const bySlug = new Map(merged.map((r) => [r.slug, r]));
report.enrichedFromSite = [];
Object.entries(ENRICH).forEach(([slug, data]) => {
  const r = bySlug.get(slug);
  if (!r) throw new Error(`ENRICH: unknown slug ${slug}`);
  if (!r.fromArchive && data.short) throw new Error(`ENRICH must not replace curated text: ${slug}`);
  if (data.specs && r.specs) {
    const have = new Set(r.specs.map(([k]) => k));
    r.specs = [...r.specs, ...data.specs.filter(([k]) => !have.has(k))];
    Object.assign(r, { ...data, specs: r.specs });
  } else Object.assign(r, data);
  report.enrichedFromSite.push(slug);
});

/* ---------- validation ---------- */
const slugs = new Map();
merged.forEach((r) => {
  [r.slug, ...(r.aliases || [])].forEach((s) => {
    if (slugs.has(s)) throw new Error(`slug/alias collision: ${s} (${slugs.get(s)} / ${r.slug})`);
    slugs.set(s, r.slug);
  });
  if (!/^[a-z0-9]+(-[a-z0-9]+)*$/.test(r.slug)) throw new Error(`unclean slug ${r.slug}`);
});
report.mergedCount = merged.length;
report.newCount = report.added.length;
report.enrichedCurated = merged.filter((r) => !r.fromArchive && r.archiveId).map((r) => r.slug);
report.curatedWithoutArchive = merged.filter((r) => !r.fromArchive && !r.archiveId).map((r) => r.slug);

fs.writeFileSync(path.join(outDir, 'merged.json'), JSON.stringify(merged, null, 1));
fs.writeFileSync(path.join(outDir, 'report.json'), JSON.stringify(report, null, 1));
console.log(JSON.stringify({
  archive: report.archiveCount, current: report.currentCount, merged: report.mergedCount, added: report.newCount,
  reconciled: report.reconciled.length, skipped: report.skipped.length, aliases: report.aliases.length,
  enrichedCurated: report.enrichedCurated.length, curatedWithoutArchive: report.curatedWithoutArchive.length,
  prices: report.prices, warrantyExceptions: report.warrantyExceptions,
}, null, 1));
