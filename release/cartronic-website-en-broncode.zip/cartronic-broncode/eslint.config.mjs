export default [{
  files: ['app.js'],
  languageOptions: {
    ecmaVersion: 2022, sourceType: 'script',
    globals: { window: 'readonly', document: 'readonly', location: 'readonly', history: 'readonly', navigator: 'readonly', localStorage: 'readonly', sessionStorage: 'readonly', console: 'readonly', setTimeout: 'readonly', clearTimeout: 'readonly', requestAnimationFrame: 'readonly', performance: 'readonly', fetch: 'readonly', AbortController: 'readonly', URLSearchParams: 'readonly', CustomEvent: 'readonly', Event: 'readonly', Image: 'readonly', URL: 'readonly', Blob: 'readonly', HTMLImageElement: 'readonly', CSS: 'readonly', Intl: 'readonly', Promise: 'readonly', getComputedStyle: 'readonly', innerHeight: 'readonly', MutationObserver: 'readonly', TextEncoder: 'readonly', TextDecoder: 'readonly', atob: 'readonly', btoa: 'readonly', FileReader: 'readonly', Uint8Array: 'readonly', Uint32Array: 'readonly', DataView: 'readonly', ArrayBuffer: 'readonly' },
  },
  rules: { 'no-undef': 'error', 'no-unused-vars': ['warn', { args: 'none' }], 'no-dupe-keys': 'error', 'no-redeclare': 'error', 'no-unreachable': 'error', 'no-const-assign': 'error', 'no-use-before-define': ['error', { functions: false, classes: false, variables: false }] },
}];
