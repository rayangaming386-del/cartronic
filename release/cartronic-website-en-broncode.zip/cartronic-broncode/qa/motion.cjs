const { open, go, URL_BASE, S } = require('./harness.cjs');
const assert = (c, m) => { if (!c) { console.log('FAIL:', m); process.exitCode = 1; } else console.log('ok  :', m); };
(async () => {
  const { browser, page, errors } = await open({ width: 1440, height: 900, reduce: false });
  for (const r of ['#/', '#/expertise', '#/over', '#/mogelijkheden', '#/projecten']) {
    await page.goto(`${URL_BASE}${r}`);
    await page.waitForTimeout(1200);
    assert(await page.evaluate(() => !!window.gsap && document.documentElement.classList.contains('no-motion') === false), `${r} gsap active`);
    await page.evaluate(async () => { for (let y = 0; y < document.documentElement.scrollHeight; y += 300) { window.scrollTo(0, y); await new Promise((res) => setTimeout(res, 60)); } });
    await page.waitForTimeout(1600);
    const hidden = await page.evaluate(() => Array.from(document.querySelectorAll('#app [data-reveal], #app [data-split], #app [data-stagger] > *, #app [data-mask], #app [data-hero-item], #app .step h3')).filter((el) => !el.hidden && el.offsetParent && parseFloat(getComputedStyle(el).opacity) < 0.99).map((el) => el.className || el.tagName));
    assert(hidden.length === 0, `${r} all animated elements visible after scroll (${hidden.slice(0, 4).join(', ')})`);
    if (r === '#/') {
      const tech = await page.evaluate(() => document.querySelectorAll('.tech-card .tech-list li').length);
      assert(tech === 5, `technique card lists the 5 steps (${tech})`);
      await page.evaluate(() => window.scrollTo(0, 0)); await page.waitForTimeout(300);
    }
  }
  // before/after slider (test-only data: two existing photos)
  await page.evaluate(() => { const l = window.CT.Repo.projects(); l[2] = { ...l[2], before: 'img:proj_kalibratie', after: 'img:about' }; window.CT.Repo.saveProjects(l); });
  await go(page, '#/projecten/precisie-in-kalibratie', { scroll: false });
  const ba = page.locator('[data-ba]');
  await ba.scrollIntoViewIfNeeded();
  const box = await ba.boundingBox();
  await page.mouse.click(box.x + box.width * 0.25, box.y + box.height / 2);
  const pos1 = await ba.evaluate((el) => el.style.getPropertyValue('--pos'));
  await page.locator('[data-ba] input').focus();
  await page.keyboard.press('ArrowRight'); await page.keyboard.press('ArrowRight');
  const pos2 = await ba.evaluate((el) => el.style.getPropertyValue('--pos'));
  assert(pos1 !== '50%' && parseInt(pos2, 10) === parseInt(pos1, 10) + 2, `before/after: click → ${pos1}, keyboard → ${pos2}`);
  await page.screenshot({ path: `${S}/qa/ba.png` });
  console.log('errors:', errors);
  await browser.close();
})();
