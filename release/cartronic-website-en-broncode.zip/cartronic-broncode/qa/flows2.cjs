const { open, go, S } = require('./harness.cjs');
const assert = (c, m) => { if (!c) { console.log('FAIL:', m); process.exitCode = 1; } else console.log('ok  :', m); };
(async () => {
  const { browser, page, errors } = await open({ width: 1440, height: 900, reduce: false });
  const shot = (n, full = false) => page.screenshot({ path: `${S}/qa/f_${n}.png`, fullPage: full });
  await go(page, '#/webshop', { scroll: false });
  const stock0 = await page.evaluate(() => window.CT.Repo.product('prd_cam_set').stock);
  // add from card
  await page.locator('[data-action="add-to-cart"][data-id="prd_cam_set"]').first().click();
  await page.waitForTimeout(400);
  assert(await page.locator('#miniCart.is-open').count() === 1, 'mini cart popover opens');
  await shot('minicart');
  assert((await page.locator('#cartBtn .count').innerText()) === '1', 'cart badge = 1');
  // sold out button disabled
  assert(await page.locator('[data-action="add-to-cart"][data-id="prd_cam_module"]').isDisabled(), 'sold-out product cannot be added');
  // PDP qty + add
  await go(page, '#/webshop/usb-connectiviteitsmodule', { scroll: false });
  const max = await page.locator('[data-qty] input').getAttribute('max');
  assert(max === '3', `PDP qty max = stock (3) → ${max}`);
  await page.locator('[data-qty] [data-step="1"]').click();
  await page.locator('[data-qty] [data-step="1"]').click();
  assert(await page.locator('[data-qty] input').inputValue() === '3' && await page.locator('[data-qty] [data-step="1"]').isDisabled(), 'qty stepper stops at stock (3)');
  await page.fill('[data-qty] input', '9'); await page.locator('[data-qty] input').dispatchEvent('change');
  assert(await page.locator('[data-qty] input').inputValue() === '3', 'typed qty clamps to stock');
  await page.locator('.buy-row [data-action="add-to-cart"]').click();
  await page.waitForTimeout(500);
  assert((await page.locator('#cartBtn .count').innerText()) === '4', 'cart badge = 4');
  assert(await page.locator('.buy-row [data-action="add-to-cart"]').isDisabled(), 'PDP add disabled when max in cart');
  // cart drawer
  await page.locator('#cartBtn').click();
  await page.waitForSelector('.drawer.is-open');
  await page.waitForTimeout(400);
  await shot('drawer');
  const total1 = await page.locator('.drawer .t-row.is-total').innerText();
  assert(total1.includes('486,00'), `drawer total 249 + 3×79 = 486 → ${total1.replace(/\s+/g, ' ')}`);
  await page.locator('.drawer [data-qty="prd_usb"] [data-step="-1"]').click();
  await page.waitForTimeout(200);
  assert((await page.locator('.drawer .t-row.is-total').innerText()).includes('407,00'), 'qty change updates total (407)');
  await page.keyboard.press('Escape');
  // cart page
  await go(page, '#/winkelmand', { scroll: false });
  await shot('cart', true);
  const disc = await page.locator('.summary-card .t-row.is-discount').innerText();
  assert(disc.includes('50,00'), `discount line shows −€50 → ${disc.replace(/\s+/g, ' ')}`);
  // stale data: admin raises price in "another tab"
  await page.evaluate(() => { const p = window.CT.Repo.product('prd_usb'); window.CT.Repo.saveProduct({ ...p, regularPrice: 8900 }); });
  await page.reload(); await page.waitForTimeout(400);
  const notes = await page.locator('.notice').allInnerTexts();
  assert(notes.some((n) => n.replace(/\u00a0/g, ' ').includes('gewijzigd van € 79,00 naar € 89,00')), 'price change notice in cart');
  // checkout validation
  await go(page, '#/afrekenen', { scroll: false });
  await page.locator('[data-submit]').click();
  await page.waitForTimeout(200);
  assert(await page.locator('.error-summary').count() === 1, 'checkout shows error summary');
  await shot('checkout-errors', true);
  await page.fill('#co-firstName', 'Test');
  await page.fill('#co-lastName', 'Klant');
  await page.fill('#co-email', 'test@example.com');
  await page.fill('#co-phone', '0612345678');
  await page.locator('input[name="delivery"][value="verzenden"]').check({ force: true });
  await page.waitForTimeout(100);
  assert(await page.locator('#co-postal').count() === 1, 'address fields appear for shipping');
  await page.locator('[data-submit]').click();
  await page.waitForTimeout(150);
  assert((await page.locator('#co-postal-e').innerText()).includes('postcode'), 'postcode validation');
  await page.fill('#co-street', 'Teststraat'); await page.fill('#co-houseNumber', '1'); await page.fill('#co-postal', '2289EX'); await page.fill('#co-city', 'Rijswijk');
  const sumTotal = await page.locator('.summary-card .t-row.is-total').innerText();
  assert(sumTotal.includes('433,95'), `checkout total 249 + 2×89 + 6,95 shipping = 433,95 → ${sumTotal.replace(/\s+/g, ' ')}`);
  await shot('checkout', true);
  // double submit protection
  const before = await page.evaluate(() => window.CT.Repo.orders().length);
  await page.locator('[data-submit]').dblclick();
  await page.waitForTimeout(2200);
  assert(page.url().includes('#/betaling/'), 'redirected to payment page');
  const after = await page.evaluate(() => window.CT.Repo.orders().length);
  assert(after === before + 1, `exactly one order created (${after - before})`);
  // back to checkout and submit again → same order reused
  await page.goBack(); await page.waitForTimeout(600);
  await page.locator('[data-submit]').click(); await page.waitForTimeout(1600);
  const after2 = await page.evaluate(() => window.CT.Repo.orders().length);
  assert(after2 === after, 'resubmit after back reuses the pending order (idempotency)');
  await shot('payment', true);
  // fail payment
  await page.locator('[data-outcome="failed"]').click();
  await page.waitForTimeout(1200);
  assert((await page.locator('.result-head').innerText()).includes('BETALING MISLUKT'), 'failed state');
  await shot('result-failed', true);
  // retry → cancel
  await page.locator('[data-retry]').click(); await page.waitForTimeout(900);
  assert(page.url().includes('#/betaling/'), 'retry creates new payment');
  await page.locator('[data-outcome="canceled"]').click(); await page.waitForTimeout(1200);
  assert((await page.locator('.result-head').innerText()).includes('BETALING GEANNULEERD'), 'cancelled state');
  // retry → pending → webhook paid
  await page.locator('[data-retry]').click(); await page.waitForTimeout(900);
  await page.locator('[data-outcome="pending"]').click(); await page.waitForTimeout(1200);
  assert((await page.locator('.result-head').innerText()).includes('BETALING WORDT VERWERKT'), 'processing state');
  await shot('result-pending', true);
  await page.locator('[data-sim="paid"]').click(); await page.waitForTimeout(1400);
  assert((await page.locator('.result-head').innerText()).includes('BETALING GESLAAGD'), 'paid state after webhook');
  await shot('result-paid', true);
  const st = await page.evaluate(() => ({ stock: window.CT.Repo.product('prd_cam_set').stock, cart: window.CT.Cart.count(), order: window.CT.Repo.orders().slice(-1)[0] }));
  assert(st.stock === stock0 - 1, `stock decremented once (${stock0} → ${st.stock})`);
  assert(st.cart === 0, 'cart cleared after payment');
  assert(st.order.orderStatus === 'BETAALD' && st.order.payments.length === 3, `order BETAALD with 3 payment attempts (${st.order.payments.length})`);
  // refresh result page: no new side effects
  await page.reload(); await page.waitForTimeout(500);
  const st2 = await page.evaluate(() => ({ stock: window.CT.Repo.product('prd_cam_set').stock, n: window.CT.Repo.orders().length }));
  assert(st2.stock === st.stock && st2.n === after, 'refresh of result page has no side effects');
  // snapshot: change product price after order → order keeps snapshot
  await page.evaluate(() => { const p = window.CT.Repo.product('prd_cam_set'); window.CT.Repo.saveProduct({ ...p, regularPrice: 39900, discountType: 'none' }); });
  const snap = await page.evaluate(() => window.CT.Repo.orders().slice(-1)[0].items.find((i) => i.productId === 'prd_cam_set').unitPrice);
  assert(snap === 24900, 'order snapshot keeps €249 after product price change');
  // inactive product removed from cart with notice
  await page.evaluate(() => { window.CT.Cart.add('prd_carplay', 1); const p = window.CT.Repo.product('prd_carplay'); window.CT.Repo.saveProduct({ ...p, active: false }); });
  await go(page, '#/winkelmand', { scroll: false });
  assert((await page.locator('.notice').allInnerTexts()).some((n) => n.includes('niet beschikbaar')), 'inactive product removed with notice');
  console.log('errors:', errors);
  await browser.close();
})();
