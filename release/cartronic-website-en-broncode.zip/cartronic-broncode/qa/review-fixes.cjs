// Regression checks for the 31 findings of the multi-agent review (Beheer, SEO, publishing).
// CT_URL=file://…/build.html NODE_PATH=/opt/node22/lib/node_modules node qa/review-fixes.cjs
const fs = require('fs'); const path = require('path'); const { spawn } = require('child_process');
const { open } = require('./harness.cjs');
const BUILD = decodeURIComponent(new URL(process.env.CT_URL).pathname);
const FILE = `file://${BUILD}`;
const OUT = path.join(__dirname, 'rf'); fs.rmSync(OUT, { recursive: true, force: true }); fs.mkdirSync(OUT, { recursive: true });
let fails = 0;
const ok = (c, m) => { console.log(`${c ? 'ok  ' : 'FAIL'}: ${m}`); if (!c) fails++; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const BROKEN = 'Deze pagina kon niet worden geladen';
/** A copy of the build with a published bundle in script#ctContent. */
function variant(name, bundle) {
  const html = fs.readFileSync(BUILD, 'utf8');
  const marker = '<script id="ctContent" type="application/json">{}</script>';
  if (!html.includes(marker)) throw new Error('ctContent marker missing');
  const file = path.join(OUT, `${name}.html`);
  fs.writeFileSync(file, html.replace(marker, () => `<script id="ctContent" type="application/json">${JSON.stringify(bundle).replace(/</g, '\\u003c')}</script>`));
  return `file://${file}`;
}
async function visit(page, url) { await page.goto(url); await page.waitForTimeout(220); }
async function leaveIfAsked(page) {
  if (await page.$('.modal [data-ok]') && (await page.textContent('.modal')).includes('Pagina verlaten')) { await page.click('.modal [data-ok]'); await page.waitForTimeout(450); } // the dialog fades out in 380 ms
}
async function login(page, base) {
  await visit(page, `${base}${base.startsWith('file:') ? '#/admin' : '/admin'}`);
  if (await page.$('#lg-u')) {
    await page.fill('#lg-u', 'demo'); await page.fill('#lg-p', 'cartronic-demo'); await page.click('[data-login] [type=submit]');
    await page.waitForSelector('.admin-nav');
  }
}
const nav = async (page, hash) => { await visit(page, `${FILE}${hash}`); await leaveIfAsked(page); };
const appText = (page) => page.evaluate(() => document.getElementById('app').textContent);
const toasts = (page) => page.evaluate(() => [...document.querySelectorAll('.toast')].map((t) => t.textContent).join(' | '));

async function run() {
  // ---------- #0 / #29 damaged published webshop data never breaks pages
  {
    const url = variant('shop-damaged', { v: 1, stamp: '2026-01-01T00:00:00.000Z', shop: {
      products: [
        { id: 'p1', slug: 'p-een', name: 'Product een', regularPrice: 1000, compatibility: { brands: 'audi', models: 'golf-8', note: 5 }, images: 'x', category: 3, stock: 'veel', discountType: 'sale', salePrice: 'goedkoop', featured: true },
        { id: 'p2', slug: 'p-twee', name: 'Product twee', regularPrice: 2000, compatibility: { brands: ['tesla'], models: ['golf-8', 'bestaat-niet'] }, featured: true, active: 'ja' },
      ],
      shopCategories: [{ id: 'c1', name: 'Cat', slug: 'cat', order: 1 }],
      projects: [{ id: 'pr1', slug: 'pr-een', title: 'Project', image: 7, before: {}, after: [], short: 9, vehicle: null, tag: false, active: true, brands: 'seat', gallery: [1, 'img:about'] }],
      settings: { shipping: 'x', vat: 7 },
    } });
    const { browser, page, errors } = await open();
    const bad = [];
    for (const r of ['#/', '#/projecten', '#/projecten/pr-een', '#/zoeken?q=camera', '#/zoeken?q=product', '#/webshop', '#/webshop/p-een', '#/webshop/p-twee', '#/winkelmand', '#/mijn-auto']) {
      await visit(page, `${url}${r}`);
      if ((await appText(page)).includes(BROKEN)) bad.push(r);
    }
    ok(!bad.length && !errors.length, `#0/#29 damaged shop data: every page renders (${bad.join(', ') || 'all ok'}; errors ${errors.length})`);
    await browser.close();
  }

  // ---------- #2 two tabs, #24 unchanged saves, #26 recent switch, #27 link in a button, #28 hrefs
  {
    const { browser, context, page, errors } = await open();
    await login(page, FILE);
    const tabB = await context.newPage();
    await login(tabB, FILE);
    await nav(tabB, '#/admin/bedrijf'); // tab B opens a form before tab A saves
    await nav(page, '#/admin/teksten');
    await page.fill('[name="home.hero.line1"]', 'Uit tab A.');
    await page.click('[data-texts] [type=submit]'); await page.waitForTimeout(300);
    await tabB.fill('[name="kvk"]', '12345678');
    await tabB.click('[data-company] [type=submit]'); await tabB.waitForTimeout(300);
    let draft = await page.evaluate(() => JSON.parse(localStorage.getItem('ct.v1.siteDraft')));
    ok(draft.texts && draft.texts['home.hero.line1'] === 'Uit tab A.' && draft.company && draft.company.kvk === '12345678', '#2 a save in another tab keeps this tab\'s edits');
    // the stale Teksten form in tab B only saves the field it changed
    await nav(tabB, '#/admin/teksten');
    const staleB = await context.newPage(); await login(staleB, FILE); await nav(staleB, '#/admin/teksten');
    await nav(page, '#/admin/teksten');
    await page.fill('[name="home.hero.line2"]', 'Ook uit tab A.');
    await page.click('[data-texts] [type=submit]'); await page.waitForTimeout(300);
    await staleB.fill('[name="home.hero.eyebrow"]', 'Uit een oud formulier.');
    await staleB.click('[data-texts] [type=submit]'); await staleB.waitForTimeout(300);
    draft = await page.evaluate(() => JSON.parse(localStorage.getItem('ct.v1.siteDraft')));
    ok(draft.texts['home.hero.line1'] === 'Uit tab A.' && draft.texts['home.hero.line2'] === 'Ook uit tab A.' && draft.texts['home.hero.eyebrow'] === 'Uit een oud formulier.', '#2 an older Teksten form saves only its own changed field');
    await staleB.close(); await tabB.close();
    // #24: a fresh browser where nothing is changed: saving every screen unchanged is not a change
    const fresh = await open();
    const p2 = fresh.page;
    await login(p2, FILE);
    const saves = [
      ['#/admin/teksten', '[data-texts] [type=submit]'], ['#/admin/bedrijf', '[data-company] [type=submit]'], ['#/admin/weergave', '[data-display] [type=submit]'],
      ['#/admin/seo', '[data-seo] [type=submit]'], ['#/admin/opties/origineel-af-fabriek-alarm-scm', '[data-opt-form] [type=submit]'], ['#/admin/opties/volkswagen-golf-7-active-info-display', '[data-opt-form] [type=submit]'],
      ['#/admin/catalogus', '[data-catalog] [type=submit]'], ['#/admin/diensten/kalibratie-rijhulpsystemen', '[data-svc-form] [type=submit]'], ['#/admin/diensten/diagnose-storingen', '[data-svc-form] [type=submit]'],
      ['#/admin/kennis/acc-en-lane-assist-kalibreren', '[data-art-form] [type=submit]'], ['#/admin/beoordelingen', '[data-reviews] [type=submit]'], ['#/admin/meer-werk', '[data-work] [type=submit]'],
    ];
    for (const [h, sel] of saves) { await nav(p2, h); await p2.click(sel); await p2.waitForTimeout(300); }
    // hide + show again
    await nav(p2, '#/admin/opties?q=golf-8-app-connect'); await p2.waitForTimeout(300);
    await p2.click('[data-otoggle="volkswagen-golf-8-app-connect"]'); await p2.waitForTimeout(250);
    await p2.click('[data-otoggle="volkswagen-golf-8-app-connect"]'); await p2.waitForTimeout(250);
    const ch = await p2.evaluate(() => window.CT.SiteStatus.changes());
    ok(!ch.length, `#24 saving every screen unchanged reports no unpublished changes (${ch.join(', ') || 'none'})`);
    await fresh.browser.close();
    // #26 recent switch, #27 link syntax in a button text
    await nav(page, '#/mogelijkheden/origineel-af-fabriek-alarm-scm');
    await page.evaluate(() => window.CT.Content.update((d) => { d.display = { sections: { recent: false } }; d.texts = { ...(d.texts || {}), 'cta.btn1': 'Bespreek uw [mogelijkheden](/mogelijkheden)' }; }));
    await nav(page, '#/');
    ok(!(await page.$('#recent-title')), '#26 "Recent bekeken" switch hides the block on the home page');
    await nav(page, '#/mogelijkheden/audi-q5-fy-achteruitrijcamera');
    ok(!(await page.$('#recent-title')), '#26 … and on option pages');
    await nav(page, '#/over');
    const cta = await page.evaluate(() => [...document.querySelectorAll('.cta-actions a')].map((a) => a.textContent.trim()));
    ok(cta.length === 2 && cta[0] === 'Bespreek uw mogelijkheden', `#27 link syntax inside a button stays plain text (${JSON.stringify(cta)})`);
    await nav(page, '#/merken');
    ok(await page.evaluate(() => !!document.querySelector('.notice a.text-link[href="#/contact"]')), '#27 links in ordinary texts still work (brands notice)');
    await nav(page, '#/admin/teksten?groep=algemeen');
    const lbl = await page.evaluate(() => document.querySelector('label[for="tx-cta-btn1"]').textContent);
    const hints = await page.evaluate(() => document.querySelectorAll('[data-text-field] .hint').length);
    ok(lbl === 'Afsluitende balk — knop', `#27 control texts keep their field name in Beheer (${lbl})`);
    ok(await page.evaluate(() => !document.querySelector('[data-text-field="cta.title"] .text-field-foot').textContent.includes('links werken hier niet')), `#27 the "no links" hint only on button texts (${hints} hints in group)`);
    const hrefs = await page.evaluate(() => [window.CT.Content.safeHref('#//evil.example'), window.CT.Content.safeHref('/\\evil.example'), window.CT.Content.safeHref('/contact'), window.CT.fmtText('[x](#//evil.example)'), window.CT.Router.toRoute('//evil.example')]);
    ok(hrefs[0] === '' && hrefs[1] === '' && hrefs[2] === '#/contact' && !hrefs[3].includes('<a') && hrefs[4] === '/evil.example', `#28 protocol-relative links are refused (${JSON.stringify(hrefs)})`);
    console.log('   errors:', errors.length ? errors : 'none');
    await browser.close();
  }

  // ---------- #3, #4, #5, #9, #10, #12, #15, #16, #20–#23, #25 (local file)
  {
    const { browser, context, page, errors } = await open();
    await login(page, FILE);
    // #3 factory reset keeps orders
    await page.evaluate(() => {
      const R = window.CT.Repo; const o = JSON.parse(JSON.stringify(R.orders()[0]));
      o.id = 'ord_eigen_1'; o.orderNumber = 'CT-2026-00007'; o.isDemo = false; R.saveOrder(o);
      R.saveSettings({ ...R.settings(), orderSeq: 7 });
    });
    await nav(page, '#/admin/website');
    await page.click('[data-factory]'); await page.click('.modal [data-ok]'); await page.waitForTimeout(400);
    const after = await page.evaluate(() => ({ has: !!window.CT.Repo.order('ord_eigen_1'), seq: window.CT.Repo.settings().orderSeq }));
    ok(after.has && after.seq === 7, `#3 factory reset keeps orders and the order counter (${JSON.stringify(after)})`);
    // #4 category names are escaped in the filters
    await page.evaluate(() => window.CT.Content.update((d) => { d.categories = { 'camera-parkeren': { name: '<b>Camera</b> & zo' } }; }));
    await nav(page, '#/mogelijkheden');
    const opt = await page.evaluate(() => ({ text: document.querySelector('#f-cat option[value="camera-parkeren"]').textContent, bold: !!document.querySelector('#f-cat b') }));
    ok(opt.text === '<b>Camera</b> & zo' && !opt.bold, `#4 category name shown literally in the filter (${JSON.stringify(opt)})`);
    // #5 project without a valid slug
    await nav(page, '#/admin/projecten/nieuw');
    await page.fill('[name="title"]', 'Ø €'); await page.fill('[name="vehicle"]', 'Auto'); await page.fill('[name="tag"]', 'Label'); await page.fill('[name="short"]', 'Kort');
    await page.fill('[name="image"]', 'img:hero');
    await page.click('[data-pj-form] [type=submit]'); await page.waitForTimeout(250);
    ok((await page.textContent('[data-pj-err]')).includes('geldige slug'), '#5 a project without a valid slug is refused');
    // #9 canonical of catalog filters
    const canon = async (h) => { await nav(page, h); return page.evaluate(() => (document.querySelector('link[rel=canonical]') || {}).href || ''); };
    const c1 = await canon('#/mogelijkheden?merk=xyz'); const c2 = await canon('#/mogelijkheden?merk=audi&model=golf-7'); const c3 = await canon('#/mogelijkheden?cat=zzz&q=camera');
    ok(c1 === 'https://www.cartronic.nl/mogelijkheden' && c2 === 'https://www.cartronic.nl/mogelijkheden?merk=volkswagen&model=golf-7' && c3 === 'https://www.cartronic.nl/mogelijkheden', `#9 canonical uses valid filters only (${c1} | ${c2} | ${c3})`);
    // #10 query decoded once
    await nav(page, '#/zoeken?q=%2541bc');
    ok((await page.inputValue('[data-search-form] input[name="q"]')) === '%41bc', '#10 query value decoded once');
    // #12 opening hours without spaces
    await page.evaluate(() => window.CT.Content.update((d) => { d.company = { hours: [['Dinsdag-zaterdag', '09.30-17.00'], ['Ma t/m vr', '8.00 - 12.00 uur']] }; }));
    await nav(page, '#/contact');
    const oh = await page.evaluate(() => JSON.parse(document.getElementById('ctOrgLd').textContent).openingHoursSpecification.map((x) => `${x.dayOfWeek.length}:${x.opens}-${x.closes}`));
    ok(oh.join() === '5:09:30-17:00,5:08:00-12:00', `#12 opening hours "Dinsdag-zaterdag" and "Ma t/m vr" (${oh.join(' ')})`);
    // #15 a too-long text is reported, nothing lost
    await nav(page, '#/admin/teksten?groep=overig');
    await page.evaluate(() => { const el = document.querySelector('[name="priv.body"]'); el.value = 'x'.repeat(13000); el.dispatchEvent(new Event('input', { bubbles: true })); });
    await page.click('[data-texts] [type=submit]'); await page.waitForTimeout(300);
    const t15 = await page.evaluate(() => ({ kept: document.querySelector('[name="priv.body"]').value.length, stored: !!(JSON.parse(localStorage.getItem('ct.v1.siteDraft')).texts || {})['priv.body'] }));
    ok(t15.kept === 13000 && !t15.stored && (await toasts(page)).includes('te lang'), `#15 too-long text refused with a message (${JSON.stringify(t15)})`);
    await page.evaluate(() => { const el = document.querySelector('[name="priv.body"]'); el.value = el.defaultValue; });
    // #16 "+31 (0)70 …"
    await nav(page, '#/admin/bedrijf');
    await page.fill('[name="phoneIntl"]', '+31 (0)70 383 9836');
    await page.click('[data-company] [type=submit]'); await page.waitForTimeout(300);
    const tel = await page.evaluate(() => document.querySelector('.header-phone').getAttribute('href'));
    ok(tel === 'tel:+31703839836' && !(await page.textContent('[data-err="phoneIntl"]')), `#16 "+31 (0)70 383 9836" gives tel:+31703839836 (${tel})`);
    await page.fill('[name="phoneIntl"]', '+310703839836');
    await page.click('[data-company] [type=submit]'); await page.waitForTimeout(250);
    ok((await page.textContent('[data-err="phoneIntl"]')).includes('Laat de 0'), '#16 "+310…" is refused');
    // #20 "nieuw" cannot be an address
    await nav(page, '#/admin/opties/nieuw');
    await page.fill('[name="title"]', 'Nieuw'); await page.fill('[name="name"]', 'Nieuw'); await page.fill('[name="short"]', 'Test');
    await page.check('input[name="models"][value="golf-8"]', { force: true });
    await page.click('[data-opt-form] [type=submit]'); await page.waitForTimeout(250);
    const e20a = await page.textContent('[data-err="slug"]');
    await nav(page, '#/admin/diensten/nieuw');
    await page.fill('[name="title"]', 'Nieuw'); await page.fill('[name="short"]', 'Kort'); await page.fill('[name="body"]', 'Tekst');
    await page.click('[data-svc-form] [type=submit]'); await page.waitForTimeout(250);
    const e20b = await page.textContent('[data-err="slug"]');
    await nav(page, '#/admin/kennis/nieuw');
    await page.fill('[name="title"]', 'Nieuw'); await page.fill('[name="short"]', 'Kort'); await page.fill('[name="body"]', 'Tekst');
    await page.click('[data-art-form] [type=submit]'); await page.waitForTimeout(250);
    const e20c = await page.textContent('[data-err="slug"]');
    ok([e20a, e20b, e20c].every((x) => x.includes('gereserveerd')), '#20 the address "nieuw" is refused for options, services and articles');
    // #21 clearing the calibration text removes the block
    await nav(page, '#/admin/catalogus');
    await page.evaluate(() => { document.querySelectorAll('details').forEach((d) => { d.open = true; }); });
    await page.fill('[name="assistentie:calibrate"]', '');
    await page.fill('[name="beveiliging:program"]', '');
    await page.click('[data-catalog] [type=submit]'); await page.waitForTimeout(300);
    const assist = await page.evaluate(() => window.CT.catalog.RETROFITS.find((r) => r.cat === 'assistentie').slug);
    await nav(page, `#/mogelijkheden/${assist}`);
    ok(!(await appText(page)).includes('Kalibratie nodig?'), '#21 an emptied calibration text removes the block');
    await nav(page, '#/mogelijkheden/origineel-af-fabriek-alarm-scm');
    ok((await appText(page)).includes('Na de montage wordt de optie via de online verbinding'), '#21 an emptied programme text falls back to the general text');
    // #22 service topic "Geen"
    await nav(page, '#/admin/diensten/diagnose-storingen');
    await page.selectOption('[name="topic"]', '');
    await page.click('[data-svc-form] [type=submit]'); await page.waitForTimeout(300);
    await nav(page, '#/diensten/diagnose-storingen');
    const t22 = await page.evaluate(() => document.querySelector('.detail-actions .btn--primary').getAttribute('href'));
    await nav(page, '#/admin/diensten/diagnose-storingen');
    ok(t22 === '#/contact' && (await page.inputValue('[name="topic"]')) === '', `#22 topic "Geen" is kept (${t22})`);
    // #23 duplicate keeps build years per model
    const src = await page.evaluate(() => window.CT.catalog.RETROFITS.find((r) => r.yearsByModel));
    await nav(page, `#/admin/opties/nieuw?van=${src.slug}`);
    await page.click('[data-opt-form] [type=submit]'); await page.waitForTimeout(400);
    const dup = await page.evaluate((t) => window.CT.catalog.RETROFITS.find((r) => r.title === `${t} (kopie)`), src.title);
    console.log('   duplicate saved as', page.url().split('#')[1], dup && dup.slug);
    ok(!!dup && JSON.stringify(dup.yearsByModel) === JSON.stringify(Object.fromEntries(Object.entries(src.yearsByModel).filter(([m]) => dup.models.includes(m)))), `#23 a duplicate keeps the build years per model (${dup && JSON.stringify(dup.yearsByModel)})`);
    // #25 link limits
    await nav(page, '#/admin/kennis/optielijst-van-uw-auto');
    await page.fill('[name="links"]', Array.from({ length: 7 }, (_, i) => `Link ${i} | /contact`).join('\n'));
    await page.click('[data-art-form] [type=submit]'); await page.waitForTimeout(250);
    ok((await page.textContent('[data-err="links"]')).includes('maximaal 6'), '#25 more than 6 article links is refused');
    await nav(page, '#/admin/meer-werk');
    await page.fill('[data-w="links"]', Array.from({ length: 5 }, (_, i) => `Link ${i} | https://example.com/${i}`).join('\n'));
    await page.click('[data-work] [type=submit]'); await page.waitForTimeout(250);
    ok((await toasts(page)).includes('maximaal 4'), '#25 more than 4 links per card is refused');
    await leaveIfAsked(page);
    // #11 a new-tab click keeps the cart drawer open
    await nav(page, '#/webshop');
    await page.evaluate(() => window.CT.Cart.add('prd_cam_set', 1));
    await page.click('#cartBtn'); await page.waitForTimeout(400);
    context.on('page', (p) => p.close().catch(() => {}));
    const link = await page.$('.drawer a[href="#/winkelmand"], .drawer a[href$="winkelmand"]');
    if (link) await link.click({ modifiers: ['Control'] });
    await page.waitForTimeout(400);
    ok(!!link && await page.evaluate(() => !!document.querySelector('.drawer.is-open')), '#11 Ctrl-click in the cart drawer keeps it open');
    console.log('   errors:', errors.length ? errors : 'none');
    await browser.close();
  }

  // ---------- #13, #14/#30, #17, #18, #19: the published files
  {
    const { browser, page, errors } = await open();
    await login(page, FILE);
    await page.evaluate(() => window.CT.Content.update((d) => {
      d.company = { name: 'CarTronic /*__CSS__*/', phoneDisplay: '070 999 0000' };
      d.seo = { description: 'Specialist /*__JS__*/ in VAG-opties', siteUrl: 'https://example.nl/cartronic', pages: { '/mogelijkheden': { noindex: true } } };
    }));
    const res = await page.evaluate(async () => {
      const P = window.CT.Publisher;
      const html = P.html(P.bundle('2026-03-01T00:00:00.000Z'));
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const files = (await P.files()).files.map((f) => f.name);
      return {
        size: html.length, apps: html.split('<script id="ctApp">').length - 1, styles: html.split('<style id="ctStyles">').length - 1,
        canonical: !!doc.querySelector('link[rel=canonical]'), ogUrl: !!doc.querySelector('meta[property="og:url"]'),
        desc: doc.querySelector('meta[name=description]').content, site: doc.querySelector('meta[property="og:site_name"]').content,
        org: (() => { try { return JSON.parse(doc.getElementById('ctOrgLd').textContent).name; } catch (e) { return `ERR ${e.message}`; } })(),
        noscript: doc.querySelector('noscript') ? doc.querySelector('noscript').textContent : '',
        base: doc.querySelector('meta[name="ct-base"]').content,
        sitemap: P.sitemap('2026-03-01T00:00:00.000Z'), redirects: P.redirects(), files,
      };
    });
    ok(!res.canonical && !res.ogUrl, '#13 the shared static head has no canonical or og:url');
    ok(res.apps === 1 && res.styles === 1 && res.desc === 'Specialist /*__JS__*/ in VAG-opties' && res.site === 'CarTronic /*__CSS__*/' && res.org === 'CarTronic /*__CSS__*/', `#14/#30 placeholders in editor text are not expanded (apps ${res.apps}, org ${res.org})`);
    ok(res.noscript.includes('070 999 0000') && res.noscript.includes('CarTronic /*__CSS__*/'), '#17 the noscript text follows the company data');
    ok(!res.sitemap.includes('?merk=') && !res.sitemap.includes('/mogelijkheden<') && res.sitemap.includes('https://example.nl/cartronic/over'), '#18 no catalog filter URLs when the catalog page is not indexed');
    ok(res.base === '/cartronic/' && res.files.includes('cartronic-website/cartronic/index.html') && res.files.includes('cartronic-website/cartronic/sitemap.xml')
      && res.files.includes('cartronic-website/_redirects') && res.files.includes('cartronic-website/robots.txt') && res.files.includes('cartronic-website/404.html')
      && res.redirects.includes('/    /cartronic/    301') && res.redirects.includes('/cartronic/*    /cartronic/index.html    200'), `#19 sub-path layout (${res.files.join(', ')})`);
    console.log('   errors:', errors.length ? errors : 'none');
    await browser.close();
  }

  // ---------- Served (clean URLs): #1, #6, #7, #8 (hash), #11 path
  const SITE = path.join(OUT, 'site'); fs.mkdirSync(SITE, { recursive: true });
  const PORT = 8833; const ORIGIN = `http://localhost:${PORT}`;
  const server = spawn('node', [path.join(__dirname, 'serve.cjs'), SITE, String(PORT)], { stdio: 'ignore' });
  await sleep(500);
  try {
    // Two publications made from a local copy
    const gen = await open();
    await login(gen.page, FILE);
    const pubs = await gen.page.evaluate(() => {
      const P = window.CT.Publisher; const R = window.CT.Repo;
      const v1 = P.html(P.bundle('2026-01-01T00:00:00.000Z'));
      R.saveProduct({ ...R.product('prd_usb'), regularPrice: 5000 });
      const v2 = P.html(P.bundle('2026-02-01T00:00:00.000Z'));
      return { v1, v2 };
    });
    await gen.browser.close();
    fs.writeFileSync(path.join(SITE, 'index.html'), pubs.v1);
    // #6/#7 path mode guard and history
    const { browser, page, errors } = await open();
    await login(page, ORIGIN);
    await visit(page, `${ORIGIN}/over`);
    await page.evaluate(() => window.CT.Router.go('/admin/bedrijf')); await page.waitForTimeout(400);
    await page.fill('[name="kvk"]', '12345678');
    await page.click('.admin-nav a[href="/admin/bedrijf"]'); await page.waitForTimeout(300);
    const asked = await page.isVisible('.modal');
    if (asked) { await page.click('.modal [data-cancel]'); await page.waitForTimeout(300); }
    ok(asked && (await page.inputValue('[name="kvk"]')) === '12345678', '#6 clicking the open page asks before throwing away changes');
    await page.evaluate(() => history.back()); await page.waitForTimeout(500);
    const asked2 = await page.isVisible('.modal');
    if (asked2) { await page.click('.modal [data-cancel]'); await page.waitForTimeout(500); }
    ok(asked2 && page.url() === `${ORIGIN}/admin/bedrijf`, `#7 Back with unsaved changes asks; "Blijven" stays (${page.url()})`);
    await page.click('[data-company] [type=submit]'); await page.waitForTimeout(300);
    await page.evaluate(() => history.back()); await page.waitForTimeout(500);
    ok(page.url() === `${ORIGIN}/over` && (await page.textContent('h1')).length > 0, `#7 after saving, Back returns to the previous page (${page.url()})`);
    await page.evaluate(() => history.forward()); await page.waitForTimeout(500);
    await page.fill('[name="kvk"]', '87654321');
    await page.evaluate(() => history.back()); await page.waitForTimeout(500);
    if (await page.isVisible('.modal')) { await page.click('.modal [data-ok]'); await page.waitForTimeout(600); }
    const leftTo = page.url();
    await page.evaluate(() => history.forward()); await page.waitForTimeout(500);
    ok(leftTo === `${ORIGIN}/over` && page.url() === `${ORIGIN}/admin/bedrijf`, `#7 "Pagina verlaten" goes back and keeps Forward (${leftTo} → ${page.url()})`);
    // #1 parked webshop: publishing waits for a decision
    await page.evaluate(() => { const R = window.CT.Repo; R.saveProduct({ ...R.product('prd_carplay'), regularPrice: 18900 }); });
    fs.writeFileSync(path.join(SITE, 'index.html'), pubs.v2);
    await visit(page, `${ORIGIN}/admin/website`);
    const parked = await page.evaluate(() => window.CT.Repo.shopParked);
    const notice = await page.evaluate(() => (document.querySelector('.admin-content .notice') || {}).textContent || '');
    let downloaded = false;
    page.once('download', () => { downloaded = true; });
    await page.click('[data-publish]'); await page.waitForTimeout(1200);
    ok(parked && notice.includes('eigen concept') && !downloaded && (await toasts(page)).includes('Kies eerst'), '#1 a parked webshop must be decided before publishing');
    await page.click('[data-parked="published"]'); await page.click('.modal [data-ok]'); await page.waitForTimeout(500);
    const usb = await page.evaluate(() => ({ parked: window.CT.Repo.shopParked, usb: window.CT.Repo.product('prd_usb').regularPrice }));
    ok(!usb.parked && usb.usb === 5000, `#1 choosing the published version loads its webshop data (${JSON.stringify(usb)})`);
    console.log('   errors:', errors.length ? errors : 'none');
    await browser.close();
    // #8 hash mode: a guarded link click leaves no duplicate history entry
    const h = await open();
    await login(h.page, FILE);
    await visit(h.page, `${FILE}#/over`);
    await h.page.evaluate(() => window.CT.Router.go('/admin/bedrijf')); await h.page.waitForTimeout(400);
    await h.page.fill('[name="kvk"]', '12345678');
    await h.page.click('.admin-nav a[href="#/admin/teksten"]'); await h.page.waitForTimeout(300);
    if (await h.page.isVisible('.modal')) { await h.page.click('.modal [data-ok]'); await h.page.waitForTimeout(400); }
    const at = h.page.url().split('#')[1];
    await h.page.evaluate(() => history.back()); await h.page.waitForTimeout(400);
    const b1 = h.page.url().split('#')[1];
    await h.page.evaluate(() => history.back()); await h.page.waitForTimeout(400);
    const b2 = h.page.url().split('#')[1];
    ok(at === '/admin/teksten' && b1 === '/admin/bedrijf' && b2 === '/over', `#8 hash mode: leaving via a link keeps a clean history (${at} → ${b1} → ${b2})`);
    // #7 in hash mode too
    await h.page.evaluate(() => history.forward()); await h.page.waitForTimeout(400);
    await h.page.fill('[name="kvk"]', '11112222');
    await h.page.evaluate(() => history.back()); await h.page.waitForTimeout(500);
    const askedH = await h.page.isVisible('.modal');
    if (askedH) { await h.page.click('.modal [data-cancel]'); await h.page.waitForTimeout(500); }
    const stay = h.page.url().split('#')[1];
    await h.page.click('[data-company] [type=submit]'); await h.page.waitForTimeout(300);
    await h.page.evaluate(() => history.back()); await h.page.waitForTimeout(500);
    ok(askedH && stay === '/admin/bedrijf' && h.page.url().split('#')[1] === '/over', `#7 hash mode: Back, "Blijven", save, Back (${stay} → ${h.page.url().split('#')[1]})`);
    console.log('   errors:', h.errors.length ? h.errors : 'none');
    await h.browser.close();
  } finally { server.kill(); }
}
run().then(() => {
  console.log(fails ? `${fails} FAILED` : 'ALL REVIEW-FIX CHECKS PASSED');
  process.exit(fails ? 1 : 0);
}).catch((e) => { console.error(e); process.exit(1); });
