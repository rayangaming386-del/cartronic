const { open, go, S } = require('./harness.cjs');
const assert = (c, m) => { if (!c) { console.log('FAIL:', m); process.exitCode = 1; } else console.log('ok  :', m); };
(async () => {
  const { browser, page, errors } = await open({ width: 1440, height: 900, reduce: false });
  const shot = (n) => page.screenshot({ path: `${S}/qa/f_${n}.png` });
  await go(page, '#/', { scroll: false });
  await page.waitForTimeout(900);
  // home finder opens on brand/model (approved design); the plate search is one click away
  assert(await page.locator('#vind-uw-auto [role="tablist"]').count() === 0 && await page.locator('#vind-uw-auto select[name="brand"]').isVisible(), 'home finder: brand/model first, no tabs');
  assert(await page.locator('#vind-uw-auto .finder-year').isHidden(), 'home finder: year hidden until a model is chosen');
  await page.selectOption('#vind-uw-auto select[name="brand"]', 'volkswagen');
  await page.selectOption('#vind-uw-auto select[name="model"]', 'golf-7');
  assert(await page.locator('#vind-uw-auto .finder-year').isVisible(), 'home finder: year appears after model');
  await page.locator('#vind-uw-auto [data-panel="manual"] [data-tab="plate"]').click();
  assert(await page.locator('#vind-uw-auto input[name="plate"]').isVisible(), 'home finder: switch to plate search');
  // invalid plate
  const plate = page.locator('#vind-uw-auto input[name="plate"]');
  await plate.fill('abc');
  await page.locator('#vind-uw-auto [data-plate-submit]').click();
  assert((await page.locator('#vind-uw-auto [data-plate-err]').textContent()).includes('geen geldig'), 'invalid plate shows error');
  // normalisation
  await plate.fill('');
  await plate.type('12abc3');
  assert(await plate.inputValue() === '12-ABC-3', `plate normalised while typing (${await plate.inputValue()})`);
  // live RDW (mocked) → Golf 8 by type code
  await page.locator('#vind-uw-auto [data-plate-submit]').click();
  await page.waitForSelector('#vind-uw-auto .state-card--ok', { timeout: 5000 });
  const t1 = await page.locator('#vind-uw-auto .state-card--ok').innerText();
  assert(t1.includes('VOERTUIG GEVONDEN') && t1.includes('Golf 8') && t1.includes('RDW'), 'live RDW match → Volkswagen Golf 8');
  await page.waitForTimeout(400);
  await shot('found');
  assert((await page.locator('#vehicleChip').innerText()).toUpperCase().includes('GOLF 8'), 'header chip shows Golf 8');
  // RDW unavailable
  await plate.fill('XX-999-X');
  await page.locator('#vind-uw-auto [data-plate-submit]').click();
  await page.waitForSelector('#vind-uw-auto .state-card--warn', { timeout: 10000 });
  assert((await page.locator('#vind-uw-auto .state-card--warn').innerText()).includes('RDW TIJDELIJK NIET BEREIKBAAR'), 'RDW unavailable state');
  // not found (mock returns [])
  await plate.fill('99-ZZZ-9');
  await page.locator('#vind-uw-auto [data-plate-submit]').click();
  await page.waitForSelector('#vind-uw-auto .state-card--error', { timeout: 5000 });
  assert((await page.locator('#vind-uw-auto .state-card--error').innerText()).includes('KENTEKEN NIET GEVONDEN'), 'not found state');
  // demo plates list
  await page.locator('#vind-uw-auto [data-demo-toggle]').click();
  await page.locator('#vind-uw-auto [data-demo-plate="TEST06"]').click();
  await page.waitForSelector('#vind-uw-auto [data-gen]', { timeout: 5000 });
  assert(true, 'ambiguous generation shows choices');
  await shot('ambiguous');
  await page.locator('#vind-uw-auto [data-gen="golf-7"]').click();
  assert((await page.locator('#vind-uw-auto .state-card--ok').innerText()).includes('Golf 7'), 'choosing generation sets Golf 7');
  for (const [p, txt] of [['TEST05', 'MERK NIET ONDERSTEUND'], ['TEST07', 'MODEL NIET IN ONLINE CATALOGUS'], ['TEST11', 'GENERATIE NIET IN ONLINE CATALOGUS'], ['TEST09', 'RDW TIJDELIJK']]) {
    await page.locator(`#vind-uw-auto [data-demo-plate="${p}"]`).click();
    await page.waitForTimeout(1100);
    const t = await page.locator('#vind-uw-auto [data-result]').innerText();
    assert(t.includes(txt), `demo ${p} → ${txt}`);
  }
  await shot('unsupported');
  // demo match → go to catalog
  await page.locator('#vind-uw-auto [data-demo-plate="TEST03"]').click();
  await page.waitForSelector('#vind-uw-auto .state-card--ok');
  await page.locator('#vind-uw-auto [data-r="done"]').click();
  await page.waitForTimeout(600);
  assert(page.url().includes('#/mogelijkheden'), 'navigated to catalog');
  const count = await page.locator('[data-count]').innerText();
  assert(/\d+ mogelijkhe/.test(count), `catalog count shown: ${count}`);
  const vb = await page.locator('.vehicle-bar').innerText();
  assert(vb.includes('SEAT Ibiza KJ'), 'vehicle bar shows SEAT Ibiza KJ');
  const statuses = await page.locator('.results-grid .status').allInnerTexts();
  assert(statuses.length > 0 && statuses[0].toUpperCase().includes('BESCHIKBAAR'), `statuses shown (${statuses.slice(0, 3).join(', ')})`);
  await page.waitForTimeout(500);
  await shot('catalog-vehicle');
  // toggle all
  await page.locator('a:has-text("Toon alle mogelijkheden")').click();
  await page.waitForTimeout(500);
  assert((await page.locator('[data-count]').innerText()).startsWith('327'), 'show all → 327');
  // filter by category via select
  await page.selectOption('#f-cat', 'trekhaken');
  await page.waitForTimeout(300);
  assert(page.url().includes('cat=trekhaken'), 'filter writes URL state');
  const n = parseInt(await page.locator('[data-count] strong').innerText(), 10);
  assert(n > 0 && n < 327, `trekhaken filter → ${n}`);
  // text search with synonyms
  await page.selectOption('#f-cat', '');
  await page.fill('#f-q', 'carplay');
  await page.waitForTimeout(500);
  const titles = await page.locator('.results-grid .card-title').allInnerTexts();
  assert(titles.some((t) => t.includes('App Connect')) && titles.some((t) => t.includes('Smartphone Interface')), `synonym carplay → App Connect + Smartphone Interface (${titles.length})`);
  // manual selection via vehicle modal
  await page.locator('#vehicleChip').click();
  await page.waitForSelector('.modal.is-open');
  await page.locator('.modal [data-tab="manual"]').click();
  await page.selectOption('.modal select[name="brand"]', 'audi');
  await page.selectOption('.modal select[name="model"]', 'a4-b9');
  await page.selectOption('.modal select[name="year"]', '2019');
  await shot('modal-manual');
  await page.locator('.modal [data-manual-form] button[type="submit"]').click();
  await page.waitForTimeout(700);
  assert((await page.locator('#vehicleChip').innerText()).toUpperCase().includes('A4'), 'manual selection → A4 B9');
  assert(page.url().endsWith('#/mogelijkheden'), `manual selection → catalog (${page.url().split('#')[1]})`);
  // retrofit detail with vehicle context (Avant requirement, no body known → variant)
  await go(page, '#/mogelijkheden/audi-a4-b9-avant-elektrische-achterklep', { scroll: false });
  const cp = await page.locator('.compat-panel').innerText();
  assert(cp.includes('UITVOERING AFHANKELIJK'), 'A4 Avant tailgate → UITVOERING AFHANKELIJK');
  await page.locator('.acc-trigger').nth(1).click();
  assert(await page.locator('.acc-item').nth(1).evaluate((e) => e.classList.contains('is-open')), 'accordion opens');
  await page.locator('[data-action="toggle-save"]').first().click();
  assert((await page.locator('[data-save-label]').innerText()) === 'Bewaard', 'save option toggles');
  await shot('detail');
  // year outside range → contact
  await page.evaluate(() => window.CT.VehicleStore.set({ brandId: 'skoda', modelId: 'kodiaq', year: 2022, source: 'manual' }));
  await go(page, '#/mogelijkheden/skoda-kodiaq-achteruitrijcamera', { scroll: false });
  assert((await page.locator('.compat-panel').innerText()).includes('NEEM CONTACT OP'), 'Kodiaq 2022 → NEEM CONTACT OP');
  // share URL without plate
  await go(page, '#/mogelijkheden?merk=volkswagen&model=golf-8', { scroll: false });
  assert((await page.locator('.notice').first().innerText()).includes('Gedeelde selectie'), 'shared selection banner');
  // search overlay
  await go(page, '#/', { scroll: false });
  await page.keyboard.press('Control+k');
  await page.waitForSelector('.search-panel.is-open');
  await page.keyboard.type('camera');
  await page.waitForTimeout(300);
  const groups = await page.locator('.search-option .so-type').allInnerTexts();
  assert(groups.includes('CATEGORIE') && groups.includes('RETROFIT') && groups.includes('PRODUCT'), `autocomplete types: ${[...new Set(groups)].join(',')}`);
  await shot('search');
  await page.keyboard.press('ArrowDown');
  await page.keyboard.press('Enter');
  await page.waitForTimeout(500);
  assert(!page.url().endsWith('#/'), `keyboard enter navigates (${page.url().split('#')[1]})`);
  console.log('errors:', errors);
  await browser.close();
})();
