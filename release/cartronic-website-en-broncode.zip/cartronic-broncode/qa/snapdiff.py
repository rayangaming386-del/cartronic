import json,sys,difflib,re
a=json.load(open(sys.argv[1])); b=json.load(open(sys.argv[2]))
ws=lambda x: re.sub(r'\s+',' ',re.sub(r'>\s+<','><',x or '')).strip()
diffs=0; wsonly=[]
for k in sorted(set(a)|set(b)):
    if k not in a or k not in b: print('MISSING', k, k in a, k in b); diffs+=1; continue
    for f in ('title','desc','app','header','footer','mnav'):
        if a[k].get(f)!=b[k].get(f):
            if ws(a[k].get(f))==ws(b[k].get(f)): wsonly.append((k,f)); continue
            diffs+=1
            if diffs<=15:
                sa=ws(a[k].get(f)).replace('><','>\n<').split('\n'); sb=ws(b[k].get(f)).replace('><','>\n<').split('\n')
                d=[l for l in difflib.unified_diff(sa,sb,lineterm='',n=0) if not l.startswith(('---','+++','@@'))]
                print('DIFF',k,f); print('\n'.join(x[:400] for x in d[:10]))
print('whitespace-only diffs', len(wsonly), wsonly[:20])
print('total diffs', diffs)
