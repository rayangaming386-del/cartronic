const fs = require('fs');
const { open, go, S } = require('./harness.cjs');
const AXE = fs.readFileSync(`${S}/tools/node_modules/axe-core/axe.min.js`, 'utf8');
const ROUTES = ['#/', '#/mogelijkheden', '#/mogelijkheden/audi-a3-8v-virtual-cockpit', '#/mogelijkheden/audi-q5-fy-virtual-cockpit', '#/mogelijkheden/volkswagen-discover-navigatie-met-carplay', '#/mogelijkheden/volkswagen-golf-7-active-info-display', '#/mogelijkheden?merk=skoda&model=kodiaq', '#/merken/audi', '#/zoeken?q=golf%207%20camera', '#/merken', '#/projecten', '#/projecten/precisie-in-kalibratie', '#/expertise', '#/over', '#/contact', '#/mijn-auto', '#/webshop', '#/webshop/parkeersensor-retrofit-set', '#/winkelmand', '#/zoeken?q=acc', '#/admin', '#/beoordelingen', '#/kennis', '#/kennis/acc-en-lane-assist-kalibreren', '#/productinformatie', '#/privacy', '#/diensten/online-programmeren'];
(async () => {
  const { browser, page } = await open({ width: 1440, height: 900 });
  const summary = {};
  for (const r of ROUTES) {
    await go(page, r, { scroll: false });
    await page.addScriptTag({ content: AXE });
    const res = await page.evaluate(async () => {
      const out = await window.axe.run(document, { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'best-practice'] }, rules: { 'region': { enabled: false } } });
      return out.violations.map((v) => ({ id: v.id, impact: v.impact, n: v.nodes.length, help: v.help, sample: v.nodes.slice(0, 12).map((n) => n.target.join(' ') + ' :: ' + (n.failureSummary || '').split('\n').slice(1, 2).join('')) }));
    });
    for (const v of res) { const e = (summary[v.id] = summary[v.id] || { impact: v.impact, help: v.help, pages: [], sample: [] }); e.pages.push(`${r}(${v.n})`); e.sample.push(...v.sample.map((x) => r + ' ' + x)); }
  }
  for (const [id, v] of Object.entries(summary)) console.log(`${v.impact.padEnd(9)} ${id}: ${v.help}\n   ${v.pages.join(' ')}\n   e.g. ${v.sample.join('\n        ')}`);
  await browser.close();
})();
