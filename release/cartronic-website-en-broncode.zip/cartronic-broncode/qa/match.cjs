const { open, go } = require('./harness.cjs');
(async () => {
  const { browser, page } = await open({ width: 800, height: 600 });
  await go(page, '#/', { scroll: false });
  const out = await page.evaluate(() => {
    const M = (merk, naam, d, type = '', kind = 'Personenauto', inr = '') => { const r = window.CT.VehicleLookup && null; return null; };
    const cases = [
      ['VOLKSWAGEN', 'GOLF', '20190301', 'AU'], ['VOLKSWAGEN', 'GOLF', '20210301', 'CD'], ['VOLKSWAGEN', 'GOLF', '20200601', ''], ['VOLKSWAGEN', 'GOLF', '20200601', 'CD'],
      ['VOLKSWAGEN', 'GOLF SPORTSVAN', '20180301', 'AM'], ['VOLKSWAGEN', 'VOLKSWAGEN T-ROC', '20200301', 'A1'], ['SKODA', 'OCTAVIA COMBI', '20200901', 'NX'], ['SKODA', 'OCTAVIA', '20210101', 'NX'],
      ['AUDI', 'A3 SPORTBACK E-TRON', '20160101', '8V'], ['AUDI', 'Q4 SPORTBACK E-TRON', '20220101', 'F4'], ['SEAT', 'IBIZA', '20160101', '6J'], ['CUPRA', 'FORMENTOR', '20220101', 'KM'],
      ['VOLKSWAGEN', 'UP!', '20170101', ''], ['VOLKSWAGEN', 'ID.3', '20210101', ''], ['VOLKSWAGEN', 'TRANSPORTER', '20190101', 'SG', 'Bedrijfsauto'], ['YAMAHA', 'MT-07', '20190101', '', 'Motorfiets'],
    ];
    return cases.map(([merk, h, d, type, kind]) => { const r = window.CT.VehicleMatcher.match({ merk, handelsbenaming: h, datum_eerste_toelating: d, type, voertuigsoort: kind || 'Personenauto' }); return `${merk} ${h} ${d.slice(0, 4)} ${type} → ${r.status} ${r.modelId || (r.options || []).join('/') || ''} ${r.confidence || ''}`; });
  }).catch((e) => [String(e)]);
  console.log(out.join('\n'));
  await browser.close();
})();
