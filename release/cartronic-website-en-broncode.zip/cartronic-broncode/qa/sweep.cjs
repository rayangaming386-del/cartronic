const { open, go, overflow, S } = require('./harness.cjs');
const fs = require('fs');
const [,, width = '1440', height = '900', tag = 'd', only = ''] = process.argv;
const ROUTES = [
  ['home', '#/'], ['catalog', '#/producten'], ['retrofit', '#/producten/audi-a3-8v-virtual-cockpit'],
  ['brands', '#/merken'], ['brand', '#/merken/audi'], ['projects', '#/portfolio'], ['project', '#/portfolio/seat-ibiza-camera-meesturende-lijnen'],
  ['expertise', '#/diensten'], ['service', '#/diensten/kalibratie-rijhulpsystemen'], ['about', '#/over'], ['contact', '#/contact'],
  ['garage', '#/mijn-auto'], ['search', '#/zoeken?q=camera'], ['shop', '#/webshop'], ['product', '#/webshop/achteruitrijcamera-retrofit-set'],
  ['cart', '#/winkelmand'], ['checkout', '#/afrekenen'], ['admin', '#/admin'], ['notfound', '#/bestaat-niet'],
  ['r-q5vc', '#/producten/audi-q5-fy-virtual-cockpit'], ['r-aid', '#/producten/volkswagen-golf-7-active-info-display'],
  ['r-dcp', '#/producten/volkswagen-discover-navigatie-met-carplay'], ['r-caddy', '#/producten/volkswagen-caddy-sa-achteruitrijcamera-achterdeuren'],
  ['r-alarm', '#/producten/origineel-af-fabriek-alarm-scm'], ['cat-kodiaq', '#/producten?merk=skoda&model=kodiaq'],
  ['brand-vw', '#/merken/volkswagen'], ['search-g7', '#/zoeken?q=golf%207%20camera'],
  ['reviews', '#/beoordelingen'], ['kennis', '#/kennis'], ['article', '#/kennis/origineel-alarm-met-scm-certificaat'], ['prodinfo', '#/productinformatie'], ['privacy', '#/privacy'], ['service-prog', '#/diensten/online-programmeren'],
];
(async () => {
  const { browser, page, errors } = await open({ width: +width, height: +height, mobile: +width < 800 });
  fs.mkdirSync(`${S}/qa/${tag}`, { recursive: true });
  for (const [name, hash] of ROUTES) {
    if (only && !only.split(',').includes(name)) continue;
    errors.length = 0;
    await go(page, hash);
    await page.waitForTimeout(300);
    await page.screenshot({ path: `${S}/qa/${tag}/${name}.png`, fullPage: true });
    const o = await overflow(page);
    const h = await page.evaluate(() => document.documentElement.scrollHeight);
    console.log(`${name.padEnd(10)} h=${h} overflow=${o.scrollWidth > o.clientWidth ? 'YES ' + JSON.stringify(o.offenders) : 'no'} errors=${errors.length ? JSON.stringify(errors) : 0}`);
  }
  await browser.close();
})();
