// Prints the login data (salted PBKDF2-SHA-256 hash) for DEFAULT_AUTH in src/03-domain.js.
// The password is read from the environment and is never written anywhere:
//   CT_ADMIN_USER=… CT_ADMIN_PASSWORD=… node qa/make-auth.cjs
const crypto = require('crypto');
const user = process.env.CT_ADMIN_USER; const pass = process.env.CT_ADMIN_PASSWORD;
if (!user || !pass) { console.error('Zet CT_ADMIN_USER en CT_ADMIN_PASSWORD.'); process.exit(1); }
const iter = 600000;
const salt = crypto.randomBytes(16);
const hash = crypto.pbkdf2Sync(Buffer.from(pass, 'utf8'), salt, iter, 32, 'sha256');
console.log(JSON.stringify({ user, salt: salt.toString('base64'), hash: hash.toString('base64'), iter }));
