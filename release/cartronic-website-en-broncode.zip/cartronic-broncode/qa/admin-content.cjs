// Beheer → website content: every screen saves, validates and changes the site as expected.
const { open, go } = require('./harness.cjs');
let fails = 0;
const assert = (c, m) => { console.log(`${c ? 'ok  ' : 'FAIL'}: ${m}`); if (!c) fails++; };
(async () => {
  const { browser, page, errors } = await open({ width: 1440, height: 900 });
  const save = async (sel = 'form [type=submit]') => { await page.click(sel); await page.waitForTimeout(250); };
  const visit = async (h) => {
    await go(page, h, { scroll: false }); await page.waitForTimeout(120);
    // A dirty form asks before leaving: confirm, as a user who means to leave would.
    if (await page.$('.modal [data-ok]') && (await page.textContent('.modal')).includes('Pagina verlaten')) { await page.click('.modal [data-ok]'); await page.waitForTimeout(400); }
  };
  const setv = (sel, v) => page.evaluate(([s, val]) => { const el = document.querySelector(s); el.value = val; el.dispatchEvent(new Event('input', { bubbles: true })); }, [sel, v]);
  const text = (sel) => page.evaluate((s) => (document.querySelector(s) || {}).textContent || '', sel);
  await visit('#/admin');
  await page.fill('#lg-u', 'demo'); await page.fill('#lg-p', 'cartronic-demo'); await page.click('[data-login] [type=submit]');
  await page.waitForSelector('.admin-nav');
  assert(await page.evaluate(() => localStorage.getItem('ct.v1.editor') === 'true'), 'login marks this browser as editor');

  // ---- Teksten
  await visit('#/admin/teksten');
  await page.fill('[name="home.hero.line1"]', 'Testtitel.');
  await setv('[name="footer.proto"]', '');
  await setv('[name="cta.text"]', 'Bel ons **vandaag** nog.\nTweede regel.');
  await save();
  await visit('#/');
  assert((await text('#hero-title')).includes('Testtitel.'), 'hero title from Teksten');
  assert(!(await text('#siteFooter')).includes('Interactief prototype'), 'optional footer text can be emptied');
  assert(await page.evaluate(() => /<strong>vandaag<\/strong>[^<]*<br>Tweede regel\./.test(document.querySelector('.cta-band p').innerHTML)), 'bold and line break formatting');
  await visit('#/admin/teksten?groep=home');
  assert(await page.evaluate(() => document.querySelector('[data-text-field="home.hero.line1"] .pill--info') !== null), 'changed text marked as Aangepast');
  await page.click('[data-text-reset="home.hero.line1"]'); await save();
  await visit('#/');
  assert((await text('#hero-title')).includes('Origineel.'), 'text reset to default');
  // search across groups
  await visit('#/admin/teksten');
  await page.fill('[data-text-q]', 'optielijst');
  await page.waitForTimeout(300);
  const found = await page.evaluate(() => [...document.querySelectorAll('[data-text-field]')].filter((f) => !f.hidden && !f.closest('[hidden]')).map((f) => f.dataset.textField));
  assert(found.includes('pi.opt.link') && found.includes('topic.optielijst'), `text search finds fields in other groups (${found.length})`);

  // ---- Bedrijfsgegevens
  await visit('#/admin/bedrijf');
  await page.fill('[name="email"]', 'geen-email');
  await save();
  assert(await page.evaluate(() => document.querySelector('[data-err="email"]').textContent.length > 0), 'invalid e-mail rejected');
  await page.fill('[name="email"]', 'test@cartronic.nl');
  await page.fill('[name="phoneDisplay"]', '070 123 4567');
  await page.fill('[name="phoneIntl"]', '+31 70 123 4567');
  await page.fill('[name="kvk"]', '12345678');
  await page.click('[data-hours-add]');
  const rows = await page.$$('.row-edit');
  await rows[rows.length - 1].$eval('[data-h="day"]', (el) => { el.value = 'Feestdagen'; });
  await rows[rows.length - 1].$eval('[data-h="time"]', (el) => { el.value = 'Gesloten'; });
  await save();
  await visit('#/contact');
  const foot = await text('#siteFooter');
  assert(foot.includes('070 123 4567') && foot.includes('test@cartronic.nl') && foot.includes('Feestdagen') && foot.includes('KvK 12345678'), 'footer shows new company data');
  assert(await page.evaluate(() => document.querySelector('.header-phone').getAttribute('href') === 'tel:+31701234567'), 'call link uses the international number');
  const org = await page.evaluate(() => JSON.parse(document.getElementById('ctOrgLd').textContent));
  assert(org.telephone === '+31701234567' && org.openingHoursSpecification && org.openingHoursSpecification[0].dayOfWeek.join() === 'Tuesday,Wednesday,Thursday,Friday', 'structured data: phone and opening hours parsed');

  // ---- Weergave
  await visit('#/admin/weergave');
  await page.click('[name="shop"] + .track');
  await page.click('[name="a:on"] + .track');
  await page.fill('[name="a:text"]', 'Wij zijn **gesloten** op 27 april.');
  await page.fill('[name="a:linkLabel"]', 'Contact');
  await page.fill('[name="a:link"]', '/contact');
  await page.click('[name="s:home.reviews"] + .track');
  await save();
  await visit('#/');
  assert(await page.evaluate(() => !document.querySelector('.main-nav a[data-nav="webshop"]') && !document.getElementById('cartBtn')), 'shop off: nav item and cart button gone');
  assert(await page.evaluate(() => !document.querySelector('#featured-title') && !document.querySelector('#reviews-title')), 'home: shop and reviews sections hidden');
  assert((await text('#announceBar')).includes('gesloten op 27 april'), 'announcement bar shown');
  await visit('#/webshop');
  assert((await text('h1')).includes('niet beschikbaar'), 'webshop closed page');
  assert(await page.evaluate(() => document.querySelector('meta[name=robots]').content.startsWith('noindex')), 'closed webshop not indexed');
  await visit('#/admin/weergave');
  await page.click('[name="shop"] + .track'); await page.click('[name="a:on"] + .track'); await page.click('[name="s:home.reviews"] + .track');
  await save();
  await visit('#/');
  assert(await page.evaluate(() => !!document.getElementById('cartBtn') && !document.getElementById('announceBar') && !!document.querySelector('#reviews-title')), 'display settings restored');

  // ---- SEO
  await visit('#/admin/seo');
  await page.fill('[name="siteUrl"]', 'https://example.nl/');
  await page.fill('[name="homeTitle"]', 'Test home');
  await save('[data-seo] [type=submit]');
  await visit('#/mogelijkheden');
  assert(await page.evaluate(() => document.querySelector('link[rel=canonical]').href === 'https://example.nl/mogelijkheden'), 'canonical uses website address');
  await visit('#/');
  assert((await page.title()) === 'Test home', 'home title from SEO');
  await visit('#/admin/seo?q=contact');
  await page.waitForTimeout(300);
  await page.click('[data-seo-edit="/contact"]');
  await page.fill('.modal [name="title"]', 'Neem contact op');
  await page.click('[data-seo-save]');
  await page.waitForTimeout(400);
  await visit('#/contact');
  assert((await page.title()) === 'Neem contact op | CarTronic', `per-page title (${await page.title()})`);

  // ---- Opties: hide, edit, revert, add, duplicate, delete
  const count = () => page.evaluate(() => window.CT.catalog.RETROFITS.length);
  const before = await count();
  await visit('#/admin/opties?q=golf-8-app-connect');
  await page.waitForTimeout(300);
  await page.click('[data-otoggle="volkswagen-golf-8-app-connect"]');
  await page.waitForTimeout(300);
  assert(await count() === before - 1, 'hidden option removed from catalog');
  await visit('#/mogelijkheden/volkswagen-golf-8-app-connect');
  assert((await text('h1')).includes('bestaat niet'), 'hidden option page is a 404');
  await visit('#/admin/opties?status=verborgen');
  await page.waitForTimeout(300);
  await page.click('[data-otoggle="volkswagen-golf-8-app-connect"]');
  await page.waitForTimeout(300);
  assert(await count() === before, 'option shown again');
  await visit('#/admin/opties/volkswagen-golf-7-active-info-display');
  await page.fill('[name="price"]', '€ 999 excl. btw');
  await save();
  await visit('#/mogelijkheden/volkswagen-golf-7-active-info-display');
  assert((await text('.spec-list')).includes('€ 999 excl. btw'), 'edited price on option page');
  const stored = await page.evaluate(() => JSON.parse(localStorage.getItem('ct.v1.siteDraft')).retrofits.edit['volkswagen-golf-7-active-info-display']);
  assert(stored && Object.keys(stored).join() === 'price', `only the changed field is stored (${JSON.stringify(stored)})`);
  await visit('#/admin/opties/volkswagen-golf-7-active-info-display');
  page.once('dialog', (d) => d.accept());
  await page.click('[data-opt-revert]');
  await page.click('.modal [data-ok]');
  await page.waitForTimeout(300);
  await visit('#/mogelijkheden/volkswagen-golf-7-active-info-display');
  assert((await text('.spec-list')).includes('€ 1.099 excl. btw'), 'option reverted to default');
  // unchanged save stores nothing
  await visit('#/admin/opties/origineel-af-fabriek-alarm-scm');
  await save();
  const alarmEdit = await page.evaluate(() => (JSON.parse(localStorage.getItem('ct.v1.siteDraft')).retrofits.edit || {})['origineel-af-fabriek-alarm-scm']);
  assert(!alarmEdit, 'saving an unchanged brand-wide option stores no edit');
  await visit('#/admin/opties/audi-smartphone-interface-carplay');
  await save();
  assert(!(await page.evaluate(() => (JSON.parse(localStorage.getItem('ct.v1.siteDraft')).retrofits.edit || {})['audi-smartphone-interface-carplay'])), 'saving unchanged single-brand option stores no edit');
  // new option
  await visit('#/admin/opties/nieuw');
  await page.fill('[name="title"]', 'Volkswagen Golf 8 – Testoptie');
  await page.fill('[name="name"]', 'Testoptie');
  await page.selectOption('[name="cat"]', 'comfort');
  await save();
  assert(await page.evaluate(() => document.querySelector('[data-err="models"]').textContent.length > 0), 'new option requires a model');
  await page.check('input[name="models"][value="golf-8"]', { force: true });
  await page.fill('[name="short"]', 'Een testoptie voor de Golf 8.');
  await page.fill('[name="specs"]', 'Kleur: zwart');
  await page.fill('[name="yearFrom"]', '2021'); await page.fill('[name="yearTo"]', '2024');
  await save();
  assert(page.url().endsWith('#/admin/opties/volkswagen-golf-8-testoptie'), `new option saved (${page.url().split('#')[1]})`);
  await visit('#/mogelijkheden/volkswagen-golf-8-testoptie');
  assert((await text('h1')).includes('Testoptie') && (await text('.spec-list')).includes('Kleur'), 'new option page renders');
  await visit('#/mogelijkheden?merk=volkswagen&model=golf-8&cat=comfort');
  await page.waitForTimeout(300);
  assert((await text('[data-results]')).includes('Testoptie'), 'new option in the catalog for its model');
  const hits = await page.evaluate(() => window.CT.Search.query('testoptie').map((r) => r.id));
  assert(hits.includes('volkswagen-golf-8-testoptie'), 'new option is searchable');
  await visit('#/admin/opties/nieuw?van=origineel-af-fabriek-alarm-scm');
  assert((await page.inputValue('[name="title"]')).includes('(kopie)') && await page.isChecked('input[name="scope"][value="brand"]'), 'duplicate pre-fills the form');
  await page.fill('[name="slug"]', 'origineel-af-fabriek-alarm-scm');
  await save();
  assert(await page.evaluate(() => document.querySelector('[data-err="slug"]').textContent.includes('bestaat al')), 'duplicate slug rejected');
  await visit('#/admin/opties/volkswagen-golf-8-testoptie');
  await page.click('[data-opt-delete]'); await page.click('.modal [data-ok]');
  await page.waitForTimeout(300);
  assert(await count() === before, 'added option deleted');

  // ---- Categorieën & merken
  await visit('#/admin/catalogus');
  await page.evaluate(() => { document.querySelectorAll('details').forEach((d) => { d.open = true; }); });
  await page.fill('[name="comfort:name"]', 'Comfort & gemak');
  await page.fill('[name="brand:seat"]', 'SEAT-introductie test.');
  await save();
  await visit('#/');
  assert((await text('.cat-grid')).includes('Comfort & gemak'), 'category name on home');
  await visit('#/merken/seat');
  assert((await text('.page-header')).includes('SEAT-introductie test.'), 'brand intro');

  // ---- Diensten
  await visit('#/admin/diensten/nieuw');
  await page.fill('[name="title"]', 'Testdienst');
  await page.fill('[name="short"]', 'Korte omschrijving van de testdienst.');
  await page.fill('[name="body"]', 'Eerste alinea.\n\nTweede alinea.');
  await save();
  await visit('#/diensten/testdienst');
  assert((await text('h1')).includes('Testdienst') && (await page.$$('.prose p')).length === 2, 'new service page with two paragraphs');
  await visit('#/admin/diensten');
  const last = (await page.$$('[data-move]')).length / 2 - 1;
  await page.click(`[data-move="${last}"][data-dir="-1"]`);
  await page.waitForTimeout(250);
  assert(await page.evaluate(() => window.CT.Repo && [...document.querySelectorAll('.p-name')].map((a) => a.textContent).indexOf('Testdienst')) === last - 1, 'service moved up');
  await page.click(`[data-del="${last - 1}"]`); await page.click('.modal [data-ok]');
  await page.waitForTimeout(250);
  await visit('#/diensten/testdienst');
  assert((await text('h1')).includes('bestaat niet'), 'service deleted');

  // ---- Kennis
  await visit('#/admin/kennis/nieuw');
  await page.fill('[name="title"]', 'Testbericht');
  await page.fill('[name="short"]', 'Samenvatting.');
  await page.fill('[name="body"]', 'Intro.\n\n## Kopje\n- punt een\n- punt twee');
  await page.fill('[name="links"]', 'Naar contact | /contact');
  await save();
  await visit('#/kennis/testbericht');
  assert(await page.evaluate(() => document.querySelector('.article h2').textContent === 'Kopje' && document.querySelectorAll('.article li').length === 2 && document.querySelector('.article-links a').getAttribute('href') === '#/contact'), 'new article renders blocks and links');
  await visit('#/admin/kennis/nieuw');
  await page.fill('[name="title"]', 'Fout'); await page.fill('[name="short"]', 'x'); await page.fill('[name="body"]', 'x');
  await page.fill('[name="links"]', 'zonder adres');
  await save();
  assert(await page.evaluate(() => document.querySelector('[data-err="links"]').textContent.length > 0), 'invalid link line rejected');

  // ---- Beoordelingen & meer werk
  await visit('#/admin/beoordelingen');
  await page.fill('[name="count"]', '230');
  await save();
  await visit('#/');
  assert((await text('.reviews-score')).includes('230'), 'review count on home');
  await visit('#/admin/meer-werk');
  for (let i = 0; i < 4; i++) { await page.click('.row-edit [data-row-del]'); }
  await save();
  await visit('#/projecten');
  assert(!(await page.$('#more-title')), 'no more-work cards: block hidden');
  assert((await text('.app')).includes('Projecten blijven als referentie beschikbaar'), 'project note still shown');

  // ---- Publish status and guard
  await visit('#/admin/website');
  const changes = await text('.panel');
  console.log('   changed sections:', (changes.match(/Gewijzigd sinds de laatste publicatie: ([^.]*)\./) || [])[1]);
  assert(['Teksten', 'Bedrijfsgegevens', 'SEO', 'Categorieën', 'Merken', 'Beoordelingen', 'Meer van ons werk', 'Berichten & kennis'].every((x) => changes.includes(x)), 'publish page lists changed sections');
  // Options and services were changed and then restored in this test: that is no change.
  assert(!changes.includes('Opties') && !changes.includes('Diensten'), 'restored sections are not listed as changed');
  await visit('#/admin/bedrijf');
  await page.fill('[name="city"]', 'Delft');
  await page.click('.admin-nav a[href$="/admin/teksten"]');
  await page.waitForTimeout(300);
  assert(await page.isVisible('.modal'), 'leaving with unsaved changes asks for confirmation');
  await page.click('.modal [data-cancel]');
  await page.waitForTimeout(300);
  assert(page.url().includes('/admin/bedrijf'), 'stay keeps the form');

  console.log('errors:', errors);
  console.log(fails ? `${fails} FAILED` : 'ALL ADMIN CONTENT CHECKS PASSED');
  await browser.close();
  process.exit(fails ? 1 : 0);
})();
