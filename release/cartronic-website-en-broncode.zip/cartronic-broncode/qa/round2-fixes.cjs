// Regression checks for the second review round (problems found after the first fix round).
// CT_URL=file://…/build.html NODE_PATH=/opt/node22/lib/node_modules node qa/round2-fixes.cjs
const fs = require('fs'); const path = require('path'); const { spawn } = require('child_process');
const { open } = require('./harness.cjs');
const BUILD = decodeURIComponent(new URL(process.env.CT_URL).pathname);
const FILE = `file://${BUILD}`;
const OUT = path.join(__dirname, 'r2f'); fs.rmSync(OUT, { recursive: true, force: true }); fs.mkdirSync(OUT, { recursive: true });
let fails = 0;
const ok = (c, m) => { console.log(`${c ? 'ok  ' : 'FAIL'}: ${m}`); if (!c) fails++; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const BROKEN = 'Deze pagina kon niet worden geladen';
const MARKER = '<script id="ctContent" type="application/json">{}</script>';
/** A copy of the build with a published bundle (and optionally another ct-base). */
function variant(name, bundle, { base } = {}) {
  let html = fs.readFileSync(BUILD, 'utf8');
  if (!html.includes(MARKER)) throw new Error('ctContent marker missing');
  html = html.replace(MARKER, () => `<script id="ctContent" type="application/json">${JSON.stringify(bundle).replace(/</g, '\\u003c')}</script>`);
  if (base) html = html.replace(/<meta name="ct-base" content="[^"]*">/, `<meta name="ct-base" content="${base}">`);
  const file = path.join(OUT, `${name}.html`);
  fs.writeFileSync(file, html);
  return { url: `file://${file}`, file, html };
}
function serve(dir, port) {
  const p = spawn(process.execPath, [path.join(__dirname, 'serve.cjs'), dir, String(port)], { stdio: 'ignore' });
  return { stop: () => p.kill(), ready: sleep(500) };
}
async function visit(page, url) { await page.goto(url); await page.waitForTimeout(220); }
async function leaveIfAsked(page) {
  if (await page.$('.modal [data-ok]') && (await page.textContent('.modal')).includes('Pagina verlaten')) { await page.click('.modal [data-ok]'); await page.waitForTimeout(450); } // the dialog fades out in 380 ms
}
async function login(page, base) {
  await visit(page, `${base}${base.startsWith('file:') ? '#/admin' : '/admin'}`);
  if (await page.$('#lg-u')) {
    await page.fill('#lg-u', 'demo'); await page.fill('#lg-p', 'cartronic-demo'); await page.click('[data-login] [type=submit]');
    await page.waitForSelector('.admin-nav');
  }
}
const appText = (page) => page.evaluate(() => document.getElementById('app').textContent);
const toasts = (page) => page.evaluate(() => [...document.querySelectorAll('.toast')].map((t) => t.textContent).join(' | '));
const draftOf = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('ct.v1.siteDraft') || 'null'));
const modals = (page) => page.evaluate(() => document.querySelectorAll('.modal.is-open').length);
const route = (page) => page.evaluate(() => document.documentElement.dataset.route);

async function run() {
  // ---------- P1/P19 "art:<built-in name>" image references never break a page
  {
    const { url } = variant('art-proto', { v: 1, stamp: '2026-03-01T00:00:00.000Z', shop: {
      shopCategories: [{ id: 'c1', name: 'Cat', slug: 'cat', order: 1 }],
      products: [{ id: 'p1', slug: 'p-een', name: 'Product een', regularPrice: 1000, category: 'c1', featured: true, active: true, images: ['art:constructor:0', 'art:__proto__:1', 'img:toString'] }],
      projects: [{ id: 'pr1', slug: 'pr-een', title: 'Project', vehicle: 'Auto', tag: 'Tag', short: 'Kort', image: 'art:constructor:0', gallery: ['art:valueOf:2', 'img:constructor'], active: true }],
    } });
    const { browser, page, errors } = await open();
    const bad = [];
    for (const r of ['#/', '#/projecten', '#/projecten/pr-een', '#/webshop', '#/webshop/p-een', '#/mijn-auto', '#/zoeken?q=product']) {
      await visit(page, `${url}${r}`);
      if ((await appText(page)).includes(BROKEN)) bad.push(r);
    }
    ok(!bad.length && !errors.length, `P1/P19 prototype-named image refs: every page renders (${bad.join(', ') || 'all ok'}; errors ${errors.length})`);
    const kept = await page.evaluate(() => ({ imgs: CT.Repo.products()[0].images, proj: CT.Repo.projects()[0].image }));
    ok(kept.imgs.length === 0 && kept.proj === '', `P1/P19 invalid refs are dropped from published data (${JSON.stringify(kept)})`);
    // Restored data in the editor's browser (no cleaning on that path) still renders
    await page.evaluate(() => localStorage.clear()); // a fresh browser for the unpublished file
    await login(page, FILE);
    await page.evaluate(() => { const ps = CT.Repo.projects(); ps[0] = { ...ps[0], image: 'art:constructor:0' }; CT.Repo.saveProjects(ps); });
    const bad2 = [];
    for (const r of ['#/', '#/projecten', '#/admin/projecten']) { await visit(page, `${FILE}${r}`); if ((await appText(page)).includes(BROKEN)) bad2.push(r); }
    ok(!bad2.length, `P19 a stored "art:constructor" project image renders as an illustration (${bad2.join(', ') || 'ok'})`);
    await browser.close();
  }

  // ---------- P2 product import with a wrongly typed compatibility is refused
  {
    const { browser, page, errors } = await open();
    await login(page, FILE);
    await visit(page, `${FILE}#/admin/instellingen`);
    const exp = await page.evaluate(() => ({ format: 'cartronic-products', version: 1, categories: CT.Repo.shopCategories(), products: CT.Repo.products() }));
    exp.products[0].compatibility = { brands: ['volkswagen'], models: 'golf-8', note: '' };
    const f = path.join(OUT, 'import-bad.json'); fs.writeFileSync(f, JSON.stringify(exp));
    await page.setInputFiles('[data-import]', f); await page.waitForTimeout(400);
    const txt = await page.textContent('.modal').catch(() => '');
    ok(/Import afgebroken/.test(txt) && /Compatibiliteit/.test(txt), `P2 import with models as text is refused with a message (${txt.slice(0, 90)})`);
    const exp2 = JSON.parse(JSON.stringify(exp)); exp2.products[0].compatibility = { brands: [], models: [], note: '' }; exp2.products[0].images = ['art:__proto__:0'];
    fs.writeFileSync(f, JSON.stringify(exp2));
    await page.keyboard.press('Escape'); await page.waitForTimeout(200);
    await page.setInputFiles('[data-import]', f); await page.waitForTimeout(400);
    const txt2 = await page.textContent('.modal').catch(() => '');
    ok(/Import afgebroken/.test(txt2) && /Afbeeldingen/.test(txt2), 'P2 import with an "art:__proto__" image is refused');
    await visit(page, `${FILE}#/zoeken?q=camera`);
    ok(!(await appText(page)).includes(BROKEN) && !errors.length, 'P2 search still works after the refused imports');
    await browser.close();
  }

  // ---------- P3 two tabs with the same Beheer screen: each save keeps the other tab's change
  {
    const { browser, context, page, errors } = await open();
    await login(page, FILE);
    const b = await context.newPage(); await login(b, FILE);
    const both = async (hash) => { await visit(page, `${FILE}${hash}`); await visit(b, `${FILE}${hash}`); };
    await both('#/admin/bedrijf');
    await page.fill('[name="kvk"]', '12345678'); await page.click('[data-company] [type=submit]'); await sleep(300);
    await b.fill('[name="vat"]', 'NL001234567B01'); await b.click('[data-company] [type=submit]'); await sleep(300);
    let d = await draftOf(page);
    ok(d.company && d.company.kvk === '12345678' && d.company.vat === 'NL001234567B01', `P3 Bedrijfsgegevens: both tabs' fields kept (${JSON.stringify(d.company)})`);
    await both('#/admin/weergave');
    await page.click('[name="s:home.brands"] + .track'); await page.click('[data-display] [type=submit]'); await sleep(300);
    await b.click('[name="footerAdmin"] + .track'); await b.click('[data-display] [type=submit]'); await sleep(300);
    d = await draftOf(page);
    ok(d.display && d.display.sections['home.brands'] === false && d.display.footerAdmin === false, `P3 Weergave: both switches kept (${JSON.stringify(d.display)})`);
    await both('#/admin/seo');
    await page.fill('[name="homeTitle"]', 'Titel uit tab A'); await page.click('[data-seo] [type=submit]'); await sleep(300);
    await b.fill('[name="suffix"]', ' | Tab B'); await b.click('[data-seo] [type=submit]'); await sleep(300);
    d = await draftOf(page);
    ok(d.seo && d.seo.homeTitle === 'Titel uit tab A' && d.seo.suffix === ' | Tab B', `P3 SEO: both fields kept (${d.seo && d.seo.homeTitle} / ${d.seo && d.seo.suffix})`);
    await both('#/admin/catalogus');
    const cat = await page.evaluate(() => CT.catalog.CATEGORIES[0].id);
    await page.evaluate((c) => { document.querySelectorAll('details').forEach((x) => { x.open = true; }); document.querySelector(`[name="${c}:tagline"]`).value = 'Slogan uit tab A'; document.querySelector('[data-catalog]').dispatchEvent(new Event('input', { bubbles: true })); }, cat);
    await page.click('[data-catalog] [type=submit]'); await sleep(300);
    await b.fill('[name="brand:audi"]', 'Intro uit tab B.'); await b.click('[data-catalog] [type=submit]'); await sleep(300);
    d = await draftOf(page);
    ok(d.categories && d.categories[cat] && d.categories[cat].tagline === 'Slogan uit tab A' && d.brands && d.brands.audi && d.brands.audi.intro === 'Intro uit tab B.', 'P3 Categorieën & merken: both changes kept');
    await both('#/admin/beoordelingen');
    await page.fill('[name="source"]', 'Bron A'); await page.click('[data-reviews] [type=submit]'); await sleep(300);
    await b.fill('[name="count"]', '123'); await b.click('[data-reviews] [type=submit]'); await sleep(300);
    d = await draftOf(page);
    ok(d.reviews && d.reviews.source === 'Bron A' && d.reviews.count === 123, `P3 Beoordelingen: both fields kept (${JSON.stringify({ s: d.reviews && d.reviews.source, c: d.reviews && d.reviews.count })})`);
    ok(!errors.length, `P3 no errors (${errors.join(' | ').slice(0, 200)})`);
    await browser.close();
  }

  // ---------- P4/P26/P5/P27 Beheer refuses what a publication would cut or drop
  {
    const { browser, page, errors } = await open();
    await login(page, FILE);
    await visit(page, `${FILE}#/admin/producten/nieuw`);
    await page.fill('#pf-name', 'Lange test');
    await page.fill('#pf-slug', `lange-slug-${'a'.repeat(125)}`);
    await page.fill('#pf-sku', 'TST-LANG-1'); await page.fill('#pf-shortDescription', 'Kort');
    await page.fill('#pf-regularPrice', '49,00');
    await page.evaluate(() => { const t = document.querySelector('#pf-description'); t.value = 'x'.repeat(13000); t.dispatchEvent(new Event('input', { bubbles: true })); });
    await page.evaluate(() => { const t = document.querySelector('#pf-cnote'); t.value = 'n'.repeat(700); t.dispatchEvent(new Event('input', { bubbles: true })); });
    const before = await page.evaluate(() => CT.Repo.products().length);
    await page.click('[data-save]'); await sleep(300);
    const sum = await page.textContent('[data-errsum]').catch(() => '');
    const after = await page.evaluate(() => CT.Repo.products().length);
    ok(after === before && /Slug: Gebruik maximaal 120/.test(sum) && /Volledige omschrijving: Gebruik maximaal 12\.000/.test(sum) && /Compatibiliteitsinformatie: Gebruik maximaal 600/.test(sum), `P4/P5 product: long slug, description and note are refused, nothing saved (${sum.slice(0, 160)})`);
    // 13th image is refused
    await page.fill('#pf-slug', 'lange-test'); await page.evaluate(() => { const t = document.querySelector('#pf-description'); t.value = 'Omschrijving'; t.dispatchEvent(new Event('input', { bubbles: true })); const n = document.querySelector('#pf-cnote'); n.value = ''; n.dispatchEvent(new Event('input', { bubbles: true })); });
    for (let i = 0; i < 13; i++) { await page.selectOption('[data-img-art]', 'camera'); await sleep(60); }
    const imgs = await page.evaluate(() => document.querySelectorAll('.image-item').length);
    ok(imgs === 12 && /maximaal 12 afbeeldingen/.test(await toasts(page)), `P4 product: at most 12 images (${imgs})`);
    await page.click('[data-save]'); await sleep(300);
    const saved = await page.evaluate(() => CT.Repo.productBySlug('lange-test'));
    ok(!!saved && saved.images.length === 12, 'P4 a valid product with 12 images is saved');
    // project limits
    await visit(page, `${FILE}#/admin/projecten/nieuw`);
    await page.fill('#pj-title', 'T'.repeat(189)); await page.fill('#pj-vehicle', 'Auto'); await page.fill('#pj-tag', 'Tag'); await page.fill('#pj-short', 'Kort');
    await page.fill('#pj-image', 'img:proj_ibiza');
    await page.evaluate(() => { const t = document.querySelector('#pj-body'); t.value = 'b'.repeat(7000); });
    const pBefore = await page.evaluate(() => CT.Repo.projects().length);
    await page.click('[data-pj-form] [type=submit]'); await sleep(300);
    const pErr = await page.textContent('[data-pj-err]');
    ok(/De titel is te lang: maximaal 160/.test(pErr) && (await page.evaluate(() => CT.Repo.projects().length)) === pBefore, `P4 project: a 189-character title is refused (${pErr})`);
    await page.fill('#pj-title', 'Project met lange tekst'); await page.click('[data-pj-form] [type=submit]'); await sleep(300);
    ok(/De tekst is te lang: maximaal 6\.000/.test(await page.textContent('[data-pj-err]')), 'P4 project: a 7000-character text is refused');
    // shop data made in Beheer is identical after cleaning (what a publication carries)
    const same = await page.evaluate(() => { const s = CT.Repo.shopSnapshot(); return JSON.stringify(CT.Content.cleanShop(s)) === JSON.stringify(CT.Content.cleanShop(CT.Content.cleanShop(s))) && CT.Content.cleanShop(s).products.length === s.products.length; });
    ok(same && !errors.length, 'P26 the published shape keeps every product made in Beheer');
    await browser.close();
  }

  // ---------- P6 new-tab clicks leave search, mobile menu and mini cart open
  {
    const { browser, page } = await open({ width: 700, height: 900 });
    await visit(page, `${FILE}#/over`);
    await page.keyboard.press('Control+k'); await sleep(300);
    await page.fill('.search-panel input[role="combobox"]', 'carplay');
    await sleep(500);
    const all = await page.$('.search-panel [data-all]');
    let stillOpen = null;
    if (all) { await all.click({ modifiers: ['Control'] }); await sleep(250); stillOpen = await page.evaluate(() => !!document.querySelector('.search-panel.is-open')); }
    ok(all && stillOpen, `P6 Ctrl-click on "Alle resultaten" keeps the search open (${stillOpen})`);
    await page.keyboard.press('Escape'); await sleep(200);
    await page.click('[data-action="toggle-menu"]'); await sleep(300);
    await page.click('#mobileNav a[href*="contact"]', { modifiers: ['Control'] }); await sleep(250);
    ok(await page.evaluate(() => document.getElementById('mobileNav').classList.contains('is-open')), 'P6 Ctrl-click in the mobile menu keeps the menu open');
    await browser.close();
  }

  // ---------- P7 path mode: a typed "/#/route" with unsaved changes asks first; P20 scroll after a guarded Back
  {
    const dir = path.join(OUT, 'site'); fs.mkdirSync(dir, { recursive: true });
    fs.copyFileSync(BUILD, path.join(dir, 'index.html'));
    const srv = serve(dir, 8841); await srv.ready;
    const O = 'http://localhost:8841';
    const { browser, page, errors } = await open({ width: 1280, height: 600 });
    await login(page, O);
    await visit(page, `${O}/over`);
    await page.evaluate(() => CT.Router.go('/admin/bedrijf')); await sleep(300);
    await page.fill('[name="kvk"]', '12345678');
    await page.evaluate(() => { location.hash = '#/kennis'; }); await sleep(500);
    ok((await modals(page)) === 1, 'P7 typed "#/kennis" with unsaved changes shows the question');
    await page.click('.modal [data-cancel]'); await sleep(300);
    ok(page.url() === `${O}/admin/bedrijf` && (await page.inputValue('[name="kvk"]')) === '12345678', `P7 "Blijven" keeps the form and its address (${page.url()})`);
    await page.click('[data-company] [type=submit]'); await sleep(300);
    await page.goBack(); await sleep(400);
    ok((await route(page)) === '/over', `P7 after saving, Back goes to /over (${await route(page)})`);
    // P20: the previous page opens at the top after a guarded Back
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.evaluate(() => CT.Router.go('/admin/teksten')); await sleep(300);
    await page.fill('[name="home.hero.line2"]', 'Gewijzigd');
    await page.evaluate(() => window.scrollTo(0, 900)); await sleep(150);
    await page.goBack(); await sleep(500);
    if (await modals(page)) { await page.click('.modal [data-ok]'); await sleep(600); }
    const y = await page.evaluate(() => window.scrollY);
    ok((await route(page)) === '/over' && y < 5, `P20 after "Pagina verlaten" the previous page shows at the top (y=${y})`);
    // catalog: Back returns to the scroll position (both URL styles keep the visitor's place)
    await visit(page, `${O}/mogelijkheden`);
    await page.evaluate(() => window.scrollTo(0, 1500)); await sleep(200);
    await page.evaluate(() => { const a = [...document.querySelectorAll('#app a[href*="/mogelijkheden/"]')].find((l) => { const r = l.getBoundingClientRect(); return r.top > 40 && r.bottom < innerHeight - 40; }); a.click(); });
    await sleep(500); await page.goBack(); await sleep(600);
    const y2 = await page.evaluate(() => window.scrollY);
    ok(Math.abs(y2 - 1500) < 3, `P20 path mode: Back to the catalog returns to the same place (y=${y2})`);
    // P12: an address outside the sub-path shows "page not found"
    const sub = path.join(OUT, 'subsite'); fs.mkdirSync(sub, { recursive: true });
    fs.writeFileSync(path.join(sub, 'index.html'), fs.readFileSync(BUILD, 'utf8').replace(/<meta name="ct-base" content="[^"]*">/, '<meta name="ct-base" content="/cartronic/">'));
    const srv2 = serve(sub, 8842); await srv2.ready;
    const p2 = await browser.newPage();
    await p2.goto('http://localhost:8842/bestaat-niet'); await sleep(400);
    const nf = await p2.evaluate(() => ({ h1: document.querySelector('#app h1') && document.querySelector('#app h1').textContent, robots: document.querySelector('meta[name="robots"]').content, canonical: !!document.querySelector('link[rel="canonical"]'), path: CT.Router.pathMode }));
    ok(/bestaat niet/i.test(nf.h1 || '') && /noindex/.test(nf.robots) && !nf.canonical && nf.path, `P12 outside the sub-path: "Pagina niet gevonden", noindex, no canonical (${JSON.stringify(nf)})`);
    await p2.click('#app a[href="/cartronic/"], #app a[href^="/cartronic/mogelijkheden"]').catch(() => {});
    await sleep(400);
    ok(p2.url().startsWith('http://localhost:8842/cartronic/'), `P12 links on that page lead into the site (${p2.url()})`);
    await p2.goto('http://localhost:8842/'); await sleep(400);
    ok(await p2.evaluate(() => !CT.Router.pathMode && document.documentElement.dataset.route === '/'), 'P12 the bare host root still shows the site (hash fallback)');
    ok(!errors.length, `P7/P12/P20 no errors (${errors.join(' | ').slice(0, 200)})`);
    await browser.close(); srv.stop(); srv2.stop();
  }

  // ---------- P8/P21/P22/P23 hash mode: typed addresses and questions leave a clean history
  {
    const { browser, page, errors } = await open();
    await login(page, FILE);
    await visit(page, `${FILE}#/over`);
    await page.evaluate(() => CT.Router.go('/admin/bedrijf')); await sleep(300);
    await page.fill('[name="kvk"]', '12345678');
    await page.evaluate(() => { location.hash = '#/kennis'; }); await sleep(500);
    ok((await modals(page)) === 1, 'P8 typed address with unsaved changes asks');
    await page.evaluate(() => { location.hash = '#/contact'; }); await sleep(500); // typed again while asking (P21)
    ok((await modals(page)) === 1 && new URL(page.url()).hash === '#/admin/bedrijf', `P21 an address typed while asking is undone (${new URL(page.url()).hash})`);
    await page.click('.modal [data-cancel]'); await sleep(300);
    ok(new URL(page.url()).hash === '#/admin/bedrijf' && (await route(page)) === '/admin/bedrijf', 'P21 "Blijven": address and page match');
    await page.click('[data-company] [type=submit]'); await sleep(300);
    await page.goBack(); await sleep(400);
    ok((await route(page)) === '/over', `P8 after "Blijven" and saving, one Back goes to /over (${await route(page)})`);
    // leave variant (P22): no duplicate form entry
    await page.evaluate(() => CT.Router.go('/admin/bedrijf')); await sleep(300);
    await page.fill('[name="kvk"]', '87654321');
    await page.evaluate(() => { location.hash = '#/kennis'; }); await sleep(500);
    await page.click('.modal [data-ok]'); await sleep(400);
    const r1 = await route(page);
    await page.goBack(); await sleep(400); const r2 = await route(page);
    await page.goBack(); await sleep(400); const r3 = await route(page);
    ok(r1 === '/kennis' && r2 === '/admin/bedrijf' && r3 === '/over', `P22 "Pagina verlaten": /kennis, Back → form, Back → /over (${r1}, ${r2}, ${r3})`);
    // P23: Back while a link-click question is open gives one question
    await visit(page, `${FILE}#/admin/bedrijf`);
    await page.fill('[name="kvk"]', '11112222');
    await page.click('.admin-nav a[href$="/admin/teksten"]'); await sleep(300);
    await page.evaluate(() => history.back()); await sleep(500);
    ok((await modals(page)) === 1, `P23 Back during a link-click question shows one question (${await modals(page)})`);
    await page.click('.modal [data-cancel]'); await sleep(300);
    ok((await route(page)) === '/admin/bedrijf' && new URL(page.url()).hash === '#/admin/bedrijf', 'P23 "Blijven" keeps form and address');
    // hash mode: Back to the catalog returns to the same place
    await visit(page, `${FILE}#/mogelijkheden`); await leaveIfAsked(page);
    await page.evaluate(() => window.scrollTo(0, 1500)); await sleep(200);
    await page.evaluate(() => { const a = [...document.querySelectorAll('#app a[href^="#/mogelijkheden/"]')].find((l) => { const r = l.getBoundingClientRect(); return r.top > 40 && r.bottom < innerHeight - 40; }); a.click(); });
    await sleep(500); await page.goBack(); await sleep(600);
    const y = await page.evaluate(() => window.scrollY);
    ok(Math.abs(y - 1500) < 3, `hash mode: Back to the catalog returns to the same place (y=${y})`);
    ok(!errors.length, `P8/P21/P22/P23 no errors (${errors.join(' | ').slice(0, 200)})`);
    await browser.close();
  }

  // ---------- P9/P24 unsaved changes: the browser asks before a reload
  {
    const { browser, page } = await open();
    await login(page, FILE);
    await visit(page, `${FILE}#/admin/bedrijf`);
    await page.fill('[name="kvk"]', '12345678');
    let type = null;
    page.on('dialog', async (d) => { type = d.type(); await d.dismiss(); });
    await page.reload({ timeout: 3000 }).catch(() => {});
    await sleep(300);
    ok(type === 'beforeunload' && (await page.inputValue('[name="kvk"]')) === '12345678', `P9 reload with unsaved changes asks (dialog: ${type})`);
    await browser.close();
  }

  // ---------- P10 opening hours
  {
    const { browser, page } = await open();
    await visit(page, `${FILE}#/`);
    const res = await page.evaluate(() => {
      const d = (t) => { const r = CT.Seo.openingHours([[t, '09:00 - 17:00']]); return r.length ? r[0].dayOfWeek.map((x) => x.slice(0, 2)).join(',') : '-'; };
      return {
        a: d('Maandag - vrijdag, zaterdag'), b: d('Ma t.m. vr'), c: d('Maandag, woensdag – vrijdag'), e: d('ma tm vr'),
        f: d('Maandag en woensdag t/m vrijdag'), g: d('Elke dag behalve zondag'), h: d('Dinsdag-zaterdag'), i: d('Za/zo'),
        j: d('Ma–vr (op afspraak)'), k: d('Zaterdag - maandag'), l: d('Gesloten'),
        split: CT.Seo.openingHours([['Ma t/m vr', '09:00 - 12:00, 13:00 - 17:00']]).length,
        badTime: CT.Seo.openingHours([['Ma', '25:00 - 17:00']]).length,
      };
    });
    const want = { a: 'Mo,Tu,We,Th,Fr,Sa', b: 'Mo,Tu,We,Th,Fr', c: 'Mo,We,Th,Fr', e: 'Mo,Tu,We,Th,Fr', f: 'Mo,We,Th,Fr', g: '-', h: 'Tu,We,Th,Fr,Sa', i: 'Sa,Su', j: 'Mo,Tu,We,Th,Fr', k: 'Mo,Sa,Su', l: '-', split: 2, badTime: 0 };
    const wrong = Object.keys(want).filter((k) => res[k] !== want[k]);
    ok(!wrong.length, `P10 opening hours are read correctly or left out (${wrong.map((k) => `${k}=${res[k]}`).join(' ') || 'all ok'})`);
    await browser.close();
  }

  // ---------- P11 Teksten: a long paste is kept in full and saving is refused with a message
  {
    const { browser, page } = await open();
    await login(page, FILE);
    await visit(page, `${FILE}#/admin/teksten?groep=overig`);
    await page.fill('[name="priv.body"]', '');
    await page.focus('[name="priv.body"]');
    const long = `${Array.from({ length: 1200 }, (_, i) => `regel${String(i).padStart(4, '0')}`).join(' ')} EINDE-VAN-DE-TEKST`;
    await page.keyboard.insertText(long);
    const val = await page.inputValue('[name="priv.body"]');
    const live = await page.evaluate(() => document.querySelector('[data-text-field="priv.body"] [data-text-err]').textContent);
    await page.click('[data-texts] [type=submit]'); await sleep(300);
    const d = await draftOf(page);
    ok(val.endsWith('EINDE-VAN-DE-TEKST') && /maximaal 12\.000/.test(live) && !(d && d.texts && d.texts['priv.body']), `P11 pasted ${val.length} characters kept, warned and not saved`);
    await browser.close();
  }

  // ---------- P13 website address: normalised, and a sub-path with special characters is refused
  {
    const { browser, page } = await open();
    await login(page, FILE);
    await visit(page, `${FILE}#/admin/seo`);
    await page.fill('[name="siteUrl"]', 'https://www.example.nl/über');
    await page.click('[data-seo] [type=submit]'); await sleep(300);
    const e1 = await page.textContent('[data-err="siteUrl"]');
    ok(/alleen letters, cijfers/.test(e1), `P13 "/über" is refused (${e1.slice(0, 60)})`);
    await page.fill('[name="siteUrl"]', 'https://WWW.Example.nl/site/');
    await page.click('[data-seo] [type=submit]'); await sleep(300);
    const s = await page.evaluate(() => ({ site: CT.Content.seo().siteUrl, base: CT.Publisher.base() }));
    ok(s.site === 'https://www.example.nl/site' && s.base === '/site/', `P13 address normalised (${JSON.stringify(s)})`);
    ok(await page.evaluate(() => ['https://x.nl/?a=1', 'https://x.nl/#x', 'https://u:p@x.nl', 'ftp://x.nl', 'https://x.nl/a b'].every((u) => CT.Content.siteAddress(u) === '')), 'P13 addresses with ?, #, a login, another protocol or a space are refused');
    await browser.close();
  }

  // ---------- P14 duplicating an option: the body restriction is visible and can be removed
  {
    const { browser, page, errors } = await open();
    await login(page, FILE);
    const src = 'audi-a4-b9-avant-elektrische-achterklep';
    await visit(page, `${FILE}#/admin/opties/nieuw?van=${src}`);
    const sw = await page.$('[name="keepBody"]');
    ok(!!sw && await sw.isChecked() && /carrosserie: stationwagen/.test(await appText(page)), 'P14 the copy shows "Alleen voor carrosserie: stationwagen"');
    await page.evaluate(() => { const c = document.querySelector('input[name="models"]:checked'); if (c) c.checked = false; const a3 = document.querySelector('input[name="models"][value="a3-8v"]'); a3.checked = true; });
    await page.fill('[name="title"]', 'Audi A3 elektrische achterklep test'); await page.fill('[name="slug"]', 'audi-a3-test-achterklep');
    await page.click('[name="keepBody"] + .track');
    await page.click('[data-opt-form] [type=submit]'); await sleep(400);
    const added = await page.evaluate(() => (CT.Content.draft.retrofits.add || []).find((a) => a.slug === 'audi-a3-test-achterklep'));
    ok(added && !added.body, `P14 switched off: the copy has no body restriction (${added && added.body})`);
    await visit(page, `${FILE}#/admin/opties/nieuw?van=${src}`);
    await page.fill('[name="title"]', 'Audi A4 Avant kopie'); await page.fill('[name="slug"]', 'audi-a4-avant-kopie');
    await page.click('[data-opt-form] [type=submit]'); await sleep(400);
    const kept = await page.evaluate(() => (CT.Content.draft.retrofits.add || []).find((a) => a.slug === 'audi-a4-avant-kopie'));
    ok(kept && kept.body === 'stationwagen', 'P14 switched on: the copy keeps the body restriction');
    ok(!errors.length, 'P14 no errors');
    await browser.close();
  }

  // ---------- P15 hiding, showing and hiding again leaves no change to publish
  {
    const hide = ['volkswagen-golf-7-app-connect', 'volkswagen-golf-8-app-connect'];
    const { url } = variant('hidden', { v: 1, stamp: '2026-03-02T00:00:00.000Z', retrofits: { hide } });
    const { browser, page } = await open();
    await login(page, url);
    await visit(page, `${url}#/admin/opties?q=golf 7 app connect`);
    await page.click(`[data-otoggle="${hide[0]}"]`); await sleep(250);
    await page.click(`[data-otoggle="${hide[0]}"]`); await sleep(250);
    const ch = await page.evaluate(() => CT.Content.changes());
    ok(!ch.length, `P15 back to the published state: nothing to publish (${ch.join(', ')})`);
    await browser.close();
  }

  // ---------- P16 limits in the catalog screens are reported, never cut silently
  {
    const { browser, page } = await open();
    await login(page, FILE);
    const slug = await page.evaluate(() => CT.catalog.RETROFITS[0].slug);
    await visit(page, `${FILE}#/admin/opties/${slug}`);
    await page.fill('[name="specs"]', Array.from({ length: 22 }, (_, i) => `Spec ${i}: waarde ${i}`).join('\n'));
    await page.click('[data-opt-form] [type=submit]'); await sleep(300);
    ok(/maximaal 20 specificaties/.test(await page.textContent('[data-err="specs"]')), 'P16 22 specifications are refused');
    await page.fill('[name="specs"]', `Lang: ${'w'.repeat(400)}`);
    await page.click('[data-opt-form] [type=submit]'); await sleep(300);
    ok(/300 voor de waarde/.test(await page.textContent('[data-err="specs"]')), 'P16 a 400-character value is refused');
    await visit(page, `${FILE}#/admin/catalogus`); await leaveIfAsked(page);
    const cat = await page.evaluate(() => CT.catalog.CATEGORIES[0].id);
    await page.evaluate((c) => { document.querySelectorAll('details').forEach((x) => { x.open = true; }); const t = document.querySelector(`[name="${c}:benefits"]`); t.value = 'b'.repeat(250); t.dispatchEvent(new Event('input', { bubbles: true })); }, cat);
    await page.click('[data-catalog] [type=submit]'); await sleep(300);
    ok(/Maximaal 200 tekens per regel/.test(await page.textContent(`[data-err="${cat}:benefits"]`)), 'P16 a 250-character benefit is refused');
    await visit(page, `${FILE}#/admin/meer-werk`); await leaveIfAsked(page);
    await page.fill('.row-edit [data-w="links"]', `${'L'.repeat(100)} | https://example.com`);
    await page.click('[data-work] [type=submit]'); await sleep(300);
    ok(/maximaal 80 tekens/.test(await toasts(page)), 'P16 a 100-character link text is refused');
    await visit(page, `${FILE}#/admin/kennis/nieuw`); await leaveIfAsked(page);
    await page.fill('[name="title"]', 'Test'); await page.fill('[name="short"]', 'Kort'); await page.fill('[name="body"]', 'Tekst');
    await page.fill('[name="links"]', `${'L'.repeat(100)} | /contact`);
    await page.click('[data-art-form] [type=submit]'); await sleep(300);
    ok(/maximaal 80 tekens/.test(await page.textContent('[data-err="links"]')), 'P16 article: a 100-character link text is refused');
    // multi-line fields: no maxlength, a clear message instead
    await visit(page, `${FILE}#/admin/opties/${slug}`); await leaveIfAsked(page);
    await page.fill('[name="short"]', 's'.repeat(1300));
    const live = await page.textContent('[data-err="short"]');
    ok((await page.inputValue('[name="short"]')).length === 1300 && /Maximaal 1\.200 tekens/.test(live), `P16 a long description is kept and flagged (${live.slice(0, 50)})`);
    await browser.close();
  }

  // ---------- P17 the "Recent bekeken" switch also hides the block in the webshop
  {
    const { browser, page } = await open();
    await visit(page, `${FILE}#/webshop/achteruitrijcamera-retrofit-set`);
    await visit(page, `${FILE}#/webshop`);
    const on = await page.evaluate(() => [...document.querySelectorAll('#app h2')].some((h) => h.textContent.includes('Recent bekeken')));
    await login(page, FILE);
    await visit(page, `${FILE}#/admin/weergave`);
    await page.click('[name="s:recent"] + .track'); await page.click('[data-display] [type=submit]'); await sleep(300);
    await visit(page, `${FILE}#/webshop`);
    const off = await page.evaluate(() => [...document.querySelectorAll('#app h2')].some((h) => h.textContent.includes('Recent bekeken')));
    ok(on && !off, `P17 webshop: block shown when on (${on}), hidden when off (${!off})`);
    await browser.close();
  }

  // ---------- P18 tabs and line breaks never let a link leave the site
  {
    const { browser, page } = await open();
    await visit(page, `${FILE}#/`);
    const r = await page.evaluate(() => ({
      a: CT.Content.safeHref('/\t/evil.example'), b: CT.Content.safeHref('#/\t/evil.example'), c: CT.Content.safeHref('/\n/evil.example'),
      d: CT.Content.safeHref('#/\r/evil.example'), e: CT.Content.safeHref('/\t\\evil.example'), f: CT.Content.safeHref('/contact'),
      g: CT.fmtText('[x](/\u0001/evil.example)'), h: CT.Router.href('/\t/evil.example'),
    }));
    ok(!r.a && !r.b && !r.c && !r.d && !r.e && r.f === '#/contact' && !r.g.includes('<a') && !r.h.replace(/^#/, '').startsWith('//'), `P18 control characters are refused (${JSON.stringify(r)})`);
    await browser.close();
  }

  // ---------- P25 a tab left open on an older version stops saving once a newer one is opened
  {
    const s1 = variant('pub-s1', { v: 1, stamp: '2026-04-01T00:00:00.000Z', texts: { 'home.hero.line1': 'Versie een.' } });
    const s2 = variant('pub-s2', { v: 1, stamp: '2026-04-02T00:00:00.000Z', texts: { 'home.hero.line1': 'Versie twee.' } });
    const { browser, context, page, errors } = await open();
    await login(page, s1.url);
    await visit(page, `${s1.url}#/admin/teksten`);
    const b = await context.newPage();
    await visit(b, `${s2.url}#/`); await sleep(300);
    ok(await page.evaluate(() => CT.Content.stale && CT.SiteStatus.undecided()), 'P25 the old tab knows it is outdated');
    ok(/Deze pagina is verouderd/.test(await page.textContent('[data-site-notice]')), 'P25 Beheer shows "Deze pagina is verouderd" with a reload button');
    await page.fill('[name="home.hero.line2"]', 'Extra regel.');
    await page.click('[data-texts] [type=submit]'); await sleep(300);
    const d = await draftOf(page);
    ok(!(d && d.texts && d.texts['home.hero.line2']) && /andere versie van de website/.test(await toasts(page)), 'P25 saving in the outdated tab is refused with a message');
    ok(await page.evaluate(() => CT.Content.rawText('home.hero.line1')) === 'Versie een.', 'P25 the outdated tab keeps its own view (no silent switch)');
    ok(!errors.length, 'P25 no errors');
    await browser.close();
  }

  // ---------- P28 "Gepubliceerde versie gebruiken" for parked content keeps later webshop changes
  {
    const pub = variant('pub-p28', { v: 1, stamp: '2026-05-02T00:00:00.000Z' });
    const { browser, page } = await open();
    await login(page, pub.url);
    // a content draft based on an older publication
    await page.evaluate(() => { localStorage.setItem('ct.v1.siteDraft', JSON.stringify({ v: 1, base: '2026-05-01T00:00:00.000Z', texts: { 'home.hero.line1': 'Oud concept.' } })); });
    await page.reload(); await sleep(500);
    const st = await page.evaluate(() => ({ parked: CT.Content.parked, shop: CT.Repo.shopParked }));
    await page.evaluate(() => { const p = CT.Repo.products()[0]; CT.Repo.saveProduct({ ...p, regularPrice: 5555 }); });
    await page.click('[data-parked="published"]'); await sleep(300);
    const msg = await page.textContent('.modal');
    await page.click('.modal [data-ok]'); await sleep(300);
    const after = await page.evaluate(() => ({ price: CT.Repo.products()[0].regularPrice, parked: CT.Content.parked, draft: localStorage.getItem('ct.v1.siteDraft') }));
    ok(st.parked && !st.shop && /website-inhoud/.test(msg) && after.price === 5555 && !after.parked && !after.draft, `P28 only the parked content is thrown away (${JSON.stringify(after).slice(0, 80)})`);
    await browser.close();
  }

  // ---------- N28 website address: no file name, ?, # or /admin
  {
    const { browser, page } = await open();
    await visit(page, `${FILE}#/`);
    const r = await page.evaluate(() => ['https://www.cartronic.nl/index.html', 'https://www.cartronic.nl/#/', 'https://www.cartronic.nl/?utm=x', 'https://www.cartronic.nl/admin', 'https://www.cartronic.nl/a//b', 'https://www.cartronic.nl/café'].map((u) => CT.Content.siteAddress(u)));
    ok(r.every((x) => x === ''), `N28 unusable website addresses are refused (${JSON.stringify(r)})`);
    ok(await page.evaluate(() => CT.Content.siteAddress('https://www.cartronic.nl/') === 'https://www.cartronic.nl' && CT.Content.siteAddress('https://www.cartronic.nl/nieuwe-site') === 'https://www.cartronic.nl/nieuwe-site'), 'N28 normal addresses are kept');
    await browser.close();
  }

  // ---------- N31 choosing a version first asks about unsaved text in the open form
  {
    const pub = variant('pub-n31', { v: 1, stamp: '2026-05-03T00:00:00.000Z' });
    const { browser, page } = await open();
    await login(page, pub.url);
    await page.evaluate(() => { localStorage.setItem('ct.v1.siteDraft', JSON.stringify({ v: 1, base: '2026-05-01T00:00:00.000Z', texts: { 'home.hero.line1': 'Oud concept.' } })); });
    await page.reload(); await sleep(400);
    await visit(page, `${pub.url}#/admin/teksten`);
    await page.fill('[name="home.hero.line2"]', 'Net getypt.');
    await page.click('[data-parked="keep"]'); await sleep(300);
    const asked = /Wijzigingen niet opgeslagen/.test(await page.textContent('.modal').catch(() => ''));
    await page.click('.modal [data-cancel]'); await sleep(300);
    ok(asked && (await page.inputValue('[name="home.hero.line2"]')) === 'Net getypt.' && (await page.evaluate(() => CT.Content.parked)), 'N31 "Blijven" keeps the typed text and the choice is not made');
    await browser.close();
  }

  // ---------- N32 saving webshop data without changes is no unpublished change
  {
    const { browser, page } = await open();
    await login(page, FILE);
    const before = await page.evaluate(() => CT.SiteStatus.changes());
    const pid = await page.evaluate(() => CT.Repo.projects()[0].id);
    await visit(page, `${FILE}#/admin/projecten/${pid}`);
    await page.click('[data-pj-form] [type=submit]'); await sleep(300);
    await visit(page, `${FILE}#/admin/instellingen`);
    await page.click('[data-ship] [type=submit]'); await sleep(300);
    const prod = await page.evaluate(() => CT.Repo.products()[0].id);
    await visit(page, `${FILE}#/admin/producten/${prod}`);
    await page.click('[data-save]'); await sleep(300);
    const after = await page.evaluate(() => CT.SiteStatus.changes());
    await page.evaluate(() => { const p = CT.Repo.products()[0]; CT.Repo.saveProduct({ ...p, regularPrice: p.regularPrice + 100 }); });
    const changed = await page.evaluate(() => CT.SiteStatus.changes());
    await page.evaluate(() => { const p = CT.Repo.products()[0]; CT.Repo.saveProduct({ ...p, regularPrice: p.regularPrice - 100 }); });
    const back = await page.evaluate(() => CT.SiteStatus.changes());
    ok(!before.length && !after.length && changed.includes('Webshop & projecten') && !back.length, `N32 unchanged saves: none; a real change: listed; changed back: none (${JSON.stringify([before, after, changed, back])})`);
    await browser.close();
  }

  // ---------- N33 rich texts take bold and links
  {
    const { browser, page } = await open();
    await login(page, FILE);
    await visit(page, `${FILE}#/admin/teksten?groep=overig`);
    await page.fill('[name="priv.body"]', '## Kop\nAlinea met **vet** en [link](/contact).\n- punt **b**');
    await page.click('[data-texts] [type=submit]'); await sleep(300);
    await visit(page, `${FILE}#/privacy`);
    const h = await page.evaluate(() => document.getElementById('app').innerHTML);
    ok(/<strong>vet<\/strong>/.test(h) && /<a class="text-link" href="#\/contact">link<\/a>/.test(h) && /<li>punt <strong>b<\/strong><\/li>/.test(h) && !h.includes('**'), 'N33 rich text shows bold and a link');
    await browser.close();
  }

  // ---------- N34 the reserved slug "nieuw" has its own message
  {
    const { browser, page } = await open();
    await login(page, FILE);
    await visit(page, `${FILE}#/admin/diensten/nieuw`);
    await page.fill('[name="title"]', 'Nieuw'); await page.fill('[name="short"]', 'Kort'); await page.fill('[name="body"]', 'Tekst');
    await page.click('[data-svc-form] [type=submit]'); await sleep(300);
    ok(/gereserveerd/.test(await page.textContent('[data-err="slug"]')), 'N34 "nieuw" is reported as reserved');
    await browser.close();
  }

  console.log(fails ? `\n${fails} ROUND-2 CHECK(S) FAILED` : '\nALL ROUND-2 CHECKS PASSED');
  process.exit(fails ? 1 : 0);
}
run().catch((e) => { console.error(e); process.exit(1); });
