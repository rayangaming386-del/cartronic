// Catalog QA: data validation, search, vehicle matching, redirects, detail pages.
// Usage: CT_URL=file:///…/index.html NODE_PATH=/opt/node22/lib/node_modules node qa/catalog.cjs
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { open, go } = require('./harness.cjs');

const fails = []; const notes = [];
const check = (ok, msg) => { if (!ok) fails.push(msg); };

(async () => {
  const { browser, page, errors } = await open();
  await go(page, '#/', { scroll: false });

  /* ---------- 1. Data validation ---------- */
  const data = await page.evaluate(() => {
    const { RETROFITS, RETROFIT_ALIAS, MODELS, FEATURES, CATEGORIES, ART } = window.CT.catalog;
    return { R: RETROFITS, A: RETROFIT_ALIAS, M: MODELS, F: Object.keys(FEATURES), C: CATEGORIES.map((c) => c.id), ART, IMG: Object.keys(window.CT_IMAGES || {}) };
  });
  const { R, A, M, F, C, ART, IMG } = data;
  const MID = new Map(M.map((m) => [m.id, m]));
  const slugSet = new Set();
  const titles = new Map();
  const GENERIC = /^(Comfortretrofit|Comfortupgrade|Rijassistentie-retrofit|Parkeerhulp-retrofit|OEM-stijl camerasysteem|Multimedia-upgrade|Digitale cockpitupgrade|Origineel-ogende verlichtingsupgrade|Trekhaakoplossing|Originele cruise-controlfunctionaliteit|Retrofit voor de)/;
  R.forEach((r) => {
    check(/^[a-z0-9]+(-[a-z0-9]+)*$/.test(r.slug), `unclean slug ${r.slug}`);
    check(!slugSet.has(r.slug), `duplicate slug ${r.slug}`); slugSet.add(r.slug);
    check(!titles.has(r.title), `duplicate title "${r.title}" (${r.slug} / ${titles.get(r.title)})`); titles.set(r.title, r.slug);
    check(F.includes(r.feature), `unknown feature ${r.feature} on ${r.slug}`);
    check(C.includes(r.cat), `unknown category ${r.cat} on ${r.slug}`);
    check(ART.includes(r.art), `unknown art ${r.art} on ${r.slug}`);
    check(!r.image || IMG.includes(r.image), `missing image ${r.image} on ${r.slug}`);
    check(r.title && r.name && r.short && r.short.length > 20, `empty text on ${r.slug}`);
    check(!/aanbieding\s*\d/i.test(`${r.title} ${r.name}`), `offer title leaked into ${r.slug}`);
    check(!GENERIC.test(r.short), `generic archive text on ${r.slug}`);
    if (r.scope === 'brand') check((r.brands || [r.brand]).every((b) => ['volkswagen', 'audi', 'seat', 'skoda'].includes(b)), `bad brands ${r.slug}`);
    else {
      check(r.models.length > 0, `no model on ${r.slug}`);
      r.models.forEach((m) => { const mm = MID.get(m); check(mm && mm.brand === r.brand, `model ${m} invalid for ${r.slug}`); });
      if (r.years) {
        const mm = MID.get(r.models[0]);
        check(r.years[0] <= r.years[1], `bad years ${r.slug}`);
        if (r.years[0] < mm.from || r.years[1] > (mm.to || 9999)) notes.push(`years ${r.years.join('–')} outside model range ${mm.from}–${mm.to || 'heden'} on ${r.slug}`);
      }
      const mm0 = MID.get(r.models[0]);
      check(r.title.includes(mm0.name) || r.title.includes(mm0.base) || r.models.length > 1, `title lacks model name: ${r.slug}`);
    }
    if (r.feature === 'dimmende-binnenspiegel') check(!/inklap/i.test(r.short), `wrong mirror text on ${r.slug}`);
  });
  Object.entries(A).forEach(([a, s]) => { check(!slugSet.has(a), `alias equals a slug: ${a}`); check(slugSet.has(s), `alias target missing: ${a} → ${s}`); });
  M.forEach((m) => { const n = R.filter((r) => r.models.includes(m.id)).length; check(n > 0, `model without options: ${m.id}`); });
  check(R.length === 327, `expected 327 entries, got ${R.length}`);
  check(Object.keys(A).length === 35, `expected 35 aliases, got ${Object.keys(A).length}`);

  // Curated entries: approved text and compatibility notes unchanged.
  const before = fs.readFileSync(path.join(__dirname, '02-data.before.js'), 'utf8');
  const st = before.indexOf('const RETROFITS = ['); const en = before.indexOf('\n];', st) + 3;
  const ctx = { SRC_OLD: '', SRC_NEW: '' };
  vm.runInNewContext(before.slice(st, en).replace('const RETROFITS', 'globalThis.RETROFITS'), ctx);
  const bySlug = new Map(R.map((r) => [r.slug, r]));
  ctx.RETROFITS.forEach((o) => {
    const n = bySlug.get(o.slug);
    check(!!n, `curated entry lost: ${o.slug}`);
    if (!n) return;
    ['title', 'name', 'short', 'cat', 'art', 'image', 'body', 'project', 'imageNote'].forEach((k) => check((o[k] || '') === (n[k] || ''), `curated ${k} changed on ${o.slug}`));
    check((o.variantNote || '') === (n.variantNote || ''), `curated variantNote changed on ${o.slug}`);
    check(JSON.stringify(o.models) === JSON.stringify(n.models), `curated models changed on ${o.slug}`);
    if (o.years) check(JSON.stringify(o.years) === JSON.stringify(n.years), `curated years changed on ${o.slug}`);
    else if (n.years) notes.push(`curated entry got verified years ${n.years.join('–')}: ${o.slug}`);
  });
  // Curated order kept at the start of the catalog.
  check(ctx.RETROFITS.every((o, i) => R[i].slug === o.slug), 'curated order not preserved');

  /* ---------- 2. Search ---------- */
  const SEARCH = [
    ['Golf 7 camera', (r) => r.id === 'volkswagen-golf-7-achteruitrijcamera', (all) => all.every((x) => x.models.includes('golf-7') || x.wide)],
    ['A4 B9 CarPlay', (r) => r.id === 'audi-a4-b9-smartphone-interface', (all) => all.every((x) => x.models.includes('a4-b9') || x.wide)],
    ['T-Roc inklapbare spiegels', (r) => r.id === 'volkswagen-t-roc-inklapbare-spiegels', (all) => all.length === 1],
    ['A3 Virtual Cockpit', (r) => r.id === 'audi-a3-8v-virtual-cockpit', (all) => all.every((x) => x.models.some((m) => m.startsWith('a3-')))],
    ['Kodiaq camera', (r) => r.id === 'skoda-kodiaq-achteruitrijcamera', (all) => all.some((x) => x.id === 'skoda-kodiaq-area-view-360-camera') && all.every((x) => x.models.includes('kodiaq'))],
    ['Ateca parkeerhulp', (r) => r.id.startsWith('seat-ateca-parkeerhulp'), (all) => all.slice(0, 3).every((x) => x.id.startsWith('seat-ateca-parkeerhulp')) && all.every((x) => x.models.includes('ateca'))],
    ['golf7 camera', (r) => r.id === 'volkswagen-golf-7-achteruitrijcamera', null],
    ['t6 camera', (r) => r.id.startsWith('volkswagen-transporter-t6-achteruitrijcamera'), (all) => all.every((x) => x.models.includes('transporter-t6'))],
    ['Q5 keyless', (r) => r.id === 'audi-q5-fy-comfortsleutel-keyless-entry', null],
    ['audi ringen', (r) => r.id.endsWith('instapverlichting-audi-ringen'), null],
    ['360 camera', (r) => /area-view|top-view/.test(r.id), null],
    ['carplay', (r) => /app-connect|smartphone-interface|carplay/.test(r.id), null],
    ['homelink', (r) => r.id.endsWith('garagedeuropener-homelink'), null],
    ['Golf 7 Sportsvan', (r) => r.id === 'volkswagen-golf-7-sportsvan-led-achterlichten', (all) => all.every((x) => x.models.includes('golf-sportsvan') || x.wide)],
    ['Kodiaq', (r) => r.id.startsWith('skoda-kodiaq-'), (all) => all.length === 12],
    ['parkeren', (r) => /parkeerhulp|camera/.test(r.id), null],
    ['led achterlichten', (r) => /achterlichten/.test(r.id), (all) => all.every((x) => /achterlichten/.test(x.id))],
    ['cruise control golf', (r) => r.id.startsWith('volkswagen-golf-7-cruise-control'), null],
    ['alarm', (r) => r.id === 'origineel-af-fabriek-alarm-scm', null],
    // review regressions: filler words, trims, years, category words, facelift suffixes
    ['camera inbouwen', (r) => /camera/.test(r.id), (all) => all.every((x) => /camera/.test(x.id))],
    ['trekhaak inbouwen', (r) => /trekhaak/.test(r.id), (all) => all.length >= 20 && all.every((x) => /trekhaak/.test(x.id))],
    ['trekhaak monteren', (r) => /trekhaak/.test(r.id), null],
    ['spiegels inklapbaar', (r) => /spiegel/.test(r.id), null],
    ['carplay activeren', (r) => /app-connect|smartphone-interface|carplay/.test(r.id), null],
    ['golf 7 camera inbouwen', (r) => r.id === 'volkswagen-golf-7-achteruitrijcamera', null],
    ['golf gti camera', (r) => r.id === 'volkswagen-golf-7-achteruitrijcamera', null],
    ['golf 2018 camera', (r) => r.id === 'volkswagen-golf-7-achteruitrijcamera', (all) => all.every((x) => x.models.includes('golf-7') || x.wide)],
    ['passat b8 2017 navigatie', (r) => /passat-b8-discover|discover-navigatie/.test(r.id), null],
    ['seat comfort', (r) => r.id.startsWith('seat-'), (all) => all.length >= 4 && all.every((x) => x.id.startsWith('seat-') || x.wide)],
    ['passat assistentie', (r) => r.id.startsWith('volkswagen-passat-b8-'), (all) => all.filter((x) => !x.wide).length === 3],
    ['golf 7 camera parkeren', (r) => r.id.startsWith('volkswagen-golf-7-'), (all) => all.filter((x) => !x.wide).length === 4],
    ['golf 7.5', (r) => r.models.includes('golf-7'), (all) => all.length >= 17],
    ['t6.1 camera', (r) => r.id.startsWith('volkswagen-transporter-t6-achteruitrijcamera'), null],
    ['adaptieve cruisecontrol', (r) => /cruise/.test(r.id), (all) => all.length > 1],
  ];
  for (const [q, first, all] of SEARCH) {
    const res = await page.evaluate((qq) => window.CT.Search.query(qq, { limit: 999, perType: 0, types: ['RETROFIT'] }).map((x) => ({ id: x.id, models: x.models, wide: x.wide })), q);
    check(res.length && first(res[0]), `search "${q}": top result ${res[0] ? res[0].id : 'none'}`);
    if (all) check(all(res), `search "${q}": result set wrong (${res.length}: ${res.slice(0, 6).map((x) => x.id).join(', ')})`);
    notes.push(`search "${q}" → ${res.length} results, top: ${res.slice(0, 3).map((x) => x.id).join(', ')}`);
  }
  const mixed = await page.evaluate(() => window.CT.Search.query('golf 7').map((x) => `${x.type}:${x.id}`));
  check(mixed[0] === 'MODEL:golf-7', `overlay "golf 7" first result ${mixed[0]}`);
  const t0 = Date.now();
  await page.evaluate(() => { for (let i = 0; i < 200; i++) window.CT.Search.query(['golf 7 camera', 'a4 b9 carplay', 'parkeerhulp', 'kodiaq'][i % 4]); });
  notes.push(`search speed: ${((Date.now() - t0) / 200).toFixed(2)} ms/query (incl. round trip)`);

  /* ---------- 3. Vehicle matching (representative VW, Audi, SEAT, Škoda) ---------- */
  const VEH = [
    [{ merk: 'VOLKSWAGEN', handelsbenaming: 'GOLF', datum_eerste_toelating: '20160301', voertuigsoort: 'Personenauto', type: 'AU' }, 'golf-7'],
    [{ merk: 'VOLKSWAGEN', handelsbenaming: 'GOLF SPORTSVAN', datum_eerste_toelating: '20170301', voertuigsoort: 'Personenauto' }, 'golf-sportsvan'],
    [{ merk: 'VOLKSWAGEN', handelsbenaming: 'CADDY', datum_eerste_toelating: '20180301', voertuigsoort: 'Bedrijfsauto' }, 'caddy-sa'],
    [{ merk: 'VOLKSWAGEN', handelsbenaming: 'CRAFTER', datum_eerste_toelating: '20190301', voertuigsoort: 'Bedrijfsauto' }, 'crafter-sy'],
    [{ merk: 'VOLKSWAGEN', handelsbenaming: 'T-ROC', datum_eerste_toelating: '20190301', voertuigsoort: 'Personenauto', type: 'A1' }, 't-roc'],
    [{ merk: 'AUDI', handelsbenaming: 'A1 SPORTBACK', datum_eerste_toelating: '20150301', voertuigsoort: 'Personenauto', type: '8X' }, 'a1-8x'],
    [{ merk: 'AUDI', handelsbenaming: 'A1 SPORTBACK', datum_eerste_toelating: '20180901', voertuigsoort: 'Personenauto', type: 'GB' }, 'a1-gb'],
    [{ merk: 'AUDI', handelsbenaming: 'Q5', datum_eerste_toelating: '20180301', voertuigsoort: 'Personenauto', type: 'FY' }, 'q5-fy'],
    [{ merk: 'AUDI', handelsbenaming: 'Q7', datum_eerste_toelating: '20170301', voertuigsoort: 'Personenauto', type: '4M' }, 'q7-4m'],
    [{ merk: 'AUDI', handelsbenaming: 'Q3 SPORTBACK', datum_eerste_toelating: '20200301', voertuigsoort: 'Personenauto', type: 'F3' }, 'q3-f3'],
    [{ merk: 'AUDI', handelsbenaming: 'A4 AVANT', datum_eerste_toelating: '20180301', voertuigsoort: 'Personenauto', type: '8W', inrichting: 'stationwagen' }, 'a4-b9'],
    [{ merk: 'SEAT', handelsbenaming: 'ATECA', datum_eerste_toelating: '20180301', voertuigsoort: 'Personenauto' }, 'ateca'],
    [{ merk: 'SEAT', handelsbenaming: 'MII', datum_eerste_toelating: '20150301', voertuigsoort: 'Personenauto' }, 'mii'],
    [{ merk: 'SKODA', handelsbenaming: 'KODIAQ', datum_eerste_toelating: '20180301', voertuigsoort: 'Personenauto' }, 'kodiaq'],
    [{ merk: 'SKODA', handelsbenaming: 'YETI', datum_eerste_toelating: '20150301', voertuigsoort: 'Personenauto' }, 'yeti'],
    [{ merk: 'SKODA', handelsbenaming: 'SUPERB COMBI', datum_eerste_toelating: '20170301', voertuigsoort: 'Personenauto', type: '3V' }, 'superb-3v'],
  ];
  for (const [raw, expect] of VEH) {
    const m = await page.evaluate((x) => window.CT.VehicleMatcher.match(x), raw);
    check(m.status === 'matched' && m.modelId === expect, `match ${raw.merk} ${raw.handelsbenaming} ${raw.datum_eerste_toelating.slice(0, 4)} → ${m.status} ${m.modelId || (m.options || []).join('/')}`);
  }
  // Old generations stay unmatched (no wrong generation is suggested).
  const old = [
    [{ merk: 'VOLKSWAGEN', handelsbenaming: 'CADDY', datum_eerste_toelating: '20220301', voertuigsoort: 'Bedrijfsauto' }, 'caddy 5'],
    [{ merk: 'AUDI', handelsbenaming: 'Q5', datum_eerste_toelating: '20120301', voertuigsoort: 'Personenauto', type: '8R' }, 'Q5 8R'],
  ];
  for (const [raw, label] of old) {
    const m = await page.evaluate((x) => window.CT.VehicleMatcher.match(x), raw);
    check(m.status !== 'matched', `${label} must not match a catalog generation (got ${m.modelId})`);
  }
  const t7 = await page.evaluate(() => window.CT.VehicleMatcher.match({ merk: 'VOLKSWAGEN', handelsbenaming: 'MULTIVAN', datum_eerste_toelating: '20230301', voertuigsoort: 'Personenauto' }));
  check(t7.status !== 'matched', `T7 Multivan 2023 must not match T6 (got ${t7.modelId})`);
  const t6 = await page.evaluate(() => window.CT.VehicleMatcher.match({ merk: 'VOLKSWAGEN', handelsbenaming: 'MULTIVAN', datum_eerste_toelating: '20180301', voertuigsoort: 'Personenauto' }));
  check(t6.status === 'matched' && t6.modelId === 'transporter-t6', 'T6 Multivan 2018 matches T6');
  const dcp = await page.evaluate(() => {
    const it = window.CT.catalog.RETROFITS.find((r) => r.slug === 'volkswagen-discover-navigatie-met-carplay');
    const s = (m, y) => window.CT.Compat.status(it, { brandId: 'volkswagen', modelId: m, year: y }).key;
    return [s('golf-7', 2016), s('golf-7', 2020), s('passat-b8', 2019), s('polo-aw', 2018)];
  });
  check(JSON.stringify(dcp) === JSON.stringify(['variant', 'contact', 'contact', 'variant']), `discover carplay per-model years ${dcp}`);
  // Compat statuses for a vehicle (Q5 FY 2018 vs 2022).
  const compat = await page.evaluate(() => {
    const it = window.CT.catalog.RETROFITS.find((r) => r.slug === 'audi-q5-fy-virtual-cockpit');
    const s1 = window.CT.Compat.status(it, { brandId: 'audi', modelId: 'q5-fy', year: 2018 });
    const s2 = window.CT.Compat.status(it, { brandId: 'audi', modelId: 'q5-fy', year: 2022 });
    const s3 = window.CT.Compat.status(it, { brandId: 'audi', modelId: 'q5-fy' });
    const lim = window.CT.catalog.RETROFITS.find((r) => r.slug === 'audi-a4-b9-limousine-led-achterlichten-donker');
    const s4 = window.CT.Compat.status(lim, { brandId: 'audi', modelId: 'a4-b9', year: 2018, body: 'stationwagen' });
    const s5 = window.CT.Compat.status(lim, { brandId: 'audi', modelId: 'a4-b9', year: 2018, body: 'Sedan' });
    return [s1.key, s2.key, s3.key, s4.key, s5.key];
  });
  check(JSON.stringify(compat) === JSON.stringify(['ok', 'contact', 'check', 'contact', 'variant']), `compat statuses ${compat}`);

  /* ---------- 4. Pages: redirects, details, catalog ---------- */
  await go(page, '#/mogelijkheden/audi-a4-b9-8w-virtual-cockpit', { scroll: false });
  check(page.url().endsWith('#/mogelijkheden/audi-a4-b9-virtual-cockpit'), `alias redirect → ${page.url()}`);
  check((await page.textContent('h1')).includes('Audi A4 B9/8W – Virtual Cockpit'), 'alias page h1');
  await go(page, '#/mogelijkheden/aanbieding-1-volkswagen-golf-7-active-info-display', { scroll: false });
  check(page.url().endsWith('#/mogelijkheden/volkswagen-golf-7-active-info-display'), 'offer alias redirect');
  const specs = await page.$$eval('.spec-list dt, .spec-list dd', (els) => els.map((e) => e.textContent.trim()));
  check(specs.join('|').includes('Prijs|€ 1.099 excl. btw') && specs.join('|').includes('Garantie|3 jaar'), `golf 7 AID specs ${specs.join('|')}`);
  await go(page, '#/mogelijkheden/nope-does-not-exist', { scroll: false });
  check((await page.textContent('h1')).includes('bestaat niet'), '404 retrofit');
  for (const bad of ['constructor', '__proto__', 'toString', 'hasOwnProperty']) {
    await go(page, `#/mogelijkheden/${bad}`, { scroll: false });
    check((await page.textContent('h1')).includes('bestaat niet'), `prototype slug ${bad} → 404`);
  }
  await go(page, '#/mogelijkheden/audi-a4-b9-virtual-cockpit', { scroll: false });
  const allLink = await page.$eval('#rel-model ~ a, .section-head a.link', (a) => a.textContent);
  await page.click('.section-head a.link');
  await page.waitForTimeout(300);
  const catCount = (await page.textContent('[data-count]')).trim();
  check(allLink.includes(catCount.split(' ')[0]), `"${allLink.trim()}" vs catalog "${catCount}"`);
  await go(page, '#/mogelijkheden/audi-a4-b9-avant-led-achterlichten-donker', { scroll: false });
  const pills = await page.$$eval('.detail-block > .cp-models a', (as) => as.map((a) => a.textContent.trim()));
  check(new Set(pills).size === pills.length, `duplicate model pills ${pills}`);
  const ld = await page.evaluate(() => JSON.parse(document.querySelector('script[data-route-ld]').textContent)[1].itemListElement.map((x) => x.name));
  const vis = await page.$$eval('nav[aria-label="Kruimelpad"] li', (li) => li.map((x) => x.textContent.trim()));
  check(JSON.stringify(ld) === JSON.stringify(vis), `breadcrumb ld ${ld} vs visible ${vis}`);

  // Every detail page renders (h1, specs, price row, no "bronpagina").
  const allSlugs = R.map((r) => r.slug);
  for (const s of allSlugs) {
    await page.evaluate((h) => { location.hash = h; }, `#/mogelijkheden/${s}`);
    await page.waitForFunction((h) => document.documentElement.dataset.route === h, `/mogelijkheden/${s}`, { timeout: 4000 }).catch(() => {});
    const info = await page.evaluate(() => ({
      h1: (document.querySelector('h1') || {}).textContent || '',
      price: [...document.querySelectorAll('.spec-list dt')].some((d) => d.textContent === 'Prijs'),
      bron: /bronpagina/i.test(document.body.innerText),
      broken: [...document.querySelectorAll('#app img')].filter((i) => i.complete && i.naturalWidth === 0).length,
      rel: document.querySelectorAll('#app section[aria-labelledby^="rel-"]').length,
      ld: [...document.querySelectorAll('script[data-route-ld]')].length,
    }));
    check(info.h1.length > 5 && info.price && !info.bron && !info.broken && info.ld === 1, `detail ${s}: ${JSON.stringify(info)}`);
    if (!R.find((r) => r.slug === s).scope) check(info.rel >= 1, `detail ${s}: no related section`);
  }
  notes.push(`rendered ${allSlugs.length} detail pages`);

  // Catalog: model filter grouped by category; counts.
  await go(page, '#/mogelijkheden?merk=audi&model=q5-fy', { scroll: false });
  const cnt = await page.textContent('[data-count]');
  check(/^19 /.test(cnt), `Q5 FY catalog count "${cnt}" (17 Q5 FY + 2 merkbrede opties)`);
  await go(page, '#/mogelijkheden?q=Kodiaq%20camera', { scroll: false });
  const kod = await page.$$eval('.retrofit-card h3', (els) => els.map((e) => e.textContent.trim()));
  check(kod.length === 2 && kod.every((t) => t.includes('Kodiaq')), `catalog q Kodiaq camera → ${kod.join(' / ')}`);
  await go(page, '#/mogelijkheden', { scroll: false });
  const firstCards = await page.$$eval('.retrofit-card h3', (els) => els.slice(0, 4).map((e) => e.textContent.trim()));
  check(firstCards[0] === 'Volkswagen Golf 7 – Active Info Display', `catalog first card ${firstCards[0]}`);
  await go(page, '#/merken/audi', { scroll: false });
  const audiModels = await page.$$eval('.model-card h3', (els) => els.map((e) => e.textContent.trim()));
  check(['A1 8X', 'A1 GB', 'Q3 F3', 'Q5 FY', 'Q7 4M'].every((m) => audiModels.includes(m)), `audi brand models ${audiModels}`);

  check(!errors.length, `console errors: ${errors.join(' | ')}`);
  await browser.close();
  console.log(notes.join('\n'));
  console.log(fails.length ? `\nFAIL (${fails.length}):\n- ${fails.join('\n- ')}` : '\nALL CATALOG CHECKS PASSED');
  process.exit(fails.length ? 1 : 0);
})();
