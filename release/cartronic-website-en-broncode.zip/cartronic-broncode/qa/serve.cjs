// Static server with an SPA fallback like Netlify's "/* /index.html 200". node qa/serve.cjs <dir> <port>
const http = require('http'); const fs = require('fs'); const path = require('path');
const dir = path.resolve(process.argv[2] || '.'); const port = Number(process.argv[3] || 8811);
const TYPES = { '.html': 'text/html; charset=utf-8', '.xml': 'application/xml', '.txt': 'text/plain', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.json': 'application/json' };
http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  let file = path.join(dir, decodeURIComponent(u.pathname));
  if (!file.startsWith(dir)) { res.writeHead(403); res.end(); return; }
  if (fs.existsSync(file) && fs.statSync(file).isDirectory()) file = path.join(file, 'index.html');
  if (!fs.existsSync(file)) file = path.join(dir, 'index.html');
  res.writeHead(200, { 'content-type': TYPES[path.extname(file)] || 'application/octet-stream' });
  fs.createReadStream(file).pipe(res);
}).listen(port, () => console.log(`serving ${dir} on ${port}`));
