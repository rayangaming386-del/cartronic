const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');
const S = path.resolve(__dirname, '..');
const GSAP = path.join(S, 'tools/node_modules/gsap/dist/gsap.min.js');
const ST = path.join(S, 'tools/node_modules/gsap/dist/ScrollTrigger.min.js');
const FONTS = path.join(S, 'fonts');
const URL_BASE = process.env.CT_URL || 'file:///home/user/cartronic/index.html';
const RDW_MOCK = {
  '12ABC3': { kenteken: '12ABC3', merk: 'VOLKSWAGEN', handelsbenaming: 'GOLF', datum_eerste_toelating: '20210510', voertuigsoort: 'Personenauto', inrichting: 'hatchback', type: 'CD' },
  'GHJ45K': { kenteken: 'GHJ45K', merk: 'AUDI', handelsbenaming: 'A3 SPORTBACK', datum_eerste_toelating: '20170301', voertuigsoort: 'Personenauto', inrichting: 'hatchback', type: '8V' },
  'XX999X': 'fail',
};
async function open({ width = 1440, height = 900, reduce = true, mobile = false } = {}) {
  const browser = await chromium.launch();
  const context = await browser.newContext({ viewport: { width, height }, deviceScaleFactor: 1, isMobile: mobile, hasTouch: mobile, reducedMotion: reduce ? 'reduce' : 'no-preference' });
  const page = await context.newPage();
  const errors = [];
  page.on('console', (m) => { if (m.type() === 'error') errors.push(`console: ${m.text()}`); });
  page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
  await page.route('**/*', async (route) => {
    const url = route.request().url();
    if (url.startsWith('file:') || url.startsWith('data:') || url.startsWith('blob:') || url.startsWith('http://localhost:')) return route.continue();
    if (url.includes('cdnjs.cloudflare.com/ajax/libs/gsap/') && process.env.NO_CDN) return route.abort();
    if (url.includes('cdnjs.cloudflare.com/ajax/libs/gsap/')) return route.fulfill({ body: fs.readFileSync(url.endsWith('ScrollTrigger.min.js') ? ST : GSAP), contentType: 'application/javascript', headers: { 'access-control-allow-origin': '*' } });
    if (url.startsWith('https://fonts.googleapis.com/')) return route.fulfill({ body: fs.readFileSync(path.join(FONTS, 'inter.css')), contentType: 'text/css' });
    if (url.startsWith('https://fonts.gstatic.com/')) return route.fulfill({ body: fs.readFileSync(path.join(FONTS, path.basename(new URL(url).pathname))), contentType: 'font/woff2', headers: { 'access-control-allow-origin': '*' } });
    if (url.startsWith('https://opendata.rdw.nl/')) {
      const plate = new URL(url).searchParams.get('kenteken');
      const d = RDW_MOCK[plate];
      if (d === 'fail') return route.abort();
      await new Promise((r) => setTimeout(r, 300));
      return route.fulfill({ body: JSON.stringify(d ? [d] : []), contentType: 'application/json', headers: { 'access-control-allow-origin': '*' } });
    }
    return route.abort();
  });
  return { browser, context, page, errors };
}
async function go(page, hash, { scroll = true } = {}) {
  await page.goto(`${URL_BASE}${hash}`);
  await page.waitForTimeout(250);
  if (scroll) {
    await page.evaluate(async () => {
      const step = window.innerHeight * 0.8;
      for (let y = 0; y < document.documentElement.scrollHeight; y += step) { window.scrollTo(0, y); await new Promise((r) => setTimeout(r, 40)); }
      window.scrollTo(0, 0);
    });
    await page.waitForTimeout(200);
  }
}
async function overflow(page) {
  return page.evaluate(() => {
    const w = document.documentElement.clientWidth;
    const offenders = [];
    if (document.documentElement.scrollWidth > w + 1) {
      document.querySelectorAll('body *').forEach((el) => {
        const r = el.getBoundingClientRect();
        if (r.right > w + 1 && r.width > 0 && getComputedStyle(el).position !== 'fixed') offenders.push(`${el.tagName.toLowerCase()}.${String(el.className).slice(0, 40)} right=${Math.round(r.right)}`);
      });
    }
    return { scrollWidth: document.documentElement.scrollWidth, clientWidth: w, offenders: offenders.slice(0, 8) };
  });
}
module.exports = { open, go, overflow, URL_BASE, S };
