// Builds the delivery zip: cartronic-website/ (exactly what Beheer → Publiceren produces) + cartronic-broncode/.
// NODE_PATH=/opt/node22/lib/node_modules node qa/make-package.cjs <build.html> <out.zip>
const fs = require('fs'); const path = require('path'); const { execSync } = require('child_process');
const { chromium } = require('playwright');
const S = path.resolve(__dirname, '..');
const [build, outZip] = process.argv.slice(2).map((p) => path.resolve(p));
const PKG = path.join(S, 'pkg3');
(async () => {
  fs.rmSync(PKG, { recursive: true, force: true }); fs.mkdirSync(PKG, { recursive: true });
  const browser = await chromium.launch();
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.route('**/*', (r) => (r.request().url().startsWith('file:') || r.request().url().startsWith('data:') || r.request().url().startsWith('blob:') ? r.continue() : r.abort()));
  await page.goto(`file://${build}#/`);
  await page.waitForFunction(() => window.CT && window.CT.Publisher);
  const files = await page.evaluate(async () => (await window.CT.Publisher.files()).files.map((f) => ({ name: f.name, text: typeof f.data === 'string' ? f.data : null, bytes: typeof f.data === 'string' ? null : Array.from(f.data) })));
  await browser.close();
  if (errors.length) throw new Error(errors.join('\n'));
  for (const f of files) {
    const p = path.join(PKG, f.name); fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p, f.text != null ? f.text : Buffer.from(f.bytes));
  }
  // Source
  const SRC = path.join(PKG, 'cartronic-broncode');
  const copy = (from, to = from) => fs.cpSync(path.join(S, from), path.join(SRC, to), { recursive: true });
  ['src', 'img', 'eslint.config.mjs', 'lint.sh'].forEach((x) => copy(x));
  fs.writeFileSync(path.join(SRC, 'build.mjs'), fs.readFileSync(path.join(S, 'build.mjs'), 'utf8')
    .replace("process.argv[2] || '/home/user/cartronic/index.html'", "process.argv[2] || path.join(here, 'index.html')"));
  fs.mkdirSync(path.join(SRC, 'qa'));
  ['harness.cjs', 'serve.cjs', 'snapshot.cjs', 'snapdiff.py', 'run-all.sh', 'catalog.cjs', 'flows1.cjs', 'flows2.cjs', 'flows3.cjs', 'mobile.cjs', 'motion.cjs', 'match.cjs', 'axe.cjs', 'axe2.cjs', 'sweep.cjs',
    'admin-tour.cjs', 'admin-content.cjs', 'admin-backup.cjs', 'publish.cjs', 'path-smoke.cjs', 'review-fixes.cjs', 'round2-fixes.cjs', 'round3-fixes.cjs', 'make-package.cjs'].forEach((x) => copy(path.join('qa', x)));
  if (fs.existsSync(path.join(S, 'tools', 'catalog'))) copy(path.join('tools', 'catalog'));
  fs.copyFileSync('/home/user/cartronic/README.md', path.join(SRC, 'README.md'));
  fs.copyFileSync('/home/user/cartronic/README.md', path.join(PKG, 'README.md'));
  fs.rmSync(outZip, { force: true });
  execSync(`cd "${PKG}" && zip -qr "${outZip}" cartronic-website cartronic-broncode README.md`);
  execSync(`unzip -tq "${outZip}"`);
  console.log('wrote', outZip, (fs.statSync(outZip).size / 1024).toFixed(0), 'KB');
  console.log(execSync(`unzip -l "${outZip}" | grep -v "cartronic-broncode/" | tail -n +1`).toString());
})().catch((e) => { console.error(e); process.exit(1); });
