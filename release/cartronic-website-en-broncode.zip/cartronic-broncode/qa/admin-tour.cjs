// Visits every Beheer screen (desktop + mobile), checks for errors and overflow, takes screenshots.
const { open, go, overflow } = require('./harness.cjs');
const PAGES = ['', '/website', '/bedrijf', '/teksten', '/teksten?groep=overig', '/weergave', '/seo', '/opties', '/opties/volkswagen-golf-7-active-info-display', '/opties/nieuw', '/opties/nieuw?van=origineel-af-fabriek-alarm-scm', '/opties/origineel-af-fabriek-alarm-scm', '/catalogus', '/diensten', '/diensten/kalibratie-rijhulpsystemen', '/diensten/nieuw', '/kennis', '/kennis/acc-en-lane-assist-kalibreren', '/kennis/nieuw', '/beoordelingen', '/meer-werk', '/producten', '/instellingen'];
(async () => {
  for (const vp of [{ width: 1440, height: 900, tag: 'd' }, { width: 390, height: 844, mobile: true, tag: 'm' }]) {
    const { browser, page, errors } = await open(vp);
    await go(page, '#/admin', { scroll: false });
    await page.fill('#lg-u', 'demo'); await page.fill('#lg-p', 'cartronic-demo'); await page.click('[data-login] [type=submit]');
    await page.waitForSelector('.admin-nav');
    for (const p of PAGES) {
      await go(page, `#/admin${p}`, { scroll: false });
      await page.waitForTimeout(150);
      const h1 = await page.evaluate(() => (document.querySelector('.admin-top h1') || {}).textContent);
      const ov = await overflow(page);
      console.log(vp.tag, p || '/', '→', h1, ov.scrollWidth > ov.clientWidth ? `OVERFLOW ${JSON.stringify(ov.offenders)}` : '');
      await page.screenshot({ path: `qa/ac/${vp.tag}${p.replace(/[/?=]/g, '_') || '_dash'}.png`, fullPage: vp.tag === 'd' });
    }
    console.log(vp.tag, 'errors', errors);
    await browser.close();
  }
})();
