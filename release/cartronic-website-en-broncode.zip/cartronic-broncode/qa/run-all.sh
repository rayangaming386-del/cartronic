#!/bin/sh
# Runs every regression suite against one build. Usage: qa/run-all.sh <build.html>
cd "$(dirname "$0")/.."
export NODE_PATH=/opt/node22/lib/node_modules CT_URL="file://$PWD/$1"
mkdir -p qa/logs
for t in catalog flows1 flows2 flows3 mobile motion match axe axe2 admin-tour admin-content admin-backup; do
  (timeout 900 node qa/$t.cjs > qa/logs/$t.log 2>&1; echo "EXIT $?" >> qa/logs/$t.log) &
done
wait
timeout 900 node qa/publish.cjs > qa/logs/publish.log 2>&1; echo "EXIT $?" >> qa/logs/publish.log
for t in catalog flows1 flows2 flows3 mobile motion match axe axe2 admin-tour admin-content admin-backup publish; do
  printf '%-14s %s | ok=%s fail=%s\n' "$t" "$(tail -1 qa/logs/$t.log)" "$(grep -c '^ok' qa/logs/$t.log)" "$(grep -c '^FAIL\|FAILED' qa/logs/$t.log)"
done
