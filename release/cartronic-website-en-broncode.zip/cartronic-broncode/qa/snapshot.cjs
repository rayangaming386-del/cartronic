// Captures the rendered HTML (header, page, footer, head meta) of every public route.
// node qa/snapshot.cjs <out.json>   (CT_URL selects the build). Used to prove refactors change nothing.
const fs = require('fs');
const { open, go } = require('./harness.cjs');
(async () => {
  const out = process.argv[2];
  const { browser, page, errors } = await open({ width: 1440, height: 900 });
  await go(page, '#/', { scroll: false });
  const src = fs.readFileSync(require('path').join(__dirname, '..', 'src', '02-data.js'), 'utf8');
  const block = (name) => { const i = src.indexOf(`const ${name} = [`); return src.slice(i, src.indexOf('\n];', i)); };
  const slugs = (name) => [...block(name).matchAll(/^  \{ slug: '([^']+)'/gm)].map((m) => m[1]);
  const extra = [...slugs('ARTICLES').map((s) => `/kennis/${s}`), ...slugs('SERVICES').map((s) => `/diensten/${s}`)];
  const routes = await page.evaluate((extra) => {
    const C = window.CT.catalog;
    const r = ['/', '/mogelijkheden', '/merken', '/projecten', '/expertise', '/over', '/contact', '/beoordelingen', '/kennis', '/productinformatie', '/privacy', '/mijn-auto', '/webshop', '/winkelmand', '/zoeken?q=camera', '/bestaat-niet',
      '/mogelijkheden?merk=audi&model=q5-fy', '/mogelijkheden?cat=trekhaken', '/contact?onderwerp=optielijst'];
    C.RETROFITS.forEach((x) => r.push(`/mogelijkheden/${x.slug}`));
    ['volkswagen', 'audi', 'seat', 'skoda'].forEach((b) => r.push(`/merken/${b}`));
    window.CT.Repo.projects().forEach((p) => r.push(`/projecten/${p.slug}`));
    window.CT.Repo.products().forEach((p) => r.push(`/webshop/${p.slug}`));
    return r.concat(extra);
  }, extra);
  const snap = {};
  for (const r of routes) {
    await page.evaluate((h) => { location.hash = h; }, `#${r}`);
    await page.waitForFunction((p) => document.documentElement.dataset.route === p.split('?')[0], r).catch(() => {});
    await page.waitForTimeout(30);
    snap[r] = await page.evaluate(() => {
      const strip = (h) => h.replace(/ style="[^"]*"/g, '').replace(/data-id="fx\d+"|fx\d+-/g, 'fx').replace(/acc_[a-z0-9]+/g, 'acc');
      return {
        title: document.title,
        desc: (document.querySelector('meta[name="description"]') || {}).content,
        app: strip(document.getElementById('app').innerHTML),
        header: strip(document.getElementById('siteHeader').innerHTML),
        footer: strip(document.getElementById('siteFooter').innerHTML),
        mnav: strip((document.getElementById('mobileNav') || {}).innerHTML || ''),
      };
    });
  }
  fs.writeFileSync(out, JSON.stringify(snap));
  console.log('routes', routes.length, 'errors', errors.length);
  await browser.close();
})();
