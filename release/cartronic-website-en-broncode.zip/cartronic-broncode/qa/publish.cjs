// Publish round trip: edit in Beheer → download zip → serve it → visitors see it → publish again from the published site.
const fs = require('fs'); const path = require('path'); const { execSync, spawn } = require('child_process'); const http = require('http');
const { open, go } = require('./harness.cjs');
let fails = 0;
const assert = (c, m) => { console.log(`${c ? 'ok  ' : 'FAIL'}: ${m}`); if (!c) fails++; };
const PUB = path.join(__dirname, 'pub'); const SITE = path.join(PUB, 'site');
const PORT = 8812; const ORIGIN = `http://localhost:${PORT}`;
const fetchText = (u) => new Promise((res, rej) => http.get(u, (r) => { let d = ''; r.setEncoding('utf8'); r.on('data', (c) => { d += c; }); r.on('end', () => res(d)); }).on('error', rej));
async function login(page) {
  await page.fill('#lg-u', 'demo'); await page.fill('#lg-p', 'cartronic-demo'); await page.click('[data-login] [type=submit]');
  await page.waitForSelector('.admin-nav');
}
async function setText(page, key, value, nav) {
  await nav('/admin/teksten');
  await page.evaluate(([k, v]) => { const el = document.querySelector(`[name="${k}"]`); el.value = v; el.dispatchEvent(new Event('input', { bubbles: true })); }, [key, value]);
  await page.click('[data-texts] [type=submit]'); await page.waitForTimeout(300);
}
async function download(page, dir) {
  const [dl] = await Promise.all([page.waitForEvent('download'), page.click('[data-publish]')]);
  const zip = path.join(PUB, `${path.basename(dir)}.zip`);
  await dl.saveAs(zip);
  execSync(`unzip -tq "${zip}"`);
  fs.rmSync(dir, { recursive: true, force: true }); fs.mkdirSync(dir, { recursive: true });
  execSync(`unzip -q "${zip}" -d "${dir}"`);
  return path.join(dir, 'cartronic-website');
}
function deploy(from) { fs.rmSync(SITE, { recursive: true, force: true }); fs.cpSync(from, SITE, { recursive: true }); }
(async () => {
  fs.rmSync(PUB, { recursive: true, force: true }); fs.mkdirSync(SITE, { recursive: true });
  const server = spawn('node', [path.join(__dirname, 'serve.cjs'), SITE, String(PORT)], { stdio: 'ignore' });
  await new Promise((r) => setTimeout(r, 500));
  try {
    // ---- 1. Edit in a local copy (file://) and publish
    const ed = await open({ width: 1440, height: 900 });
    const navLocal = async (r) => { await go(ed.page, `#${r}`, { scroll: false }); await ed.page.waitForTimeout(150); };
    await navLocal('/admin'); await login(ed.page);
    await setText(ed.page, 'home.hero.line1', 'Gepubliceerd.', navLocal);
    await navLocal('/admin/seo');
    await ed.page.fill('[name="siteUrl"]', ORIGIN);
    await ed.page.click('[data-seo] [type=submit]'); await ed.page.waitForTimeout(300);
    await navLocal('/admin/opties?q=golf-8-app-connect'); await ed.page.waitForTimeout(300);
    await ed.page.click('[data-otoggle="volkswagen-golf-8-app-connect"]'); await ed.page.waitForTimeout(300);
    await ed.page.evaluate(() => { const R = window.CT.Repo; R.saveProduct({ ...R.product('prd_carplay'), regularPrice: 18900 }); });
    await navLocal('/admin/website');
    assert((await ed.page.textContent('.panel')).includes('Webshop & projecten'), 'webshop change listed as unpublished');
    const v1 = await download(ed.page, path.join(PUB, 'v1'));
    const files = fs.readdirSync(v1).sort();
    assert(['404.html', 'LEESMIJ.txt', '_redirects', 'index.html', 'og-image.jpg', 'robots.txt', 'sitemap.xml'].every((f) => files.includes(f)), `zip contents: ${files.join(', ')}`);
    const html = fs.readFileSync(path.join(v1, 'index.html'), 'utf8');
    const m = html.match(/<script id="ctContent" type="application\/json">([\s\S]*?)<\/script>/);
    const bundle = JSON.parse(m[1]);
    assert(bundle.stamp && bundle.texts['home.hero.line1'] === 'Gepubliceerd.' && bundle.retrofits.hide.includes('volkswagen-golf-8-app-connect') && bundle.shop.products.find((p) => p.id === 'prd_carplay').regularPrice === 18900, 'bundle embeds texts, hidden option and shop data');
    assert(fs.readFileSync(path.join(v1, '404.html'), 'utf8') === html, '404.html is the same page');
    assert(!/<\/script/i.test(html.slice(html.indexOf('<script id="ctApp">') + 20, html.lastIndexOf('</script>'))), 'application script has no premature </script>');
    const sm = fs.readFileSync(path.join(v1, 'sitemap.xml'), 'utf8');
    assert(sm.includes(`<loc>${ORIGIN}/mogelijkheden/volkswagen-golf-7-active-info-display</loc>`) && !sm.includes('golf-8-app-connect') && !sm.includes('/webshop/') && sm.includes('model=golf-8'), 'sitemap: options, no hidden option, no demo products, model pages');
    assert(fs.readFileSync(path.join(v1, 'robots.txt'), 'utf8').includes(`Sitemap: ${ORIGIN}/sitemap.xml`), 'robots.txt points at the sitemap');
    assert(fs.readFileSync(path.join(v1, '_redirects'), 'utf8').includes('/*    /index.html    200'), '_redirects rewrites all paths');
    const head = html.slice(0, html.indexOf('</head>'));
    assert(!head.includes('rel="canonical"') && !head.includes('og:url') && head.includes(`content="${ORIGIN}/og-image.jpg"`), 'static head: share image, no page-specific canonical (set per route)');
    const jpg = fs.readFileSync(path.join(v1, 'og-image.jpg'));
    assert(jpg[0] === 0xFF && jpg[1] === 0xD8 && jpg.length > 20000, `og-image.jpg is a JPEG (${jpg.length} bytes)`);
    await ed.browser.close();

    // ---- 2. Visitor of the published site
    deploy(v1);
    const raw = await fetchText(`${ORIGIN}/mogelijkheden/volkswagen-golf-7-active-info-display`);
    assert(raw.includes('ctContent') && raw.includes('<title>'), 'deep link served by the SPA fallback');
    const vis = await open({ width: 1280, height: 860 });
    await vis.page.goto(`${ORIGIN}/`); await vis.page.waitForSelector('#hero-title');
    assert((await vis.page.textContent('#hero-title')).includes('Gepubliceerd.'), 'visitor sees the published text');
    assert(await vis.page.evaluate(() => window.CT.Router.pathMode && !document.querySelector('a[href^="#/"]')), 'clean URLs on the published site');
    await vis.page.goto(`${ORIGIN}/mogelijkheden/volkswagen-golf-8-app-connect`); await vis.page.waitForTimeout(400);
    assert((await vis.page.textContent('h1')).includes('bestaat niet'), 'hidden option is gone for visitors');
    await vis.page.goto(`${ORIGIN}/webshop/smartphone-integratiemodule`); await vis.page.waitForTimeout(400);
    assert((await vis.page.textContent('.pdp, main')).includes('189,00'), 'visitor sees the published product price');
    await vis.page.click('[data-action="add-to-cart"]'); await vis.page.waitForTimeout(300);
    assert(await vis.page.evaluate(() => window.CT.Cart.count() === 1), 'visitor can use the cart');
    assert(await vis.page.evaluate(() => !localStorage.getItem('ct.v1.siteDraft')), 'visitor has no draft');

    // ---- 3. Edit on the published site and publish again from there
    const ed2 = await open({ width: 1440, height: 900 });
    const navLive = async (r) => { await ed2.page.goto(`${ORIGIN}${r}`); await ed2.page.waitForTimeout(250); };
    await navLive('/admin'); await login(ed2.page);
    await setText(ed2.page, 'home.hero.line1', 'Tweede versie.', navLive);
    await navLive('/');
    assert((await ed2.page.textContent('#hero-title')).includes('Tweede versie.'), 'editor sees the draft on the live site');
    await navLive('/admin/website');
    const v2 = await download(ed2.page, path.join(PUB, 'v2'));
    const b2 = JSON.parse(fs.readFileSync(path.join(v2, 'index.html'), 'utf8').match(/<script id="ctContent" type="application\/json">([\s\S]*?)<\/script>/)[1]);
    assert(b2.texts['home.hero.line1'] === 'Tweede versie.' && b2.retrofits.hide.includes('volkswagen-golf-8-app-connect') && b2.stamp !== bundle.stamp, 'publishing from a published page keeps everything');
    deploy(v2);
    // The visitor gets the new version on the next visit; their cart stays.
    await vis.page.goto(`${ORIGIN}/`); await vis.page.waitForSelector('#hero-title');
    assert((await vis.page.textContent('#hero-title')).includes('Tweede versie.') && await vis.page.evaluate(() => window.CT.Cart.count() === 1), 'visitor sees version 2, cart kept');
    // The editor's draft equals the new publication: no question and nothing unpublished (the stored draft is
    // ignored, not deleted, so another file of the site that is still based on it keeps it).
    await navLive('/admin');
    assert(!(await ed2.page.$('[data-parked]')) && await ed2.page.evaluate(() => !window.CT.Content.draft && !window.CT.SiteStatus.changes().length), 'own publication: no question, nothing left to publish');

    // ---- 4. A newer publication made elsewhere while this editor has unpublished changes
    await setText(ed2.page, 'home.hero.line1', 'Concept van editor 2.', navLive);
    const ed3 = await open({ width: 1440, height: 900 });
    await ed3.page.goto(`${ORIGIN}/admin`); await login(ed3.page);
    await setText(ed3.page, 'home.hero.line2', 'Door editor 3.', async (r) => { await ed3.page.goto(`${ORIGIN}${r}`); await ed3.page.waitForTimeout(250); });
    await ed3.page.goto(`${ORIGIN}/admin/website`); await ed3.page.waitForTimeout(250);
    const v3 = await download(ed3.page, path.join(PUB, 'v3'));
    deploy(v3);
    await ed3.browser.close();
    await navLive('/');
    assert((await ed2.page.textContent('#hero-title')).includes('Door editor 3.') && !(await ed2.page.textContent('#hero-title')).includes('Concept van editor 2.'), 'outdated draft is parked: the new publication is shown');
    await navLive('/admin');
    assert(!!(await ed2.page.$('[data-parked="keep"]')), 'editor is asked which version to use');
    await ed2.page.click('[data-parked="keep"]'); await ed2.page.waitForTimeout(300);
    await navLive('/');
    assert((await ed2.page.textContent('#hero-title')).includes('Concept van editor 2.'), 'keeping the draft restores it');
    console.log('errors:', [...vis.errors, ...ed2.errors]);
    await vis.browser.close(); await ed2.browser.close();
  } finally { server.kill(); }
  console.log(fails ? `${fails} FAILED` : 'ALL PUBLISH CHECKS PASSED');
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
