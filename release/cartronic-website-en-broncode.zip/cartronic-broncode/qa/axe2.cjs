const fs = require('fs');
const { open, go, S } = require('./harness.cjs');
const AXE = fs.readFileSync(`${S}/tools/node_modules/axe-core/axe.min.js`, 'utf8');
(async () => {
  const { browser, page } = await open({ width: 1440, height: 900 });
  await go(page, '#/webshop', { scroll: false });
  await page.evaluate(() => { window.CT.Cart.add('prd_cam_set', 1); window.CT.Cart.add('prd_pdc_set', 2); sessionStorage.setItem('ct.v1.adminSession', JSON.stringify({ user: 'demo' })); });
  const routes = ['#/winkelmand', '#/afrekenen', '#/admin', '#/admin/producten', '#/admin/producten/prd_cam_set', '#/admin/producten/nieuw', '#/admin/categorieen', '#/admin/bestellingen', '#/admin/bestellingen/ord_demo_2', '#/admin/acties', '#/admin/voorraad', '#/admin/projecten', '#/admin/projecten/prj_ibiza', '#/admin/instellingen', '#/admin/website', '#/admin/bedrijf', '#/admin/teksten', '#/admin/teksten?groep=overig', '#/admin/weergave', '#/admin/seo', '#/admin/opties', '#/admin/opties/volkswagen-golf-7-active-info-display', '#/admin/opties/nieuw', '#/admin/catalogus', '#/admin/diensten', '#/admin/diensten/online-programmeren', '#/admin/kennis', '#/admin/kennis/acc-en-lane-assist-kalibreren', '#/admin/beoordelingen', '#/admin/meer-werk'];
  for (const r of routes) {
    await go(page, r, { scroll: false });
    await page.addScriptTag({ content: AXE });
    const res = await page.evaluate(async () => (await window.axe.run(document, { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'best-practice'] }, rules: { region: { enabled: false } } })).violations.map((v) => `${v.impact} ${v.id} (${v.nodes.length}): ${v.nodes.slice(0, 3).map((n) => n.target.join(' ') + ' — ' + (n.failureSummary || '').split('\n')[1]).join(' | ')}`));
    console.log(r, res.length ? '\n  ' + res.join('\n  ') : 'OK');
  }
  await browser.close();
})();
