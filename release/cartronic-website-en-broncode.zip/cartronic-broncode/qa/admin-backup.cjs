// Backup export/import, discard draft and factory reset in Beheer → Publiceren.
const fs = require('fs'); const path = require('path');
const { open, go } = require('./harness.cjs');
let fails = 0;
const assert = (c, m) => { console.log(`${c ? 'ok  ' : 'FAIL'}: ${m}`); if (!c) fails++; };
(async () => {
  const { browser, page, errors } = await open({ width: 1440, height: 900 });
  const nav = async (r) => { await go(page, `#${r}`, { scroll: false }); await page.waitForTimeout(200); };
  const hero = () => page.evaluate(() => document.getElementById('hero-title').textContent);
  const setHero = async (v) => {
    await nav('/admin/teksten');
    await page.fill('[name="home.hero.line1"]', v);
    await page.click('[data-texts] [type=submit]'); await page.waitForTimeout(250);
  };
  await nav('/admin');
  await page.fill('#lg-u', 'demo'); await page.fill('#lg-p', 'cartronic-demo'); await page.click('[data-login] [type=submit]');
  await page.waitForSelector('.admin-nav');
  await setHero('Back-upversie.');
  await page.evaluate(() => { const R = window.CT.Repo; R.saveProduct({ ...R.product('prd_usb'), name: 'USB-module (back-up)' }); });
  await nav('/admin/website');
  const [dl] = await Promise.all([page.waitForEvent('download'), page.click('[data-backup]')]);
  const file = path.join(__dirname, 'pub-backup.json');
  await dl.saveAs(file);
  const data = JSON.parse(fs.readFileSync(file, 'utf8'));
  assert(data.format === 'cartronic-site' && data.content.texts['home.hero.line1'] === 'Back-upversie.' && data.shop.products.some((p) => p.name === 'USB-module (back-up)') && !data.shop.settings.orderSeq, 'backup file contains content and shop data');
  // Discard draft
  await nav('/admin/website');
  await page.click('[data-discard]'); await page.click('.modal [data-ok]'); await page.waitForTimeout(400);
  await nav('/');
  assert((await hero()).includes('Origineel.') && await page.evaluate(() => window.CT.Repo.product('prd_usb').name === 'USB-connectiviteitsmodule'), 'discarding the draft restores the published content and products');
  assert(await page.evaluate(() => !localStorage.getItem('ct.v1.siteDraft') && localStorage.getItem('ct.v1.shopDirty') === 'false'), 'no draft left');
  // Import backup
  await nav('/admin/website');
  await page.setInputFiles('[data-restore-file]', file);
  await page.waitForSelector('.modal [data-ok]'); await page.click('.modal [data-ok]'); await page.waitForTimeout(500);
  await nav('/');
  assert((await hero()).includes('Back-upversie.') && await page.evaluate(() => window.CT.Repo.product('prd_usb').name === 'USB-module (back-up)'), 'backup restored');
  // Invalid file
  const bad = path.join(__dirname, 'pub-bad.json');
  fs.writeFileSync(bad, JSON.stringify({ format: 'iets-anders' }));
  await nav('/admin/website');
  await page.setInputFiles('[data-restore-file]', bad); await page.waitForTimeout(400);
  assert(await page.evaluate(() => [...document.querySelectorAll('.toast')].some((t) => t.textContent.includes('Onbekend formaat'))), 'unknown backup format rejected');
  // Damaged content inside a valid backup: other sections still load, the damaged one falls back to defaults
  const dmg = { ...data, content: { ...data.content, retrofits: { add: [{ slug: 'Kapot!' }], edit: { 'volkswagen-golf-7-active-info-display': { models: ['bestaat-niet'] } } }, services: [{ title: 'zonder slug' }] } };
  fs.writeFileSync(bad, JSON.stringify(dmg));
  await page.setInputFiles('[data-restore-file]', bad);
  await page.waitForSelector('.modal [data-ok]'); await page.click('.modal [data-ok]'); await page.waitForTimeout(500);
  await nav('/mogelijkheden/volkswagen-golf-7-active-info-display');
  assert((await page.textContent('h1')).includes('Golf 7') && await page.evaluate(() => window.CT.catalog.RETROFITS.length === 327), 'invalid option edits are ignored, catalog intact');
  await nav('/expertise');
  assert(await page.evaluate(() => document.querySelectorAll('.svc-card').length === 6), 'invalid services fall back to the defaults');
  // Factory reset
  await nav('/admin/website');
  await page.click('[data-factory]'); await page.click('.modal [data-ok]'); await page.waitForTimeout(400);
  await nav('/');
  assert((await hero()).includes('Origineel.') && await page.evaluate(() => window.CT.Repo.product('prd_usb').name === 'USB-connectiviteitsmodule'), 'factory reset restores built-in content');
  console.log('errors:', errors);
  console.log(fails ? `${fails} FAILED` : 'ALL BACKUP CHECKS PASSED');
  await browser.close();
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
