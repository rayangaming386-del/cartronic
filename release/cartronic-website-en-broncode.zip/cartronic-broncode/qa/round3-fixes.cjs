// Regression checks for the third review round (problems found in the round-2 fixes).
// CT_URL=file://…/build.html NODE_PATH=/opt/node22/lib/node_modules node qa/round3-fixes.cjs
const fs = require('fs'); const path = require('path'); const { spawn } = require('child_process');
const { open } = require('./harness.cjs');
const BUILD = decodeURIComponent(new URL(process.env.CT_URL).pathname);
const FILE = `file://${BUILD}`;
const OUT = path.join(__dirname, 'r3f'); fs.rmSync(OUT, { recursive: true, force: true }); fs.mkdirSync(OUT, { recursive: true });
let fails = 0;
const ok = (c, m) => { console.log(`${c ? 'ok  ' : 'FAIL'}: ${m}`); if (!c) fails++; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const BROKEN = 'Deze pagina kon niet worden geladen';
const MARKER = '<script id="ctContent" type="application/json">{}</script>';
/** A copy of the build with a published bundle (and optionally another ct-base). */
function variant(name, bundle, { base } = {}) {
  let html = fs.readFileSync(BUILD, 'utf8');
  if (!html.includes(MARKER)) throw new Error('ctContent marker missing');
  html = html.replace(MARKER, () => `<script id="ctContent" type="application/json">${JSON.stringify(bundle).replace(/</g, '\\u003c')}</script>`);
  if (base) html = html.replace(/<meta name="ct-base" content="[^"]*">/, `<meta name="ct-base" content="${base}">`);
  const file = path.join(OUT, `${name}.html`);
  fs.writeFileSync(file, html);
  return { url: `file://${file}`, file, html };
}
function serve(dir, port) {
  const p = spawn(process.execPath, [path.join(__dirname, 'serve.cjs'), dir, String(port)], { stdio: 'ignore' });
  return { stop: () => p.kill(), ready: sleep(500) };
}
async function visit(page, url) { await page.goto(url); await page.waitForTimeout(220); }
async function leaveIfAsked(page) {
  if (await page.$('.modal [data-ok]') && (await page.textContent('.modal')).includes('Pagina verlaten')) { await page.click('.modal [data-ok]'); await page.waitForTimeout(450); } // the dialog fades out in 380 ms
}
async function login(page, base) {
  await visit(page, `${base}${base.startsWith('file:') ? '#/admin' : '/admin'}`);
  if (await page.$('#lg-u')) {
    await page.fill('#lg-u', 'demo'); await page.fill('#lg-p', 'cartronic-demo'); await page.click('[data-login] [type=submit]');
    await page.waitForSelector('.admin-nav');
  }
}
const appText = (page) => page.evaluate(() => document.getElementById('app').textContent);
const toasts = (page) => page.evaluate(() => [...document.querySelectorAll('.toast')].map((t) => t.textContent).join(' | '));
const draftOf = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('ct.v1.siteDraft') || 'null'));
const modals = (page) => page.evaluate(() => document.querySelectorAll('.modal.is-open').length);
const route = (page) => page.evaluate(() => document.documentElement.dataset.route);

async function run() {
  const scrollTest = async (base, hash) => {
    const u = (r) => (hash ? `${base}#${r}` : `${base}${r}`);
    const { browser, page } = await open({ width: 1280, height: 700 });
    await visit(page, u('/webshop')); await page.evaluate(() => window.scrollTo(0, 650)); await sleep(250);
    await page.reload(); await sleep(700);
    const a = await page.evaluate(() => window.scrollY);
    await visit(page, u('/mogelijkheden')); await page.evaluate(() => window.scrollTo(0, 1500)); await sleep(250);
    await page.evaluate(() => CT.Router.go('/kennis')); await sleep(400);
    await page.goBack(); await sleep(600);
    await page.evaluate(() => window.scrollTo(0, 300)); await sleep(250);
    await page.reload(); await sleep(700);
    const b = await page.evaluate(() => window.scrollY);
    // typed address after Back: Forward returns to its own place (top)
    await visit(page, u('/over')); await page.evaluate(() => CT.Router.go('/mogelijkheden')); await sleep(400);
    await page.evaluate(() => window.scrollTo(0, 1400)); await sleep(250);
    await page.goBack(); await sleep(500);
    await page.evaluate(() => { location.hash = '#/kennis'; }); await sleep(500);
    await page.goBack(); await sleep(500); await page.goForward(); await sleep(600);
    const c = await page.evaluate(() => [document.documentElement.dataset.route, window.scrollY]);
    await browser.close();
    return { a, b, c };
  };
  // ---------- R0/R1 scroll position after a reload and after a typed address
  {
    const h = await scrollTest(FILE, true);
    ok(Math.abs(h.a - 650) < 3 && Math.abs(h.b - 300) < 3 && h.c[0] === '/kennis' && h.c[1] < 3, `R0/R1 hash mode: reload keeps the position, Forward after a typed address at the top (${JSON.stringify(h)})`);
    const dir = path.join(OUT, 'site'); fs.mkdirSync(dir, { recursive: true }); fs.copyFileSync(BUILD, path.join(dir, 'index.html'));
    const srv = serve(dir, 8851); await srv.ready;
    const p = await scrollTest('http://localhost:8851', false);
    ok(Math.abs(p.a - 650) < 3 && Math.abs(p.b - 300) < 3 && p.c[0] === '/kennis' && p.c[1] < 3, `R0/R1 clean URLs: same (${JSON.stringify(p)})`);
    // R3/R13 with animations on: Back restores, a new page starts at the top
    const { browser, page } = await open({ width: 1280, height: 700, reduce: false });
    await visit(page, 'http://localhost:8851/webshop'); await sleep(500);
    await page.evaluate(() => window.scrollTo(0, 800)); await sleep(300);
    await page.evaluate(() => CT.Router.go('/zoeken', { q: 'camera' })); await sleep(900);
    const top = await page.evaluate(() => window.scrollY);
    await page.goBack(); await sleep(1200);
    const back = await page.evaluate(() => window.scrollY);
    ok(top < 3 && Math.abs(back - 800) < 3, `R3/R13 animations on: new page at the top (${top}), Back restores (${back})`);
    await browser.close(); srv.stop();
  }

  // ---------- R4/R5/R12 versions: an older page is outdated at once, can be adopted; nothing of the newer one is lost
  {
    const x = variant('ver-x', { v: 1, stamp: '2026-06-01T00:00:00.000Z' });
    const y = variant('ver-y', { v: 1, stamp: '2026-06-02T00:00:00.000Z', texts: { 'home.hero.line1': 'Versie Y.' } });
    const { browser, context, page, errors } = await open();
    await login(page, y.url);
    const pid = await page.evaluate(() => CT.Repo.products()[0].id);
    await page.evaluate((id) => { const p = CT.Repo.product(id); CT.Repo.saveProduct({ ...p, regularPrice: 31900 }); }, pid);
    const old = await context.newPage();
    await login(old, x.url);
    ok(await old.evaluate(() => CT.Content.stale && CT.SiteStatus.undecided()), 'R4 an older publication opened after a newer one is outdated at once');
    ok(await old.evaluate((id) => CT.Repo.product(id).regularPrice, pid) === 31900, 'R4 opening the older page leaves the newer webshop data alone');
    await visit(old, `${x.url}#/admin/producten/${pid}`);
    await old.fill('#pf-sku', 'SKU-OUD'); await old.click('[data-save]'); await sleep(300);
    const stored = await page.evaluate((id) => CT.Repo.product(id), pid);
    ok(stored.sku !== 'SKU-OUD' && stored.regularPrice === 31900 && /andere versie/.test(await toasts(old)), 'R5 a product save in the outdated tab is refused');
    // working copy + preview of its own publication (R12)
    await old.close();
    await page.evaluate(() => localStorage.clear());
    await login(page, FILE);
    await visit(page, `${FILE}#/admin/teksten`); await page.fill('[name="home.hero.line1"]', 'Lokaal bewerkt.'); await page.click('[data-texts] [type=submit]'); await sleep(300);
    const html = await page.evaluate(() => CT.Publisher.html(CT.Publisher.bundle('2026-06-03T00:00:00.000Z'), { ogImage: false }));
    const prev = path.join(OUT, 'preview.html'); fs.writeFileSync(prev, html);
    const pv = await context.newPage(); await visit(pv, `file://${prev}#/`); await sleep(300);
    ok(await pv.evaluate(() => CT.Content.rawText('home.hero.line1')) === 'Lokaal bewerkt.' && !(await pv.evaluate(() => CT.Content.parked)), 'R12 the preview shows the publication without questions');
    ok(await page.evaluate(() => !!localStorage.getItem('ct.v1.siteDraft')), 'R12 opening the preview keeps the working copy\'s draft');
    // adopt this (older) version explicitly
    await page.reload(); await sleep(400);
    ok(await page.evaluate(() => CT.Content.stale), 'R4 the working copy is outdated after the preview');
    await visit(page, `${FILE}#/admin`); await page.click('[data-adopt]'); await sleep(200); await page.click('.modal [data-ok]'); await sleep(900);
    ok(await page.evaluate(() => !CT.Content.stale), 'R4 "Met deze versie verder" makes this page current');
    ok(!errors.filter((e) => !/verouderde versie/.test(e)).length, `R4/R5/R12 no unexpected errors (${errors.join(' | ').slice(0, 200)})`);
    await browser.close();
  }

  // ---------- R6/R7 unchanged webshop saves do not park; a decision in one tab reaches the other
  {
    const x = variant('dirty-x', { v: 1, stamp: '2026-07-01T00:00:00.000Z' });
    const { browser, context, page } = await open();
    await login(page, x.url);
    await page.evaluate(() => { const p = CT.Repo.products()[0]; CT.Repo.saveProduct({ ...p, regularPrice: p.regularPrice + 100 }); CT.Repo.saveProduct({ ...CT.Repo.products()[0], regularPrice: CT.Repo.products()[0].regularPrice - 100 }); });
    const html = await page.evaluate(() => CT.Publisher.html(CT.Publisher.bundle('2026-07-02T00:00:00.000Z'), { ogImage: false }));
    const f = path.join(OUT, 'dirty-y.html'); fs.writeFileSync(f, html);
    const b = await context.newPage(); await login(b, `file://${f}`);
    ok(await b.evaluate(() => !CT.Repo.shopParked && !CT.SiteStatus.undecided()), 'R6 a change made and reverted does not ask about a newer version');
    // R7: a real change, then a newer publication parks it in two tabs; "keep" in one reaches the other
    // a newer publication made elsewhere, with a different price
    const zHtml = await b.evaluate(() => { const bu = CT.Publisher.bundle('2026-07-03T00:00:00.000Z'); bu.shop.products[0].regularPrice += 1000; return CT.Publisher.html(bu, { ogImage: false }); });
    const zf = path.join(OUT, 'dirty-z.html'); fs.writeFileSync(zf, zHtml); const z = { url: `file://${zf}` };
    await b.evaluate(() => { const p = CT.Repo.products()[0]; CT.Repo.saveProduct({ ...p, regularPrice: p.regularPrice + 500 }); });
    const t1 = await context.newPage(); await login(t1, z.url);
    const t2 = await context.newPage(); await login(t2, z.url);
    const parked = await t1.evaluate(() => CT.Repo.shopParked) && await t2.evaluate(() => CT.Repo.shopParked);
    await visit(t1, `${z.url}#/admin`); await t1.click('[data-parked="keep"]'); await sleep(500);
    ok(parked && await t2.evaluate(() => !CT.Repo.shopParked), 'R7 "Mijn concept behouden" in one tab also clears the question in the other');
    await browser.close();
  }

  // ---------- R8 Meer van ons werk: a stale list is not saved over another tab's change
  {
    const { browser, context, page } = await open();
    await login(page, FILE);
    const b = await context.newPage(); await login(b, FILE);
    await visit(page, `${FILE}#/admin/meer-werk`); await visit(b, `${FILE}#/admin/meer-werk`);
    await page.fill('.row-edit [data-w="title"]', 'Kaart uit tab A'); await page.click('[data-work] [type=submit]'); await sleep(300);
    await b.fill('.row-edit:last-child [data-w="title"]', 'Kaart uit tab B'); await b.click('[data-work] [type=submit]'); await sleep(300);
    const d = await draftOf(page);
    ok(d.moreWork[0].title === 'Kaart uit tab A' && /ander tabblad/.test(await toasts(b)), 'R8 the second tab is told to reload; the first tab\'s card stays');
    await browser.close();
  }

  // ---------- R2/R9 the version question with unsaved form text
  {
    const pub = variant('pub-r9', { v: 1, stamp: '2026-08-02T00:00:00.000Z' });
    const { browser, page } = await open();
    await login(page, pub.url);
    await page.evaluate(() => { localStorage.setItem('ct.v1.siteDraft', JSON.stringify({ v: 1, base: '2026-08-01T00:00:00.000Z', texts: { 'home.hero.line1': 'Oud concept.' } })); });
    await page.reload(); await sleep(400);
    await visit(page, `${pub.url}#/admin/teksten`);
    await page.fill('[name="home.hero.line2"]', 'Net getypt.');
    await page.click('[data-parked="published"]'); await sleep(300);
    await page.click('.modal [data-cancel]'); await sleep(500);
    ok(await page.evaluate(() => CT.Router.hasUnsaved()), 'R9 cancelling the discard question keeps the form protected');
    await page.click('[data-parked="keep"]'); await sleep(300);
    await page.evaluate(() => history.back()); await sleep(500);
    ok(await modals(page) === 1, `R2 Back while asking shows one question (${await modals(page)})`);
    await page.click('.modal [data-cancel]'); await sleep(500);
    ok(await page.inputValue('[name="home.hero.line2"]') === 'Net getypt.', 'R2 "Blijven" keeps the text');
    await browser.close();
  }

  // ---------- R10/R11 length messages stay up to date
  {
    const { browser, page } = await open();
    await login(page, FILE);
    const slug = await page.evaluate(() => CT.catalog.RETROFITS[0].slug);
    await visit(page, `${FILE}#/admin/opties/${slug}`);
    await page.fill('[name="short"]', 's'.repeat(1300));
    await page.click('[data-opt-form] [type=submit]'); await sleep(300);
    await page.fill('[name="short"]', 's'.repeat(1250));
    const m1 = await page.textContent('[data-err="short"]');
    await page.fill('[name="short"]', 'Kort genoeg.');
    const m2 = await page.textContent('[data-err="short"]');
    ok(/nu 1\.250/.test(m1) && !m2, `R10 the length message follows the text after a refused save (${m1.slice(0, 40)} / ${m2})`);
    await visit(page, `${FILE}#/admin/seo`); await leaveIfAsked(page);
    await page.click('[data-seo-edit]'); await sleep(300);
    await page.fill('.modal [name="description"]', 'd'.repeat(320));
    ok(/Maximaal 300/.test(await page.textContent('.modal [data-err="description"]')), 'R11 the page dialog shows the length message while typing');
    await browser.close();
  }

  // ================= Round 4: version and webshop rules =================
  {
    const dir = path.join(OUT, 'live'); fs.mkdirSync(dir, { recursive: true });
    const deploy = (html) => fs.writeFileSync(path.join(dir, 'index.html'), html);
    const base = fs.readFileSync(BUILD, 'utf8');
    const withBundle = (b) => base.replace(MARKER, () => `<script id="ctContent" type="application/json">${JSON.stringify(b).replace(/</g, '\\u003c')}</script>`);
    const srv = serve(dir, 8861); await srv.ready;
    const O = 'http://localhost:8861';
    // X: the live site
    const { browser, context, page } = await open();
    deploy(withBundle({ v: 1, stamp: '2026-09-01T00:00:00.000Z' }));
    const vis = await context.browser().newContext().then((c) => c.newPage()); // a visitor (own storage)
    await visit(vis, `${O}/webshop`);
    const xPrice = await vis.evaluate(() => CT.Repo.products()[0].regularPrice);
    // F0: the editor publishes Y with a new price, deploys it, reopens, then changes the price again
    await login(page, O);
    await page.evaluate(() => { const p = CT.Repo.products()[0]; CT.Repo.saveProduct({ ...p, regularPrice: 11100 }); });
    deploy(await page.evaluate(() => CT.Publisher.html(CT.Publisher.bundle('2026-09-02T00:00:00.000Z'), { ogImage: false })));
    await visit(page, `${O}/admin`); await sleep(300);
    await page.evaluate(() => { const p = CT.Repo.products()[0]; CT.Repo.saveProduct({ ...p, regularPrice: 22200 }); });
    await visit(page, `${O}/admin`); await sleep(300);
    const f0 = await page.evaluate(() => ({ parked: CT.Repo.shopParked, undecided: CT.SiteStatus.undecided(), price: CT.Repo.products()[0].regularPrice, ch: CT.SiteStatus.changes() }));
    ok(!f0.parked && !f0.undecided && f0.price === 22200 && f0.ch.includes('Webshop & projecten'), `F0 after deploying the own publication, a new change is an ordinary unpublished change (${JSON.stringify(f0)})`);
    // F1/F6: rollback to X reaches a returning visitor
    await visit(vis, `${O}/webshop`); // sees Y
    const yPrice = await vis.evaluate(() => CT.Repo.products()[0].regularPrice);
    deploy(withBundle({ v: 1, stamp: '2026-09-01T00:00:00.000Z' }));
    await visit(vis, `${O}/webshop`);
    const back = await vis.evaluate(() => ({ p: CT.Repo.products()[0].regularPrice, stale: CT.Content.stale }));
    ok(yPrice === 11100 && back.p === xPrice && !back.stale, `F1/F6 after a rollback a returning visitor gets the rolled-back prices (${JSON.stringify({ xPrice, yPrice, back })})`);
    // F3/F8/F2: the editor on the rolled-back X is outdated; adopting asks once and mentions unsaved text
    await visit(page, `${O}/admin/bedrijf`); await sleep(300);
    ok(await page.evaluate(() => CT.Content.stale), 'F2 the editor sees the rolled-back version as outdated');
    await page.fill('[name="kvk"]', '12345678');
    await page.click('[data-adopt]'); await sleep(300);
    const msg = await page.textContent('.modal');
    await page.click('.modal [data-cancel]'); await sleep(450);
    ok(/niet zijn opgeslagen/.test(msg) && await page.evaluate(() => CT.Content.stale && CT.Router.hasUnsaved()), 'F3/F8 the adopt question mentions unsaved text; cancelling changes nothing');
    await browser.close(); srv.stop();
  }
  {
    // F4/F5: no local edits (or edits reverted) and a newer, different publication: load it, no question
    const x = variant('f5-x', { v: 1, stamp: '2026-10-01T00:00:00.000Z' });
    const { browser, page } = await open();
    await login(page, x.url);
    const y = await page.evaluate(() => { const bu = CT.Publisher.bundle('2026-10-02T00:00:00.000Z'); bu.shop.products[0].regularPrice += 1000; return { html: CT.Publisher.html(bu, { ogImage: false }), price: bu.shop.products[0].regularPrice }; });
    await page.evaluate(() => { const p = CT.Repo.products()[0]; CT.Repo.saveProduct({ ...p }); CT.Repo.saveProduct({ ...p, regularPrice: p.regularPrice + 5 }); CT.Repo.saveProduct({ ...p }); });
    const yf = path.join(OUT, 'f5-y.html'); fs.writeFileSync(yf, y.html);
    await login(page, `file://${yf}`); await sleep(200);
    const r = await page.evaluate(() => ({ parked: CT.Repo.shopParked, price: CT.Repo.products()[0].regularPrice, ch: CT.SiteStatus.changes() }));
    ok(!r.parked && r.price === y.price && !r.ch.length, `F4/F5 unchanged or reverted saves: the newer publication is loaded without a question (${JSON.stringify(r)})`);
    await browser.close();
  }
  {
    // F7: after a reload, Back returns to the previous page's position
    const { browser, page } = await open({ width: 1280, height: 700 });
    await visit(page, `${FILE}#/mogelijkheden`); await page.evaluate(() => window.scrollTo(0, 300)); await sleep(500);
    await page.evaluate(() => CT.Router.go('/webshop')); await sleep(400);
    await page.evaluate(() => window.scrollTo(0, 700)); await sleep(500);
    await page.reload(); await sleep(700);
    const a = await page.evaluate(() => window.scrollY);
    await page.goBack(); await sleep(700);
    const b = await page.evaluate(() => window.scrollY);
    await page.goForward(); await sleep(700);
    const c = await page.evaluate(() => window.scrollY);
    ok(Math.abs(a - 700) < 3 && Math.abs(b - 300) < 3 && Math.abs(c - 700) < 3, `F7 positions after a reload: ${a}, Back ${b}, Forward ${c}`);
    await browser.close();
  }
  {
    // F9/F10: "Gepubliceerde versie gebruiken" with unsaved text: one question; Back while asking is undone
    const pub = variant('pub-f9', { v: 1, stamp: '2026-11-02T00:00:00.000Z' });
    const { browser, page } = await open();
    await login(page, pub.url);
    await page.evaluate(() => { localStorage.setItem('ct.v1.siteDraft', JSON.stringify({ v: 1, base: '2026-11-01T00:00:00.000Z', texts: { 'home.hero.line1': 'Oud concept.' } })); });
    await page.reload(); await sleep(400);
    await visit(page, `${pub.url}#/admin/teksten`);
    await page.fill('[name="home.hero.line2"]', 'Net getypt.');
    await page.click('[data-parked="published"]'); await sleep(300);
    const msg = await page.textContent('.modal');
    await page.evaluate(() => history.back()); await sleep(500);
    const n = await modals(page);
    await page.click('.modal [data-ok]'); await sleep(600);
    ok(/gaan ook verloren/.test(msg) && n === 1 && (await modals(page)) === 0 && await page.evaluate(() => !CT.Content.parked), `F9/F10 one question that mentions the unsaved text; Back while asking is undone (modals ${n})`);
    await browser.close();
  }

  // ================= Round 5 =================
  {
    // G1: a visitor tab that logs in after another tab opened a newer version becomes outdated
    const x = variant('g1-x', { v: 1, stamp: '2026-12-01T00:00:00.000Z' });
    const y = variant('g1-y', { v: 1, stamp: '2026-12-02T00:00:00.000Z', texts: { 'home.hero.line1': 'Tekst uit Y.' } });
    const { browser, context, page } = await open();
    await visit(page, `${x.url}#/`);
    const b = await context.newPage(); await visit(b, `${y.url}#/webshop`);
    await login(page, x.url); await sleep(300);
    ok(await page.evaluate(() => CT.Content.stale && CT.SiteStatus.undecided()) && /verouderd/.test(await page.textContent('[data-site-notice]')), 'G1 logging in on an older version after a newer one was opened: outdated');
    // G3: on a public page the outdated editor gets a short note
    await page.reload(); await sleep(300);
    await visit(page, `${x.url}#/webshop`); await page.reload(); await sleep(400);
    ok(/andere versie van de website/.test(await toasts(page)), 'G3 an outdated editor on a public page gets a note pointing to Beheer');
    await browser.close();
  }
  {
    // G2: working copy → preview of its publication → adopt the working copy: no version question, edits kept
    const { browser, context, page } = await open();
    await login(page, FILE);
    await visit(page, `${FILE}#/admin/teksten`); await page.fill('[name="home.hero.line1"]', 'Lokaal bewerkt.'); await page.click('[data-texts] [type=submit]'); await sleep(300);
    const html = await page.evaluate(() => CT.Publisher.html(CT.Publisher.bundle('2026-12-05T00:00:00.000Z'), { ogImage: false }));
    const prev = path.join(OUT, 'g2-preview.html'); fs.writeFileSync(prev, html);
    const pv = await context.newPage(); await visit(pv, `file://${prev}#/`); await pv.close();
    await page.reload(); await sleep(400);
    await visit(page, `${FILE}#/admin`); await page.click('[data-adopt]'); await sleep(200); await page.click('.modal [data-ok]'); await sleep(900);
    const r = await page.evaluate(() => ({ stale: CT.Content.stale, parked: CT.Content.parked, line1: CT.Content.rawText('home.hero.line1'), undecided: CT.SiteStatus.undecided() }));
    ok(!r.stale && !r.parked && !r.undecided && r.line1 === 'Lokaal bewerkt.', `G2 the working copy continues with its edits, no question (${JSON.stringify(r)})`);
    await browser.close();
  }

  // ================= Round 6 =================
  {
    // H1: a Teksten save without changes, then a colleague's newer publication: no question, colleague's text stays
    const x = variant('h1-x', { v: 1, stamp: '2027-01-01T00:00:00.000Z' });
    const y = variant('h1-y', { v: 1, stamp: '2027-01-02T00:00:00.000Z', texts: { 'home.hero.line1': 'Collega Y.' } });
    const { browser, page } = await open();
    await login(page, x.url);
    await visit(page, `${x.url}#/admin/teksten`); await page.click('[data-texts] [type=submit]'); await sleep(300);
    await login(page, y.url); await sleep(300);
    const r = await page.evaluate(() => ({ parked: CT.Content.parked, undecided: CT.SiteStatus.undecided(), l1: CT.Content.rawText('home.hero.line1') }));
    ok(!r.parked && !r.undecided && r.l1 === 'Collega Y.', `H1 an unchanged save is no concept against a newer publication (${JSON.stringify(r)})`);
    // H0: rollback with a draft that has no edits since its base: adopting the older version asks nothing
    const z = variant('h0-z', { v: 1, stamp: '2027-01-03T00:00:00.000Z', texts: { 'home.hero.line1': 'Bewerking Z.' } });
    await login(page, z.url);
    await visit(page, `${z.url}#/admin/teksten`); await page.fill('[name="home.hero.line2"]', 'Extra Z.'); await page.click('[data-texts] [type=submit]'); await sleep(300);
    await page.fill('[name="home.hero.line2"]', 'Tot in detail.'); await page.click('[data-texts] [type=submit]'); await sleep(300); // changed back
    await login(page, y.url); await sleep(300); // rollback to Y: outdated
    await visit(page, `${y.url}#/admin`); await page.click('[data-adopt]'); await sleep(200); await page.click('.modal [data-ok]'); await sleep(900);
    const r0 = await page.evaluate(() => ({ parked: CT.Content.parked, stale: CT.Content.stale, l1: CT.Content.rawText('home.hero.line1'), ch: CT.SiteStatus.changes() }));
    ok(!r0.parked && !r0.stale && r0.l1 === 'Collega Y.' && !r0.ch.length, `H0 after a rollback without own edits, the rolled-back version simply applies (${JSON.stringify(r0)})`);
    await browser.close();
  }
  {
    // H2: a webshop save without changes is no unpublished change
    const { browser, page } = await open();
    await login(page, FILE);
    const pid = await page.evaluate(() => CT.Repo.products()[0].id);
    await visit(page, `${FILE}#/admin/producten/${pid}`); await page.click('[data-save]'); await sleep(300);
    ok(await page.evaluate(() => localStorage.getItem('ct.v1.shopDirty') !== 'true' && !CT.SiteStatus.changes().length), 'H2 an unchanged product save leaves nothing to publish');
    await browser.close();
  }
  {
    // H4: clean URLs: quick Back right after scrolling, reload, Forward returns to that position
    const dir = path.join(OUT, 'h4'); fs.mkdirSync(dir, { recursive: true }); fs.copyFileSync(BUILD, path.join(dir, 'index.html'));
    const srv = serve(dir, 8871); await srv.ready;
    const { browser, page } = await open({ width: 1280, height: 700 });
    await visit(page, 'http://localhost:8871/over');
    await page.evaluate(() => CT.Router.go('/mogelijkheden')); await sleep(400);
    await page.evaluate(() => window.scrollTo(0, 1200)); await sleep(60);
    await page.goBack(); await sleep(400);
    await page.reload(); await sleep(600);
    await page.goForward(); await sleep(800);
    const y = await page.evaluate(() => window.scrollY);
    ok(Math.abs(y - 1200) < 3, `H4 Forward after a quick Back and a reload returns to the position (${y})`);
    await browser.close(); srv.stop();
  }

  // ================= Round 7 =================
  {
    // I1: a stock correction in Beheer is kept (asked about) when a newer publication with the same webshop data arrives
    const x = variant('i1-x', { v: 1, stamp: '2027-02-01T00:00:00.000Z' });
    const { browser, page } = await open();
    await login(page, x.url);
    const pid = await page.evaluate(() => CT.Repo.products()[0].id);
    await page.evaluate((id) => { const p = CT.Repo.product(id); CT.Repo.saveProduct({ ...p, stock: (p.stock || 0) + 7 }); }, pid);
    const want = await page.evaluate((id) => CT.Repo.product(id).stock, pid);
    const yHtml = await page.evaluate((id) => { const bu = CT.Publisher.bundle('2027-02-02T00:00:00.000Z'); const pp = bu.shop.products.find((q) => q.id === id); pp.stock -= 7; return CT.Publisher.html(bu, { ogImage: false }); }, pid);
    const yf = path.join(OUT, 'i1-y.html'); fs.writeFileSync(yf, yHtml);
    await login(page, `file://${yf}`); await sleep(200);
    const r = await page.evaluate((id) => ({ parked: CT.Repo.shopParked, stock: CT.Repo.product(id).stock }), pid);
    ok(r.parked && r.stock === want, `I1 a stock correction made in Beheer is not silently replaced (${JSON.stringify(r)})`);
    // I3: rollback wording when only webshop data is parked
    ok(/oudere versie van de website teruggezet|nieuwere gepubliceerde versie/.test(await page.evaluate(() => CT.SiteStatus.parkedNotice())), 'I3 the notice shows');
    await browser.close();
  }
  {
    // I2: a visitor order (stock change), then a save without changes in Beheer: nothing to publish
    const x = variant('i2-x', { v: 1, stamp: '2027-03-01T00:00:00.000Z' });
    const { browser, page } = await open();
    await visit(page, `${x.url}#/`);
    const pid = await page.evaluate(() => CT.Repo.products().find((p) => p.trackStock && p.stock > 1).id);
    await page.evaluate((id) => { const p = CT.Repo.product(id); CT.Repo.saveProduct({ ...p, stock: p.stock - 1 }); }, pid); // as checkout does (public page)
    await login(page, x.url);
    await visit(page, `${x.url}#/admin/producten/${pid}`); await page.click('[data-save]'); await sleep(300);
    ok(await page.evaluate(() => !CT.SiteStatus.changes().length), 'I2 an order and then an unchanged save leave nothing to publish');
    await browser.close();
  }
  {
    // I3b: rollback with only unpublished webshop edits: the notice says an older version was put back
    const base = variant('i3-base', { v: 1, stamp: '2027-04-01T00:00:00.000Z' });
    const { browser, page } = await open();
    await login(page, base.url);
    const mk = (stamp) => page.evaluate((st) => CT.Publisher.html(CT.Publisher.bundle(st), { ogImage: false }), stamp);
    const yf = path.join(OUT, 'i3-y.html'); fs.writeFileSync(yf, await mk('2027-04-02T00:00:00.000Z'));
    const zf = path.join(OUT, 'i3-z.html'); fs.writeFileSync(zf, await mk('2027-04-03T00:00:00.000Z'));
    await login(page, `file://${zf}`);
    await page.evaluate(() => { const p = CT.Repo.products()[0]; CT.Repo.saveProduct({ ...p, regularPrice: p.regularPrice + 300 }); });
    await login(page, `file://${yf}`); await sleep(200);
    await visit(page, `file://${yf}#/admin`); await page.click('[data-adopt]'); await sleep(200); await page.click('.modal [data-ok]'); await sleep(900);
    const t = await page.evaluate(() => ({ parked: CT.Repo.shopParked, notice: (document.querySelector('[data-site-notice]') || {}).textContent || '' }));
    ok(t.parked && /oudere versie van de website teruggezet/.test(t.notice), `I3 rollback wording for parked webshop data (${t.parked} ${t.notice.slice(0, 60)})`);
    await browser.close();
  }

  console.log(fails ? `\n${fails} ROUND-3 CHECK(S) FAILED` : '\nALL ROUND-3 CHECKS PASSED');
  process.exit(fails ? 1 : 0);
}
run().catch((e) => { console.error(e); process.exit(1); });
