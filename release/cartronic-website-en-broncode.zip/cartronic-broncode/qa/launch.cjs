// Launch update: renamed pages and redirects, menu, model links, plate-first finder, Storingen, Beveiliging,
// Video's, Merken & modellen, Meer van ons werk, login (hash, lock-out, password change), publish round trip.
// The Beheer password is read from the environment: CT_ADMIN_PASSWORD=… node qa/launch.cjs
const fs = require('fs'); const path = require('path'); const { execSync, spawn } = require('child_process');
const { open, go, login, adminPassword, ADMIN_USER, URL_BASE, S } = require('./harness.cjs');
let fails = 0;
const assert = (c, m) => { console.log(`${c ? 'ok  ' : 'FAIL'}: ${m}`); if (!c) fails++; };
const PASS = adminPassword();
const PUB = path.join(__dirname, 'pub-launch'); const SITE = path.join(PUB, 'site');
const PORT = 8813; const ORIGIN = `http://localhost:${PORT}`;
const nav = async (page, r) => { await go(page, `#${r}`, { scroll: false }); await page.waitForTimeout(150); };
const hash = (page) => page.evaluate(() => location.hash);
/** A small PNG (as a file for an upload field), drawn in the page. */
async function png(page, color = '#b51625', w = 900, h = 600) {
  const b64 = await page.evaluate(([c, ww, hh]) => { const cv = document.createElement('canvas'); cv.width = ww; cv.height = hh; const g = cv.getContext('2d'); g.fillStyle = c; g.fillRect(0, 0, ww, hh); g.fillStyle = '#fff'; g.fillRect(20, 20, 200, 120); return cv.toDataURL('image/png').split(',')[1]; }, [color, w, h]);
  return { name: 'foto.png', mimeType: 'image/png', buffer: Buffer.from(b64, 'base64') };
}
const submit = async (page, form) => { await page.click(`${form} [type=submit]`); await page.waitForTimeout(400); };
const confirmOk = async (page) => { await page.waitForSelector('.modal.is-open [data-ok]'); await page.click('.modal.is-open [data-ok]'); await page.waitForTimeout(450); };

(async () => {
  // ================= Public site (file://) =================
  const v = await open({ width: 1440, height: 900 });
  const { page } = v;
  const external = [];
  page.on('request', (r) => { const u = r.url(); if (/youtube|ytimg|facebook\.com|tiktok|instagram/.test(u)) external.push(u); });

  // Redirects of renamed pages (query kept) and archived option slugs
  for (const [from, to] of [['/mogelijkheden', '#/producten'], ['/mogelijkheden?merk=audi&model=a3-8v', '#/producten?merk=audi&model=a3-8v'], ['/projecten', '#/portfolio'],
    ['/projecten/precisie-in-kalibratie', '#/portfolio/precisie-in-kalibratie'], ['/expertise', '#/diensten'], ['/mogelijkheden/aanbieding-1-volkswagen-golf-7-active-info-display', '#/producten/volkswagen-golf-7-active-info-display']]) {
    await nav(page, from);
    assert(await hash(page) === to, `redirect ${from} → ${to} (got ${await hash(page)})`);
  }
  await nav(page, '/producten?merk=audi&model=a3-8v');
  assert(await page.evaluate(() => document.querySelector('link[rel=canonical]').href) === 'https://www.cartronic.nl/producten?merk=audi&model=a3-8v', 'canonical of a model selection uses /producten');

  // Header: new names, Producten not in the bar, webshop off by default, submenu under Diensten
  await nav(page, '/');
  const navText = await page.$$eval('.main-nav > ul > li > a', (a) => a.map((x) => x.textContent.trim()));
  assert(JSON.stringify(navText) === JSON.stringify(['Merken', 'Diensten', 'Storingen', 'Portfolio', 'Video’s', 'Over ons', 'Contact']), `main menu: ${navText.join(', ')}`);
  assert(!(await page.$('#cartBtn')), 'webshop (cart) is off by default');
  await page.click('.sub-toggle');
  assert(await page.getAttribute('.sub-toggle', 'aria-expanded') === 'true' && await page.isVisible('#sub-diensten a[href$="/beveiliging"]'), 'submenu opens with the arrow button');
  await page.keyboard.press('Escape');
  assert(await page.getAttribute('.sub-toggle', 'aria-expanded') === 'false', 'Escape closes the submenu');
  const footer = await page.textContent('#siteFooter');
  assert(!/Beheer|prototype|demo/i.test(footer) && footer.includes('Storingen & oplossingen') && footer.includes('Portfolio') && footer.includes('Over ons'), 'footer: new pages, no Beheer link or prototype text');
  assert(!(await page.$('#siteFooter a[href*="admin"]')), 'no link to /admin in the footer');

  // Home: plate first, no demo plates, mirror icon, identical wordmarks, security teaser above "Uit de werkplaats"
  assert(await page.isVisible('[data-finder] [data-panel="plate"] input[name="plate"]') && !(await page.isVisible('[data-finder] [data-panel="manual"]')), 'home finder shows the plate field first');
  assert(!(await page.$('[data-demo-toggle], [data-demo-list]')), 'no demo plates under the plate field');
  await page.click('[data-finder] [data-panel="plate"] [data-tab="manual"]');
  assert(await page.isVisible('[data-finder] select[name="brand"]'), 'manual selection is the second step');
  await page.click('[data-finder] [data-panel="manual"] [data-tab="plate"]');
  await page.fill('[data-finder] input[name="plate"]', 'XX'); await page.click('[data-plate-submit]');
  assert((await page.textContent('[data-plate-err]')).includes('geen geldig'), 'plate validation message');
  await page.fill('[data-finder] input[name="plate"]', '12-ABC-3'); await page.click('[data-plate-submit]');
  await page.waitForSelector('[data-state]', { timeout: 5000 });
  assert((await page.textContent('[data-result]')).includes('Golf 8'), 'RDW lookup from the home finder works');
  await page.evaluate(() => window.CT.VehicleStore.clear());
  await nav(page, '/');
  const comfortIcon = await page.$eval('.cat-grid .cat-card:nth-child(5) .cc-icon', (e) => e.innerHTML);
  assert(comfortIcon.includes('M3.5 9.6') && (await page.$eval('.cat-grid .cat-card:nth-child(5) h3', (e) => e.textContent)) === 'Comfort', 'comfort uses the exterior-mirror icon');
  const marks = await page.$$eval('.brand-band .wordmark', (els) => els.map((e) => { const c = getComputedStyle(e); return `${c.letterSpacing}|${c.fontWeight}|${c.fontSize}`; }));
  assert(marks.length === 4 && new Set(marks).size === 1, `identical wordmarks on home (${marks[0]})`);
  const order = await page.evaluate(() => { const a = document.getElementById('sec-teaser-title'); const b = document.getElementById('projects-title'); return !!a && !!b && !!(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING); });
  assert(order, 'security teaser sits directly before “Uit de werkplaats”');

  // Merken: every model is its own link, brand separately, no stretched link over them
  await nav(page, '/merken');
  const cardMarks = await page.$$eval('.brand-card .wordmark', (els) => els.map((e) => getComputedStyle(e).letterSpacing));
  assert(new Set(cardMarks).size === 1, 'identical wordmarks on /merken');
  assert(!(await page.$('.brand-card .stretch')), 'no stretched card link over the models');
  const a3 = await page.$('.brand-card .bc-models a[href*="model=a3-8v"]');
  assert(!!a3 && (await a3.getAttribute('href')).includes('merk=audi'), 'model link carries merk and model');
  await a3.focus(); await page.keyboard.press('Enter'); await page.waitForTimeout(300);
  assert(await hash(page) === '#/producten?merk=audi&model=a3-8v' && (await page.inputValue('#f-model')) === 'a3-8v', 'keyboard: model link opens the filtered products');
  await nav(page, '/merken');
  await page.click('.brand-card .bc-brand >> nth=1'); await page.waitForTimeout(250);
  assert(await hash(page) === '#/merken/audi', 'the brand itself is still a link');

  // Storingen
  await nav(page, '/storingen');
  assert((await page.$$('.storing-card')).length === 4, 'four example storingen');
  await page.click('[data-sf] .chip[data-v="seat"]'); await page.waitForTimeout(200);
  assert((await page.$$('.storing-card:not([hidden])')).length === 4 && (await hash(page)) === '#/storingen?merk=seat', 'brand filter (examples apply to all brands)');
  await nav(page, '/storingen/acc-of-lane-assist-werkt-niet-na-voorruit');
  const wa = await page.getAttribute('.storing-ask .btn--whatsapp', 'href');
  assert(decodeURIComponent(wa).includes('Storing: Adaptieve cruisecontrol of Lane Assist'), 'WhatsApp message contains the storing');
  assert((await page.title()).startsWith('Adaptieve cruisecontrol of Lane Assist') && (await page.getAttribute('meta[name=description]', 'content')).length > 60, 'storing has its own title and description');
  await page.click('.storing-ask a[href*="contact"]'); await page.waitForTimeout(300);
  assert((await page.inputValue('#c-q')).startsWith('Storing: Adaptieve') && (await page.isChecked('input[name="topic"][value="storing"]')), 'contact form is pre-filled with the storing');
  await page.evaluate(() => sessionStorage.clear());

  // Beveiliging
  await nav(page, '/beveiliging');
  assert((await page.$$('.class-card')).length === 5 && (await page.textContent('.class-grid')).includes('Voertuigvolgsysteem'), 'five security classes');
  assert(!!(await page.$('a[href*="/kennis/origineel-alarm-met-scm-certificaat"]')) && !!(await page.$('a[href*="wa.me"]')) && !!(await page.$('a.btn[href$="/contact"]')), 'SCM article link, WhatsApp and contact');
  assert(!/€\s?\d/.test(await page.textContent('#app')), 'no prices on the security page');

  // Video's: nothing loaded before a click
  await nav(page, '/videos');
  assert((await page.$$('.video-card')).length === 2 && !(await page.$('.video-card iframe')), 'videos listed, no embed before a click');
  assert(external.length === 0, `no request to a video platform before a click (${external.length})`);
  await page.click('.video-card [data-play]'); await page.waitForTimeout(200);
  assert((await page.getAttribute('.video-card iframe', 'src')).startsWith('https://www.facebook.com/plugins/video.php?href='), 'click loads the Facebook player');

  // Search knows the new types
  await nav(page, '/zoeken?q=voorruit');
  assert((await page.textContent('#app')).includes('Storing'), 'search finds storingen');

  // Privacy page explains the video embeds
  await nav(page, '/privacy');
  assert((await page.textContent('#app')).includes('youtube-nocookie.com'), 'privacy page explains video loading');
  await v.browser.close();

  // ================= Login =================
  const l = await open({ width: 1280, height: 900 });
  await nav(l.page, '/admin');
  const lt = await l.page.textContent('#app');
  assert(!/demo|cartronic-demo|wachtwoord \S+ ·/i.test(lt) && !(await l.page.$('[data-fill]')), 'login screen: no demo notice, credentials or fill button');
  for (let i = 0; i < 5; i++) { await l.page.fill('#lg-u', ADMIN_USER); await l.page.fill('#lg-p', `fout-${i}`); await l.page.click('[data-login] [type=submit]'); await l.page.waitForTimeout(i === 4 ? 1500 : 1200); }
  assert((await l.page.textContent('[data-login-err]')).includes('Te veel mislukte pogingen') && await l.page.isDisabled('[data-login] [type=submit]'), 'lock-out after five failed attempts');
  await l.page.evaluate(() => localStorage.removeItem('ct.v1.loginGuard'));
  await nav(l.page, '/'); await nav(l.page, '/admin');
  await l.page.fill('#lg-u', 'iemand'); await l.page.fill('#lg-p', PASS); await l.page.click('[data-login] [type=submit]'); await l.page.waitForTimeout(1500);
  assert((await l.page.textContent('[data-login-err]')).includes('Onjuiste'), 'right password with a wrong user name is refused');
  await l.page.evaluate(() => localStorage.removeItem('ct.v1.loginGuard'));
  await login(l.page);
  assert(await l.page.isVisible('.admin-nav'), 'login with the new credentials');
  // Idle logout: an old session is no longer accepted
  await l.page.evaluate(() => { const k = 'ct.v1.adminSession'; const s = JSON.parse(sessionStorage.getItem(k)); s.last = Date.now() - 31 * 60 * 1000; sessionStorage.setItem(k, JSON.stringify(s)); });
  await nav(l.page, '/admin/website');
  assert(!!(await l.page.$('#lg-u')), 'session ends after 30 minutes without activity');
  await l.browser.close();

  // ================= Beheer: new content =================
  fs.rmSync(PUB, { recursive: true, force: true }); fs.mkdirSync(SITE, { recursive: true });
  const ed = await open({ width: 1440, height: 900 });
  const p = ed.page;
  await nav(p, '/admin'); await login(p);
  const navText2 = await p.$$eval('.admin-nav a', (a) => a.map((x) => x.textContent.trim()));
  assert(navText2.includes('Producten (catalogus)') && navText2.includes('Webshopproducten') && navText2.includes('Portfolio') && navText2.includes('Storingen') && navText2.includes('Video’s') && navText2.includes('Merken & modellen'), 'Beheer menu names');
  assert(!/Demo-omgeving|Demo · lokaal/.test(await p.textContent('.admin')), 'no demo labels in Beheer');

  // Storing: create with photo, edit (replace photo), order, hide, delete
  await nav(p, '/admin/storingen/nieuw');
  await p.fill('[name="title"]', 'Testcamera geeft zwart beeld');
  await p.fill('[name="symptoms"]', 'Zwart beeld\nGeen hulplijnen');
  await p.fill('[name="cause"]', 'Testoorzaak.'); await p.fill('[name="solution"]', 'Testoplossing.');
  await p.selectOption('[name="brand"]', 'audi');
  await p.check('input[name="models"][value="a3-8v"]', { force: true });
  await p.setInputFiles('[data-photos="photos"] [data-ph-add]', [await png(p, '#123456'), await png(p, '#654321')]);
  await p.waitForSelector('[data-photos="photos"] .photo-item:nth-child(2)');
  const firstSrc = await p.inputValue('[data-photos="photos"] .photo-item [data-ph-src]');
  assert(/^data:image\/(webp|jpeg);base64,/.test(firstSrc), 'upload is compressed to WebP/JPEG');
  assert((await p.inputValue('[data-photos="photos"] [data-ph-alt]')) === 'Storing', 'alt text gets a default');
  await p.fill('[data-photos="photos"] .photo-item:nth-child(2) [data-ph-alt]', '');
  await submit(p, '[data-stor-form]');
  assert((await p.textContent('[data-err="photos"]')).includes('beschrijving'), 'alt text is required');
  await p.fill('[data-photos="photos"] .photo-item:nth-child(2) [data-ph-alt]', 'Zwart scherm in de Audi A3');
  await p.click('[data-photos="photos"] .photo-item:nth-child(2) [data-ph-up]');
  await submit(p, '[data-stor-form]');
  assert(await hash(p) === '#/admin/storingen' && (await p.textContent('.admin-table')).includes('Testcamera geeft zwart beeld'), 'storing added');
  await nav(p, '/storingen/testcamera-geeft-zwart-beeld');
  assert((await p.getAttribute('.gallery .g-slide img', 'alt')) === 'Zwart scherm in de Audi A3' && (await p.textContent('#app')).includes('Audi A3 8V'), 'storing page: photos in the chosen order with alt text, model');
  await nav(p, '/admin/storingen/testcamera-geeft-zwart-beeld');
  const before = await p.inputValue('[data-photos="photos"] .photo-item [data-ph-src]');
  await p.setInputFiles('[data-photos="photos"] .photo-item:nth-child(1) [data-ph-replace]', await png(p, '#00aa00'));
  await p.waitForTimeout(400);
  assert((await p.inputValue('[data-photos="photos"] .photo-item [data-ph-src]')) !== before, 'photo replaced');
  await p.click('[data-photos="photos"] .photo-item:nth-child(2) [data-ph-del]');
  await p.uncheck('[name="visible"]', { force: true });
  await submit(p, '[data-stor-form]');
  await nav(p, '/storingen');
  assert(!(await p.textContent('#app')).includes('Testcamera'), 'hidden storing is not on the website');
  await nav(p, '/storingen/testcamera-geeft-zwart-beeld');
  assert((await p.textContent('h1')).includes('niet (meer) online'), 'hidden storing page is not found');
  await nav(p, '/admin/storingen');
  const rows = await p.$$eval('.admin-table tr .p-name', (a) => a.map((x) => x.textContent));
  await p.click(`[data-move="${rows.length - 1}"][data-dir="-1"]`); await p.waitForTimeout(400);
  const rows2 = await p.$$eval('.admin-table tr .p-name', (a) => a.map((x) => x.textContent));
  assert(rows2[rows.length - 2] === 'Testcamera geeft zwart beeld', 'storing moved up');
  await p.click('[data-texts-panel] [name="t:stor.title"]'); await p.fill('[data-texts-panel] [name="t:stor.title"]', 'Storingen opgelost.');
  await p.click('[data-texts-panel] [type=submit]'); await p.waitForTimeout(300);
  await nav(p, '/storingen');
  assert((await p.textContent('h1')).includes('Storingen opgelost.'), 'storingen heading edited in Beheer');

  // Meer van ons werk: heading, intro, card with photo
  await nav(p, '/admin/meer-werk');
  await p.fill('[name="t:projects.more.title"]', 'Nog meer werk.');
  await p.fill('[name="t:projects.more.intro"]', 'Introductie van het blok.');
  await p.click('[data-w-add]');
  const last = '[data-w-rows] .row-edit:last-child';
  await p.fill(`${last} [data-w="title"]`, 'Testkaart met foto');
  await p.fill(`${last} [data-w="links"]`, 'Bekijk het portfolio | /portfolio');
  await p.setInputFiles(`${last} [data-ph-add]`, await png(p));
  await p.waitForSelector(`${last} .photo-item`);
  await p.fill(`${last} [data-ph-alt]`, 'Testfoto van een auto');
  await p.click('[data-w-rows] .row-edit:first-child [data-row-del]');
  await submit(p, '[data-work]');
  await nav(p, '/portfolio');
  const more = await p.textContent('#more-title');
  assert(more.includes('Nog meer werk.') && (await p.textContent('.section-intro .lead')).includes('Introductie') && (await p.getAttribute('.more-card--photo img', 'alt')) === 'Testfoto van een auto', 'Meer van ons werk: heading, intro and photo card');
  assert(!(await p.textContent('.more-grid')).includes('Škoda Octavia IV') && (await p.getAttribute('.more-card--photo .more-links a', 'href')).endsWith('/portfolio'), 'card deleted; internal link works');

  // Beveiliging
  await nav(p, '/admin/beveiliging');
  await p.fill('[data-c-rows] .row-edit:nth-child(2) [data-c="text"]', 'Aangepaste uitleg klasse 2.');
  await p.uncheck('[data-c-rows] .row-edit:nth-child(5) [data-c="visible"]', { force: true });
  await p.click('[data-m-add]'); await p.fill('[data-m-rows] .row-edit:last-child [data-m="name"]', 'Testkeurmerk'); await p.fill('[data-m-rows] .row-edit:last-child [data-m="text"]', 'Uitleg.');
  await p.setInputFiles('[data-photos="photos"] [data-ph-add]', await png(p, '#333333'));
  await p.waitForSelector('[data-photos="photos"] .photo-item');
  await p.fill('[name="t:sec.btn"]', 'Vraag ons advies');
  await submit(p, '[data-sec]');
  await nav(p, '/beveiliging');
  const sec = await p.textContent('#app');
  assert(sec.includes('Aangepaste uitleg klasse 2.') && (await p.$$('.class-card')).length === 4 && sec.includes('Testkeurmerk') && sec.includes('Vraag ons advies') && !!(await p.$('.gallery img[alt="Beveiliging ingebouwd door CarTronic"]')), 'Beveiliging edited: class text, hidden class, mark, photo, button');
  await nav(p, '/admin/weergave');
  await p.uncheck('[name="s:home.security"]', { force: true }); await submit(p, '[data-display]');
  await nav(p, '/');
  assert(!(await p.$('#sec-teaser-title')), 'security teaser can be switched off in Weergave');
  await nav(p, '/admin/weergave');
  assert(!(await p.$('[name="footerAdmin"]')), 'no Weergave switch for a Beheer link');
  await p.check('[name="s:home.security"]', { force: true }); await submit(p, '[data-display]');

  // Video's
  await nav(p, '/admin/videos/nieuw');
  await p.fill('[name="url"]', 'https://vm.tiktok.com/abc/'); await p.fill('[name="title"]', 'Test');
  await submit(p, '[data-vid-form]');
  assert((await p.textContent('[data-err="url"]')).includes('verkorte link'), 'short link gives a clear error');
  await p.fill('[name="url"]', 'https://example.com/video'); await submit(p, '[data-vid-form]');
  assert((await p.textContent('[data-err="url"]')).includes('niet herkend'), 'unknown link gives an error');
  await p.fill('[name="url"]', 'https://www.youtube.com/shorts/abcdefghijk');
  assert((await p.textContent('[data-vid-platform]')).includes('YouTube'), 'platform detected from the link');
  await p.fill('[name="title"]', 'Testvideo YouTube'); await p.check('[name="featured"]', { force: true });
  await submit(p, '[data-vid-form]');
  assert(await hash(p) === '#/admin/videos', 'video saved');
  await p.check('[data-follow]', { force: true }); await p.waitForTimeout(300);
  await nav(p, '/videos');
  const titles = await p.$$eval('.video-card h3', (e) => e.map((x) => x.textContent));
  const card = '.video-card[data-platform="youtube"]';
  assert(titles.indexOf('Testvideo YouTube') < titles.indexOf('Zo werkt de 360-gradencamera') && !!(await p.$(`${card}.video-card--featured .video-frame--tall`)) && !!(await p.$('.follow-row a[href*="facebook"]')), 'featured Short before other videos, tall frame, follow row');
  await p.click(`${card} [data-play]`); await p.waitForTimeout(150);
  assert((await p.getAttribute(`${card} iframe`, 'src')).startsWith('https://www.youtube-nocookie.com/embed/abcdefghijk'), 'YouTube plays via youtube-nocookie after the click');
  await p.click('[data-vf] .chip[data-v="facebook"]'); await p.waitForTimeout(150);
  assert((await p.$$('.video-card:not([hidden])')).length === 2, 'platform filter');

  // Merken & modellen
  await nav(p, '/admin/modellen/nieuw');
  await p.selectOption('[name="brand"]', 'skoda');
  await p.fill('[name="name"]', 'Elroq'); await p.fill('[name="from"]', '2024'); await p.fill('[name="match"]', 'ELROQ'); await p.fill('[name="types"]', 'NY');
  await submit(p, '[data-model-form]');
  assert(await hash(p) === '#/admin/modellen' && (await p.textContent('.admin-content')).includes('Elroq'), 'model added');
  const m = await p.evaluate(() => window.CT.Content.working().models.find((x) => x.id === 'elroq'));
  assert(m && m.brand === 'skoda' && m.from === 2024 && m.to === null && m.match[0] === 'ELROQ' && m.types[0] === 'NY', 'model saved with years, RDW words and type code');
  await nav(p, '/merken');
  assert(!!(await p.$('.bc-models a[href*="model=elroq"]')), 'new model on /merken');
  await nav(p, '/merken/skoda');
  assert((await p.textContent('#app')).includes('Elroq'), 'new model on the brand page');
  await nav(p, '/producten?merk=skoda');
  assert(!!(await p.$('#f-model option[value="elroq"]')), 'new model in the filters');
  await nav(p, '/');
  await p.click('[data-finder] [data-tab="manual"]'); await p.selectOption('[data-finder] select[name="brand"]', 'skoda');
  assert(!!(await p.$('[data-finder] select[name="model"] option[value="elroq"]')), 'new model in the vehicle finder');
  assert(await p.evaluate(() => window.CT.Search.query('elroq', { limit: 5 }).some((r) => r.type === 'MODEL')), 'new model in search');
  assert(await p.evaluate(() => window.CT.VehicleMatcher.match({ merk: 'SKODA', handelsbenaming: 'ELROQ', datum_eerste_toelating: '20250101', voertuigsoort: 'Personenauto', type: 'NY' }).modelId === 'elroq'), 'RDW match words recognise the new model');
  // Delete a model that is in use: warning, hide instead
  await nav(p, '/admin/modellen');
  await p.click('[data-mdel="golf-8"]');
  await p.waitForSelector('.modal.is-open [data-md="hide"]');
  assert((await p.textContent('.modal.is-open')).includes('in de catalogus'), 'deleting a linked model warns about the products');
  await p.click('.modal.is-open [data-md="hide"]'); await p.waitForTimeout(450);
  await nav(p, '/merken');
  assert(!(await p.$('.bc-models a[href*="model=golf-8"]')), 'hidden model is gone from /merken');
  await nav(p, '/producten/volkswagen-golf-8-inklapbare-spiegels');
  assert((await p.textContent('h1')).includes('Golf 8'), 'products of a hidden model still work (no broken pages)');
  assert(await p.evaluate(() => !window.CT.Search.query('golf 8', { limit: 20 }).some((r) => r.type === 'MODEL' && r.id === 'golf-8')), 'hidden model not in search');
  // Unhide again for the rest of the tests
  await nav(p, '/admin/modellen'); await p.click('[data-mhide="golf-8"]'); await p.waitForTimeout(300);
  // Delete an unused model
  await p.click('[data-mdel="elroq"]'); await confirmOk(p);
  assert(!(await p.textContent('.admin-content')).includes('Elroq'), 'unused model deleted');

  // ================= Review fixes =================
  // Deleting a model that webshop products use: they keep working and can still be saved
  await p.evaluate(() => { const R = window.CT.Repo; const x = R.products()[0]; R.saveProduct({ ...x, compatibility: { ...x.compatibility, models: ['sharan'] }, model: 'sharan' }); });
  await nav(p, '/admin/modellen'); await p.click('[data-mdel="sharan"]');
  await p.waitForSelector('.modal.is-open [data-md="delete"]'); await p.click('.modal.is-open [data-md="delete"]'); await p.waitForTimeout(450);
  assert(await p.evaluate(() => { const x = window.CT.Repo.products()[0]; return !x.compatibility.models.includes('sharan') && x.model === ''; }), 'deleted model is removed from webshop products');
  await p.evaluate(() => window.CT.Content.update((d) => { d.models = window.CT.Content.P.models; }));
  // Duplicate keurmerk names are refused instead of silently dropped
  await nav(p, '/admin/beveiliging');
  await p.click('[data-m-add]'); await p.fill('[data-m-rows] .row-edit:last-child [data-m="name"]', 'SCM');
  await submit(p, '[data-sec]');
  assert((await p.evaluate(() => [...document.querySelectorAll('.toast')].map((t) => t.textContent).join(' '))).includes('dezelfde naam'), 'duplicate keurmerk name gives a message');
  await p.click('[data-m-rows] .row-edit:last-child [data-row-del]'); await submit(p, '[data-sec]');
  // An SEO setting saved under an old address can be cleared
  await p.evaluate(() => window.CT.Content.update((d) => { d.seo = { ...(d.seo || {}), pages: { ...((d.seo || {}).pages || {}), '/mogelijkheden': { title: 'Oude titel', description: '', noindex: false } } }; }));
  await nav(p, '/admin/seo?q=/producten');
  await p.click('[data-seo-edit="/producten"]'); await p.waitForSelector('[data-seo-clear]');
  await p.click('[data-seo-clear]'); await p.waitForTimeout(400);
  assert(await p.evaluate(() => !window.CT.Content.seo().pages['/producten'] && !(window.CT.Content.working().seo.pages || {})['/mogelijkheden']), 'SEO setting under an old address is cleared');
  // A rejected upload does not report success
  await nav(p, '/admin/storingen/nieuw');
  await p.setInputFiles('[data-photos="photos"] [data-ph-add]', { name: 'x.gif', mimeType: 'image/gif', buffer: Buffer.from('GIF89a') });
  await p.waitForTimeout(300);
  const tt = await p.evaluate(() => [...document.querySelectorAll('.toast')].map((t) => t.textContent).join(' '));
  assert(tt.includes('JPG') && !tt.includes('Foto toegevoegd'), 'rejected photo: only the error message');
  await nav(p, '/admin');

  // ================= Password change =================
  await nav(p, '/admin/account');
  assert((await p.textContent('.admin-content')).includes('Het nieuwe wachtwoord geldt in deze browser direct; op andere apparaten pas nadat u de website opnieuw hebt gepubliceerd en geüpload.'), 'account screen explains when the password applies');
  const NEW = `Test-${Math.random().toString(36).slice(2, 10)}-wachtwoord`;
  const tryPw = async (cur, next, again) => { await p.fill('[name="current"]', cur); await p.fill('[name="next"]', next); await p.fill('[name="again"]', again); await p.click('[data-account] [type=submit]'); await p.waitForTimeout(1500); };
  await tryPw(PASS, 'kort', 'kort');
  assert((await p.textContent('[data-err="next"]')).includes('minimaal 10'), 'new password: at least 10 characters');
  await tryPw(PASS, PASS, PASS);
  assert((await p.textContent('[data-err="next"]')).includes('anders'), 'new password must differ');
  await tryPw(PASS, NEW, `${NEW}x`);
  assert((await p.textContent('[data-err="again"]')).includes('niet gelijk'), 'new passwords must match');
  await tryPw('verkeerd-wachtwoord', NEW, NEW);
  assert((await p.textContent('[data-err="current"]')).includes('klopt niet'), 'current password is checked');
  await tryPw(PASS, NEW, NEW);
  assert(await p.isVisible('.admin-nav') && (await p.evaluate(() => !!window.CT.Content.working().auth)), 'password changed; still logged in');
  const draftAuth = await p.evaluate(() => JSON.stringify(window.CT.Content.working().auth));
  assert(!draftAuth.includes(NEW) && /"hash":"[A-Za-z0-9+/=]{40,}"/.test(draftAuth), 'only a salted hash is stored');
  await p.click('[data-admin-logout]'); await p.waitForTimeout(300);
  await p.fill('#lg-u', ADMIN_USER); await p.fill('#lg-p', PASS); await p.click('[data-login] [type=submit]'); await p.waitForTimeout(1500);
  assert(!!(await p.$('#lg-u')), 'old password no longer works in this browser');
  await login(p, { password: NEW });
  assert(await p.isVisible('.admin-nav'), 'new password works');
  // A backup import and "Standaardinhoud herstellen" keep the new password
  await nav(p, '/admin/website');
  const [bk] = await Promise.all([p.waitForEvent('download'), p.click('[data-backup]')]);
  const bkPath = path.join(PUB, 'backup.json'); await bk.saveAs(bkPath);
  const bkData = JSON.parse(fs.readFileSync(bkPath, 'utf8'));
  assert(!bkData.content.auth, 'backup contains no login data');
  bkData.content.auth = { user: ADMIN_USER, salt: 'AAAAAAAAAAAAAAAAAAAAAA==', hash: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=', iter: 600000 };
  fs.writeFileSync(bkPath, JSON.stringify(bkData));
  await p.setInputFiles('[data-restore-file]', bkPath); await confirmOk(p);
  assert(await p.evaluate(() => JSON.stringify(window.CT.Content.working().auth)) === draftAuth, 'backup import does not replace the password');
  await p.click('[data-factory]'); await confirmOk(p);
  assert(await p.evaluate(() => JSON.stringify(window.CT.Content.working().auth)) === draftAuth, 'factory reset keeps the new password');
  // Put the earlier content back by importing the backup (without its auth)
  await p.setInputFiles('[data-restore-file]', bkPath); await confirmOk(p);

  // ================= Publish round trip =================
  await nav(p, '/admin/seo');
  await p.fill('[name="siteUrl"]', ORIGIN); await submit(p, '[data-seo]');
  await nav(p, '/admin/website');
  const [dl] = await Promise.all([p.waitForEvent('download'), p.click('[data-publish]')]);
  const zip = path.join(PUB, 'site.zip'); await dl.saveAs(zip);
  execSync(`unzip -q "${zip}" -d "${PUB}/x"`);
  fs.cpSync(path.join(PUB, 'x', 'cartronic-website'), SITE, { recursive: true });
  const outDir = path.join(PUB, 'x', 'cartronic-website');
  const redirects = fs.readFileSync(path.join(outDir, '_redirects'), 'utf8');
  assert(redirects.includes('/mogelijkheden/*    /producten/:splat    301') && redirects.includes('/projecten    /portfolio    301') && redirects.includes('/expertise    /diensten    301')
    && redirects.indexOf('301') < redirects.indexOf('/index.html'), '_redirects: permanent redirects before the page rule');
  const vercel = JSON.parse(fs.readFileSync(path.join(outDir, 'vercel.json'), 'utf8'));
  assert(vercel.redirects.some((r) => r.source === '/mogelijkheden/:path*' && r.destination === '/producten/:path*' && r.permanent), 'vercel.json: permanent redirects');
  const sm = fs.readFileSync(path.join(outDir, 'sitemap.xml'), 'utf8');
  assert(sm.includes(`${ORIGIN}/producten/`) && sm.includes(`${ORIGIN}/storingen/acc-of-lane-assist`) && sm.includes(`${ORIGIN}/beveiliging<`) && sm.includes(`${ORIGIN}/videos<`) && sm.includes(`${ORIGIN}/portfolio<`)
    && !/mogelijkheden|projecten|expertise|testcamera|\/admin/.test(sm), 'sitemap: only new addresses, no hidden storing, no admin');
  const robots = fs.readFileSync(path.join(outDir, 'robots.txt'), 'utf8');
  assert(robots.includes('Disallow: /admin') && !robots.includes('Disallow: /\n'), 'robots: indexing on, /admin excluded');
  const server = spawn('node', [path.join(__dirname, 'serve.cjs'), SITE, String(PORT)], { stdio: 'ignore' });
  await new Promise((r) => setTimeout(r, 500));
  try {
    const vis = await open({ width: 1280, height: 900 });
    await vis.page.goto(`${ORIGIN}/mogelijkheden?merk=audi`); await vis.page.waitForTimeout(500);
    assert(await vis.page.evaluate(() => location.pathname + location.search) === '/producten?merk=audi', 'published site: old address redirects (path mode)');
    await vis.page.goto(`${ORIGIN}/portfolio`); await vis.page.waitForTimeout(400);
    assert((await vis.page.textContent('#more-title')).includes('Nog meer werk.') && !!(await vis.page.$('.more-card--photo img')), 'published site: Meer van ons werk with photo');
    await vis.page.goto(`${ORIGIN}/beveiliging`); await vis.page.waitForTimeout(400);
    assert((await vis.page.textContent('#app')).includes('Aangepaste uitleg klasse 2.'), 'published site: Beveiliging content');
    assert(await vis.page.evaluate(() => document.querySelector('link[rel=canonical]').href) === `${ORIGIN}/beveiliging` && (await vis.page.getAttribute('meta[name=robots]', 'content')) === 'index, follow', 'published site: canonical and robots');
    await vis.page.goto(`${ORIGIN}/admin`); await vis.page.waitForTimeout(400);
    assert((await vis.page.getAttribute('meta[name=robots]', 'content')).startsWith('noindex'), '/admin is noindex');
    await vis.page.fill('#lg-u', ADMIN_USER); await vis.page.fill('#lg-p', PASS); await vis.page.click('[data-login] [type=submit]'); await vis.page.waitForTimeout(1500);
    assert(!!(await vis.page.$('#lg-u')), 'published site: the old password no longer works on another device');
    await vis.page.evaluate(() => localStorage.removeItem('ct.v1.loginGuard'));
    await login(vis.page, { password: NEW });
    assert(await vis.page.isVisible('.admin-nav'), 'published site: the new password works after publishing');
    await vis.browser.close();
  } finally { server.kill(); }
  await ed.browser.close();

  // ================= The password is in no file =================
  const files = [path.join(S, 'qa', 'build-r8.html'), URL_BASE.replace('file://', '')].concat(
    execSync(`find "${outDir}" "${path.join(S, 'src')}" "${path.join(S, 'qa')}" -maxdepth 1 -type f \\( -name '*.html' -o -name '*.js' -o -name '*.cjs' -o -name '*.txt' -o -name '*.json' -o -name '*.xml' -o -name '_redirects' -o -name '*.md' \\)`).toString().trim().split('\n'));
  const hits = uniqFiles(files).filter((f) => fs.existsSync(f) && fs.readFileSync(f, 'utf8').includes(PASS));
  assert(hits.length === 0, `password not in the build, published files, source or tests (${hits.join(', ') || 'none'})`);
  console.log(fails ? `\n${fails} FAILED` : '\nall passed');
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
function uniqFiles(a) { return Array.from(new Set(a.filter(Boolean))); }
